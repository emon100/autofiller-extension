import { h as hasValidConsent } from './chunks/index-D0pbUIir.js';

const sidePanelOpenTabs = /* @__PURE__ */ new Set();
const CONTEXT_MENU_IDS = {
  FILL_FORM: "autofiller-fill-form",
  OPEN_SIDEPANEL: "autofiller-open-sidepanel"
};
function createContextMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: CONTEXT_MENU_IDS.FILL_FORM,
      title: "AutoFill this form",
      contexts: ["page", "editable"]
    });
    chrome.contextMenus.create({
      id: CONTEXT_MENU_IDS.OPEN_SIDEPANEL,
      title: "Open OneFillr panel",
      contexts: ["page"]
    });
  });
}
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab?.id) return;
  switch (info.menuItemId) {
    case CONTEXT_MENU_IDS.FILL_FORM:
      try {
        await chrome.tabs.sendMessage(tab.id, { action: "fill" });
      } catch (error) {
        console.error("[AutoFiller] Failed to send fill command:", error);
        try {
          await chrome.scripting.executeScript({
            target: { tabId: tab.id },
            files: ["content.js"]
          });
          setTimeout(async () => {
            try {
              await chrome.tabs.sendMessage(tab.id, { action: "fill" });
            } catch (e) {
              console.error("[AutoFiller] Fill failed after injection:", e);
            }
          }, 500);
        } catch (injectError) {
          console.error("[AutoFiller] Failed to inject content script:", injectError);
        }
      }
      break;
    case CONTEXT_MENU_IDS.OPEN_SIDEPANEL:
      if (chrome.sidePanel?.open) {
        try {
          await chrome.sidePanel.open({ tabId: tab.id });
          sidePanelOpenTabs.add(tab.id);
        } catch (error) {
          console.error("[AutoFiller] Failed to open side panel:", error);
        }
      }
      break;
  }
});
chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id) return;
  try {
    if (chrome.sidePanel?.open) {
      await chrome.sidePanel.open({ tabId: tab.id });
      sidePanelOpenTabs.add(tab.id);
    }
  } catch (error) {
    console.error("Failed to open side panel:", error);
  }
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "openSidePanel") {
    const tabId = sender.tab?.id;
    if (!tabId) {
      sendResponse({ success: false, error: "No tab ID" });
      return true;
    }
    if (chrome.sidePanel?.open) {
      chrome.sidePanel.open({ tabId }).then(() => {
        sidePanelOpenTabs.add(tabId);
        sendResponse({ success: true });
      }).catch((err) => {
        console.error("Failed to open side panel:", err);
        sendResponse({ success: false, error: String(err) });
      });
    } else {
      sendResponse({ success: false, error: "Side panel API not available" });
    }
    return true;
  }
  if (message.action === "getSidePanelState") {
    const tabId = sender.tab?.id;
    sendResponse({ isOpen: tabId ? sidePanelOpenTabs.has(tabId) : false });
    return true;
  }
  if (message.action === "sidePanelOpened") {
    const tabId = sender.tab?.id;
    if (tabId) {
      sidePanelOpenTabs.add(tabId);
    }
    sendResponse({ success: true });
    return true;
  }
  if (message.action === "sidePanelClosed") {
    const tabId = sender.tab?.id;
    if (tabId) {
      sidePanelOpenTabs.delete(tabId);
    }
    sendResponse({ success: true });
    return true;
  }
  if (message.action === "closeSidePanel") {
    chrome.runtime.sendMessage({ action: "closeSidePanel" });
    sendResponse({ success: true });
    return true;
  }
  if (message.action === "fillCurrentTab" || message.action === "undoCurrentTab") {
    const targetAction = message.action === "fillCurrentTab" ? "fill" : "undo";
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      const tab = tabs[0];
      if (!tab?.id) {
        sendResponse({ success: false, error: "No active tab" });
        return;
      }
      try {
        const response = await chrome.tabs.sendMessage(tab.id, { action: targetAction });
        sendResponse(response);
      } catch (error) {
        sendResponse({ success: false, error: String(error) });
      }
    });
    return true;
  }
  return false;
});
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log("[AutoFiller] Extension installed");
  createContextMenus();
  if (chrome.sidePanel?.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false });
  }
  if (details.reason === "install") {
    try {
      setTimeout(async () => {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab?.id && chrome.sidePanel?.open) {
          await chrome.sidePanel.open({ tabId: tab.id });
          sidePanelOpenTabs.add(tab.id);
        }
      }, 500);
    } catch (error) {
      console.log("[AutoFiller] Could not open side panel for onboarding:", error);
    }
  }
  if (details.reason === "update") {
    const consentValid = await hasValidConsent();
    if (!consentValid) {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab?.id && chrome.sidePanel?.open) {
          await chrome.sidePanel.open({ tabId: tab.id });
          sidePanelOpenTabs.add(tab.id);
        }
      } catch (error) {
        console.log("[AutoFiller] Could not open side panel for consent:", error);
      }
    }
  }
});
chrome.runtime.onStartup.addListener(() => {
  createContextMenus();
});
//# sourceMappingURL=background.js.map
