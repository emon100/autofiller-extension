(function () {
  'use strict';

  const scriptRel = 'modulepreload';const assetsURL = function(dep) { return "/"+dep };const seen = {};const __vitePreload = function preload(baseModule, deps, importerUrl) {
    let promise = Promise.resolve();
    if (false && deps && deps.length > 0) {
      document.getElementsByTagName("link");
      const cspNonceMeta = document.querySelector(
        "meta[property=csp-nonce]"
      );
      const cspNonce = cspNonceMeta?.nonce || cspNonceMeta?.getAttribute("nonce");
      promise = Promise.allSettled(
        deps.map((dep) => {
          dep = assetsURL(dep);
          if (dep in seen) return;
          seen[dep] = true;
          const isCss = dep.endsWith(".css");
          const cssSelector = isCss ? '[rel="stylesheet"]' : "";
          if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
            return;
          }
          const link = document.createElement("link");
          link.rel = isCss ? "stylesheet" : scriptRel;
          if (!isCss) {
            link.as = "script";
          }
          link.crossOrigin = "";
          link.href = dep;
          if (cspNonce) {
            link.setAttribute("nonce", cspNonce);
          }
          document.head.appendChild(link);
          if (isCss) {
            return new Promise((res, rej) => {
              link.addEventListener("load", res);
              link.addEventListener(
                "error",
                () => rej(new Error(`Unable to preload CSS for ${dep}`))
              );
            });
          }
        })
      );
    }
    function handlePreloadError(err) {
      const e = new Event("vite:preloadError", {
        cancelable: true
      });
      e.payload = err;
      window.dispatchEvent(e);
      if (!e.defaultPrevented) {
        throw err;
      }
    }
    return promise.then((res) => {
      for (const item of res || []) {
        if (item.status !== "rejected") continue;
        handlePreloadError(item.reason);
      }
      return baseModule().catch(handlePreloadError);
    });
  };

  function createEmptyDebugInfo() {
    return {
      autofillEnabled: false,
      fieldsScanned: 0,
      fieldsParsed: [],
      plansCreated: 0,
      suggestionsCreated: 0,
      sensitiveFieldsFound: 0,
      fillResults: 0
    };
  }
  const DEBUG_KEY = "autofiller_debug_logs";
  const MAX_LOGS = 50;
  async function saveDebugLog(action, details) {
    if (typeof chrome === "undefined" || !chrome.storage?.local) {
      console.log(`[AutoFiller Debug] ${action}:`, details);
      return;
    }
    try {
      const result = await chrome.storage.local.get(DEBUG_KEY);
      const logs = result[DEBUG_KEY] || [];
      logs.unshift({
        timestamp: Date.now(),
        action,
        details
      });
      if (logs.length > MAX_LOGS) {
        logs.length = MAX_LOGS;
      }
      await chrome.storage.local.set({ [DEBUG_KEY]: logs });
    } catch (e) {
      console.error("[AutoFiller] Failed to save debug log:", e);
    }
  }
  const LOG_PREFIX = "[AutoFiller]";
  function logParseField(parseLog) {
    const { label, elementInfo, parsers, finalResult, totalTimeMs } = parseLog;
    console.group(`${LOG_PREFIX} Parsing field: "${label}"`);
    console.log("Element:", elementInfo);
    console.group("Parser results:");
    for (const parser of parsers) {
      if (parser.matched) {
        console.log(
          `✓ ${parser.parserName} (${parser.timeMs.toFixed(1)}ms):`,
          parser.candidates.map((c) => `${c.type}@${c.score.toFixed(2)} [${c.reasons.join(", ")}]`).join("; ")
        );
      } else {
        console.log(`✗ ${parser.parserName} (${parser.timeMs.toFixed(1)}ms): no match`);
      }
    }
    console.groupEnd();
    console.log(`Final: ${finalResult.type}@${finalResult.score.toFixed(2)} [${finalResult.reasons.join(", ")}] (${totalTimeMs.toFixed(1)}ms total)`);
    console.groupEnd();
  }
  function logScan(scanLog) {
    console.group(`${LOG_PREFIX} 📋 Scan Results (${scanLog.totalTimeMs.toFixed(1)}ms)`);
    console.log(`Total elements found: ${scanLog.totalElementsFound}`);
    console.log(`Visible: ${scanLog.visibleElements}, Disabled: ${scanLog.disabledElements}, Excluded types: ${scanLog.excludedTypes}`);
    console.log(`Radio groups: ${scanLog.radioGroupsProcessed}, Shadow DOMs: ${scanLog.shadowDomsScanned}`);
    console.group("Fields extracted:");
    for (const field of scanLog.fields) {
      console.log(`• "${field.label}" [${field.widgetKind}] (label via: ${field.labelSource})`);
      if (Object.keys(field.attributes).length > 0) {
        console.log(`  attrs: ${JSON.stringify(field.attributes)}`);
      }
    }
    console.groupEnd();
    console.groupEnd();
  }
  function logTransformAttempt(log) {
    const statusIcon = log.canTransform ? "✓" : "✗";
    console.group(`${LOG_PREFIX} 🔄 Transform: ${log.transformerName}`);
    console.log(`${statusIcon} ${log.sourceType} → ${log.targetType}`);
    console.log(`Input: "${log.sourceValue}"`);
    if (log.canTransform) {
      console.log(`Output: "${log.transformedValue}"`);
      if (log.detectedFormat) {
        console.log(`Format detected: ${log.detectedFormat}`);
      }
    } else {
      console.log("Cannot transform (no match)");
    }
    console.groupEnd();
  }
  function logExecutor(log) {
    const statusIcon = log.success ? "✅" : "❌";
    console.group(`${LOG_PREFIX} ${statusIcon} Execute: "${log.fieldLabel}"`);
    console.log(`Widget: ${log.widgetKind}, Strategy: ${log.strategy}`);
    console.log(`Target value: "${log.targetValue}"`);
    if (log.matchedOption) {
      console.log(`Matched option: "${log.matchedOption}"`);
    }
    if (log.error) {
      console.log(`Error: ${log.error}`);
    }
    console.log(`Time: ${log.timeMs.toFixed(1)}ms`);
    console.groupEnd();
  }

  var Taxonomy = /* @__PURE__ */ ((Taxonomy2) => {
    Taxonomy2["FULL_NAME"] = "FULL_NAME";
    Taxonomy2["FIRST_NAME"] = "FIRST_NAME";
    Taxonomy2["LAST_NAME"] = "LAST_NAME";
    Taxonomy2["EMAIL"] = "EMAIL";
    Taxonomy2["PHONE"] = "PHONE";
    Taxonomy2["COUNTRY_CODE"] = "COUNTRY_CODE";
    Taxonomy2["LOCATION"] = "LOCATION";
    Taxonomy2["CITY"] = "CITY";
    Taxonomy2["LINKEDIN"] = "LINKEDIN";
    Taxonomy2["GITHUB"] = "GITHUB";
    Taxonomy2["PORTFOLIO"] = "PORTFOLIO";
    Taxonomy2["SUMMARY"] = "SUMMARY";
    Taxonomy2["SCHOOL"] = "SCHOOL";
    Taxonomy2["DEGREE"] = "DEGREE";
    Taxonomy2["MAJOR"] = "MAJOR";
    Taxonomy2["GPA"] = "GPA";
    Taxonomy2["GRAD_DATE"] = "GRAD_DATE";
    Taxonomy2["GRAD_YEAR"] = "GRAD_YEAR";
    Taxonomy2["GRAD_MONTH"] = "GRAD_MONTH";
    Taxonomy2["COMPANY_NAME"] = "COMPANY_NAME";
    Taxonomy2["JOB_TITLE"] = "JOB_TITLE";
    Taxonomy2["JOB_DESCRIPTION"] = "JOB_DESCRIPTION";
    Taxonomy2["SKILLS"] = "SKILLS";
    Taxonomy2["START_DATE"] = "START_DATE";
    Taxonomy2["END_DATE"] = "END_DATE";
    Taxonomy2["WORK_AUTH"] = "WORK_AUTH";
    Taxonomy2["NEED_SPONSORSHIP"] = "NEED_SPONSORSHIP";
    Taxonomy2["RESUME_TEXT"] = "RESUME_TEXT";
    Taxonomy2["SALARY"] = "SALARY";
    Taxonomy2["EEO_GENDER"] = "EEO_GENDER";
    Taxonomy2["EEO_ETHNICITY"] = "EEO_ETHNICITY";
    Taxonomy2["EEO_VETERAN"] = "EEO_VETERAN";
    Taxonomy2["EEO_DISABILITY"] = "EEO_DISABILITY";
    Taxonomy2["GOV_ID"] = "GOV_ID";
    Taxonomy2["UNKNOWN"] = "UNKNOWN";
    return Taxonomy2;
  })(Taxonomy || {});
  const SENSITIVE_TYPES = /* @__PURE__ */ new Set([
    "EEO_GENDER" /* EEO_GENDER */,
    "EEO_ETHNICITY" /* EEO_ETHNICITY */,
    "EEO_VETERAN" /* EEO_VETERAN */,
    "EEO_DISABILITY" /* EEO_DISABILITY */,
    "GOV_ID" /* GOV_ID */,
    "SALARY" /* SALARY */,
    "RESUME_TEXT" /* RESUME_TEXT */
  ]);
  const DEFAULT_FILL_ANIMATION_CONFIG = {
    enabled: true,
    maxDuration: 10,
    minCharDelay: 15,
    maxCharDelay: 60,
    stageDelays: {
      scanning: 800,
      thinking: 1200
    },
    fieldDelay: 100
  };

  const WORK_SECTION_KEYWORDS = [
    "work experience",
    "employment",
    "professional experience",
    "work history",
    "工作经历",
    "工作经验",
    "职业经历",
    "experience",
    "position",
    "职位"
  ];
  const EDUCATION_SECTION_KEYWORDS = [
    "education",
    "academic",
    "school",
    "university",
    "degree",
    "教育经历",
    "教育背景",
    "学历",
    "学校"
  ];
  const WORK_FIELD_TYPES = /* @__PURE__ */ new Set([
    Taxonomy.COMPANY_NAME,
    Taxonomy.JOB_TITLE,
    Taxonomy.JOB_DESCRIPTION
  ]);
  const EDUCATION_FIELD_TYPES = /* @__PURE__ */ new Set([
    Taxonomy.SCHOOL,
    Taxonomy.DEGREE,
    Taxonomy.MAJOR,
    Taxonomy.GPA,
    Taxonomy.GRAD_DATE,
    Taxonomy.GRAD_YEAR,
    Taxonomy.GRAD_MONTH
  ]);
  const SHARED_FIELD_TYPES = /* @__PURE__ */ new Set([
    Taxonomy.START_DATE,
    Taxonomy.END_DATE,
    Taxonomy.LOCATION,
    Taxonomy.CITY
  ]);
  function groupFieldsBySection(fields) {
    const groups = /* @__PURE__ */ new Map();
    for (const field of fields) {
      const sectionKey = field.sectionTitle || "_default";
      const existing = groups.get(sectionKey) || [];
      existing.push(field);
      groups.set(sectionKey, existing);
    }
    return groups;
  }
  function detectFormSections(fields, fieldTypes) {
    const sections = [];
    const groups = groupFieldsBySection(fields);
    for (const [title, groupFields] of groups) {
      const groupType = detectGroupType(title, groupFields, fieldTypes, fields);
      const blockInfo = detectRepeatingBlocks(title, groups);
      sections.push({
        id: `section-${sections.length}`,
        title,
        fields: groupFields,
        isRepeatingBlock: blockInfo.isRepeating,
        blockIndex: blockInfo.blockIndex,
        groupType
      });
    }
    sections.sort((a, b) => {
      if (a.isRepeatingBlock !== b.isRepeatingBlock) {
        return a.isRepeatingBlock ? 1 : -1;
      }
      if (a.groupType !== b.groupType) {
        if (!a.groupType) return 1;
        if (!b.groupType) return -1;
        const order = { WORK: 0, EDUCATION: 1, PROJECT: 2 };
        return order[a.groupType] - order[b.groupType];
      }
      return a.blockIndex - b.blockIndex;
    });
    return sections;
  }
  function detectGroupType(title, groupFields, fieldTypes, allFields) {
    const lowerTitle = title.toLowerCase();
    for (const keyword of WORK_SECTION_KEYWORDS) {
      if (lowerTitle.includes(keyword.toLowerCase())) {
        return "WORK";
      }
    }
    for (const keyword of EDUCATION_SECTION_KEYWORDS) {
      if (lowerTitle.includes(keyword.toLowerCase())) {
        return "EDUCATION";
      }
    }
    let workScore = 0;
    let educationScore = 0;
    for (const field of groupFields) {
      const fieldIndex = allFields.indexOf(field);
      const type = fieldTypes.get(fieldIndex);
      if (type && WORK_FIELD_TYPES.has(type)) {
        workScore += 2;
      }
      if (type && EDUCATION_FIELD_TYPES.has(type)) {
        educationScore += 2;
      }
      if (type && SHARED_FIELD_TYPES.has(type)) {
        workScore += 0.5;
        educationScore += 0.5;
      }
    }
    if (workScore > educationScore && workScore >= 2) {
      return "WORK";
    }
    if (educationScore > workScore && educationScore >= 2) {
      return "EDUCATION";
    }
    return void 0;
  }
  function detectRepeatingBlocks(title, allGroups) {
    const numberedMatch = title.match(/(.+?)\s*(\d+)\s*$/);
    if (numberedMatch) {
      const baseTitle = numberedMatch[1].trim();
      const index = parseInt(numberedMatch[2], 10) - 1;
      let hasMultiple = false;
      for (const otherTitle of allGroups.keys()) {
        if (otherTitle !== title && otherTitle.startsWith(baseTitle)) {
          hasMultiple = true;
          break;
        }
      }
      if (hasMultiple) {
        return { isRepeating: true, blockIndex: index };
      }
    }
    return { isRepeating: false, blockIndex: 0 };
  }

  const ADD_BUTTON_PATTERNS = {
    // English patterns
    text: [
      /^add\s*(another|more|new)?\s*(entry|experience|education|work|position|job|school)?$/i,
      /^\+\s*(add|new)?/i,
      /^add$/i,
      /^new\s*(entry|experience|education|work)?$/i
    ],
    // Chinese patterns
    textCN: [
      /^添加/,
      /^新增/,
      /^\+\s*添加/,
      /^增加/
    ],
    // Aria labels
    ariaLabel: [
      /add.*(another|more|entry|experience|education|work|position)/i,
      /添加/,
      /新增/
    ]
  };
  const SECTION_KEYWORDS = {
    WORK: [
      /work|experience|employment|job|position|职位|工作|经历/i
    ],
    EDUCATION: [
      /education|school|university|degree|学历|教育|学校/i
    ],
    PROJECT: [
      /project|项目/i
    ]
  };
  function findAddButtons(root = document) {
    const buttons = [];
    const selectors = [
      "button",
      'a[role="button"]',
      '[role="button"]',
      'input[type="button"]',
      ".btn",
      '[class*="add-"]',
      '[class*="Add"]'
    ].join(", ");
    const candidates = root.querySelectorAll(selectors);
    for (const element of candidates) {
      const htmlElement = element;
      if (!isClickable(htmlElement)) continue;
      const result = matchAddButton(htmlElement);
      if (result) {
        buttons.push(result);
      }
    }
    buttons.sort((a, b) => b.confidence - a.confidence);
    return buttons;
  }
  function matchAddButton(element) {
    const buttonText = getButtonText(element).trim();
    const ariaLabel = element.getAttribute("aria-label") || "";
    const title = element.getAttribute("title") || "";
    let confidence = 0;
    let context = "";
    let sectionType;
    for (const pattern of ADD_BUTTON_PATTERNS.text) {
      if (pattern.test(buttonText)) {
        confidence += 0.4;
        context = buttonText;
        break;
      }
    }
    for (const pattern of ADD_BUTTON_PATTERNS.textCN) {
      if (pattern.test(buttonText)) {
        confidence += 0.4;
        context = buttonText;
        break;
      }
    }
    for (const pattern of ADD_BUTTON_PATTERNS.ariaLabel) {
      if (pattern.test(ariaLabel) || pattern.test(title)) {
        confidence += 0.3;
        context = ariaLabel || title;
        break;
      }
    }
    if (element.querySelector('svg[class*="plus"], [class*="plus"], [class*="add"]')) {
      confidence += 0.2;
    }
    if (buttonText === "+" || buttonText === "＋") {
      confidence += 0.3;
      context = "+";
    }
    if (confidence === 0) return null;
    sectionType = detectSectionType(element, buttonText + " " + ariaLabel);
    if (sectionType) {
      confidence += 0.2;
    }
    return {
      element,
      sectionType,
      confidence: Math.min(confidence, 1),
      context
    };
  }
  function getButtonText(element) {
    const innerText = element.innerText?.trim();
    if (innerText) return innerText;
    return element.textContent?.trim() || "";
  }
  function detectSectionType(element, buttonContext) {
    for (const [type, patterns] of Object.entries(SECTION_KEYWORDS)) {
      for (const pattern of patterns) {
        if (pattern.test(buttonContext)) {
          return type;
        }
      }
    }
    let current = element.parentElement;
    let depth = 0;
    const maxDepth = 5;
    while (current && depth < maxDepth) {
      const heading = current.querySelector('h1, h2, h3, h4, h5, h6, legend, [class*="title"], [class*="header"]');
      if (heading) {
        const headingText = heading.textContent?.toLowerCase() || "";
        for (const [type, patterns] of Object.entries(SECTION_KEYWORDS)) {
          for (const pattern of patterns) {
            if (pattern.test(headingText)) {
              return type;
            }
          }
        }
      }
      const classAndId = (current.className + " " + current.id).toLowerCase();
      for (const [type, patterns] of Object.entries(SECTION_KEYWORDS)) {
        for (const pattern of patterns) {
          if (pattern.test(classAndId)) {
            return type;
          }
        }
      }
      current = current.parentElement;
      depth++;
    }
    return void 0;
  }
  function isClickable(element) {
    const style = getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden") {
      return false;
    }
    if (element.hasAttribute("disabled")) {
      return false;
    }
    const rect = element.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) {
      return false;
    }
    return true;
  }
  function findAddButtonForSection(sectionType, root = document) {
    const buttons = findAddButtons(root);
    const exactMatch = buttons.find((b) => b.sectionType === sectionType);
    if (exactMatch) return exactMatch;
    const sections = root.querySelectorAll('[class*="section"], [class*="block"], fieldset, [role="group"]');
    for (const section of sections) {
      const sectionText = (section.textContent || "").toLowerCase();
      let isMatchingSection = false;
      for (const pattern of SECTION_KEYWORDS[sectionType]) {
        if (pattern.test(sectionText)) {
          isMatchingSection = true;
          break;
        }
      }
      if (isMatchingSection) {
        const sectionButtons = findAddButtons(section);
        if (sectionButtons.length > 0) {
          return { ...sectionButtons[0], sectionType };
        }
      }
    }
    const genericButton = buttons.find((b) => !b.sectionType);
    return genericButton || null;
  }
  async function clickAddButtonAndWait(button, timeout = 3e3) {
    return new Promise((resolve) => {
      const startFieldCount = document.querySelectorAll("input, select, textarea").length;
      const observer = new MutationObserver(() => {
        const newFieldCount = document.querySelectorAll("input, select, textarea").length;
        if (newFieldCount > startFieldCount) {
          observer.disconnect();
          setTimeout(() => resolve(true), 100);
        }
      });
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
      button.element.click();
      setTimeout(() => {
        observer.disconnect();
        const newFieldCount = document.querySelectorAll("input, select, textarea").length;
        resolve(newFieldCount > startFieldCount);
      }, timeout);
    });
  }

  const INPUT_SELECTORS = [
    'input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="reset"]):not([type="image"])',
    "select",
    "textarea",
    '[role="combobox"] input',
    '[role="listbox"]',
    '[contenteditable="true"]'
  ].join(", ");
  const MIN_LABEL_LENGTH = 5;
  const MAX_LABEL_LENGTH = 200;
  const IDEAL_LABEL_LENGTH = 50;
  function extractLabelTextWithSource(element) {
    const id = element.getAttribute("id");
    if (id) {
      const label = document.querySelector(`label[for="${id}"]`);
      if (label) return { text: normalizeText(label.textContent), source: "label-for" };
    }
    const name = element.getAttribute("name");
    if (name) {
      const labelByName = document.querySelector(`label[for="${name}"]`);
      if (labelByName) return { text: normalizeText(labelByName.textContent), source: "label-for" };
    }
    const ariaLabel = element.getAttribute("aria-label");
    if (ariaLabel) return { text: normalizeText(ariaLabel), source: "aria-label" };
    const ariaLabelledBy = element.getAttribute("aria-labelledby");
    if (ariaLabelledBy) {
      const labelElement = document.getElementById(ariaLabelledBy);
      if (labelElement) return { text: normalizeText(labelElement.textContent), source: "aria-labelledby" };
    }
    const parentLabel = element.closest("label");
    if (parentLabel) {
      const clone = parentLabel.cloneNode(true);
      clone.querySelectorAll("input, select, textarea").forEach((el) => el.remove());
      return { text: normalizeText(clone.textContent), source: "parent-label" };
    }
    const siblingLabel = findSiblingLabel(element);
    if (siblingLabel) return { text: siblingLabel, source: "sibling-label" };
    const placeholder = element.getAttribute("placeholder");
    const placeholderLength = placeholder ? normalizeText(placeholder).length : 0;
    const ancestorText = findBestAncestorText(element, placeholderLength);
    if (ancestorText) return { text: ancestorText, source: "ancestor-heuristic" };
    if (placeholder) return { text: normalizeText(placeholder), source: "placeholder" };
    const nearbyText = findNearbyText(element);
    if (nearbyText) return { text: nearbyText, source: "nearby-text" };
    if (name) return { text: formatName(name), source: "name-attr" };
    return { text: "", source: "none" };
  }
  function extractLabelText(element) {
    return extractLabelTextWithSource(element).text;
  }
  function findSiblingLabel(element) {
    const parent = element.parentElement;
    if (!parent) return "";
    let sibling = element.previousElementSibling;
    while (sibling) {
      if (sibling.tagName.toLowerCase() === "label") {
        return normalizeText(sibling.textContent);
      }
      sibling = sibling.previousElementSibling;
    }
    const labels = parent.querySelectorAll("label");
    for (const label of labels) {
      if (label.querySelector("input, select, textarea")) continue;
      const labelRect = label.getBoundingClientRect();
      const elementRect = element.getBoundingClientRect();
      if (labelRect.bottom <= elementRect.top + 50) {
        return normalizeText(label.textContent);
      }
    }
    return "";
  }
  function collectAncestorContext(element, maxDepth = 6) {
    const candidates = [];
    const seenTexts = /* @__PURE__ */ new Set();
    let current = element.parentElement;
    let depth = 0;
    function addCandidate(text, el, type) {
      if (!text || seenTexts.has(text)) return;
      seenTexts.add(text);
      candidates.push({ text, depth, element: el, type });
    }
    while (current && depth < maxDepth) {
      const tag = current.tagName.toLowerCase();
      if (tag === "form" || tag === "body" || tag === "html") break;
      collectLabelsFromContainer(current, addCandidate);
      collectLegendFromFieldset(current, tag, addCandidate);
      collectHeadingsFromContainer(current, addCandidate);
      collectContainerText(current, addCandidate);
      current = current.parentElement;
      depth++;
    }
    return candidates;
  }
  function collectLabelsFromContainer(container, addCandidate) {
    const labels = container.querySelectorAll(":scope > label, :scope > div > label, :scope > span > label");
    for (const label of labels) {
      const labelEl = label;
      if (labelEl.querySelector("input, select, textarea")) continue;
      if (labelEl.classList.contains("error") || labelEl.id?.includes("-error")) continue;
      const text = normalizeText(labelEl.innerText);
      if (text.length >= MIN_LABEL_LENGTH) {
        addCandidate(text, labelEl, "label");
      }
    }
  }
  function collectLegendFromFieldset(container, tag, addCandidate) {
    if (tag !== "fieldset") return;
    const legend = container.querySelector(":scope > legend");
    if (legend) {
      addCandidate(normalizeText(legend.innerText), legend, "legend");
    }
  }
  function collectHeadingsFromContainer(container, addCandidate) {
    const headings = container.querySelectorAll(":scope > h1, :scope > h2, :scope > h3, :scope > h4, :scope > h5, :scope > h6");
    for (const heading of headings) {
      const headingEl = heading;
      const text = normalizeText(headingEl.innerText);
      if (text.length >= MIN_LABEL_LENGTH) {
        addCandidate(text, headingEl, "heading");
      }
    }
  }
  function collectContainerText(container, addCandidate) {
    const text = normalizeText(container.innerText);
    if (text.length >= MIN_LABEL_LENGTH && text.length <= MAX_LABEL_LENGTH) {
      addCandidate(text, container, "text-node");
    }
  }
  function findBestAncestorText(element, placeholderLength) {
    const candidates = collectAncestorContext(element);
    if (candidates.length === 0) return "";
    const scored = candidates.map((c) => ({
      ...c,
      score: scoreCandidate(c, placeholderLength)
    }));
    scored.sort((a, b) => b.score - a.score);
    const best = scored[0];
    if (best && best.score > 0) {
      return best.text;
    }
    return "";
  }
  function scoreCandidate(candidate, placeholderLength) {
    const { text, depth, type } = candidate;
    const len = text.length;
    let score = 0;
    if (placeholderLength > 0 && len <= placeholderLength) {
      return -1;
    }
    if (len < MIN_LABEL_LENGTH) {
      return -1;
    } else if (len > MAX_LABEL_LENGTH) {
      score -= 50;
    } else {
      const distanceFromIdeal = Math.abs(len - IDEAL_LABEL_LENGTH);
      score += Math.max(0, 100 - distanceFromIdeal);
    }
    switch (type) {
      case "label":
        score += 50;
        break;
      case "legend":
        score += 40;
        break;
      case "heading":
        score += 30;
        break;
      case "text-node":
        score += 10;
        break;
    }
    score -= depth * 15;
    if (text.includes("?") || text.includes("*")) {
      score += 20;
    }
    const lowerText = text.toLowerCase();
    if (lowerText.includes("error") || lowerText.includes("invalid") || lowerText.includes("required field")) {
      score -= 30;
    }
    return score;
  }
  function formatName(name) {
    return name.replace(/([A-Z])/g, " $1").replace(/[_-]/g, " ").replace(/^\s+/, "").trim();
  }
  function findNearbyText(element) {
    const parent = element.parentElement;
    if (!parent) return "";
    const prevSibling = element.previousElementSibling;
    if (prevSibling && isTextElement(prevSibling)) {
      return normalizeText(prevSibling.textContent);
    }
    for (const child of parent.children) {
      if (child === element) continue;
      if (isTextElement(child) && child.compareDocumentPosition(element) & Node.DOCUMENT_POSITION_FOLLOWING) {
        return normalizeText(child.textContent);
      }
    }
    return "";
  }
  function isTextElement(el) {
    const tag = el.tagName.toLowerCase();
    return ["span", "label", "p", "div", "strong", "b", "em", "i"].includes(tag) && el.children.length === 0;
  }
  function normalizeText(text) {
    if (!text) return "";
    return text.replace(/\s+/g, " ").trim();
  }
  function extractFieldContext(element) {
    const widgetSignature = detectWidgetSignature(element);
    const attributes = extractAttributes(element);
    const labelText = extractLabelText(element);
    const sectionTitle = extractSectionTitle(element);
    const optionsText = extractOptions(element, widgetSignature.kind);
    const { framePath, shadowPath } = extractPaths(element);
    return {
      element,
      labelText,
      sectionTitle,
      attributes,
      optionsText,
      framePath,
      shadowPath,
      widgetSignature
    };
  }
  function detectWidgetSignature(element) {
    const tagName = element.tagName.toLowerCase();
    const type = element.getAttribute("type")?.toLowerCase() || "";
    const role = element.getAttribute("role")?.toLowerCase() || "";
    let kind = "text";
    let interactionPlan = "nativeSetterWithEvents";
    if (tagName === "select") {
      kind = "select";
      interactionPlan = "directSet";
    } else if (tagName === "textarea") {
      kind = "textarea";
    } else if (tagName === "input") {
      switch (type) {
        case "checkbox":
          kind = "checkbox";
          interactionPlan = "directSet";
          break;
        case "radio":
          kind = "radio";
          interactionPlan = "directSet";
          break;
        case "date":
        case "datetime-local":
        case "month":
        case "week":
        case "time":
          kind = "date";
          break;
        default:
          kind = "text";
      }
    }
    const comboboxParent = element.closest('[role="combobox"]');
    if (comboboxParent || role === "combobox") {
      kind = "combobox";
      interactionPlan = "openDropdownClickOption";
    }
    const attributes = {};
    if (role) attributes["role"] = role;
    return {
      kind,
      role: role || void 0,
      attributes,
      interactionPlan,
      optionLocator: kind === "combobox" ? '[role="option"]' : void 0
    };
  }
  function extractAttributes(element) {
    const attrs = {};
    const relevantAttrs = ["id", "name", "type", "autocomplete", "role", "placeholder", "required", "pattern"];
    for (const attr of relevantAttrs) {
      const value = element.getAttribute(attr);
      if (value !== null) {
        attrs[attr] = value;
      }
    }
    return attrs;
  }
  function extractSectionTitle(element) {
    const fieldset = element.closest("fieldset");
    if (fieldset) {
      const legend = fieldset.querySelector("legend");
      if (legend) return normalizeText(legend.textContent);
    }
    let current = element;
    while (current) {
      const heading = findPreviousHeading(current);
      if (heading) return normalizeText(heading.textContent);
      current = current.parentElement;
    }
    return "";
  }
  function findPreviousHeading(element) {
    const headings = ["h1", "h2", "h3", "h4", "h5", "h6"];
    let sibling = element.previousElementSibling;
    while (sibling) {
      if (headings.includes(sibling.tagName.toLowerCase())) {
        return sibling;
      }
      const nestedHeading = sibling.querySelector(headings.join(", "));
      if (nestedHeading) return nestedHeading;
      sibling = sibling.previousElementSibling;
    }
    const parent = element.parentElement;
    if (parent && parent !== document.body) {
      return findPreviousHeading(parent);
    }
    return null;
  }
  function extractOptions(element, kind) {
    const options = [];
    if (kind === "select" && element instanceof HTMLSelectElement) {
      for (const option of element.options) {
        if (option.value) {
          options.push(normalizeText(option.textContent));
        }
      }
    }
    if (kind === "combobox") {
      const combobox = element.closest('[role="combobox"]') || element;
      const listbox = combobox.querySelector('[role="listbox"]') || document.getElementById(element.getAttribute("aria-controls") || "");
      if (listbox) {
        listbox.querySelectorAll('[role="option"]').forEach((opt) => {
          options.push(normalizeText(opt.textContent));
        });
      }
    }
    return options;
  }
  function extractPaths(element) {
    const framePath = [];
    const shadowPath = [];
    let root = element.getRootNode();
    while (root instanceof ShadowRoot) {
      const host = root.host;
      shadowPath.unshift(getElementSelector(host));
      root = host.getRootNode();
    }
    return { framePath, shadowPath };
  }
  function getElementSelector(element) {
    if (element.id) return `#${element.id}`;
    const tag = element.tagName.toLowerCase();
    const classes = Array.from(element.classList).slice(0, 2).join(".");
    if (classes) return `${tag}.${classes}`;
    return tag;
  }
  function scanFields(root, enableLogging = false) {
    const result = scanFieldsWithLog(root);
    if (enableLogging) {
      logScan(result.scanLog);
    }
    return result.fields;
  }
  function scanFieldsWithLog(root) {
    const startTime = performance.now();
    const fields = [];
    const processedRadioGroups = /* @__PURE__ */ new Set();
    const excludedTypes = /* @__PURE__ */ new Set(["hidden", "submit", "button", "reset", "image"]);
    let totalElementsFound = 0;
    let visibleElements = 0;
    let disabledCount = 0;
    let excludedCount = 0;
    let shadowDomsScanned = 0;
    const fieldLogs = [];
    function scan(node) {
      const elements = node.querySelectorAll ? node.querySelectorAll(INPUT_SELECTORS) : [];
      totalElementsFound += elements.length;
      for (const element of elements) {
        const htmlElement = element;
        if (htmlElement.closest("[data-autofiller-widget]")) continue;
        if (!isVisible(htmlElement)) {
          continue;
        }
        visibleElements++;
        if (htmlElement.hasAttribute("disabled")) {
          disabledCount++;
          continue;
        }
        const type = htmlElement.getAttribute("type")?.toLowerCase();
        if (type && excludedTypes.has(type)) {
          excludedCount++;
          continue;
        }
        if (type === "radio") {
          const name = htmlElement.getAttribute("name");
          if (name && processedRadioGroups.has(name)) continue;
          if (name) processedRadioGroups.add(name);
        }
        const labelResult = extractLabelTextWithSource(htmlElement);
        const context = extractFieldContextInternal(htmlElement, labelResult.text);
        fields.push(context);
        fieldLogs.push({
          label: labelResult.text || "(empty)",
          widgetKind: context.widgetSignature.kind,
          labelSource: labelResult.source,
          attributes: context.attributes
        });
      }
      if (node instanceof Element) {
        const shadowRoot = node.shadowRoot;
        if (shadowRoot) {
          shadowDomsScanned++;
          scan(shadowRoot);
        }
      }
      const allElements = node instanceof Document || node instanceof ShadowRoot ? node.querySelectorAll("*") : node.querySelectorAll("*");
      for (const el of allElements) {
        const shadowRoot = el.shadowRoot;
        if (shadowRoot) {
          shadowDomsScanned++;
          scan(shadowRoot);
        }
      }
    }
    scan(root);
    const scanLog = {
      totalElementsFound,
      visibleElements,
      disabledElements: disabledCount,
      excludedTypes: excludedCount,
      radioGroupsProcessed: processedRadioGroups.size,
      shadowDomsScanned,
      fields: fieldLogs,
      totalTimeMs: performance.now() - startTime
    };
    return { fields, scanLog };
  }
  function extractFieldContextInternal(element, labelText) {
    const widgetSignature = detectWidgetSignature(element);
    const attributes = extractAttributes(element);
    const sectionTitle = extractSectionTitle(element);
    const optionsText = extractOptions(element, widgetSignature.kind);
    const { framePath, shadowPath } = extractPaths(element);
    return {
      element,
      labelText,
      sectionTitle,
      attributes,
      optionsText,
      framePath,
      shadowPath,
      widgetSignature
    };
  }
  function isVisible(element) {
    const style = getComputedStyle(element);
    if (style.display === "none" || style.visibility === "hidden") {
      return false;
    }
    if (element.hasAttribute("hidden")) {
      return false;
    }
    return true;
  }

  function getAugmentedNamespace(n) {
    if (n.__esModule) return n;
    var f = n.default;
  	if (typeof f == "function") {
  		var a = function a () {
  			if (this instanceof a) {
          return Reflect.construct(f, arguments, this.constructor);
  			}
  			return f.apply(this, arguments);
  		};
  		a.prototype = f.prototype;
    } else a = {};
    Object.defineProperty(a, '__esModule', {value: true});
  	Object.keys(n).forEach(function (k) {
  		var d = Object.getOwnPropertyDescriptor(n, k);
  		Object.defineProperty(a, k, d.get ? d : {
  			enumerable: true,
  			get: function () {
  				return n[k];
  			}
  		});
  	});
  	return a;
  }

  let JsonContext$1 = class JsonContext {
      constructor() {
          this.contextStack = [];
      }

      get current() {
          return this.contextStack[this.contextStack.length - 1];
      }

      get context() {
          return [...this.contextStack];
      }

      get empty() {
          return this.contextStack.length === 0;
      }

      set(value) {
          this.contextStack.push(value);
      }

      reset() {
          this.contextStack = [];
      }

      remove(value) {
          const index = this.contextStack.lastIndexOf(value);
          if (index !== -1) {
              this.contextStack.splice(index, 1);
          }
      }
  };

  // Context değerleri için enum benzeri sabitler
  const ContextValues$1 = {
      OBJECT_KEY: 'OBJECT_KEY',
      OBJECT_VALUE: 'OBJECT_VALUE',
      ARRAY: 'ARRAY'
  };

  var JsonContext_1 = { JsonContext: JsonContext$1, ContextValues: ContextValues$1 };

  const { JsonContext, ContextValues } = JsonContext_1;

  const STRING_DELIMITERS = ['"', "'"];
  const WHITESPACE = new Set([0x20, 0x09, 0x0A, 0x0D]); // space, tab, newline, return

  let JsonParser$1 = class JsonParser {
      constructor(jsonStr = "", logging = false) {
          this.jsonStr = jsonStr;
          this.index = 0;
          this.context = new JsonContext();
          this.logging = logging;
          this.logger = [];
      }

      log(text) {
          if (!this.logging) return;
          const window = 10;
          const start = Math.max(this.index - window, 0);
          const end = Math.min(this.index + window, this.jsonStr.length);
          const context = this.jsonStr.slice(start, end);
          this.logger.push({ text, context });
      }

      parse() {
          let foundJson = false;

          while (this.index < this.jsonStr.length) {
              const char = this.peek();
              
              // Handle code blocks in markdown/text
              if (char === '`') {
                  if (this.jsonStr.slice(this.index, this.index + 3) === '```') {
                      this.index += 3;
                      continue;
                  }
              }

              // Look for JSON start
              if (char === '{' || char === '[') {
                  foundJson = true;
                  break;
              }

              this.index++;
          }

          if (!foundJson) {
              return "";
          }

          const result = this.parseValue();
          return this.logging ? [result, this.logger] : result;
      }

      parseValue() {
          this.skipWhitespace();
          const char = this.peek();

          if (!char) return "";
          
          if (char === "{") return this.parseObject();
          if (char === "[") return this.parseArray();
          if (STRING_DELIMITERS.includes(char)) return this.parseString();
          if (/[-0-9]/.test(char)) return this.parseNumber();
          if (/[a-zA-Z]/.test(char)) return this.parseUnquotedString();

          this.index++;
          return "";
      }

      parseObject() {
          const obj = {};
          this.index++; // skip {

          while (this.index < this.jsonStr.length) {
              this.skipWhitespace();
              
              if (this.peek() === "}") {
                  this.index++;
                  break;
              }

              // Parse key
              this.context.set(ContextValues.OBJECT_KEY);
              const key = this.parseString() || this.parseUnquotedString();
              if (!key) break;

              this.skipWhitespace();

              // Handle missing colon
              if (this.peek() !== ":") {
                  this.log("Missing colon after key, adding it");
              } else {
                  this.index++; // skip :
              }

              this.skipWhitespace();
              
              // Parse value
              this.context.reset();
              this.context.set(ContextValues.OBJECT_VALUE);
              const value = this.parseValue();
              this.context.reset();

              if (key) {
                  obj[key] = value;
              }

              this.skipWhitespace();

              // Handle comma
              if (this.peek() === ",") {
                  this.index++;
              }
          }

          return obj;
      }

      parseArray() {
          const arr = [];
          this.index++; // skip [
          this.context.set(ContextValues.ARRAY);

          while (this.index < this.jsonStr.length) {
              this.skipWhitespace();
              
              if (this.peek() === "]") {
                  this.index++;
                  break;
              }

              const value = this.parseValue();
              if (value !== undefined) {
                  arr.push(value);
              }

              this.skipWhitespace();

              // Handle comma
              if (this.peek() === ",") {
                  this.index++;
              }
          }

          this.context.reset();
          return arr;
      }

      parseString() {
          let char = this.peek();
          let isQuoted = STRING_DELIMITERS.includes(char);
          let stringAcc = "";

          // Skip leading whitespace
          while (char && /\s/.test(char)) {
              this.index++;
              char = this.peek();
          }

          if (isQuoted) {
              const quote = char;
              this.index++; // skip opening quote

              while (this.index < this.jsonStr.length) {
                  char = this.peek();
                  
                  if (char === quote && this.jsonStr[this.index - 1] !== "\\") {
                      this.index++; // skip closing quote
                      break;
                  }

                  stringAcc += char;
                  this.index++;
              }
          } else {
              // For unquoted strings, collect until delimiter
              while (this.index < this.jsonStr.length) {
                  char = this.peek();

                  if ([",", "}", "]", ":"].includes(char)) {
                      break;
                  } else if (/\s/.test(char)) {
                      // Skip whitespace between words
                      if (stringAcc && this.index < this.jsonStr.length - 1) {
                          const nextChar = this.jsonStr[this.index + 1];
                          if (!/[,}\]:]/.test(nextChar)) {
                              stringAcc += " ";
                          }
                      }
                  } else {
                      stringAcc += char;
                  }

                  this.index++;
              }
          }

          // Convert value types for object values
          if (!isQuoted && this.context.current === ContextValues.OBJECT_VALUE) {
              const trimmed = stringAcc.trim();
              
              // Try number
              const num = Number(trimmed);
              if (!isNaN(num)) return num;
              
              // Try boolean/null
              if (trimmed.toLowerCase() === "true") return true;
              if (trimmed.toLowerCase() === "false") return false;
              if (trimmed.toLowerCase() === "null") return null;
          }

          return stringAcc.trim();
      }

      parseNumber() {
          let numStr = "";
          
          while (this.index < this.jsonStr.length) {
              const char = this.peek();
              if (!/[-0-9.eE]/.test(char)) break;
              numStr += char;
              this.index++;
          }

          const num = Number(numStr);
          return isNaN(num) ? numStr : num;
      }

      parseUnquotedString() {
          let str = "";
          
          while (this.index < this.jsonStr.length) {
              const char = this.peek();
              if ([",", "}", "]", ":"].includes(char) || /\s/.test(char)) break;
              str += char;
              this.index++;
          }

          return str;
      }

      skipWhitespace() {
          while (this.index < this.jsonStr.length) {
              const code = this.jsonStr.charCodeAt(this.index);
              if (!WHITESPACE.has(code)) break;
              this.index++;
          }
      }

      peek() {
          return this.jsonStr[this.index];
      }
  };

  var JsonParser_1 = JsonParser$1;

  const __viteBrowserExternal = {};

  const __viteBrowserExternal$1 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: __viteBrowserExternal
  }, Symbol.toStringTag, { value: 'Module' }));

  const require$$1 = /*@__PURE__*/getAugmentedNamespace(__viteBrowserExternal$1);

  const JsonParser = JsonParser_1;

  /**
   * Bozuk JSON string'ini onarır
   * @param {string} jsonStr - Onarılacak JSON string'i
   * @param {Object} options - Onarım seçenekleri
   * @param {boolean} options.returnObjects - true ise JavaScript objesi döner, false ise JSON string döner
   * @param {boolean} options.skipJsonParse - true ise JSON.parse kontrolünü atlar
   * @param {boolean} options.logging - true ise onarım loglarını da döner
   * @param {boolean} options.ensureAscii - false ise Unicode karakterleri korur
   * @returns {string|Object} Onarılmış JSON string'i veya objesi
   */
  function repairJson(jsonStr = "", options = {}) {
      const {
          returnObjects = false,
          skipJsonParse = false,
          logging = false,
          ensureAscii = true
      } = options;

      // Önce normal JSON.parse ile dene
      if (!skipJsonParse) {
          try {
              const parsed = JSON.parse(jsonStr);
              return returnObjects ? parsed : JSON.stringify(parsed, null, 2);
          } catch (e) {
              // JSON.parse başarısız olursa devam et
          }
      }

      // JSON.parse başarısız olduysa veya atlanması istendiyse, onararak parse et
      const parser = new JsonParser(jsonStr, logging);
      const result = parser.parse();

      if (logging) {
          return result; // [parsedJson, logs] şeklinde döner
      }

      // String'e çevir veya obje olarak döndür
      if (returnObjects) {
          return result;
      }

      // JSON string'e çevir
      const indent = 2;
      const replacer = ensureAscii ? (key, value) => {
          if (typeof value === 'string') {
              return value.replace(/[^\x00-\x7F]/g, char => {
                  return '\\u' + ('0000' + char.charCodeAt(0).toString(16)).slice(-4);
              });
          }
          return value;
      } : null;

      return JSON.stringify(result, replacer, indent);
  }

  /**
   * JSON.parse benzeri fonksiyon, ancak bozuk JSON'ları da onarır
   * @param {string} jsonStr - Parse edilecek JSON string'i
   * @param {Object} options - Parse seçenekleri
   * @param {boolean} options.skipJsonParse - true ise JSON.parse kontrolünü atlar
   * @param {boolean} options.logging - true ise onarım loglarını da döner
   * @returns {Object} Parse edilmiş JavaScript objesi
   */
  function loads(jsonStr, options = {}) {
      return repairJson(jsonStr, { ...options, returnObjects: true });
  }

  /**
   * Dosyadan JSON okur ve onarır
   * @param {string} filename - JSON dosyasının yolu
   * @param {Object} options - Parse seçenekleri
   * @returns {Object} Parse edilmiş JavaScript objesi
   */
  function fromFile(filename, options = {}) {
      const fs = require$$1;
      const content = fs.readFileSync(filename, 'utf8');
      return loads(content, options);
  }

  var src = {
      repairJson,
      loads,
      fromFile
  };

  function parseJSONSafe(text, fallback = {}) {
    if (!text || typeof text !== "string") {
      return fallback;
    }
    try {
      return JSON.parse(text);
    } catch {
    }
    const codeBlockMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (codeBlockMatch) {
      try {
        return JSON.parse(codeBlockMatch[1].trim());
      } catch {
      }
    }
    const jsonMatch = text.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
    if (jsonMatch) {
      try {
        return JSON.parse(jsonMatch[1]);
      } catch {
      }
    }
    try {
      const result = src.loads(text);
      if (result !== void 0 && result !== null) {
        return result;
      }
    } catch {
    }
    try {
      const repaired = src.repairJson(text, {
        returnObjects: true,
        ensureAscii: false
      });
      if (repaired !== void 0 && repaired !== null) {
        return repaired;
      }
    } catch {
    }
    console.warn("[JSONRepair] Failed to parse/repair JSON:", text.substring(0, 200));
    return fallback;
  }

  const STORAGE_KEY$2 = "experiences";
  async function getStorage$1(key) {
    const result = await chrome.storage.local.get(key);
    return result[key] || null;
  }
  async function setStorage$1(key, value) {
    await chrome.storage.local.set({ [key]: value });
  }
  class ExperienceStorage {
    async save(entry) {
      const entries = await this.getAllMap();
      entries[entry.id] = entry;
      await setStorage$1(STORAGE_KEY$2, entries);
    }
    async saveBatch(newEntries) {
      const entries = await this.getAllMap();
      for (const entry of newEntries) {
        entries[entry.id] = entry;
      }
      await setStorage$1(STORAGE_KEY$2, entries);
    }
    async getById(id) {
      const entries = await this.getAllMap();
      return entries[id] || null;
    }
    async getByGroupType(type) {
      const all = await this.getAll();
      return all.filter((e) => e.groupType === type).sort((a, b) => a.priority - b.priority);
    }
    async getByPriority(type, priority) {
      const entries = await this.getByGroupType(type);
      return entries[priority] || null;
    }
    async getAll() {
      const entries = await this.getAllMap();
      return Object.values(entries).sort((a, b) => {
        if (a.groupType !== b.groupType) {
          const order = { WORK: 0, EDUCATION: 1, PROJECT: 2 };
          return order[a.groupType] - order[b.groupType];
        }
        return a.priority - b.priority;
      });
    }
    async delete(id) {
      const entries = await this.getAllMap();
      delete entries[id];
      await setStorage$1(STORAGE_KEY$2, entries);
      await this.normalizePriorities();
    }
    async deleteByGroupType(type) {
      const entries = await this.getAllMap();
      const filtered = Object.fromEntries(
        Object.entries(entries).filter(([, entry]) => entry.groupType !== type)
      );
      await setStorage$1(STORAGE_KEY$2, filtered);
    }
    async update(id, updates) {
      const entry = await this.getById(id);
      if (entry) {
        const updated = {
          ...entry,
          ...updates,
          updatedAt: Date.now()
        };
        await this.save(updated);
      }
    }
    async reorder(ids) {
      const entries = await this.getAllMap();
      for (let i = 0; i < ids.length; i++) {
        const entry = entries[ids[i]];
        if (entry) {
          entry.priority = i;
          entry.updatedAt = Date.now();
        }
      }
      await setStorage$1(STORAGE_KEY$2, entries);
    }
    async clearAll() {
      await setStorage$1(STORAGE_KEY$2, {});
    }
    async getCount() {
      const entries = await this.getAllMap();
      return Object.keys(entries).length;
    }
    async getCountByGroupType(type) {
      const entries = await this.getByGroupType(type);
      return entries.length;
    }
    async getAllMap() {
      return await getStorage$1(STORAGE_KEY$2) || {};
    }
    async normalizePriorities() {
      const entries = await this.getAllMap();
      const groups = ["WORK", "EDUCATION", "PROJECT"];
      for (const type of groups) {
        const typeEntries = Object.values(entries).filter((e) => e.groupType === type).sort((a, b) => a.priority - b.priority);
        typeEntries.forEach((entry, index) => {
          entry.priority = index;
        });
      }
      await setStorage$1(STORAGE_KEY$2, entries);
    }
  }
  const experienceStorage = new ExperienceStorage();

  const PROVIDER_ENDPOINTS$1 = {
    openai: "https://api.openai.com/v1/chat/completions",
    anthropic: "https://api.anthropic.com/v1/messages",
    dashscope: "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
    deepseek: "https://api.deepseek.com/v1/chat/completions",
    zhipu: "https://open.bigmodel.cn/api/paas/v4/chat/completions"
  };
  const DEFAULT_MODELS$1 = {
    openai: "gpt-4o-mini",
    anthropic: "claude-3-haiku-20240307",
    dashscope: "qwen-plus",
    deepseek: "deepseek-chat",
    zhipu: "glm-4-flash"
  };
  const MONTH_MAP$1 = {
    jan: "01",
    january: "01",
    feb: "02",
    february: "02",
    mar: "03",
    march: "03",
    apr: "04",
    april: "04",
    may: "05",
    jun: "06",
    june: "06",
    jul: "07",
    july: "07",
    aug: "08",
    august: "08",
    sep: "09",
    september: "09",
    oct: "10",
    october: "10",
    nov: "11",
    november: "11",
    dec: "12",
    december: "12"
  };
  async function callOpenAICompatible(config, prompt, systemPrompt = "You are a helpful assistant. Respond with valid JSON only.", options = {}) {
    const endpoint = config.endpoint || PROVIDER_ENDPOINTS$1[config.provider] || PROVIDER_ENDPOINTS$1.openai;
    const model = config.model || DEFAULT_MODELS$1[config.provider] || "gpt-4o-mini";
    const needsStream = config.provider === "zhipu" || model.startsWith("glm-4");
    const requestBody = {
      model,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: prompt }
      ],
      temperature: options.temperature ?? 0,
      max_tokens: options.maxTokens ?? 500
    };
    if (needsStream || options.stream) {
      requestBody.stream = true;
    }
    if (config.disableThinking) {
      requestBody.enable_thinking = false;
      requestBody.thinking = { type: "disabled" };
    }
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${config.apiKey}`
      },
      body: JSON.stringify(requestBody)
    });
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`API error ${response.status}: ${errorText}`);
    }
    if (requestBody.stream) {
      return parseStreamResponse(response);
    }
    const data = await response.json();
    return data.choices?.[0]?.message?.content || "";
  }
  async function callAnthropic(config, prompt, options = {}) {
    const endpoint = config.endpoint || PROVIDER_ENDPOINTS$1.anthropic;
    const model = config.model || DEFAULT_MODELS$1.anthropic;
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": config.apiKey,
        "anthropic-version": "2023-06-01",
        "anthropic-dangerous-direct-browser-access": "true"
      },
      body: JSON.stringify({
        model,
        max_tokens: options.maxTokens ?? 500,
        messages: [{ role: "user", content: prompt }]
      })
    });
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Anthropic API error ${response.status}: ${errorText}`);
    }
    const data = await response.json();
    return data.content?.[0]?.text || "";
  }
  async function callLLM(config, prompt, systemPrompt, options = {}) {
    if (config.provider === "anthropic") {
      const fullPrompt = systemPrompt ? `${systemPrompt}

${prompt}` : prompt;
      return callAnthropic(config, fullPrompt, options);
    }
    return callOpenAICompatible(config, prompt, systemPrompt, options);
  }
  async function parseStreamResponse(response) {
    const reader = response.body?.getReader();
    if (!reader) {
      throw new Error("No response body");
    }
    const decoder = new TextDecoder();
    let content = "";
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, { stream: true });
        const lines = chunk.split("\n");
        for (const line of lines) {
          if (line.startsWith("data: ")) {
            const data = line.slice(6).trim();
            if (data === "[DONE]") continue;
            try {
              const json = JSON.parse(data);
              const delta = json.choices?.[0]?.delta?.content;
              if (delta) {
                content += delta;
              }
            } catch {
            }
          }
        }
      }
    } finally {
      reader.releaseLock();
    }
    return content;
  }
  let cachedConfig = null;
  let configLoaded = false;
  async function loadLLMConfig() {
    if (configLoaded) {
      return cachedConfig;
    }
    try {
      const result = await chrome.storage.local.get("llmConfig");
      cachedConfig = result.llmConfig || null;
      configLoaded = true;
    } catch {
      configLoaded = true;
    }
    return cachedConfig;
  }
  async function isLLMAvailable() {
    const config = await loadLLMConfig();
    return !!(config?.enabled && config?.apiKey);
  }
  function resetLLMConfigCache() {
    cachedConfig = null;
    configLoaded = false;
  }

  const DEGREE_FALLBACK = {
    "bachelor's": { level: "bachelor", standardName: "Bachelor's Degree", abbreviation: "BS" },
    "bs": { level: "bachelor", standardName: "Bachelor's Degree", abbreviation: "BS" },
    "ba": { level: "bachelor", standardName: "Bachelor's Degree", abbreviation: "BA" },
    "本科": { level: "bachelor", standardName: "Bachelor's Degree", abbreviation: "BS" },
    "master's": { level: "master", standardName: "Master's Degree", abbreviation: "MS" },
    "ms": { level: "master", standardName: "Master's Degree", abbreviation: "MS" },
    "mba": { level: "master", standardName: "MBA", abbreviation: "MBA" },
    "硕士": { level: "master", standardName: "Master's Degree", abbreviation: "MS" },
    "phd": { level: "doctoral", standardName: "PhD", abbreviation: "PhD" },
    "博士": { level: "doctoral", standardName: "PhD", abbreviation: "PhD" }
  };
  const SKILL_FALLBACK = {
    "javascript": { name: "JavaScript", category: "language", aliases: ["JS"] },
    "js": { name: "JavaScript", category: "language", aliases: ["JS"] },
    "typescript": { name: "TypeScript", category: "language", aliases: ["TS"] },
    "python": { name: "Python", category: "language", aliases: [] },
    "react": { name: "React", category: "framework", aliases: ["ReactJS"] },
    "vue": { name: "Vue.js", category: "framework", aliases: ["Vue"] },
    "node": { name: "Node.js", category: "framework", aliases: ["NodeJS"] }
  };
  const COUNTRY_FALLBACK = {
    "us": { name: "United States", code: "US" },
    "usa": { name: "United States", code: "US" },
    "美国": { name: "United States", code: "US" },
    "china": { name: "China", code: "CN" },
    "中国": { name: "China", code: "CN" },
    "uk": { name: "United Kingdom", code: "GB" }
  };
  class KnowledgeNormalizer {
    config = null;
    configLoaded = false;
    /**
     * Whether to use LLM for normalization (sends user data to LLM)
     * Default: false - only use local rules to protect user privacy
     */
    useLLMForNormalization = false;
    constructor() {
      this.initConfig();
    }
    async initConfig() {
      this.config = await loadLLMConfig();
      this.configLoaded = true;
      try {
        const result = await chrome.storage.local.get("useLLMNormalization");
        this.useLLMForNormalization = result.useLLMNormalization === true;
      } catch {
        this.useLLMForNormalization = false;
      }
    }
    async ensureConfigLoaded() {
      if (!this.configLoaded) {
        this.config = await loadLLMConfig();
        this.configLoaded = true;
      }
      return this.config;
    }
    /**
     * Check if LLM normalization is available AND user has opted in
     * By default, we don't send user data to LLM for privacy
     */
    isLLMNormalizationEnabled() {
      return this.useLLMForNormalization && !!(this.config?.enabled && this.config?.apiKey);
    }
    // --------------------------------------------------------------------------
    // Main Normalization API (LLM-first)
    // --------------------------------------------------------------------------
    /**
     * Normalize a degree value
     * LLM-first with local fallback
     */
    async normalizeDegree(degree) {
      await this.ensureConfigLoaded();
      if (this.isLLMNormalizationEnabled()) {
        try {
          const result = await this.llmNormalizeDegree(degree);
          if (result.confidence >= 0.7) return result;
        } catch (e) {
          console.warn("[KnowledgeNormalizer] LLM degree normalization failed, using fallback:", e);
        }
      }
      return this.fallbackNormalizeDegree(degree);
    }
    /**
     * Normalize a major/field of study
     */
    async normalizeMajor(major) {
      await this.ensureConfigLoaded();
      if (this.isLLMNormalizationEnabled()) {
        try {
          const result = await this.llmNormalize("major", major, `
Standardize this field of study/major to a common format.
- Use standard English names (e.g., "Computer Science", "Business Administration")
- Include common abbreviations as aliases
- For Chinese majors, translate to English equivalent`);
          if (result.confidence >= 0.7) return result;
        } catch (e) {
          console.warn("[KnowledgeNormalizer] LLM major normalization failed:", e);
        }
      }
      return this.fallbackNormalizeMajor(major);
    }
    /**
     * Normalize a skill name
     */
    async normalizeSkill(skill) {
      await this.ensureConfigLoaded();
      if (this.isLLMNormalizationEnabled()) {
        try {
          const result = await this.llmNormalizeSkill(skill);
          if (result.confidence >= 0.7) return result;
        } catch (e) {
          console.warn("[KnowledgeNormalizer] LLM skill normalization failed:", e);
        }
      }
      return this.fallbackNormalizeSkill(skill);
    }
    /**
     * Normalize a list of skills (with deduplication)
     */
    async normalizeSkills(skills) {
      const seen = /* @__PURE__ */ new Set();
      const result = [];
      await this.ensureConfigLoaded();
      if (this.isLLMNormalizationEnabled() && skills.length > 0) {
        try {
          const batchResult = await this.llmNormalizeSkillsBatch(skills);
          for (const info of batchResult) {
            const key = info.name.toLowerCase();
            if (!seen.has(key)) {
              seen.add(key);
              result.push(info);
            }
          }
          return result;
        } catch (e) {
          console.warn("[KnowledgeNormalizer] LLM batch skill normalization failed:", e);
        }
      }
      for (const skill of skills) {
        const normalized = await this.normalizeSkill(skill);
        const key = normalized.normalized.name.toLowerCase();
        if (!seen.has(key)) {
          seen.add(key);
          result.push(normalized.normalized);
        }
      }
      return result;
    }
    /**
     * Normalize a company name
     */
    async normalizeCompany(company) {
      await this.ensureConfigLoaded();
      if (this.isLLMNormalizationEnabled()) {
        try {
          const result = await this.llmNormalize("company", company, `
Clean and standardize this company name:
- Remove suffixes like Inc., Ltd., LLC, Corp., GmbH, 有限公司, etc.
- Keep the core brand name
- Fix capitalization
- Do NOT translate company names`);
          if (result.confidence >= 0.7) return result;
        } catch (e) {
          console.warn("[KnowledgeNormalizer] LLM company normalization failed:", e);
        }
      }
      return this.fallbackNormalizeCompany(company);
    }
    /**
     * Normalize a location/address
     */
    async normalizeLocation(location) {
      await this.ensureConfigLoaded();
      if (this.isLLMNormalizationEnabled()) {
        try {
          const result = await this.llmNormalizeLocation(location);
          if (result.confidence >= 0.6) return result;
        } catch (e) {
          console.warn("[KnowledgeNormalizer] LLM location normalization failed:", e);
        }
      }
      return this.fallbackNormalizeLocation(location);
    }
    /**
     * Normalize work authorization status
     */
    async normalizeWorkAuth(auth) {
      await this.ensureConfigLoaded();
      if (this.isLLMNormalizationEnabled()) {
        try {
          const result = await this.llmNormalizeWorkAuth(auth);
          if (result.confidence >= 0.7) return result;
        } catch (e) {
          console.warn("[KnowledgeNormalizer] LLM work auth normalization failed:", e);
        }
      }
      return this.fallbackNormalizeWorkAuth(auth);
    }
    /**
     * Normalize phone number to E.164 format
     */
    normalizePhone(phone, defaultCountryCode = "+1") {
      let digits = phone.replace(/[^\d+]/g, "");
      if (digits.startsWith("+")) {
        return { original: phone, normalized: digits, confidence: 0.95, method: "rule" };
      }
      if (digits.length === 10) {
        return { original: phone, normalized: `+1${digits}`, confidence: 0.9, method: "rule" };
      }
      if (digits.length === 11 && digits.startsWith("1")) {
        if (/^1[3-9]\d{9}$/.test(digits)) {
          return { original: phone, normalized: `+86${digits}`, confidence: 0.85, method: "rule" };
        }
        return { original: phone, normalized: `+${digits}`, confidence: 0.8, method: "rule" };
      }
      return { original: phone, normalized: `${defaultCountryCode}${digits}`, confidence: 0.6, method: "rule" };
    }
    /**
     * Normalize a date string to YYYY-MM format
     */
    normalizeDate(date) {
      if (!date || date.toLowerCase() === "present") {
        return { original: date, normalized: date?.toLowerCase() === "present" ? "present" : "", confidence: 1, method: "passthrough" };
      }
      if (/^\d{4}-\d{2}$/.test(date)) {
        return { original: date, normalized: date, confidence: 1, method: "passthrough" };
      }
      const chineseMatch = date.match(/(\d{4})年(\d{1,2})月?/);
      if (chineseMatch) {
        return { original: date, normalized: `${chineseMatch[1]}-${chineseMatch[2].padStart(2, "0")}`, confidence: 0.95, method: "rule" };
      }
      const englishMatch = date.match(/([A-Za-z]+)\s+(\d{4})/);
      if (englishMatch) {
        const month = MONTH_MAP$1[englishMatch[1].toLowerCase().slice(0, 3)];
        if (month) {
          return { original: date, normalized: `${englishMatch[2]}-${month}`, confidence: 0.95, method: "rule" };
        }
      }
      const yearMatch = date.match(/^(\d{4})$/);
      if (yearMatch) {
        return { original: date, normalized: `${yearMatch[1]}-01`, confidence: 0.7, method: "rule" };
      }
      return { original: date, normalized: date, confidence: 0.3, method: "passthrough" };
    }
    // --------------------------------------------------------------------------
    // Batch Processing
    // --------------------------------------------------------------------------
    /**
     * Normalize an entire AnswerValue
     */
    async normalizeAnswer(answer) {
      const normalized = { ...answer };
      switch (answer.type) {
        case Taxonomy.DEGREE: {
          const result = await this.normalizeDegree(answer.value);
          normalized.value = result.normalized.standardName;
          normalized.aliases = result.aliases || [];
          break;
        }
        case Taxonomy.MAJOR: {
          const result = await this.normalizeMajor(answer.value);
          normalized.value = result.normalized;
          normalized.aliases = result.aliases || [];
          break;
        }
        case Taxonomy.PHONE: {
          const result = this.normalizePhone(answer.value);
          normalized.value = result.normalized;
          break;
        }
        case Taxonomy.COMPANY_NAME: {
          const result = await this.normalizeCompany(answer.value);
          normalized.value = result.normalized;
          break;
        }
        case Taxonomy.LOCATION:
        case Taxonomy.CITY: {
          const result = await this.normalizeLocation(answer.value);
          if (answer.type === Taxonomy.CITY && result.normalized.city) {
            normalized.value = result.normalized.city;
          }
          break;
        }
        case Taxonomy.WORK_AUTH:
        case Taxonomy.NEED_SPONSORSHIP: {
          const result = await this.normalizeWorkAuth(answer.value);
          normalized.value = result.normalized.standard;
          break;
        }
        case Taxonomy.SKILLS: {
          const skills = answer.value.split(/[,;，；]/).map((s) => s.trim()).filter(Boolean);
          const normalizedSkills = await this.normalizeSkills(skills);
          normalized.value = normalizedSkills.map((s) => s.name).join(", ");
          break;
        }
      }
      return normalized;
    }
    /**
     * Normalize an ExperienceEntry
     */
    async normalizeExperience(entry) {
      const normalized = { ...entry, fields: { ...entry.fields } };
      if (entry.startDate) normalized.startDate = this.normalizeDate(entry.startDate).normalized;
      if (entry.endDate) normalized.endDate = this.normalizeDate(entry.endDate).normalized;
      if (entry.groupType === "WORK") {
        if (normalized.fields[Taxonomy.COMPANY_NAME]) {
          normalized.fields[Taxonomy.COMPANY_NAME] = (await this.normalizeCompany(normalized.fields[Taxonomy.COMPANY_NAME])).normalized;
        }
      }
      if (entry.groupType === "EDUCATION") {
        if (normalized.fields[Taxonomy.DEGREE]) {
          const result = await this.normalizeDegree(normalized.fields[Taxonomy.DEGREE]);
          normalized.fields[Taxonomy.DEGREE] = result.normalized.standardName;
        }
        if (normalized.fields[Taxonomy.MAJOR]) {
          normalized.fields[Taxonomy.MAJOR] = (await this.normalizeMajor(normalized.fields[Taxonomy.MAJOR])).normalized;
        }
        if (normalized.fields[Taxonomy.SCHOOL]) {
          normalized.fields[Taxonomy.SCHOOL] = (await this.normalizeCompany(normalized.fields[Taxonomy.SCHOOL])).normalized;
        }
      }
      for (const field of [Taxonomy.START_DATE, Taxonomy.END_DATE, Taxonomy.GRAD_DATE]) {
        if (normalized.fields[field]) {
          normalized.fields[field] = this.normalizeDate(normalized.fields[field]).normalized;
        }
      }
      return normalized;
    }
    // --------------------------------------------------------------------------
    // LLM Normalization Methods
    // --------------------------------------------------------------------------
    async llmNormalizeDegree(degree) {
      const prompt = `Standardize this academic degree to a common format.

Input: "${degree}"

Rules:
- Map to standard English degree names
- Identify the level: high_school, associate, bachelor, master, doctoral, professional, other
- Provide standard name and common abbreviation
- Handle Chinese degrees (本科=Bachelor's, 硕士=Master's, 博士=PhD)

Return JSON only:
{
  "level": "bachelor|master|doctoral|...",
  "standardName": "Bachelor's Degree",
  "abbreviation": "BS",
  "confidence": 0.0-1.0,
  "aliases": ["other forms"]
}`;
      const response = await this.callLLMInternal(prompt);
      const parsed = this.parseJSON(response);
      return {
        original: degree,
        normalized: {
          level: parsed.level || "other",
          standardName: parsed.standardName || degree,
          abbreviation: parsed.abbreviation || degree
        },
        confidence: parsed.confidence || 0.8,
        method: "llm",
        aliases: parsed.aliases
      };
    }
    async llmNormalizeSkill(skill) {
      const prompt = `Standardize this technical skill name.

Input: "${skill}"

Rules:
- Use official/common industry naming (e.g., "JavaScript" not "javascript")
- Categorize: language, framework, tool, database, cloud, soft_skill, other
- Include common aliases/abbreviations

Return JSON only:
{
  "name": "JavaScript",
  "category": "language",
  "aliases": ["JS", "js"],
  "confidence": 0.0-1.0
}`;
      const response = await this.callLLMInternal(prompt);
      const parsed = this.parseJSON(response);
      return {
        original: skill,
        normalized: {
          name: parsed.name || skill,
          category: parsed.category || "other",
          aliases: parsed.aliases || []
        },
        confidence: parsed.confidence || 0.8,
        method: "llm",
        aliases: parsed.aliases
      };
    }
    async llmNormalizeSkillsBatch(skills) {
      const prompt = `Standardize these technical skills.

Input: ${JSON.stringify(skills)}

Rules:
- Use official/common industry naming
- Categorize each: language, framework, tool, database, cloud, soft_skill, other
- Deduplicate (e.g., "JS" and "JavaScript" are the same)
- Include aliases for each

Return JSON array only:
[{"name": "JavaScript", "category": "language", "aliases": ["JS"]}]`;
      const response = await this.callLLMInternal(prompt);
      const parsed = this.parseJSON(response);
      if (Array.isArray(parsed)) {
        return parsed.map((item) => ({
          name: item.name || "",
          category: item.category || "other",
          aliases: item.aliases || []
        }));
      }
      throw new Error("Invalid batch response");
    }
    async llmNormalizeLocation(location) {
      const prompt = `Parse and standardize this location/address.

Input: "${location}"

Rules:
- Extract: city, state/province, country, countryCode (ISO 3166-1 alpha-2)
- Standardize country names to English
- For Chinese addresses, extract city name without 市/区/县 suffix
- For Western addresses, preserve original city names

Return JSON only:
{
  "city": "San Francisco",
  "state": "California",
  "country": "United States",
  "countryCode": "US",
  "confidence": 0.0-1.0
}`;
      const response = await this.callLLMInternal(prompt);
      const parsed = this.parseJSON(response);
      return {
        original: location,
        normalized: {
          city: parsed.city,
          state: parsed.state,
          country: parsed.country,
          countryCode: parsed.countryCode
        },
        confidence: parsed.confidence || 0.8,
        method: "llm"
      };
    }
    async llmNormalizeWorkAuth(auth) {
      const prompt = `Standardize this work authorization status.

Input: "${auth}"

Rules:
- Determine if person needs visa sponsorship
- Map to standard terms:
  - "US Citizen", "Permanent Resident", "Green Card" → needsSponsorship: false
  - "H1B", "OPT", "F1", "Requires Sponsorship" → needsSponsorship: true
  - "Authorized to work" (without context) → assume needsSponsorship: false

Return JSON only:
{
  "standard": "Permanent Resident",
  "needsSponsorship": false,
  "confidence": 0.0-1.0
}`;
      const response = await this.callLLMInternal(prompt);
      const parsed = this.parseJSON(response);
      return {
        original: auth,
        normalized: {
          standard: parsed.standard || auth,
          needsSponsorship: !!parsed.needsSponsorship
        },
        confidence: parsed.confidence || 0.8,
        method: "llm"
      };
    }
    async llmNormalize(_type, value, instructions) {
      const prompt = `${instructions}

Input: "${value}"

Return JSON only:
{
  "normalized": "standardized value",
  "confidence": 0.0-1.0,
  "aliases": ["other forms"]
}`;
      const response = await this.callLLMInternal(prompt);
      const parsed = this.parseJSON(response);
      return {
        original: value,
        normalized: parsed.normalized || value,
        confidence: parsed.confidence || 0.8,
        method: "llm",
        aliases: parsed.aliases
      };
    }
    // --------------------------------------------------------------------------
    // Fallback Methods (when LLM unavailable)
    // --------------------------------------------------------------------------
    fallbackNormalizeDegree(degree) {
      const lower = degree.toLowerCase().trim();
      for (const [key, info] of Object.entries(DEGREE_FALLBACK)) {
        if (lower === key || lower.includes(key)) {
          return { original: degree, normalized: info, confidence: 0.8, method: "rule" };
        }
      }
      return {
        original: degree,
        normalized: { level: "other", standardName: degree, abbreviation: degree },
        confidence: 0.3,
        method: "passthrough"
      };
    }
    fallbackNormalizeMajor(major) {
      return { original: major, normalized: this.titleCase(major), confidence: 0.5, method: "passthrough" };
    }
    fallbackNormalizeSkill(skill) {
      const lower = skill.toLowerCase().trim();
      const mapped = SKILL_FALLBACK[lower];
      if (mapped) {
        return { original: skill, normalized: mapped, confidence: 0.8, method: "rule", aliases: mapped.aliases };
      }
      return {
        original: skill,
        normalized: { name: skill, category: "other", aliases: [] },
        confidence: 0.3,
        method: "passthrough"
      };
    }
    fallbackNormalizeCompany(company) {
      const suffixes = [
        /,?\s*(inc\.?|incorporated|corp\.?|corporation|llc|ltd\.?|limited|co\.?|company|plc|gmbh|ag|sa|pte\.?\s*ltd\.?)$/i,
        /,?\s*(株式会社|有限公司|有限责任公司|集团|控股)$/
      ];
      let normalized = company.trim();
      for (const pattern of suffixes) {
        normalized = normalized.replace(pattern, "").trim();
      }
      return {
        original: company,
        normalized,
        confidence: normalized !== company ? 0.85 : 0.5,
        method: "rule"
      };
    }
    fallbackNormalizeLocation(location) {
      const parts = location.split(/[,，·]/).map((p) => p.trim()).filter(Boolean);
      const components = {};
      for (let i = parts.length - 1; i >= 0; i--) {
        const lower = parts[i].toLowerCase();
        const country = COUNTRY_FALLBACK[lower];
        if (country) {
          components.country = country.name;
          components.countryCode = country.code;
          parts.splice(i, 1);
          break;
        }
      }
      if (/[\u4e00-\u9fa5]/.test(location)) {
        for (let i = parts.length - 1; i >= 0; i--) {
          if (!parts[i].includes("省") && !parts[i].includes("国")) {
            components.city = parts[i].replace(/[市区县]$/, "");
            break;
          }
        }
      } else if (parts.length > 0) {
        components.city = parts[0];
        if (parts.length > 1) components.state = parts[1];
      }
      return {
        original: location,
        normalized: components,
        confidence: components.city ? 0.7 : 0.4,
        method: "rule"
      };
    }
    fallbackNormalizeWorkAuth(auth) {
      const lower = auth.toLowerCase();
      if (/citizen|permanent|green\s*card|authorized/i.test(lower)) {
        return {
          original: auth,
          normalized: { standard: "Authorized to work", needsSponsorship: false },
          confidence: 0.7,
          method: "rule"
        };
      }
      if (/h1b|opt|f1|sponsor|visa/i.test(lower)) {
        return {
          original: auth,
          normalized: { standard: "Requires Sponsorship", needsSponsorship: true },
          confidence: 0.7,
          method: "rule"
        };
      }
      return {
        original: auth,
        normalized: { standard: auth, needsSponsorship: false },
        confidence: 0.3,
        method: "passthrough"
      };
    }
    // --------------------------------------------------------------------------
    // LLM Call Infrastructure (using shared @/utils/llmProvider)
    // --------------------------------------------------------------------------
    async callLLMInternal(prompt) {
      if (!this.config) throw new Error("LLM config not loaded");
      return callLLM(
        this.config,
        prompt,
        "You are a data normalization assistant. Respond with valid JSON only.",
        { maxTokens: 300 }
      );
    }
    parseJSON(text) {
      return parseJSONSafe(text, {});
    }
    titleCase(str) {
      return str.toLowerCase().split(" ").map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
    }
    /** Reset config (for testing or after settings change) */
    resetConfig() {
      this.configLoaded = false;
      this.config = null;
      this.useLLMForNormalization = false;
      resetLLMConfigCache();
    }
    /**
     * Enable or disable LLM normalization
     * When enabled, user data (degree, company, etc.) will be sent to LLM for better normalization
     * When disabled (default), only local rules are used - no user data sent to LLM
     */
    async setLLMNormalization(enabled) {
      this.useLLMForNormalization = enabled;
      try {
        await chrome.storage.local.set({ useLLMNormalization: enabled });
      } catch {
      }
    }
    /**
     * Check if LLM normalization is currently enabled
     */
    isLLMNormalizationActive() {
      return this.useLLMForNormalization;
    }
  }
  const knowledgeNormalizer = new KnowledgeNormalizer();

  const STORAGE_KEYS = {
    ANSWERS: "answers",
    OBSERVATIONS: "observations",
    SITE_SETTINGS: "siteSettings",
    QUESTION_KEYS: "questionKeys",
    AUTH_STATE: "authState",
    CREDITS_CACHE: "creditsCache"
  };
  function isExtensionContextValid() {
    try {
      if (typeof chrome === "undefined") return false;
      if (chrome.runtime) {
        return !!chrome.runtime.id;
      }
      if (chrome.storage?.local) {
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }
  class ExtensionContextInvalidatedError extends Error {
    constructor() {
      super("Extension has been updated. Please refresh the page.");
      this.name = "ExtensionContextInvalidatedError";
    }
  }
  async function getStorage(key) {
    if (!isExtensionContextValid()) {
      throw new ExtensionContextInvalidatedError();
    }
    const result = await chrome.storage.local.get(key);
    return result[key] || null;
  }
  async function setStorage(key, value) {
    if (!isExtensionContextValid()) {
      throw new ExtensionContextInvalidatedError();
    }
    await chrome.storage.local.set({ [key]: value });
  }
  class AnswerStorage {
    /**
     * Save an answer with optional normalization
     * @param answer The answer to save
     * @param normalize Whether to normalize the value before saving (default: true)
     */
    async save(answer, normalize = true) {
      const toSave = normalize ? await knowledgeNormalizer.normalizeAnswer(answer) : answer;
      const answers = await this.getAllMap();
      answers[toSave.id] = toSave;
      await setStorage(STORAGE_KEYS.ANSWERS, answers);
    }
    async getById(id) {
      const answers = await this.getAllMap();
      return answers[id] || null;
    }
    async getByType(type) {
      const answers = await this.getAllMap();
      return Object.values(answers).filter((a) => a.type === type);
    }
    async findByValue(type, value) {
      const answers = await this.getByType(type);
      const normalizedValue = value.toLowerCase().trim();
      for (const answer of answers) {
        if (answer.value.toLowerCase() === normalizedValue) {
          return answer;
        }
        if (answer.aliases.some((a) => a.toLowerCase() === normalizedValue)) {
          return answer;
        }
      }
      return null;
    }
    async getAll() {
      const answers = await this.getAllMap();
      return Object.values(answers);
    }
    async delete(id) {
      const answers = await this.getAllMap();
      delete answers[id];
      await setStorage(STORAGE_KEYS.ANSWERS, answers);
    }
    async update(id, updates) {
      const answer = await this.getById(id);
      if (answer) {
        const updated = { ...answer, ...updates, updatedAt: Date.now() };
        await this.save(updated);
      }
    }
    async getAllMap() {
      return await getStorage(STORAGE_KEYS.ANSWERS) || {};
    }
  }
  class ObservationStorage {
    async save(observation) {
      const observations = await this.getAllMap();
      observations[observation.id] = observation;
      await setStorage(STORAGE_KEYS.OBSERVATIONS, observations);
    }
    async getById(id) {
      const observations = await this.getAllMap();
      return observations[id] || null;
    }
    async getBySite(siteKey) {
      const observations = await this.getAllMap();
      return Object.values(observations).filter((o) => o.siteKey === siteKey).sort((a, b) => b.timestamp - a.timestamp);
    }
    async getRecent(limit = 50) {
      const observations = await this.getAllMap();
      return Object.values(observations).sort((a, b) => b.timestamp - a.timestamp).slice(0, limit);
    }
    async getByQuestionKey(questionKeyId) {
      const observations = await this.getAllMap();
      return Object.values(observations).filter((o) => o.questionKeyId === questionKeyId).sort((a, b) => b.timestamp - a.timestamp);
    }
    /**
     * Get relevant historical examples for few-shot learning
     * Returns high-confidence observations grouped by taxonomy type
     */
    async getRelevantExamples(limit = 5) {
      const observations = await this.getAllMap();
      return Object.values(observations).filter((o) => o.confidence >= 0.8).sort((a, b) => b.confidence - a.confidence).slice(0, limit).map((o) => ({
        questionKeyId: o.questionKeyId,
        answerId: o.answerId,
        confidence: o.confidence,
        siteKey: o.siteKey
      }));
    }
    async delete(id) {
      const observations = await this.getAllMap();
      delete observations[id];
      await setStorage(STORAGE_KEYS.OBSERVATIONS, observations);
    }
    async clearBySite(siteKey) {
      const observations = await this.getAllMap();
      const filtered = {};
      for (const [id, obs] of Object.entries(observations)) {
        if (obs.siteKey !== siteKey) {
          filtered[id] = obs;
        }
      }
      await setStorage(STORAGE_KEYS.OBSERVATIONS, filtered);
    }
    async getAllMap() {
      return await getStorage(STORAGE_KEYS.OBSERVATIONS) || {};
    }
  }
  class SiteSettingsStorage {
    async save(settings) {
      const allSettings = await this.getAllMap();
      allSettings[settings.siteKey] = settings;
      await setStorage(STORAGE_KEYS.SITE_SETTINGS, allSettings);
    }
    async get(siteKey) {
      const allSettings = await this.getAllMap();
      return allSettings[siteKey] || null;
    }
    async getOrCreate(siteKey) {
      const existing = await this.get(siteKey);
      if (existing) return existing;
      const newSettings = {
        siteKey,
        recordEnabled: true,
        autofillEnabled: false,
        // Default OFF for security - prevents data leakage on malicious forms
        createdAt: Date.now(),
        updatedAt: Date.now()
      };
      await this.save(newSettings);
      return newSettings;
    }
    async update(siteKey, updates) {
      const settings = await this.get(siteKey);
      if (settings) {
        const updated = { ...settings, ...updates, updatedAt: Date.now() };
        await this.save(updated);
      }
    }
    async delete(siteKey) {
      const allSettings = await this.getAllMap();
      delete allSettings[siteKey];
      await setStorage(STORAGE_KEYS.SITE_SETTINGS, allSettings);
    }
    async getAll() {
      const allSettings = await this.getAllMap();
      return Object.values(allSettings);
    }
    async getAllMap() {
      return await getStorage(STORAGE_KEYS.SITE_SETTINGS) || {};
    }
  }
  class PendingObservationStorage {
    pendingByForm = /* @__PURE__ */ new Map();
    add(formId, pending) {
      const existing = this.pendingByForm.get(formId) || [];
      const idx = existing.findIndex((p) => p.fieldLocator === pending.fieldLocator);
      if (idx >= 0) existing[idx] = pending;
      else existing.push(pending);
      this.pendingByForm.set(formId, existing);
    }
    getByForm(formId) {
      return this.pendingByForm.get(formId) || [];
    }
    getAllPending() {
      return Array.from(this.pendingByForm.values()).flat();
    }
    getFormIds() {
      return Array.from(this.pendingByForm.keys());
    }
    updateStatus(formId, status) {
      this.pendingByForm.get(formId)?.forEach((p) => p.status = status);
    }
    commit(formId) {
      const pending = this.pendingByForm.get(formId) || [];
      this.pendingByForm.delete(formId);
      return pending.map((p) => ({ ...p, status: "committed" }));
    }
    discard(formId) {
      this.pendingByForm.delete(formId);
    }
    discardAll() {
      this.pendingByForm.clear();
    }
    hasPending(formId) {
      return (this.pendingByForm.get(formId)?.length ?? 0) > 0;
    }
    getPendingCount() {
      return Array.from(this.pendingByForm.values()).reduce((sum, arr) => sum + arr.length, 0);
    }
  }
  const API_BASE_URL$1 = "https://www.onefil.help/api";
  const TOKEN_BUFFER_MS = 5 * 60 * 1e3;
  class AuthStorage {
    async getAuthState() {
      return getStorage(STORAGE_KEYS.AUTH_STATE);
    }
    async setAuthState(state) {
      await setStorage(STORAGE_KEYS.AUTH_STATE, state);
    }
    async clearAuthState() {
      if (!isExtensionContextValid()) throw new ExtensionContextInvalidatedError();
      await chrome.storage.local.remove(STORAGE_KEYS.AUTH_STATE);
    }
    async getAccessToken() {
      const state = await this.getAuthState();
      if (!state || state.expiresAt <= Date.now() + TOKEN_BUFFER_MS) return null;
      return state.accessToken;
    }
    async fetchCredits() {
      const token = await this.getAccessToken();
      if (!token) return null;
      try {
        const response = await fetch(`${API_BASE_URL$1}/credits`, {
          headers: { "Authorization": `Bearer ${token}` }
        });
        if (!response.ok) {
          if (response.status === 401) await this.clearAuthState();
          return null;
        }
        const credits = await response.json();
        await setStorage(STORAGE_KEYS.CREDITS_CACHE, credits);
        return credits;
      } catch {
        return getStorage(STORAGE_KEYS.CREDITS_CACHE);
      }
    }
    async consumeCredits(amount, type) {
      const token = await this.getAccessToken();
      if (!token) return { success: false, newBalance: 0, error: "Not logged in" };
      try {
        const response = await fetch(`${API_BASE_URL$1}/credits`, {
          method: "POST",
          headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
          body: JSON.stringify({ amount, type })
        });
        const result = await response.json();
        if (!response.ok) {
          return { success: false, newBalance: result.balance || 0, error: result.error || "Failed to consume credits" };
        }
        const cached = await getStorage(STORAGE_KEYS.CREDITS_CACHE);
        if (cached) {
          cached.balance = result.newBalance;
          await setStorage(STORAGE_KEYS.CREDITS_CACHE, cached);
        }
        return { success: true, newBalance: result.newBalance };
      } catch (e) {
        return { success: false, newBalance: 0, error: `Network error: ${e}` };
      }
    }
  }
  class Storage {
    answers = new AnswerStorage();
    observations = new ObservationStorage();
    siteSettings = new SiteSettingsStorage();
    pendingObservations = new PendingObservationStorage();
    experiences = experienceStorage;
    auth = new AuthStorage();
    async clearAll() {
      await chrome.storage.local.remove([
        STORAGE_KEYS.ANSWERS,
        STORAGE_KEYS.OBSERVATIONS,
        STORAGE_KEYS.SITE_SETTINGS,
        STORAGE_KEYS.QUESTION_KEYS,
        "experiences"
      ]);
      this.pendingObservations.discardAll();
    }
    async exportData() {
      const [answers, observations, siteSettings, experiences] = await Promise.all([
        this.answers.getAll(),
        this.observations.getRecent(1e3),
        this.siteSettings.getAll(),
        this.experiences.getAll()
      ]);
      return { answers, observations, siteSettings, experiences };
    }
    async importData(data) {
      if (data.answers) {
        for (const answer of data.answers) {
          await this.answers.save(answer);
        }
      }
      if (data.siteSettings) {
        for (const settings of data.siteSettings) {
          await this.siteSettings.save(settings);
        }
      }
      if (data.experiences) {
        await this.experiences.saveBatch(data.experiences);
      }
    }
  }
  const storage = new Storage();

  const API_BASE_URL = "https://www.onefil.help/api";
  const TAXONOMY_DESCRIPTIONS = {
    [Taxonomy.FULL_NAME]: "Full name (first and last)",
    [Taxonomy.FIRST_NAME]: "First/given name only",
    [Taxonomy.LAST_NAME]: "Last/family name only",
    [Taxonomy.EMAIL]: "Email address",
    [Taxonomy.PHONE]: "Phone/mobile number",
    [Taxonomy.COUNTRY_CODE]: "Phone country code",
    [Taxonomy.LOCATION]: "Full address or location",
    [Taxonomy.CITY]: "City name",
    [Taxonomy.LINKEDIN]: "LinkedIn profile URL",
    [Taxonomy.GITHUB]: "GitHub profile URL",
    [Taxonomy.PORTFOLIO]: "Portfolio/personal website URL",
    [Taxonomy.SCHOOL]: "School/university name",
    [Taxonomy.DEGREE]: "Degree type (Bachelor, Master, PhD)",
    [Taxonomy.MAJOR]: "Field of study/major",
    [Taxonomy.GRAD_DATE]: "Graduation date",
    [Taxonomy.GRAD_YEAR]: "Graduation year",
    [Taxonomy.GRAD_MONTH]: "Graduation month",
    [Taxonomy.START_DATE]: "Start date (job/education)",
    [Taxonomy.END_DATE]: "End date (job/education)",
    [Taxonomy.WORK_AUTH]: "Work authorization status",
    [Taxonomy.NEED_SPONSORSHIP]: "Visa sponsorship requirement",
    [Taxonomy.RESUME_TEXT]: "Resume/CV content",
    [Taxonomy.SALARY]: "Salary expectation",
    [Taxonomy.EEO_GENDER]: "Gender (EEO)",
    [Taxonomy.EEO_ETHNICITY]: "Race/ethnicity (EEO)",
    [Taxonomy.EEO_VETERAN]: "Veteran status (EEO)",
    [Taxonomy.EEO_DISABILITY]: "Disability status (EEO)",
    [Taxonomy.GOV_ID]: "Government ID (SSN, etc.)",
    [Taxonomy.SUMMARY]: "Professional summary/objective",
    [Taxonomy.GPA]: "Grade point average",
    [Taxonomy.COMPANY_NAME]: "Company/employer name",
    [Taxonomy.JOB_TITLE]: "Job title/position",
    [Taxonomy.JOB_DESCRIPTION]: "Job duties/responsibilities",
    [Taxonomy.SKILLS]: "Skills and competencies",
    [Taxonomy.UNKNOWN]: "Unknown/unrecognized field"
  };
  const PROVIDER_ENDPOINTS = {
    openai: "https://api.openai.com/v1/chat/completions",
    anthropic: "https://api.anthropic.com/v1/messages",
    dashscope: "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
    deepseek: "https://api.deepseek.com/v1/chat/completions",
    zhipu: "https://open.bigmodel.cn/api/paas/v4/chat/completions"
  };
  const DEFAULT_MODELS = {
    openai: "gpt-4o-mini",
    anthropic: "claude-3-haiku-20240307",
    dashscope: "qwen-plus",
    deepseek: "deepseek-chat",
    zhipu: "glm-4-flash"
  };
  const DEFAULT_CONFIG$1 = {
    enabled: true,
    // Enabled by default (uses backend API)
    useCustomApi: false,
    // Default to backend API
    provider: "openai",
    apiKey: "",
    model: "gpt-4o-mini"
  };
  const BATCH_SIZE = 10;
  class LLMParser {
    name = "LLMParser";
    priority = 50;
    cache = /* @__PURE__ */ new Map();
    config = null;
    configLoaded = false;
    cacheTimeout = 3e5;
    async ensureConfigLoaded() {
      if (!this.configLoaded) {
        try {
          const result = await chrome.storage.local.get("llmConfig");
          this.config = result.llmConfig ? { ...DEFAULT_CONFIG$1, ...result.llmConfig } : DEFAULT_CONFIG$1;
        } catch {
          this.config = DEFAULT_CONFIG$1;
        }
        this.configLoaded = true;
      }
      return this.config;
    }
    canParse(_context) {
      return true;
    }
    async parse(context) {
      const config = await this.ensureConfigLoaded();
      if (!config.enabled) {
        return [];
      }
      if (config.useCustomApi && !config.apiKey) {
        return [];
      }
      if (!config.useCustomApi) {
        if (!isExtensionContextValid()) {
          return [];
        }
        const token = await storage.auth.getAccessToken();
        if (!token) {
          console.log("[LLMParser] Skipped - not logged in for backend API");
          return [];
        }
      }
      const cacheKey = this.getCacheKey(context);
      const cached = this.cache.get(cacheKey);
      if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
        return cached.result;
      }
      try {
        const metadata = this.extractMetadata(context, 0);
        const scrubbed = this.scrubPII(metadata);
        console.log("[LLMParser] Calling LLM for single field:", scrubbed.labelText || scrubbed.surroundingText.slice(0, 50));
        const result = await this.callLLMSingle(scrubbed);
        console.log("[LLMParser] Result:", result);
        this.cache.set(cacheKey, { result, timestamp: Date.now() });
        return result;
      } catch (error) {
        console.error("[LLMParser] Error:", error);
        return [];
      }
    }
    /**
     * Batch parse multiple fields - sends fields in batches of BATCH_SIZE
     * Returns a Map from field index to candidates
     *
     * @param contexts - Array of field contexts to classify
     * @param filledFields - Optional array of already-classified fields for context
     * @param pageContext - Optional page-level context (title, URL keywords)
     * @param fewShotExamples - Optional historical examples for few-shot learning
     */
    async parseBatch(contexts, filledFields, pageContext, fewShotExamples) {
      const config = await this.ensureConfigLoaded();
      const results = /* @__PURE__ */ new Map();
      if (!config.enabled) {
        console.log("[LLMParser] Batch parse skipped - not enabled");
        return results;
      }
      if (config.useCustomApi && !config.apiKey) {
        console.log("[LLMParser] Batch parse skipped - custom API enabled but no API key");
        return results;
      }
      if (!config.useCustomApi) {
        if (!isExtensionContextValid()) {
          console.log("[LLMParser] Batch parse skipped - test environment");
          return results;
        }
        const token = await storage.auth.getAccessToken();
        if (!token) {
          console.log("[LLMParser] Batch parse skipped - not logged in for backend API");
          return results;
        }
      }
      const uncachedFields = [];
      for (let i = 0; i < contexts.length; i++) {
        const cacheKey = this.getCacheKey(contexts[i]);
        const cached = this.cache.get(cacheKey);
        if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
          results.set(i, cached.result);
        } else {
          uncachedFields.push({ index: i, context: contexts[i] });
        }
      }
      console.log(`[LLMParser] Batch parse: ${contexts.length} total, ${results.size} cached, ${uncachedFields.length} to process`);
      if (uncachedFields.length === 0) {
        return results;
      }
      const batches = [];
      for (let i = 0; i < uncachedFields.length; i += BATCH_SIZE) {
        batches.push(uncachedFields.slice(i, i + BATCH_SIZE));
      }
      console.log(`[LLMParser] Processing ${batches.length} batches of up to ${BATCH_SIZE} fields each`);
      for (let batchIndex = 0; batchIndex < batches.length; batchIndex++) {
        const batch = batches[batchIndex];
        console.log(`[LLMParser] Processing batch ${batchIndex + 1}/${batches.length} (${batch.length} fields)`);
        try {
          const batchResults = await this.processSingleBatch(batch, filledFields, pageContext, fewShotExamples);
          for (const [fieldIndex, candidates] of batchResults) {
            results.set(fieldIndex, candidates);
            const cacheKey = this.getCacheKey(contexts[fieldIndex]);
            this.cache.set(cacheKey, { result: candidates, timestamp: Date.now() });
          }
        } catch (error) {
          console.error(`[LLMParser] Batch ${batchIndex + 1} failed:`, error);
          for (const { index } of batch) {
            results.set(index, []);
          }
        }
        if (batchIndex < batches.length - 1) {
          await new Promise((resolve) => setTimeout(resolve, 100));
        }
      }
      return results;
    }
    async processSingleBatch(batch, filledFields, pageContext, fewShotExamples) {
      const results = /* @__PURE__ */ new Map();
      const config = this.config;
      const metadataList = batch.map(({ index, context }) => {
        const metadata = this.extractMetadata(context, index);
        return this.scrubPII(metadata);
      });
      let response;
      if (!config.useCustomApi) {
        response = await this.callBackendAPI(metadataList);
      } else {
        const prompt = this.buildBatchPrompt(metadataList, filledFields, pageContext, fewShotExamples);
        if (config.provider === "anthropic") {
          response = await this.callAnthropicBatch(prompt);
        } else {
          response = await this.callOpenAICompatibleBatch(prompt);
        }
      }
      for (const item of response) {
        const batchItem = batch.find((b) => b.index === item.index);
        if (!batchItem) continue;
        const type = item.type;
        const confidence = Math.min(Math.max(item.confidence || 0.5, 0), 1);
        if (!Object.values(Taxonomy).includes(type) || type === Taxonomy.UNKNOWN) {
          results.set(item.index, []);
          continue;
        }
        results.set(item.index, [{
          type,
          score: confidence * 0.85,
          reasons: [`LLM batch classification (${confidence.toFixed(2)} confidence)`]
        }]);
      }
      for (const { index } of batch) {
        if (!results.has(index)) {
          results.set(index, []);
        }
      }
      return results;
    }
    getCacheKey(context) {
      const key = [
        context.labelText,
        context.attributes.name || "",
        context.attributes.id || "",
        context.attributes.type || "",
        context.attributes.placeholder || "",
        context.optionsText.slice(0, 5).join(",")
      ].join("|");
      return btoa(encodeURIComponent(key)).slice(0, 64);
    }
    extractMetadata(context, index) {
      const { ancestorCandidates, surroundingText } = this.extractAncestorInfo(context.element);
      return {
        index,
        tagName: context.element.tagName.toLowerCase(),
        type: context.attributes.type || "",
        name: context.attributes.name || "",
        id: context.attributes.id || "",
        placeholder: context.attributes.placeholder || "",
        labelText: context.labelText,
        sectionTitle: context.sectionTitle,
        options: context.optionsText.slice(0, 10),
        ariaLabel: context.attributes["aria-label"] || "",
        surroundingText,
        ancestorCandidates
      };
    }
    extractAncestorInfo(element) {
      try {
        const candidates = collectAncestorContext(element);
        const ancestorCandidates = candidates.map((c) => ({
          text: c.text.slice(0, 200),
          depth: c.depth,
          type: c.type
        }));
        const surroundingText = this.selectBestCandidateText(candidates);
        return { ancestorCandidates, surroundingText };
      } catch {
        return {
          ancestorCandidates: [],
          surroundingText: this.extractFallbackSurroundingText(element)
        };
      }
    }
    selectBestCandidateText(candidates) {
      if (candidates.length === 0) return "";
      const sorted = [...candidates].sort((a, b) => {
        if (a.type === "label" && b.type !== "label") return -1;
        if (b.type === "label" && a.type !== "label") return 1;
        return a.depth - b.depth;
      });
      return sorted[0].text.slice(0, 200);
    }
    extractFallbackSurroundingText(element) {
      const parent = element.closest('.form-group, .field, .input-group, [class*="form"], [class*="field"]');
      if (parent?.textContent) {
        return parent.textContent.trim().slice(0, 200);
      }
      const prevSibling = element.previousElementSibling;
      if (prevSibling?.textContent) {
        return prevSibling.textContent.trim().slice(0, 200);
      }
      return element.parentElement?.textContent?.trim().slice(0, 200) || "";
    }
    scrubPII(metadata) {
      const emailPattern = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
      const phonePattern = /[\+]?[(]?[0-9]{1,3}[)]?[-\s\.]?[(]?[0-9]{1,3}[)]?[-\s\.]?[0-9]{4,6}/g;
      const ssnPattern = /\d{3}[-\s]?\d{2}[-\s]?\d{4}/g;
      const scrub = (text) => {
        return text.replace(emailPattern, "[EMAIL]").replace(phonePattern, "[PHONE]").replace(ssnPattern, "[SSN]");
      };
      return {
        ...metadata,
        labelText: scrub(metadata.labelText),
        placeholder: scrub(metadata.placeholder),
        options: metadata.options.map(scrub),
        ariaLabel: scrub(metadata.ariaLabel),
        surroundingText: scrub(metadata.surroundingText),
        ancestorCandidates: metadata.ancestorCandidates.map((c) => ({
          ...c,
          text: scrub(c.text)
        }))
      };
    }
    buildBatchPrompt(metadataList, filledFields, pageContext, fewShotExamples) {
      const taxonomyList = this.buildTaxonomyList();
      const fieldsDescription = metadataList.map((metadata) => `[Field ${metadata.index}]
${this.formatMetadataContext(metadata)}`).join("\n\n");
      const contextSections = [];
      if (pageContext) {
        const pageSection = [
          "## Page Context",
          `- Title: ${pageContext.title}`,
          `- URL Path: ${pageContext.urlPath}`,
          pageContext.keywords.length > 0 ? `- Keywords: ${pageContext.keywords.join(", ")}` : ""
        ].filter(Boolean).join("\n");
        contextSections.push(pageSection);
      }
      if (filledFields && filledFields.length > 0) {
        const filledSection = [
          "## Form State (already classified fields)",
          ...filledFields.slice(0, 10).map(
            (f) => `- "${f.labelText}" → ${f.type}${f.value ? ` (value: ${f.value})` : ""}`
          )
        ].join("\n");
        contextSections.push(filledSection);
      }
      if (fewShotExamples && fewShotExamples.length > 0) {
        const exampleSection = [
          "## Past Examples (from user history)",
          ...fewShotExamples.map(
            (ex) => `- Label "${ex.labelText}" → ${ex.type} (confidence: ${ex.confidence.toFixed(2)})`
          )
        ].join("\n");
        contextSections.push(exampleSection);
      }
      const contextBlock = contextSections.length > 0 ? `${contextSections.join("\n\n")}

` : "";
      return `Classify these ${metadataList.length} form fields. Available types:

${taxonomyList}

${contextBlock}Fields to classify:

${fieldsDescription}

Return a JSON array with classification for each field:
[{"index": 0, "type": "TYPE_NAME", "confidence": 0.0-1.0}, ...]

Rules:
- Use UNKNOWN with confidence 0 if uncertain
- Each field must have an entry in the response
- Confidence should reflect how certain you are about the classification
- Pay attention to the "Ancestor text" - it often contains the question being asked
- Use the Page Context and Form State to understand field relationships
- Learn from Past Examples to match similar field patterns`;
    }
    buildSinglePrompt(metadata) {
      const taxonomyList = this.buildTaxonomyList();
      const contextParts = this.formatMetadataContext(metadata);
      return `Classify this form field. Available types:

${taxonomyList}

Field context:
${contextParts}

Return JSON only: {"type": "TYPE_NAME", "confidence": 0.0-1.0}
If uncertain: {"type": "UNKNOWN", "confidence": 0}
Note: "Ancestor text candidates" shows text found in parent elements - this often contains the actual question.`;
    }
    buildTaxonomyList() {
      return Object.entries(TAXONOMY_DESCRIPTIONS).filter(([key]) => key !== "UNKNOWN").map(([key, desc]) => `- ${key}: ${desc}`).join("\n");
    }
    formatMetadataContext(metadata) {
      const parts = [];
      if (metadata.tagName) parts.push(`Element: <${metadata.tagName}>`);
      if (metadata.type) parts.push(`Type: ${metadata.type}`);
      if (metadata.name) parts.push(`Name: ${metadata.name}`);
      if (metadata.id) parts.push(`ID: ${metadata.id}`);
      if (metadata.labelText) parts.push(`Label: ${metadata.labelText}`);
      if (metadata.placeholder) parts.push(`Placeholder: ${metadata.placeholder}`);
      if (metadata.sectionTitle) parts.push(`Section: ${metadata.sectionTitle}`);
      if (metadata.ariaLabel) parts.push(`ARIA: ${metadata.ariaLabel}`);
      if (metadata.options.length > 0) parts.push(`Options: ${metadata.options.join(", ")}`);
      if (metadata.ancestorCandidates.length > 0) {
        const candidatesStr = metadata.ancestorCandidates.slice(0, 3).map((c) => `[${c.type}@depth${c.depth}] ${c.text.slice(0, 100)}`).join("; ");
        parts.push(`Ancestor text: ${candidatesStr}`);
      } else if (metadata.surroundingText) {
        parts.push(`Context: ${metadata.surroundingText.slice(0, 100)}`);
      }
      return parts.join("\n");
    }
    async callLLMSingle(metadata) {
      const config = this.config;
      const prompt = this.buildSinglePrompt(metadata);
      if (config.provider === "anthropic") {
        return this.callAnthropicSingle(prompt);
      }
      return this.callOpenAICompatibleSingle(prompt);
    }
    async callOpenAICompatibleSingle(prompt) {
      const config = this.config;
      const endpoint = config.endpoint || PROVIDER_ENDPOINTS[config.provider] || PROVIDER_ENDPOINTS.openai;
      const model = config.model || DEFAULT_MODELS[config.provider] || "gpt-4o-mini";
      const needsStream = config.provider === "zhipu" || model.startsWith("glm-4");
      const requestBody = {
        model,
        messages: [
          { role: "system", content: "You are a form field classifier. Respond only with valid JSON." },
          { role: "user", content: prompt }
        ],
        temperature: 0,
        max_tokens: 100
      };
      if (needsStream) {
        requestBody.stream = true;
      }
      if (config.disableThinking) {
        requestBody.enable_thinking = false;
        requestBody.thinking = { type: "disabled" };
      }
      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${config.apiKey}`
        },
        body: JSON.stringify(requestBody)
      });
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`API error ${response.status}: ${errorText}`);
      }
      let content;
      if (needsStream) {
        content = await this.parseStreamResponse(response);
      } else {
        const data = await response.json();
        content = data.choices?.[0]?.message?.content || "";
      }
      return this.parseSingleResponse(content);
    }
    async callAnthropicSingle(prompt) {
      const config = this.config;
      const endpoint = config.endpoint || PROVIDER_ENDPOINTS.anthropic;
      const model = config.model || DEFAULT_MODELS.anthropic;
      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": config.apiKey,
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true"
        },
        body: JSON.stringify({
          model,
          max_tokens: 100,
          messages: [{ role: "user", content: prompt }]
        })
      });
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Anthropic API error ${response.status}: ${errorText}`);
      }
      const data = await response.json();
      const content = data.content?.[0]?.text || "";
      return this.parseSingleResponse(content);
    }
    /**
     * Call backend API for classification (uses user's credits)
     */
    async callBackendAPI(fields) {
      const token = await storage.auth.getAccessToken();
      if (!token) {
        throw new Error("Not logged in");
      }
      console.log(`[LLMParser] Calling backend API for ${fields.length} fields`);
      const response = await fetch(`${API_BASE_URL}/llm/classify`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ fields })
      });
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        if (response.status === 402) {
          throw new Error(`Insufficient credits: ${errorData.balance || 0} remaining`);
        }
        throw new Error(`Backend API error ${response.status}: ${errorData.error || "Unknown"}`);
      }
      const data = await response.json();
      if (!data.success || !Array.isArray(data.results)) {
        throw new Error("Invalid backend response");
      }
      console.log(`[LLMParser] Backend API success, used ${data.creditsUsed} credits`);
      return data.results;
    }
    async callOpenAICompatibleBatch(prompt) {
      const config = this.config;
      const endpoint = config.endpoint || PROVIDER_ENDPOINTS[config.provider] || PROVIDER_ENDPOINTS.openai;
      const model = config.model || DEFAULT_MODELS[config.provider] || "gpt-4o-mini";
      console.log(`[LLMParser] Calling ${config.provider} batch at ${endpoint} with model ${model}`);
      const needsStream = config.provider === "zhipu" || model.startsWith("glm-4");
      const requestBody = {
        model,
        messages: [
          { role: "system", content: "You are a form field classifier. Respond only with valid JSON array." },
          { role: "user", content: prompt }
        ],
        temperature: 0,
        max_tokens: 1e3
        // More tokens for batch response
      };
      if (needsStream) {
        requestBody.stream = true;
      }
      if (config.disableThinking) {
        requestBody.enable_thinking = false;
        requestBody.thinking = { type: "disabled" };
      }
      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${config.apiKey}`
        },
        body: JSON.stringify(requestBody)
      });
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`API error ${response.status}: ${errorText}`);
      }
      let content;
      if (needsStream) {
        content = await this.parseStreamResponse(response);
      } else {
        const data = await response.json();
        content = data.choices?.[0]?.message?.content || "";
      }
      return this.parseBatchResponse(content);
    }
    async callAnthropicBatch(prompt) {
      const config = this.config;
      const endpoint = config.endpoint || PROVIDER_ENDPOINTS.anthropic;
      const model = config.model || DEFAULT_MODELS.anthropic;
      console.log(`[LLMParser] Calling Anthropic batch at ${endpoint} with model ${model}`);
      const response = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": config.apiKey,
          "anthropic-version": "2023-06-01",
          "anthropic-dangerous-direct-browser-access": "true"
        },
        body: JSON.stringify({
          model,
          max_tokens: 1e3,
          messages: [{ role: "user", content: prompt }]
        })
      });
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Anthropic API error ${response.status}: ${errorText}`);
      }
      const data = await response.json();
      const content = data.content?.[0]?.text || "";
      return this.parseBatchResponse(content);
    }
    parseSingleResponse(content) {
      console.log("[LLMParser] Raw single response:", content);
      const parsed = parseJSONSafe(content, {});
      if (!parsed.type) {
        console.log("[LLMParser] No type found in response");
        return [];
      }
      const type = parsed.type;
      const confidence = Math.min(Math.max(parsed.confidence || 0.5, 0), 1);
      if (!Object.values(Taxonomy).includes(type) || type === Taxonomy.UNKNOWN) {
        return [];
      }
      return [{
        type,
        score: confidence * 0.85,
        reasons: [`LLM classification (${confidence.toFixed(2)} confidence)`]
      }];
    }
    parseBatchResponse(content) {
      console.log("[LLMParser] Raw batch response:", content);
      const parsed = parseJSONSafe(content, []);
      if (Array.isArray(parsed)) {
        console.log(`[LLMParser] Parsed ${parsed.length} classifications`);
        return parsed;
      }
      console.log("[LLMParser] Parsed result is not an array");
      return [];
    }
    /**
     * 解析流式响应 (SSE 格式)
     */
    async parseStreamResponse(response) {
      const reader = response.body?.getReader();
      if (!reader) {
        throw new Error("No response body");
      }
      const decoder = new TextDecoder();
      let content = "";
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          const chunk = decoder.decode(value, { stream: true });
          const lines = chunk.split("\n");
          for (const line of lines) {
            if (line.startsWith("data: ")) {
              const data = line.slice(6).trim();
              if (data === "[DONE]") continue;
              try {
                const json = JSON.parse(data);
                const delta = json.choices?.[0]?.delta?.content;
                if (delta) {
                  content += delta;
                }
              } catch {
              }
            }
          }
        }
      } finally {
        reader.releaseLock();
      }
      return content;
    }
    clearCache() {
      this.cache.clear();
    }
    resetConfig() {
      this.configLoaded = false;
      this.config = null;
    }
  }

  class AutocompleteParser {
    name = "AutocompleteParser";
    priority = 100;
    autocompleteMap = {
      "name": Taxonomy.FULL_NAME,
      "given-name": Taxonomy.FIRST_NAME,
      "family-name": Taxonomy.LAST_NAME,
      "email": Taxonomy.EMAIL,
      "tel": Taxonomy.PHONE,
      "tel-country-code": Taxonomy.COUNTRY_CODE,
      "address-level2": Taxonomy.CITY,
      "url": Taxonomy.PORTFOLIO
    };
    canParse(context) {
      const autocomplete = context.attributes.autocomplete;
      return !!autocomplete && autocomplete in this.autocompleteMap;
    }
    async parse(context) {
      const autocomplete = context.attributes.autocomplete;
      const type = this.autocompleteMap[autocomplete];
      if (type) {
        return [{
          type,
          score: 0.95,
          reasons: [`autocomplete="${autocomplete}"`]
        }];
      }
      return [];
    }
  }
  class TypeAttributeParser {
    name = "TypeAttributeParser";
    priority = 90;
    typeMap = {
      "email": Taxonomy.EMAIL,
      "tel": Taxonomy.PHONE,
      "date": Taxonomy.GRAD_DATE,
      "month": Taxonomy.GRAD_DATE,
      "url": Taxonomy.PORTFOLIO
    };
    canParse(context) {
      const type = context.attributes.type?.toLowerCase();
      return !!type && type in this.typeMap;
    }
    async parse(context) {
      const type = context.attributes.type?.toLowerCase();
      const taxonomy = this.typeMap[type || ""];
      if (taxonomy) {
        return [{
          type: taxonomy,
          score: 0.9,
          reasons: [`type="${type}"`]
        }];
      }
      return [];
    }
  }
  class NameIdParser {
    name = "NameIdParser";
    priority = 80;
    patterns = [
      { pattern: /full.?name|fullname/i, type: Taxonomy.FULL_NAME, score: 0.9 },
      { pattern: /first.?name|given.?name|fname/i, type: Taxonomy.FIRST_NAME, score: 0.9 },
      { pattern: /last.?name|family.?name|surname|lname/i, type: Taxonomy.LAST_NAME, score: 0.9 },
      { pattern: /^name$/i, type: Taxonomy.FULL_NAME, score: 0.85 },
      { pattern: /e.?mail/i, type: Taxonomy.EMAIL, score: 0.9 },
      { pattern: /phone|mobile|tel/i, type: Taxonomy.PHONE, score: 0.9 },
      { pattern: /country.?code/i, type: Taxonomy.COUNTRY_CODE, score: 0.85 },
      { pattern: /city|town/i, type: Taxonomy.CITY, score: 0.85 },
      { pattern: /linkedin/i, type: Taxonomy.LINKEDIN, score: 0.95 },
      { pattern: /github/i, type: Taxonomy.GITHUB, score: 0.95 },
      { pattern: /portfolio|website/i, type: Taxonomy.PORTFOLIO, score: 0.85 },
      { pattern: /school|university|college|institution/i, type: Taxonomy.SCHOOL, score: 0.9 },
      { pattern: /degree/i, type: Taxonomy.DEGREE, score: 0.85 },
      { pattern: /major|field.?of.?study|specialization/i, type: Taxonomy.MAJOR, score: 0.85 },
      { pattern: /grad.*date|graduation/i, type: Taxonomy.GRAD_DATE, score: 0.85 },
      { pattern: /grad.*year/i, type: Taxonomy.GRAD_YEAR, score: 0.85 },
      { pattern: /grad.*month/i, type: Taxonomy.GRAD_MONTH, score: 0.85 },
      { pattern: /start.?date/i, type: Taxonomy.START_DATE, score: 0.8 },
      { pattern: /end.?date/i, type: Taxonomy.END_DATE, score: 0.8 },
      { pattern: /authorized.?to.?work|work.?auth|legally.?authorized/i, type: Taxonomy.WORK_AUTH, score: 0.9 },
      { pattern: /sponsor|visa/i, type: Taxonomy.NEED_SPONSORSHIP, score: 0.9 },
      { pattern: /gender|sex/i, type: Taxonomy.EEO_GENDER, score: 0.9 },
      { pattern: /ethnic|race/i, type: Taxonomy.EEO_ETHNICITY, score: 0.9 },
      { pattern: /veteran|military/i, type: Taxonomy.EEO_VETERAN, score: 0.9 },
      { pattern: /disab/i, type: Taxonomy.EEO_DISABILITY, score: 0.9 },
      { pattern: /salary|compensation|pay/i, type: Taxonomy.SALARY, score: 0.85 },
      { pattern: /resume|cv/i, type: Taxonomy.RESUME_TEXT, score: 0.85 }
    ];
    canParse(_context) {
      return true;
    }
    async parse(context) {
      const name = context.attributes.name || "";
      const id = context.attributes.id || "";
      const combined = `${name} ${id}`.toLowerCase();
      const results = [];
      for (const { pattern, type, score } of this.patterns) {
        if (pattern.test(combined)) {
          results.push({
            type,
            score,
            reasons: [`name/id matches "${pattern.source}"`]
          });
        }
      }
      return results.sort((a, b) => b.score - a.score);
    }
  }
  class LabelParser {
    name = "LabelParser";
    priority = 70;
    patterns = [
      { pattern: /full\s*name|姓名|名字/i, type: Taxonomy.FULL_NAME, score: 0.85 },
      { pattern: /first\s*name|given\s*name|名/i, type: Taxonomy.FIRST_NAME, score: 0.85 },
      { pattern: /last\s*name|family\s*name|surname|姓/i, type: Taxonomy.LAST_NAME, score: 0.85 },
      { pattern: /email|邮箱|电子邮件/i, type: Taxonomy.EMAIL, score: 0.85 },
      { pattern: /phone|电话|手机/i, type: Taxonomy.PHONE, score: 0.85 },
      { pattern: /city|城市/i, type: Taxonomy.CITY, score: 0.8 },
      { pattern: /linkedin/i, type: Taxonomy.LINKEDIN, score: 0.9 },
      { pattern: /github/i, type: Taxonomy.GITHUB, score: 0.9 },
      { pattern: /school|university|学校|大学/i, type: Taxonomy.SCHOOL, score: 0.85 },
      { pattern: /degree|学历|学位/i, type: Taxonomy.DEGREE, score: 0.8 },
      { pattern: /major|专业/i, type: Taxonomy.MAJOR, score: 0.8 },
      { pattern: /graduation|毕业/i, type: Taxonomy.GRAD_DATE, score: 0.8 },
      { pattern: /authorized\s*to\s*work|work\s*authorization|工作授权/i, type: Taxonomy.WORK_AUTH, score: 0.85 },
      { pattern: /sponsorship|签证担保/i, type: Taxonomy.NEED_SPONSORSHIP, score: 0.85 },
      { pattern: /gender|性别/i, type: Taxonomy.EEO_GENDER, score: 0.85 },
      { pattern: /ethnicity|race|种族/i, type: Taxonomy.EEO_ETHNICITY, score: 0.85 },
      { pattern: /veteran|退伍/i, type: Taxonomy.EEO_VETERAN, score: 0.85 },
      { pattern: /disability|残疾/i, type: Taxonomy.EEO_DISABILITY, score: 0.85 }
    ];
    canParse(context) {
      return context.labelText.length > 0;
    }
    async parse(context) {
      const label = context.labelText.toLowerCase();
      const section = context.sectionTitle.toLowerCase();
      const combined = `${label} ${section}`;
      const results = [];
      for (const { pattern, type, score } of this.patterns) {
        if (pattern.test(combined)) {
          results.push({
            type,
            score: pattern.test(label) ? score : score * 0.9,
            reasons: [`label matches "${pattern.source}"`]
          });
        }
      }
      return results.sort((a, b) => b.score - a.score);
    }
  }
  const ruleParsers = [
    new AutocompleteParser(),
    new TypeAttributeParser(),
    new NameIdParser(),
    new LabelParser()
  ];
  const llmParser = new LLMParser();
  const parsers = [
    ...ruleParsers,
    llmParser
  ];
  function getParsers() {
    return [...parsers].sort((a, b) => b.priority - a.priority);
  }
  async function parseField(context, enableLogging = true) {
    const startTime = performance.now();
    const allResults = [];
    const sortedParsers = getParsers();
    const parserLogs = [];
    for (const parser of sortedParsers) {
      const parserStart = performance.now();
      const canParse = parser.canParse(context);
      if (canParse) {
        const results = await parser.parse(context);
        const parserTime = performance.now() - parserStart;
        parserLogs.push({
          parserName: parser.name,
          matched: results.length > 0,
          candidates: results.map((r) => ({
            type: r.type,
            score: r.score,
            reasons: r.reasons
          })),
          timeMs: parserTime
        });
        for (const result of results) {
          const existing = allResults.find((r) => r.type === result.type);
          if (existing) {
            if (result.score > existing.score) {
              existing.score = result.score;
              existing.reasons = [...existing.reasons, ...result.reasons];
            }
          } else {
            allResults.push(result);
          }
        }
      } else {
        const parserTime = performance.now() - parserStart;
        parserLogs.push({
          parserName: parser.name,
          matched: false,
          candidates: [],
          timeMs: parserTime
        });
      }
    }
    if (allResults.length === 0) {
      allResults.push({
        type: Taxonomy.UNKNOWN,
        score: 0,
        reasons: ["no match found"]
      });
    }
    const sortedResults = allResults.sort((a, b) => b.score - a.score);
    const totalTime = performance.now() - startTime;
    if (enableLogging) {
      const label = context.labelText || context.attributes.placeholder || context.attributes.name || "Unknown";
      const parseLog = {
        label,
        elementInfo: {
          tagName: context.element.tagName.toLowerCase(),
          type: context.attributes.type,
          name: context.attributes.name,
          id: context.attributes.id,
          autocomplete: context.attributes.autocomplete
        },
        parsers: parserLogs,
        finalResult: {
          type: sortedResults[0].type,
          score: sortedResults[0].score,
          reasons: sortedResults[0].reasons
        },
        totalTimeMs: totalTime
      };
      logParseField(parseLog);
    }
    return sortedResults;
  }
  async function parseFieldsBatch(contexts, enableLogging = true) {
    const startTime = performance.now();
    const results = /* @__PURE__ */ new Map();
    const fieldsNeedingLLM = [];
    console.log(`[Parser] Batch parsing ${contexts.length} fields`);
    for (let i = 0; i < contexts.length; i++) {
      const context = contexts[i];
      const fieldResults = [];
      for (const parser of ruleParsers) {
        if (parser.canParse(context)) {
          const parserResults = await parser.parse(context);
          for (const result of parserResults) {
            const existing = fieldResults.find((r) => r.type === result.type);
            if (existing) {
              if (result.score > existing.score) {
                existing.score = result.score;
                existing.reasons = [...existing.reasons, ...result.reasons];
              }
            } else {
              fieldResults.push(result);
            }
          }
        }
      }
      fieldResults.sort((a, b) => b.score - a.score);
      const bestResult = fieldResults[0];
      if (!bestResult || bestResult.type === Taxonomy.UNKNOWN || bestResult.score < 0.5) {
        fieldsNeedingLLM.push({ index: i, context });
        results.set(i, fieldResults.length > 0 ? fieldResults : [{
          type: Taxonomy.UNKNOWN,
          score: 0,
          reasons: ["pending LLM classification"]
        }]);
      } else {
        results.set(i, fieldResults);
      }
    }
    const ruleMatchedCount = contexts.length - fieldsNeedingLLM.length;
    console.log(`[Parser] Rule-based: ${ruleMatchedCount} matched, ${fieldsNeedingLLM.length} need LLM`);
    if (fieldsNeedingLLM.length > 0) {
      const llmContexts = fieldsNeedingLLM.map((f) => f.context);
      const llmResults = await llmParser.parseBatch(llmContexts);
      for (let i = 0; i < fieldsNeedingLLM.length; i++) {
        const { index } = fieldsNeedingLLM[i];
        const llmCandidates = llmResults.get(i) || [];
        if (llmCandidates.length > 0) {
          const existingResults = results.get(index) || [];
          const mergedResults = [...existingResults];
          for (const llmResult of llmCandidates) {
            const existing = mergedResults.find((r) => r.type === llmResult.type);
            if (existing) {
              if (llmResult.score > existing.score) {
                existing.score = llmResult.score;
                existing.reasons = [...existing.reasons, ...llmResult.reasons];
              }
            } else {
              mergedResults.push(llmResult);
            }
          }
          mergedResults.sort((a, b) => b.score - a.score);
          results.set(index, mergedResults);
        } else {
          const existingResults = results.get(index) || [];
          if (existingResults.length === 0 || existingResults[0].type === Taxonomy.UNKNOWN) {
            results.set(index, [{
              type: Taxonomy.UNKNOWN,
              score: 0,
              reasons: ["no match from rules or LLM"]
            }]);
          }
        }
      }
    }
    const totalTime = performance.now() - startTime;
    console.log(`[Parser] Batch parsing complete in ${totalTime.toFixed(1)}ms`);
    if (enableLogging) {
      for (let i = 0; i < contexts.length; i++) {
        const context = contexts[i];
        const fieldResults = results.get(i) || [];
        const label = context.labelText || context.attributes.placeholder || context.attributes.name || "Unknown";
        const parseLog = {
          label,
          elementInfo: {
            tagName: context.element.tagName.toLowerCase(),
            type: context.attributes.type,
            name: context.attributes.name,
            id: context.attributes.id,
            autocomplete: context.attributes.autocomplete
          },
          parsers: [],
          // Batch mode doesn't track individual parser logs
          finalResult: {
            type: fieldResults[0]?.type || Taxonomy.UNKNOWN,
            score: fieldResults[0]?.score || 0,
            reasons: fieldResults[0]?.reasons || ["no match"]
          },
          totalTimeMs: totalTime / contexts.length
          // Average time per field
        };
        logParseField(parseLog);
      }
    }
    return results;
  }

  const MONTH_NAMES = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
  ];
  const MONTH_SHORT = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
  ];
  class NameTransformer {
    name = "NameTransformer";
    sourceType = Taxonomy.FULL_NAME;
    targetTypes = [Taxonomy.FULL_NAME, Taxonomy.FIRST_NAME, Taxonomy.LAST_NAME];
    canTransform(sourceValue, _targetContext) {
      return sourceValue.length > 0;
    }
    transform(sourceValue, targetContext) {
      const targetType = this.detectTargetType(targetContext);
      const isChinese = /[\u4e00-\u9fa5]/.test(sourceValue);
      if (targetType === Taxonomy.FULL_NAME) {
        return sourceValue;
      }
      if (isChinese) {
        const chars = sourceValue.trim();
        if (targetType === Taxonomy.LAST_NAME) {
          return chars.charAt(0);
        }
        if (targetType === Taxonomy.FIRST_NAME) {
          return chars.slice(1);
        }
      } else {
        const parts = sourceValue.trim().split(/\s+/);
        if (targetType === Taxonomy.FIRST_NAME) {
          return parts[0] || "";
        }
        if (targetType === Taxonomy.LAST_NAME) {
          return parts[parts.length - 1] || "";
        }
      }
      return sourceValue;
    }
    detectTargetType(context) {
      const combined = `${context.labelText} ${context.attributes.name || ""} ${context.attributes.id || ""}`.toLowerCase();
      if (/first.?name|given.?name|名/.test(combined)) {
        return Taxonomy.FIRST_NAME;
      }
      if (/last.?name|family.?name|sur.?name|姓/.test(combined)) {
        return Taxonomy.LAST_NAME;
      }
      return Taxonomy.FULL_NAME;
    }
  }
  class DateTransformer {
    name = "DateTransformer";
    sourceType = Taxonomy.GRAD_DATE;
    targetTypes = [Taxonomy.GRAD_DATE, Taxonomy.GRAD_YEAR, Taxonomy.GRAD_MONTH];
    canTransform(sourceValue, _targetContext) {
      return sourceValue.length > 0;
    }
    transform(sourceValue, targetContext) {
      const parsed = this.parseDate(sourceValue);
      if (!parsed) return sourceValue;
      const targetFormat = this.detectTargetFormat(targetContext);
      return this.formatDate(parsed, targetFormat, targetContext);
    }
    parseDate(value) {
      const isoMatch = value.match(/^(\d{4})-(\d{2})(?:-(\d{2}))?$/);
      if (isoMatch) {
        return {
          year: parseInt(isoMatch[1]),
          month: parseInt(isoMatch[2]),
          day: isoMatch[3] ? parseInt(isoMatch[3]) : void 0
        };
      }
      const usMatch = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
      if (usMatch) {
        return {
          month: parseInt(usMatch[1]),
          day: parseInt(usMatch[2]),
          year: parseInt(usMatch[3])
        };
      }
      const yearOnly = value.match(/^(\d{4})$/);
      if (yearOnly) {
        return { year: parseInt(yearOnly[1]) };
      }
      return null;
    }
    detectTargetFormat(context) {
      const type = context.attributes.type?.toLowerCase();
      const name = (context.attributes.name || "").toLowerCase();
      const label = context.labelText.toLowerCase();
      if (type === "date") return "iso";
      if (type === "month") return "month-input";
      if (context.widgetSignature.kind === "select") {
        const options = context.optionsText.join(" ").toLowerCase();
        const allMonthPatterns = [...MONTH_NAMES, ...MONTH_SHORT];
        if (allMonthPatterns.some((m) => options.includes(m.toLowerCase()))) {
          return "month-name";
        }
        if (context.optionsText.some((opt) => /^(0?[1-9]|1[0-2])$/.test(opt.trim()))) {
          return "month-number";
        }
        if (/^\d{4}$/.test(context.optionsText[0] || "")) {
          return "year-only";
        }
      }
      if (/year|年/.test(name) || /year|年/.test(label)) return "year-only";
      if (/month|月/.test(name) || /month|月/.test(label)) return "month-only";
      return "iso";
    }
    formatDate(date, format, context) {
      const { year, month, day } = date;
      const m = month || 1;
      const d = day || 1;
      switch (format) {
        case "iso":
          return `${year}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
        case "us":
          return `${String(m).padStart(2, "0")}/${String(d).padStart(2, "0")}/${year}`;
        case "month-input":
          return `${year}-${String(m).padStart(2, "0")}`;
        case "year-only":
          return String(year);
        case "month-only":
          return String(m);
        case "month-name":
          return this.matchMonthOption(m, context);
        case "month-number":
          return this.matchMonthNumber(m, context);
        case "month-year":
          return `${MONTH_NAMES[m - 1]} ${year}`;
        default:
          return `${year}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
      }
    }
    matchMonthOption(month, context) {
      if (!context?.optionsText?.length) {
        return MONTH_NAMES[month - 1] || String(month);
      }
      const opts = context.optionsText;
      const optsLower = opts.map((o) => o.toLowerCase());
      const fullName = MONTH_NAMES[month - 1];
      const shortName = MONTH_SHORT[month - 1];
      const fullMatch = optsLower.findIndex((o) => o === fullName.toLowerCase());
      if (fullMatch !== -1) return opts[fullMatch];
      const shortMatch = optsLower.findIndex((o) => o === shortName.toLowerCase());
      if (shortMatch !== -1) return opts[shortMatch];
      const numMatch = opts.findIndex((o) => o === String(month) || o === String(month).padStart(2, "0"));
      if (numMatch !== -1) return opts[numMatch];
      return fullName;
    }
    matchMonthNumber(month, context) {
      if (!context?.optionsText?.length) {
        return String(month);
      }
      const opts = context.optionsText;
      if (opts.includes(String(month))) return String(month);
      if (opts.includes(String(month).padStart(2, "0"))) return String(month).padStart(2, "0");
      return String(month);
    }
  }
  class PhoneTransformer {
    name = "PhoneTransformer";
    sourceType = Taxonomy.PHONE;
    targetTypes = [Taxonomy.PHONE, Taxonomy.COUNTRY_CODE];
    canTransform(sourceValue, _targetContext) {
      return this.parsePhone(sourceValue) !== null;
    }
    transform(sourceValue, targetContext) {
      const parsed = this.parsePhone(sourceValue);
      if (!parsed) return sourceValue;
      const targetFormat = this.detectTargetFormat(targetContext);
      return this.formatPhone(parsed, targetFormat);
    }
    parsePhone(value) {
      const cleaned = value.replace(/[\s\-\(\)\.]/g, "");
      const e164Match = cleaned.match(/^\+(\d{1,3})(\d{10})$/);
      if (e164Match) {
        return { countryCode: e164Match[1], number: e164Match[2] };
      }
      const withCountry = cleaned.match(/^\+(\d{1,3})(\d{7,15})$/);
      if (withCountry) {
        return { countryCode: withCountry[1], number: withCountry[2] };
      }
      const localMatch = cleaned.match(/^(\d{10,11})$/);
      if (localMatch) {
        return { number: localMatch[1] };
      }
      return null;
    }
    detectTargetFormat(context) {
      const name = (context.attributes.name || "").toLowerCase();
      const label = context.labelText.toLowerCase();
      if (/country.?code|国家|区号/.test(name) || /country.?code|国家|区号/.test(label)) {
        return "country-only";
      }
      if (context.attributes.maxlength === "10" || /local|本地/.test(label)) {
        return "local-only";
      }
      const placeholder = context.attributes.placeholder || "";
      if (/\(\d{3}\)/.test(placeholder)) return "us-format";
      if (/\d{3}-\d{3}-\d{4}/.test(placeholder)) return "us-dashes";
      return "digits-only";
    }
    formatPhone(phone, format) {
      const { countryCode, number } = phone;
      switch (format) {
        case "e164":
          return countryCode ? `+${countryCode}${number}` : number;
        case "country-only":
          return countryCode ? `+${countryCode}` : "+1";
        case "local-only":
          return number;
        case "digits-only":
          return number;
        case "us-format":
          if (number.length === 10) {
            return `(${number.slice(0, 3)}) ${number.slice(3, 6)}-${number.slice(6)}`;
          }
          return number;
        case "us-dashes":
          if (number.length === 10) {
            return `${number.slice(0, 3)}-${number.slice(3, 6)}-${number.slice(6)}`;
          }
          return number;
        case "international":
          return countryCode ? `+${countryCode} ${number}` : number;
        default:
          return number;
      }
    }
  }
  class BooleanTransformer {
    name = "BooleanTransformer";
    sourceType = Taxonomy.WORK_AUTH;
    targetTypes = [Taxonomy.WORK_AUTH, Taxonomy.NEED_SPONSORSHIP];
    trueValues = ["yes", "true", "1", "on", "是", "authorized", "i agree", "i confirm"];
    falseValues = ["no", "false", "0", "off", "否", "not authorized", "i decline"];
    canTransform(sourceValue, _targetContext) {
      const normalized = sourceValue.toLowerCase().trim();
      return this.trueValues.includes(normalized) || this.falseValues.includes(normalized);
    }
    transform(sourceValue, targetContext) {
      const normalized = sourceValue.toLowerCase().trim();
      const isTrue = this.trueValues.includes(normalized);
      if (targetContext.widgetSignature.kind === "checkbox") {
        return isTrue ? "true" : "false";
      }
      const options = targetContext.optionsText.map((o) => o.toLowerCase());
      if (isTrue) {
        for (const trueVal of this.trueValues) {
          const match = options.find((o) => o.includes(trueVal));
          if (match) return targetContext.optionsText[options.indexOf(match)];
        }
        return "Yes";
      } else {
        for (const falseVal of this.falseValues) {
          const match = options.find((o) => o.includes(falseVal));
          if (match) return targetContext.optionsText[options.indexOf(match)];
        }
        return "No";
      }
    }
  }
  class DegreeTransformer {
    name = "DegreeTransformer";
    sourceType = Taxonomy.DEGREE;
    targetTypes = [Taxonomy.DEGREE];
    degreeAliases = {
      "bachelor's": ["bachelor", "bs", "ba", "bsc", "undergraduate", "本科", "学士"],
      "master's": ["master", "ms", "ma", "msc", "graduate", "硕士", "研究生"],
      "ph.d.": ["phd", "doctorate", "doctoral", "博士"],
      "associate": ["associate", "aa", "as", "专科", "大专"],
      "high school": ["high school", "hs", "高中"]
    };
    canTransform(sourceValue, _targetContext) {
      return sourceValue.length > 0;
    }
    transform(sourceValue, targetContext) {
      const normalized = sourceValue.toLowerCase().trim();
      const options = targetContext.optionsText.filter((o) => o.trim().length > 0);
      if (options.length === 0) return sourceValue;
      let matchedKey = null;
      for (const [key, aliases] of Object.entries(this.degreeAliases)) {
        if (key === normalized || aliases.some((a) => normalized.includes(a) || a.includes(normalized))) {
          matchedKey = key;
          break;
        }
      }
      if (!matchedKey) return sourceValue;
      const allAliases = [matchedKey, ...this.degreeAliases[matchedKey] || []];
      for (const option of options) {
        const optLower = option.toLowerCase();
        if (allAliases.some((alias) => optLower.includes(alias) || alias.includes(optLower))) {
          return option;
        }
      }
      return sourceValue;
    }
  }
  const transformers = [
    new NameTransformer(),
    new DateTransformer(),
    new PhoneTransformer(),
    new BooleanTransformer(),
    new DegreeTransformer()
  ];
  function transformValue(sourceValue, sourceType, targetContext, enableLogging = false) {
    const result = transformValueWithLog(sourceValue, sourceType, targetContext, enableLogging);
    return result.value;
  }
  function transformValueWithLog(sourceValue, sourceType, targetContext, enableLogging = false) {
    const logs = [];
    const targetType = detectTargetType(targetContext, sourceType);
    for (const transformer of transformers) {
      if (transformer.sourceType === sourceType || transformer.targetTypes.includes(sourceType)) {
        const canTransform = transformer.canTransform(sourceValue, targetContext);
        const log = {
          transformerName: transformer.name,
          sourceType,
          targetType,
          sourceValue,
          canTransform
        };
        if (canTransform) {
          const transformedValue = transformer.transform(sourceValue, targetContext);
          log.transformedValue = transformedValue;
          log.detectedFormat = detectFormat(transformer.name, targetContext);
          logs.push(log);
          if (enableLogging) {
            logTransformAttempt(log);
          }
          return { value: transformedValue, transformed: true, logs };
        }
        logs.push(log);
        if (enableLogging) {
          logTransformAttempt(log);
        }
      }
    }
    return { value: sourceValue, transformed: false, logs };
  }
  function detectTargetType(context, fallback) {
    const combined = `${context.labelText} ${context.attributes.name || ""} ${context.attributes.id || ""}`.toLowerCase();
    if (/first.?name|given.?name/.test(combined)) return "FIRST_NAME";
    if (/last.?name|family.?name/.test(combined)) return "LAST_NAME";
    if (/year|年/.test(combined)) return "GRAD_YEAR";
    if (/month|月/.test(combined)) return "GRAD_MONTH";
    if (/country.?code|区号/.test(combined)) return "COUNTRY_CODE";
    return fallback;
  }
  function detectFormat(transformerName, context) {
    if (transformerName === "DateTransformer") {
      const type = context.attributes.type?.toLowerCase();
      if (type === "date") return "ISO date";
      if (type === "month") return "month input";
      if (context.widgetSignature.kind === "select") return "select dropdown";
      return "text";
    }
    if (transformerName === "PhoneTransformer") {
      const placeholder = context.attributes.placeholder || "";
      if (/\(\d{3}\)/.test(placeholder)) return "US format (xxx) xxx-xxxx";
      if (/\d{3}-\d{3}-\d{4}/.test(placeholder)) return "US dashes xxx-xxx-xxxx";
      return "digits only";
    }
    if (transformerName === "NameTransformer") {
      return "name split";
    }
    return void 0;
  }

  function createFillSnapshot(element) {
    const snapshot = {};
    if (element instanceof HTMLInputElement) {
      if (element.type === "checkbox" || element.type === "radio") {
        snapshot.checked = element.checked;
      } else {
        snapshot.value = element.value;
      }
    } else if (element instanceof HTMLSelectElement) {
      snapshot.selectedIndex = element.selectedIndex;
      snapshot.value = element.value;
    } else if (element instanceof HTMLTextAreaElement) {
      snapshot.value = element.value;
    }
    return snapshot;
  }
  function restoreSnapshot(element, snapshot) {
    if (element instanceof HTMLInputElement) {
      if (element.type === "checkbox" || element.type === "radio") {
        if (snapshot.checked !== void 0) {
          element.checked = snapshot.checked;
          dispatchEvents(element, ["change"]);
        }
      } else {
        if (snapshot.value !== void 0) {
          setInputValue(element, snapshot.value);
        }
      }
    } else if (element instanceof HTMLSelectElement) {
      if (snapshot.selectedIndex !== void 0) {
        element.selectedIndex = snapshot.selectedIndex;
        dispatchEvents(element, ["change"]);
      }
    } else if (element instanceof HTMLTextAreaElement) {
      if (snapshot.value !== void 0) {
        setInputValue(element, snapshot.value);
      }
    }
  }
  function setInputValue(element, value) {
    const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
      element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype,
      "value"
    )?.set;
    if (nativeInputValueSetter) {
      nativeInputValueSetter.call(element, value);
    } else {
      element.value = value;
    }
    dispatchEvents(element, ["input", "change"]);
  }
  function dispatchEvents(element, eventTypes) {
    for (const type of eventTypes) {
      const event = new Event(type, { bubbles: true, cancelable: true });
      element.dispatchEvent(event);
    }
  }
  async function fillText(element, value) {
    const previousValue = element.value;
    try {
      setInputValue(element, value);
      return {
        success: true,
        element,
        previousValue,
        newValue: value
      };
    } catch (error) {
      return {
        success: false,
        element,
        previousValue,
        newValue: value,
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
  async function fillSelect(element, value, label = "") {
    const startTime = performance.now();
    const previousValue = element.value;
    const normalizedValue = value.toLowerCase().trim();
    let strategy = "none";
    let matchedOption;
    try {
      let matched = false;
      for (const option of element.options) {
        if (option.value.toLowerCase() === normalizedValue) {
          element.value = option.value;
          matched = true;
          strategy = "exact-value";
          matchedOption = option.value;
          break;
        }
      }
      if (!matched) {
        for (const option of element.options) {
          const optionText = option.textContent?.toLowerCase().trim() || "";
          if (optionText === normalizedValue) {
            element.value = option.value;
            matched = true;
            strategy = "exact-text";
            matchedOption = option.textContent || option.value;
            break;
          }
        }
      }
      if (!matched) {
        for (const option of element.options) {
          const optionText = option.textContent?.toLowerCase().trim() || "";
          if (optionText.includes(normalizedValue) || normalizedValue.includes(optionText)) {
            element.value = option.value;
            matched = true;
            strategy = "fuzzy-contains";
            matchedOption = option.textContent || option.value;
            break;
          }
        }
      }
      const executorLog = {
        fieldLabel: label,
        widgetKind: "select",
        strategy,
        targetValue: value,
        matchedOption,
        success: matched,
        error: matched ? void 0 : `No matching option found for "${value}"`,
        timeMs: performance.now() - startTime
      };
      if (!matched) {
        return {
          success: false,
          element,
          previousValue,
          newValue: value,
          error: `No matching option found for "${value}"`,
          executorLog
        };
      }
      dispatchEvents(element, ["change"]);
      return {
        success: true,
        element,
        previousValue,
        newValue: element.value,
        executorLog
      };
    } catch (error) {
      return {
        success: false,
        element,
        previousValue,
        newValue: value,
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
  async function fillRadio(element, value) {
    const name = element.getAttribute("name");
    const previousValue = element.checked ? element.value : "";
    const normalizedValue = value.toLowerCase().trim();
    try {
      const radios = name ? document.querySelectorAll(`input[type="radio"][name="${name}"]`) : [element];
      let matched = false;
      for (const radio of radios) {
        const radioValue = radio.value.toLowerCase();
        const isMatch = radioValue === normalizedValue || normalizedValue === "true" && radioValue === "yes" || normalizedValue === "false" && radioValue === "no" || normalizedValue === "yes" && radioValue === "true" || normalizedValue === "no" && radioValue === "false";
        if (isMatch) {
          radio.checked = true;
          radio.click();
          dispatchEvents(radio, ["change"]);
          matched = true;
          break;
        }
      }
      if (!matched) {
        return {
          success: false,
          element,
          previousValue,
          newValue: value,
          error: `No matching radio option found for "${value}"`
        };
      }
      return {
        success: true,
        element,
        previousValue,
        newValue: value
      };
    } catch (error) {
      return {
        success: false,
        element,
        previousValue,
        newValue: value,
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
  async function fillCheckbox(element, value) {
    const previousValue = element.checked ? "true" : "false";
    const normalizedValue = value.toLowerCase().trim();
    const shouldCheck = ["true", "yes", "1", "on", "checked"].includes(normalizedValue);
    try {
      if (element.checked !== shouldCheck) {
        element.click();
        dispatchEvents(element, ["change"]);
      }
      return {
        success: true,
        element,
        previousValue,
        newValue: shouldCheck ? "true" : "false"
      };
    } catch (error) {
      return {
        success: false,
        element,
        previousValue,
        newValue: value,
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
  async function fillCombobox(element, value) {
    const previousValue = element.value;
    try {
      element.focus();
      await new Promise((resolve) => setTimeout(resolve, 50));
      setInputValue(element, value);
      await new Promise((resolve) => setTimeout(resolve, 100));
      const combobox = element.closest('[role="combobox"]');
      const listboxId = element.getAttribute("aria-controls");
      const listbox = listboxId ? document.getElementById(listboxId) : combobox?.querySelector('[role="listbox"]');
      if (listbox) {
        const options = listbox.querySelectorAll('[role="option"]');
        const normalizedValue = value.toLowerCase();
        for (const option of options) {
          const optionText = option.textContent?.toLowerCase() || "";
          if (optionText.includes(normalizedValue) || normalizedValue.includes(optionText)) {
            option.click();
            break;
          }
        }
      }
      return {
        success: true,
        element,
        previousValue,
        newValue: element.value
      };
    } catch (error) {
      return {
        success: false,
        element,
        previousValue,
        newValue: value,
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
  async function fillField(context, value, enableLogging = false) {
    const startTime = performance.now();
    const { element, widgetSignature, labelText } = context;
    let result;
    switch (widgetSignature.kind) {
      case "text":
      case "textarea":
      case "date":
        result = await fillText(element, value);
        result.executorLog = {
          fieldLabel: labelText,
          widgetKind: widgetSignature.kind,
          strategy: "direct-set",
          targetValue: value,
          success: result.success,
          error: result.error,
          timeMs: performance.now() - startTime
        };
        break;
      case "select":
        result = await fillSelect(element, value, labelText);
        break;
      case "radio":
        result = await fillRadio(element, value);
        result.executorLog = {
          fieldLabel: labelText,
          widgetKind: "radio",
          strategy: "value-match",
          targetValue: value,
          success: result.success,
          error: result.error,
          timeMs: performance.now() - startTime
        };
        break;
      case "checkbox":
        result = await fillCheckbox(element, value);
        result.executorLog = {
          fieldLabel: labelText,
          widgetKind: "checkbox",
          strategy: "boolean-check",
          targetValue: value,
          success: result.success,
          error: result.error,
          timeMs: performance.now() - startTime
        };
        break;
      case "combobox":
        result = await fillCombobox(element, value);
        result.executorLog = {
          fieldLabel: labelText,
          widgetKind: "combobox",
          strategy: "type-and-select",
          targetValue: value,
          success: result.success,
          error: result.error,
          timeMs: performance.now() - startTime
        };
        break;
      default:
        result = {
          success: false,
          element,
          previousValue: "",
          newValue: value,
          error: `Unsupported widget kind: ${widgetSignature.kind}`,
          executorLog: {
            fieldLabel: labelText,
            widgetKind: widgetSignature.kind,
            strategy: "unsupported",
            targetValue: value,
            success: false,
            error: `Unsupported widget kind: ${widgetSignature.kind}`,
            timeMs: performance.now() - startTime
          }
        };
    }
    if (enableLogging && result.executorLog) {
      logExecutor(result.executorLog);
    }
    return result;
  }
  async function fillTextAnimated(element, value, charDelay, onProgress) {
    const previousValue = element.value;
    try {
      element.focus();
      const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
        element instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype,
        "value"
      )?.set;
      for (let i = 0; i <= value.length; i++) {
        const partialValue = value.substring(0, i);
        if (nativeInputValueSetter) {
          nativeInputValueSetter.call(element, partialValue);
        } else {
          element.value = partialValue;
        }
        element.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
        onProgress?.(i, value.length);
        if (i < value.length) {
          await new Promise((resolve) => setTimeout(resolve, charDelay));
        }
      }
      element.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
      return {
        success: true,
        element,
        previousValue,
        newValue: value
      };
    } catch (error) {
      return {
        success: false,
        element,
        previousValue,
        newValue: value,
        error: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
  function calculateCharDelay(plans, config) {
    const totalChars = plans.reduce((sum, p) => sum + p.value.length, 0);
    const totalFields = plans.length;
    const stageTime = config.stageDelays.scanning + config.stageDelays.thinking;
    const fieldDelayTime = totalFields * config.fieldDelay;
    const availableTime = config.maxDuration * 1e3 - stageTime - fieldDelayTime;
    if (totalChars === 0) return config.minCharDelay;
    const calculatedDelay = availableTime / totalChars;
    return Math.max(config.minCharDelay, Math.min(config.maxCharDelay, calculatedDelay));
  }
  async function executeFillPlanAnimated(plans, options = {}) {
    const {
      config = DEFAULT_FILL_ANIMATION_CONFIG,
      onProgress,
      enableLogging = false
    } = options;
    const results = [];
    const charDelay = calculateCharDelay(plans, config);
    for (let fieldIndex = 0; fieldIndex < plans.length; fieldIndex++) {
      const { context, value } = plans[fieldIndex];
      const { element, widgetSignature, labelText } = context;
      const startTime = performance.now();
      let result;
      if ((widgetSignature.kind === "text" || widgetSignature.kind === "textarea") && element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement) {
        const fillResult = await fillTextAnimated(
          element,
          value,
          charDelay,
          (currentChar, totalChars) => {
            onProgress?.(fieldIndex, plans.length, currentChar, totalChars, labelText);
          }
        );
        result = {
          ...fillResult,
          executorLog: {
            fieldLabel: labelText,
            widgetKind: widgetSignature.kind,
            strategy: "animated-typewriter",
            targetValue: value,
            success: fillResult.success,
            error: fillResult.error,
            timeMs: performance.now() - startTime
          }
        };
      } else {
        result = await fillField(context, value, enableLogging);
        onProgress?.(fieldIndex, plans.length, value.length, value.length, labelText);
      }
      results.push(result);
      if (enableLogging && result.executorLog) {
        logExecutor(result.executorLog);
      }
      if (fieldIndex < plans.length - 1) {
        await new Promise((resolve) => setTimeout(resolve, config.fieldDelay));
      }
    }
    return results;
  }

  function generateId() {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }
  function getSiteKey() {
    try {
      const url = new URL(window.location.href);
      return url.hostname;
    } catch {
      return "unknown";
    }
  }
  function hashOptions(options) {
    const normalized = options.map((o) => o.toLowerCase().trim()).sort().join("|");
    let hash = 0;
    for (let i = 0; i < normalized.length; i++) {
      const char = normalized.charCodeAt(i);
      hash = (hash << 5) - hash + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString(16);
  }
  function createQuestionKey(context, type) {
    const phrases = [];
    if (context.labelText) {
      phrases.push(context.labelText.toLowerCase().trim());
    }
    if (context.attributes["name"]) {
      phrases.push(context.attributes["name"].toLowerCase());
    }
    if (context.attributes["id"]) {
      phrases.push(context.attributes["id"].toLowerCase());
    }
    if (context.attributes["placeholder"]) {
      phrases.push(context.attributes["placeholder"].toLowerCase());
    }
    const sectionHints = [];
    if (context.sectionTitle) {
      sectionHints.push(context.sectionTitle.toLowerCase().trim());
    }
    let choiceSetHash;
    if (context.optionsText.length > 0) {
      choiceSetHash = hashOptions(context.optionsText);
    }
    return {
      id: generateId(),
      type,
      phrases: [...new Set(phrases)],
      sectionHints,
      choiceSetHash
    };
  }
  function createObservation(context, questionKey, answerId, _value, confidence) {
    return {
      id: generateId(),
      timestamp: Date.now(),
      siteKey: getSiteKey(),
      url: window.location.href,
      questionKeyId: questionKey.id,
      answerId,
      widgetSignature: context.widgetSignature,
      confidence
    };
  }
  function createPendingObservation(context, formId, classifiedType, rawValue, confidence) {
    const questionKey = createQuestionKey(context, classifiedType);
    return {
      id: generateId(),
      timestamp: Date.now(),
      siteKey: getSiteKey(),
      url: window.location.href,
      formId,
      questionKeyId: questionKey.id,
      fieldLocator: getFieldLocator(context.element),
      widgetSignature: context.widgetSignature,
      confidence,
      rawValue,
      classifiedType,
      status: "pending"
    };
  }
  function getFieldLocator(element) {
    if (element.id) return `#${element.id}`;
    if (element.getAttribute("name")) return `[name="${element.getAttribute("name")}"]`;
    return "";
  }
  function getFormId(element) {
    const form = element.closest("form");
    if (form) {
      if (form.id) return `form#${form.id}`;
      if (form.getAttribute("name")) return `form[name="${form.getAttribute("name")}"]`;
      if (form.action) return `form[action="${form.action}"]`;
    }
    return "default-form";
  }
  const SUBMIT_BUTTON_PATTERNS = /submit|next|continue|save|apply|下一步|提交|保存|继续/i;
  class Recorder {
    _isRecording = false;
    callbacks = [];
    pendingCallbacks = [];
    commitCallbacks = [];
    lastValues = /* @__PURE__ */ new Map();
    pendingStorage;
    boundHandleBlur;
    boundHandleChange;
    boundHandleSubmit;
    boundHandleClick;
    boundHandleBeforeUnload;
    constructor() {
      this.pendingStorage = storage.pendingObservations;
      this.boundHandleBlur = this.handleBlur.bind(this);
      this.boundHandleChange = this.handleChange.bind(this);
      this.boundHandleSubmit = this.handleSubmit.bind(this);
      this.boundHandleClick = this.handleClick.bind(this);
      this.boundHandleBeforeUnload = this.handleBeforeUnload.bind(this);
    }
    get isRecording() {
      return this._isRecording;
    }
    onObservation(callback) {
      this.callbacks.push(callback);
    }
    onPending(callback) {
      this.pendingCallbacks.push(callback);
    }
    onCommit(callback) {
      this.commitCallbacks.push(callback);
    }
    start() {
      if (this._isRecording) return;
      this._isRecording = true;
      document.addEventListener("blur", this.boundHandleBlur, true);
      document.addEventListener("change", this.boundHandleChange, true);
      document.addEventListener("submit", this.boundHandleSubmit, true);
      document.addEventListener("click", this.boundHandleClick, true);
      window.addEventListener("beforeunload", this.boundHandleBeforeUnload);
    }
    stop() {
      if (!this._isRecording) return;
      this._isRecording = false;
      document.removeEventListener("blur", this.boundHandleBlur, true);
      document.removeEventListener("change", this.boundHandleChange, true);
      document.removeEventListener("submit", this.boundHandleSubmit, true);
      document.removeEventListener("click", this.boundHandleClick, true);
      window.removeEventListener("beforeunload", this.boundHandleBeforeUnload);
      this.lastValues.clear();
    }
    async commitAllPending() {
      const formIds = this.pendingStorage.getFormIds();
      let totalCommitted = 0;
      for (const formId of formIds) {
        const count = await this.commitForm(formId);
        totalCommitted += count;
      }
      return totalCommitted;
    }
    getPendingCount() {
      return this.pendingStorage.getPendingCount();
    }
    handleBlur(event) {
      const target = event.target;
      if (!this.isFormField(target)) return;
      this.captureField(target);
    }
    handleChange(event) {
      const target = event.target;
      if (!this.isFormField(target)) return;
      if (target instanceof HTMLSelectElement || target instanceof HTMLInputElement && (target.type === "checkbox" || target.type === "radio")) {
        this.captureField(target);
      }
    }
    handleSubmit(event) {
      const form = event.target;
      if (form.tagName !== "FORM") return;
      const formId = getFormId(form.querySelector("input, select, textarea") || form);
      this.commitForm(formId);
    }
    handleClick(event) {
      const target = event.target;
      const button = target.closest('button, [type="submit"], [role="button"]');
      if (!button) return;
      const buttonText = button.textContent || "";
      const buttonType = button.getAttribute("type");
      if (buttonType === "submit" || SUBMIT_BUTTON_PATTERNS.test(buttonText)) {
        const formId = getFormId(button);
        setTimeout(() => this.commitForm(formId), 100);
      }
    }
    handleBeforeUnload(_event) {
      this.pendingStorage.discardAll();
    }
    async commitForm(formId) {
      const pending = this.pendingStorage.commit(formId);
      if (pending.length === 0) return 0;
      for (const p of pending) {
        const questionKey = {
          id: generateId(),
          type: p.classifiedType,
          phrases: [],
          sectionHints: []
        };
        const observation = createObservation(
          {
            element: document.createElement("div"),
            widgetSignature: p.widgetSignature
          },
          questionKey,
          generateId(),
          p.rawValue,
          p.confidence
        );
        for (const callback of this.callbacks) {
          callback(observation, p.rawValue, questionKey);
        }
      }
      for (const callback of this.commitCallbacks) {
        callback(pending.length);
      }
      return pending.length;
    }
    isFormField(element) {
      return element instanceof HTMLInputElement || element instanceof HTMLSelectElement || element instanceof HTMLTextAreaElement;
    }
    getFieldValue(element) {
      if (element instanceof HTMLInputElement) {
        if (element.type === "checkbox" || element.type === "radio") {
          return element.checked ? element.value || "true" : "";
        }
        return element.value;
      }
      if (element instanceof HTMLSelectElement) {
        return element.value;
      }
      if (element instanceof HTMLTextAreaElement) {
        return element.value;
      }
      return "";
    }
    captureField(element) {
      const value = this.getFieldValue(element);
      if (!value || value.trim() === "") return;
      const lastValue = this.lastValues.get(element);
      if (lastValue === value) return;
      this.lastValues.set(element, value);
      const context = extractFieldContext(element);
      const formId = getFormId(element);
      parseField(context).then((candidates) => {
        const bestCandidate = candidates[0];
        const pending = createPendingObservation(
          context,
          formId,
          bestCandidate.type,
          value,
          bestCandidate.score
        );
        this.pendingStorage.add(formId, pending);
        for (const callback of this.pendingCallbacks) {
          callback(pending);
        }
      });
    }
  }

  const FILL_METHOD_LABELS = {
    rule: "Rule-based",
    llm: "AI-classified",
    history: "From history",
    transform: "Transformed"
  };
  function getBadgeColor(state) {
    switch (state.type) {
      case "filled":
        return "green";
      case "suggest":
        return "blue";
      case "sensitive":
        return "gray";
      case "pending":
        return "yellow";
    }
  }
  function getBadgeIcon(state) {
    switch (state.type) {
      case "filled":
        return "✓";
      case "suggest":
        return "?";
      case "sensitive":
        return "⚠";
      case "pending":
        return "…";
    }
  }
  function getBadgeTooltip(state) {
    switch (state.type) {
      case "filled": {
        const base = "Auto-filled";
        if (state.source) {
          const method = FILL_METHOD_LABELS[state.source.method];
          const confidence = `${Math.round(state.source.confidence * 100)}%`;
          const reason = state.source.reason ? ` - ${state.source.reason}` : "";
          return `${base} (${method}, ${confidence}${reason})`;
        }
        return base;
      }
      case "suggest":
        return "Suggestions available";
      case "sensitive":
        return "Sensitive field - click to fill";
      case "pending":
        return "Pending save";
    }
  }

  const BADGE_CLASS = "autofiller-badge";
  const BADGE_DROPDOWN_CLASS = "autofiller-badge-dropdown";
  const BADGE_Z_INDEX = 2147483647;
  class BadgeManager {
    badges = /* @__PURE__ */ new Map();
    callbacks = {};
    styleInjected = false;
    constructor(callbacks = {}) {
      this.callbacks = callbacks;
    }
    showBadge(field, state) {
      this.injectStyles();
      const existing = this.badges.get(field.element);
      if (existing) {
        this.updateBadgeContent(existing, state, field);
        return;
      }
      const badge = this.createBadge(state, field);
      this.insertBadgeNextToElement(field.element, badge);
      this.badges.set(field.element, badge);
    }
    hideBadge(field) {
      const badge = this.badges.get(field.element);
      if (badge) {
        badge.remove();
        this.badges.delete(field.element);
      }
    }
    updateBadge(field, state) {
      const badge = this.badges.get(field.element);
      if (badge) {
        this.updateBadgeContent(badge, state, field);
      }
    }
    hideAll() {
      for (const badge of this.badges.values()) {
        badge.remove();
      }
      this.badges.clear();
    }
    createBadge(state, field) {
      const badge = document.createElement("span");
      badge.className = BADGE_CLASS;
      badge.setAttribute("data-state", state.type);
      this.updateBadgeContent(badge, state, field);
      return badge;
    }
    updateBadgeContent(badge, state, field) {
      const color = getBadgeColor(state);
      const icon = getBadgeIcon(state);
      const tooltip = getBadgeTooltip(state);
      badge.setAttribute("data-state", state.type);
      badge.setAttribute("data-color", color);
      badge.title = tooltip;
      badge.innerHTML = "";
      const iconSpan = document.createElement("span");
      iconSpan.className = "autofiller-badge-icon";
      iconSpan.textContent = icon;
      badge.appendChild(iconSpan);
      if (state.type === "filled" && state.canUndo) {
        const undoBtn = document.createElement("button");
        undoBtn.className = "autofiller-badge-undo";
        undoBtn.textContent = "×";
        undoBtn.title = "Undo";
        undoBtn.onclick = (e) => {
          e.stopPropagation();
          this.callbacks.onUndo?.(field);
          this.hideBadge(field);
        };
        badge.appendChild(undoBtn);
      }
      if (state.type === "suggest" || state.type === "sensitive") {
        badge.onclick = () => this.showDropdown(badge, state.candidates, field, state.sources);
      }
    }
    showDropdown(badge, candidates, field, sources) {
      const existingDropdown = badge.querySelector(`.${BADGE_DROPDOWN_CLASS}`);
      if (existingDropdown) {
        existingDropdown.remove();
        return;
      }
      const dropdown = document.createElement("div");
      dropdown.className = BADGE_DROPDOWN_CLASS;
      for (const candidate of candidates) {
        const item = document.createElement("button");
        item.className = "autofiller-badge-dropdown-item";
        item.textContent = candidate.display || candidate.value;
        const source = sources?.get(candidate.id);
        let tooltipText = `${candidate.type}: ${candidate.value}`;
        if (source) {
          const method = FILL_METHOD_LABELS[source.method];
          const confidence = `${Math.round(source.confidence * 100)}%`;
          tooltipText += `
(${method}, ${confidence})`;
          if (source.reason) {
            tooltipText += `
${source.reason}`;
          }
        }
        item.title = tooltipText;
        item.onclick = (e) => {
          e.stopPropagation();
          this.callbacks.onCandidateSelect?.(field, candidate);
          dropdown.remove();
          this.updateBadge(field, { type: "filled", answerId: candidate.id, canUndo: true, source });
        };
        dropdown.appendChild(item);
      }
      const dismissItem = document.createElement("button");
      dismissItem.className = "autofiller-badge-dropdown-item autofiller-badge-dismiss";
      dismissItem.textContent = "Dismiss";
      dismissItem.onclick = (e) => {
        e.stopPropagation();
        this.callbacks.onDismiss?.(field);
        this.hideBadge(field);
      };
      dropdown.appendChild(dismissItem);
      badge.appendChild(dropdown);
      const closeDropdown = (e) => {
        if (!dropdown.contains(e.target) && !badge.contains(e.target)) {
          dropdown.remove();
          document.removeEventListener("click", closeDropdown);
        }
      };
      setTimeout(() => document.addEventListener("click", closeDropdown), 0);
    }
    insertBadgeNextToElement(element, badge) {
      element.insertAdjacentElement("afterend", badge);
    }
    injectStyles() {
      if (this.styleInjected) return;
      this.styleInjected = true;
      const style = document.createElement("style");
      style.textContent = `
      .${BADGE_CLASS} {
        display: inline-flex;
        align-items: center;
        gap: 2px;
        padding: 2px 6px;
        border-radius: 10px;
        font-size: 12px;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        cursor: pointer;
        transition: all 0.15s ease;
        box-shadow: 0 1px 3px rgba(0,0,0,0.12);
        user-select: none;
        vertical-align: middle;
        margin-left: 4px;
        position: relative;
        z-index: ${BADGE_Z_INDEX};
      }
      
      .${BADGE_CLASS}[data-color="green"] {
        background: #dcfce7;
        color: #166534;
        border: 1px solid #86efac;
      }
      
      .${BADGE_CLASS}[data-color="blue"] {
        background: #dbeafe;
        color: #1e40af;
        border: 1px solid #93c5fd;
      }
      
      .${BADGE_CLASS}[data-color="gray"] {
        background: #f3f4f6;
        color: #374151;
        border: 1px solid #d1d5db;
      }
      
      .${BADGE_CLASS}[data-color="yellow"] {
        background: #fef3c7;
        color: #92400e;
        border: 1px solid #fcd34d;
      }
      
      .${BADGE_CLASS}:hover {
        transform: scale(1.05);
        box-shadow: 0 2px 6px rgba(0,0,0,0.15);
      }
      
      .autofiller-badge-icon {
        font-size: 11px;
      }
      
      .autofiller-badge-undo {
        background: none;
        border: none;
        padding: 0 2px;
        margin-left: 2px;
        cursor: pointer;
        opacity: 0.6;
        transition: opacity 0.15s;
        font-size: 14px;
        line-height: 1;
        color: inherit;
      }

      .${BADGE_CLASS}:hover .autofiller-badge-undo {
        opacity: 1;
      }

      .autofiller-badge-undo:hover {
        opacity: 1;
        color: #dc2626;
      }
      
      .${BADGE_DROPDOWN_CLASS} {
        position: absolute;
        top: 100%;
        left: 0;
        margin-top: 4px;
        background: white;
        border: 1px solid #e5e7eb;
        border-radius: 6px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        min-width: 150px;
        max-width: 250px;
        z-index: ${BADGE_Z_INDEX};
        overflow: hidden;
      }
      
      .autofiller-badge-dropdown-item {
        display: block;
        width: 100%;
        padding: 8px 12px;
        border: none;
        background: none;
        text-align: left;
        cursor: pointer;
        font-size: 13px;
        color: #374151;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      
      .autofiller-badge-dropdown-item:hover {
        background: #f3f4f6;
      }
      
      .autofiller-badge-dismiss {
        color: #6b7280;
        border-top: 1px solid #e5e7eb;
      }
    `;
      document.head.appendChild(style);
    }
  }

  const WIDGET_STYLES = `
@keyframes af-fadeIn {
  from { opacity: 0; transform: scale(0.95) translateY(10px); }
  to { opacity: 1; transform: scale(1) translateY(0); }
}
@keyframes af-slideIn {
  from { opacity: 0; transform: translateX(-10px); }
  to { opacity: 1; transform: translateX(0); }
}
@keyframes af-slideOut {
  from { opacity: 1; transform: translateX(0); }
  to { opacity: 0; transform: translateX(20px); }
}
@keyframes af-toastIn {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}
@keyframes af-checkBounce {
  0% { transform: scale(0); }
  50% { transform: scale(1.2); }
  100% { transform: scale(1); }
}
@keyframes af-spin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
@keyframes af-pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}
@keyframes af-typing {
  0% { opacity: 0.3; }
  50% { opacity: 1; }
  100% { opacity: 0.3; }
}
@keyframes af-stageIn {
  from { opacity: 0; transform: translateY(-8px); }
  to { opacity: 1; transform: translateY(0); }
}
@keyframes af-progressFill {
  from { width: 0%; }
  to { width: 100%; }
}
@keyframes af-dotBounce {
  0%, 80%, 100% { transform: scale(0); }
  40% { transform: scale(1); }
}

.af-animate-fadeIn { animation: af-fadeIn 0.3s ease-out forwards; }
.af-animate-slideIn { animation: af-slideIn 0.3s ease-out forwards; }
.af-animate-slideOut { animation: af-slideOut 0.3s ease-in forwards; }
.af-animate-toastIn { animation: af-toastIn 0.3s ease-out forwards; }
.af-animate-checkBounce { animation: af-checkBounce 0.4s ease-out forwards; }
.af-animate-spin { animation: af-spin 1s linear infinite; }
.af-animate-pulse { animation: af-pulse 1.5s ease-in-out infinite; }
.af-animate-typing { animation: af-typing 1s ease-in-out infinite; }
.af-animate-stageIn { animation: af-stageIn 0.3s ease-out forwards; }

.af-dot-bounce {
  display: inline-block;
  width: 6px;
  height: 6px;
  background: currentColor;
  border-radius: 50%;
  animation: af-dotBounce 1.4s infinite ease-in-out both;
}
.af-dot-bounce:nth-child(1) { animation-delay: -0.32s; }
.af-dot-bounce:nth-child(2) { animation-delay: -0.16s; }
.af-dot-bounce:nth-child(3) { animation-delay: 0s; }

.af-widget {
  position: fixed;
  bottom: 24px;
  right: 24px;
  z-index: 2147483647;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  font-size: 14px;
  line-height: 1.5;
}

.af-widget * {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

.af-widget button {
  cursor: pointer;
  border: none;
  background: none;
  font-family: inherit;
}

.af-hidden { display: none !important; }

.af-scrollbar::-webkit-scrollbar { width: 5px; }
.af-scrollbar::-webkit-scrollbar-track { background: transparent; }
.af-scrollbar::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 3px; }
.af-scrollbar::-webkit-scrollbar-thumb:hover { background: #cbd5e1; }

.af-btn-hover { transition: transform 0.15s; }
.af-btn-hover:hover { transform: scale(1.02); }
.af-btn-hover:active { transform: scale(0.98); }

.af-toast-container {
  position: fixed;
  bottom: 100px;
  right: 24px;
  z-index: 2147483646;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.af-toast {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 16px;
  border-radius: 12px;
  box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1);
  color: white;
  font-size: 14px;
}

.af-toast-success { background: #16a34a; }
.af-toast-warning { background: #f59e0b; }
.af-toast-info { background: #1f2937; }

.af-filling-popup {
  background: linear-gradient(135deg, #1e1b4b 0%, #312e81 100%);
  border-radius: 16px;
  box-shadow: 0 20px 40px -10px rgba(0,0,0,0.3);
  border: 1px solid rgba(129, 140, 248, 0.3);
  width: 280px;
  overflow: hidden;
  color: white;
}

.af-filling-header {
  padding: 20px 20px 16px;
  text-align: center;
}

.af-filling-stage {
  font-size: 22px;
  font-weight: 600;
  margin-bottom: 8px;
  min-height: 32px;
}

.af-filling-field {
  font-size: 13px;
  color: rgba(255,255,255,0.7);
  min-height: 20px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.af-filling-progress {
  padding: 0 20px 20px;
}

.af-progress-bar {
  height: 6px;
  background: rgba(255,255,255,0.2);
  border-radius: 3px;
  overflow: hidden;
}

.af-progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #818cf8, #c084fc);
  border-radius: 3px;
  transition: width 0.1s ease-out;
}

.af-filling-stats {
  display: flex;
  justify-content: space-between;
  margin-top: 12px;
  font-size: 11px;
  color: rgba(255,255,255,0.6);
}
`;

  let toastContainer = null;
  let toastIdCounter = 0;
  function ensureContainer() {
    if (toastContainer && document.body.contains(toastContainer)) {
      return toastContainer;
    }
    toastContainer = document.createElement("div");
    toastContainer.className = "af-toast-container";
    document.body.appendChild(toastContainer);
    return toastContainer;
  }
  function showToast(message, type = "info", undoCallbackOrOptions) {
    const container = ensureContainer();
    const id = ++toastIdCounter;
    let undoCallback;
    let options;
    if (typeof undoCallbackOrOptions === "function") {
      undoCallback = undoCallbackOrOptions;
    } else if (undoCallbackOrOptions) {
      options = undoCallbackOrOptions;
    }
    const toast = document.createElement("div");
    toast.id = `af-toast-${id}`;
    toast.className = `af-toast af-toast-${type} af-animate-toastIn`;
    const bgColors = {
      success: "#16a34a",
      warning: "#f59e0b",
      info: "#1f2937"
    };
    toast.style.cssText = `
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 16px;
    border-radius: 12px;
    box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1);
    color: white;
    font-size: 14px;
    background: ${bgColors[type]};
  `;
    const textSpan = document.createElement("span");
    textSpan.textContent = message;
    toast.appendChild(textSpan);
    if (type === "success" && undoCallback) {
      const undoBtn = document.createElement("button");
      undoBtn.textContent = "Undo";
      undoBtn.style.cssText = `
      color: rgba(255,255,255,0.8);
      text-decoration: underline;
      background: none;
      border: none;
      cursor: pointer;
      font-size: 14px;
    `;
      undoBtn.onmouseover = () => undoBtn.style.color = "white";
      undoBtn.onmouseout = () => undoBtn.style.color = "rgba(255,255,255,0.8)";
      undoBtn.onclick = () => {
        removeToast(id);
        undoCallback();
      };
      toast.appendChild(undoBtn);
    }
    if (options?.action) {
      const actionBtn = document.createElement("button");
      actionBtn.textContent = options.action.label;
      actionBtn.style.cssText = `
      color: white;
      background: rgba(255,255,255,0.2);
      border: none;
      border-radius: 6px;
      padding: 4px 12px;
      cursor: pointer;
      font-size: 13px;
      font-weight: 500;
    `;
      actionBtn.onmouseover = () => actionBtn.style.background = "rgba(255,255,255,0.3)";
      actionBtn.onmouseout = () => actionBtn.style.background = "rgba(255,255,255,0.2)";
      const handler = options.action.onClick;
      actionBtn.onclick = () => {
        removeToast(id);
        handler();
      };
      toast.appendChild(actionBtn);
    }
    const closeBtn = document.createElement("button");
    closeBtn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>`;
    closeBtn.style.cssText = `
    color: rgba(255,255,255,0.6);
    background: none;
    border: none;
    cursor: pointer;
    padding: 0;
    display: flex;
  `;
    closeBtn.onmouseover = () => closeBtn.style.color = "white";
    closeBtn.onmouseout = () => closeBtn.style.color = "rgba(255,255,255,0.6)";
    closeBtn.onclick = () => removeToast(id);
    toast.appendChild(closeBtn);
    container.appendChild(toast);
    setTimeout(() => removeToast(id), 5e3);
    return id;
  }
  function removeToast(id) {
    const toast = document.getElementById(`af-toast-${id}`);
    if (toast) {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(20px)";
      toast.style.transition = "all 0.3s ease-out";
      setTimeout(() => toast.remove(), 300);
    }
  }

  const TYPE_LABELS = {
    FULL_NAME: "Full Name",
    FIRST_NAME: "First Name",
    LAST_NAME: "Last Name",
    EMAIL: "Email",
    PHONE: "Phone",
    COUNTRY_CODE: "Country Code",
    SCHOOL: "School",
    DEGREE: "Degree",
    MAJOR: "Major",
    GPA: "GPA",
    GRAD_DATE: "Graduation Date",
    GRAD_YEAR: "Graduation Year",
    GRAD_MONTH: "Graduation Month",
    LINKEDIN: "LinkedIn",
    GITHUB: "GitHub",
    PORTFOLIO: "Portfolio",
    LOCATION: "Location",
    CITY: "City",
    COMPANY_NAME: "Company Name",
    JOB_TITLE: "Job Title",
    JOB_DESCRIPTION: "Job Description",
    START_DATE: "Start Date",
    END_DATE: "End Date",
    WORK_AUTH: "Work Authorization",
    NEED_SPONSORSHIP: "Need Sponsorship",
    EEO_GENDER: "Gender (EEO)",
    EEO_ETHNICITY: "Ethnicity (EEO)",
    EEO_VETERAN: "Veteran Status (EEO)",
    EEO_DISABILITY: "Disability (EEO)",
    GOV_ID: "Government ID",
    SALARY: "Salary",
    SUMMARY: "Summary",
    SKILLS: "Skills",
    UNKNOWN: "Unknown"
  };
  const TAXONOMY_OPTIONS = Object.entries(TYPE_LABELS).map(
    ([value, label]) => ({ value, label })
  );

  const STORAGE_KEY$1 = "userLocale";
  function detectBrowserLocale() {
    const lang = navigator.language || navigator.userLanguage || "en";
    return lang.toLowerCase().startsWith("zh") ? "zh" : "en";
  }
  let currentLocale = detectBrowserLocale();
  let userPreference = "auto";
  try {
    if (typeof chrome !== "undefined" && chrome.storage?.local) {
      chrome.storage.local.get(STORAGE_KEY$1).then((result) => {
        if (result[STORAGE_KEY$1]) {
          userPreference = result[STORAGE_KEY$1];
          currentLocale = userPreference === "auto" ? detectBrowserLocale() : userPreference;
        }
      }).catch(() => {
      });
    }
  } catch {
  }
  const messages = {
    // App
    "app.title": {
      en: "OneFillr",
      zh: "OneFillr"
    },
    // Language Settings
    "settings.language": {
      en: "Language",
      zh: "语言"
    },
    "settings.language.auto": {
      en: "Auto (Browser)",
      zh: "自动 (跟随浏览器)"
    },
    "settings.language.en": {
      en: "English",
      zh: "English"
    },
    "settings.language.zh": {
      en: "中文",
      zh: "中文"
    },
    // Tabs
    "tabs.localKnowledge": {
      en: "Local Database",
      zh: "本地知识库"
    },
    "tabs.import": {
      en: "Import",
      zh: "导入"
    },
    "tabs.thisSite": {
      en: "This Site",
      zh: "此网站"
    },
    "tabs.activity": {
      en: "Activity",
      zh: "活动"
    },
    "tabs.settings": {
      en: "Settings",
      zh: "设置"
    },
    "tabs.developer": {
      en: "Developer",
      zh: "开发者"
    },
    // Consent Modal
    "consent.title": {
      en: "Privacy Notice",
      zh: "隐私声明"
    },
    "consent.subtitle": {
      en: "Please understand how we handle your data before using",
      zh: "在使用前，请了解我们如何处理您的数据"
    },
    "consent.localStorage.title": {
      en: "Local Data Storage",
      zh: "本地数据存储"
    },
    "consent.localStorage.desc": {
      en: "Your form data is stored locally on your device. We do not automatically upload your personal information to any server.",
      zh: "您的表单数据存储在本地设备，不会自动上传到任何服务器。您完全掌控自己的数据。"
    },
    "consent.ai.title": {
      en: "AI Recognition (Optional)",
      zh: "AI 智能识别 (可选)"
    },
    "consent.ai.desc": {
      en: "When enabled, form field labels (not your data) may be sent to AI services to improve recognition accuracy.",
      zh: "启用后，表单字段标签（非您的数据）可能发送至 AI 服务以提高识别准确度。"
    },
    "consent.policyAck": {
      en: "I have read and agree to the",
      zh: "我已阅读并同意"
    },
    "consent.privacyPolicy": {
      en: "Privacy Policy",
      zh: "隐私政策"
    },
    "consent.decline": {
      en: "Decline",
      zh: "拒绝"
    },
    "consent.accept": {
      en: "Accept & Continue",
      zh: "同意并继续"
    },
    "consent.saving": {
      en: "Saving...",
      zh: "保存中..."
    },
    // Privacy Section
    "privacy.title": {
      en: "Privacy & Data",
      zh: "隐私与数据"
    },
    "privacy.policy": {
      en: "Privacy Policy",
      zh: "隐私政策"
    },
    "privacy.dataSummary": {
      en: "Local Data Summary",
      zh: "本地数据摘要"
    },
    "privacy.savedAnswers": {
      en: "Saved Answers",
      zh: "已保存答案"
    },
    "privacy.workEducation": {
      en: "Work/Education",
      zh: "工作/教育"
    },
    "privacy.fillRecords": {
      en: "Fill Records",
      zh: "填充记录"
    },
    "privacy.aiEnabled": {
      en: "AI Features Enabled",
      zh: "AI 功能已启用"
    },
    "privacy.aiDataSentTo": {
      en: "Field metadata may be sent to:",
      zh: "字段元数据可能发送至:"
    },
    "privacy.aiDataNote": {
      en: "Your actual data values are not sent, only field labels and type information.",
      zh: "您的实际数据值不会被发送，仅发送字段标签和类型信息。"
    },
    "privacy.allowAiSharing": {
      en: "Allow AI data sharing",
      zh: "允许 AI 数据共享"
    },
    "privacy.deleteAll": {
      en: "Delete All Data",
      zh: "删除所有数据"
    },
    "privacy.deleteConfirm": {
      en: "Are you sure you want to delete all data?",
      zh: "确定要删除所有数据吗？"
    },
    "privacy.deleteWarning": {
      en: "This will remove all saved answers, experiences, and settings. This action cannot be undone.",
      zh: "此操作将移除所有保存的答案、经历和设置，且无法恢复。"
    },
    "privacy.cancel": {
      en: "Cancel",
      zh: "取消"
    },
    "privacy.confirmDelete": {
      en: "Confirm Delete",
      zh: "确认删除"
    },
    "privacy.deleting": {
      en: "Deleting...",
      zh: "删除中..."
    },
    // Settings
    "settings.account": {
      en: "Account",
      zh: "账户"
    },
    "settings.loading": {
      en: "Loading...",
      zh: "加载中..."
    },
    "settings.signOut": {
      en: "Sign out",
      zh: "退出登录"
    },
    "settings.credits": {
      en: "Credits",
      zh: "积分"
    },
    "settings.unlimited": {
      en: "Unlimited",
      zh: "无限"
    },
    "settings.renews": {
      en: "renews",
      zh: "续期"
    },
    "settings.buyCredits": {
      en: "Buy Credits",
      zh: "购买积分"
    },
    "settings.loginDesc": {
      en: "Sign in to manage your credits and use premium features.",
      zh: "登录以管理您的积分和使用高级功能。"
    },
    "settings.login": {
      en: "Sign In",
      zh: "登录账户"
    },
    "settings.loggingIn": {
      en: "Signing in...",
      zh: "登录中..."
    },
    "settings.noAccountNeeded": {
      en: "Local fill features available without account",
      zh: "不登录也可使用本地填充功能"
    },
    "settings.llm.title": {
      en: "LLM Classification",
      zh: "LLM 分类"
    },
    "settings.llm.desc": {
      en: "Use AI to classify ambiguous form fields. Requires API key.",
      zh: "使用 AI 对模糊的表单字段进行分类。需要 API 密钥。"
    },
    "settings.llm.provider": {
      en: "Provider",
      zh: "提供商"
    },
    "settings.llm.apiKey": {
      en: "API Key",
      zh: "API 密钥"
    },
    "settings.llm.model": {
      en: "Model",
      zh: "模型"
    },
    "settings.llm.modelPlaceholder": {
      en: "Select or type model name",
      zh: "选择或输入模型名称"
    },
    "settings.llm.modelHint": {
      en: "Select from list or type custom model name",
      zh: "从列表中选择或输入自定义模型名称"
    },
    "settings.llm.modelName": {
      en: "Model Name",
      zh: "模型名称"
    },
    "settings.llm.endpoint": {
      en: "Endpoint URL",
      zh: "接口地址"
    },
    "settings.llm.disableThinking": {
      en: "Disable Thinking Mode",
      zh: "禁用思考模式"
    },
    "settings.llm.disableThinkingDesc": {
      en: "Turn off deep reasoning for faster responses (required for some models)",
      zh: "关闭深度推理以加快响应速度（某些模型需要）"
    },
    "settings.save": {
      en: "Save Settings",
      zh: "保存设置"
    },
    "settings.saving": {
      en: "Saving...",
      zh: "保存中..."
    },
    "settings.saved": {
      en: "Saved",
      zh: "已保存"
    },
    "settings.about": {
      en: "About",
      zh: "关于"
    },
    "settings.aboutDesc": {
      en: "Smart form auto-filler for job applications.",
      zh: "智能求职表单自动填充工具。"
    },
    "settings.typingAnimation": {
      en: "Typing Animation",
      zh: "打字动画"
    },
    "settings.typingAnimationDesc": {
      en: "Show typewriter effect when filling forms",
      zh: "填充表单时显示打字机效果"
    },
    "settings.devMode": {
      en: "Developer Mode",
      zh: "开发者模式"
    },
    "settings.devModeDesc": {
      en: "Enable developer tools tab",
      zh: "启用开发者工具选项卡"
    },
    "settings.aiEnhancement": {
      en: "AI Enhancement",
      zh: "AI 增强"
    },
    "settings.aiEnhancementDesc": {
      en: "Use AI to better recognize complex form fields",
      zh: "使用 AI 更好地识别复杂表单字段"
    },
    "settings.aiEnhancementLoginRequired": {
      en: "Login required to use AI features",
      zh: "需要登录才能使用 AI 功能"
    },
    "settings.usingBackendApi": {
      en: "Using cloud API (included in your plan)",
      zh: "使用云端 API（已包含在您的套餐中）"
    },
    "settings.useCustomApi": {
      en: "Use Custom LLM API",
      zh: "使用自定义 LLM API"
    },
    "settings.useCustomApiDesc": {
      en: "Use your own API key instead of backend service",
      zh: "使用自己的 API 密钥而非后端服务"
    },
    // Saved Answers
    "answers.search": {
      en: "Search...",
      zh: "搜索..."
    },
    "answers.noSaved": {
      en: "No saved answers",
      zh: "没有保存的答案"
    },
    "answers.noSavedDesc": {
      en: "Fill out forms to save your answers automatically.",
      zh: "填写表单以自动保存您的答案。"
    },
    "answers.workExperience": {
      en: "Work Experience",
      zh: "工作经历"
    },
    "answers.educationExperience": {
      en: "Education",
      zh: "教育经历"
    },
    "answers.personal": {
      en: "Personal",
      zh: "个人信息"
    },
    "answers.education": {
      en: "Education",
      zh: "教育"
    },
    "answers.sensitive": {
      en: "Sensitive",
      zh: "敏感信息"
    },
    "answers.noAutoFill": {
      en: "no auto-fill",
      zh: "不自动填充"
    },
    "answers.noItems": {
      en: "No items in this category",
      zh: "此分类下没有项目"
    },
    "answers.noWorkExp": {
      en: "No work experiences",
      zh: "没有工作经历"
    },
    "answers.noEduExp": {
      en: "No education experiences",
      zh: "没有教育经历"
    },
    "answers.auto": {
      en: "Auto",
      zh: "自动"
    },
    "answers.edit": {
      en: "Edit",
      zh: "编辑"
    },
    "answers.delete": {
      en: "Delete",
      zh: "删除"
    },
    "answers.save": {
      en: "Save",
      zh: "保存"
    },
    "answers.deleteConfirm": {
      en: "Delete this answer?",
      zh: "删除此答案？"
    },
    "answers.deleteExpConfirm": {
      en: "Delete this experience?",
      zh: "删除此经历？"
    },
    "answers.untitledPosition": {
      en: "Untitled Position",
      zh: "未命名职位"
    },
    "answers.untitledEducation": {
      en: "Untitled Education",
      zh: "未命名教育"
    },
    "answers.present": {
      en: "Present",
      zh: "至今"
    },
    // Floating Widget
    "widget.save": {
      en: "Save",
      zh: "保存"
    },
    "widget.fill": {
      en: "Fill",
      zh: "填充"
    },
    "widget.manageDb": {
      en: "Manage Database",
      zh: "管理数据库"
    },
    "widget.closePanel": {
      en: "Close Panel",
      zh: "关闭面板"
    },
    "widget.learned": {
      en: "I just learned these:",
      zh: "我刚学到了这些："
    },
    "widget.editHint": {
      en: "(Edit values and types, then confirm)",
      zh: "(编辑值和类型，然后确认)"
    },
    "widget.willReplace": {
      en: "Will replace:",
      zh: "将替换："
    },
    "widget.sensitive": {
      en: "(sensitive)",
      zh: "(敏感)"
    },
    "widget.cancel": {
      en: "Cancel",
      zh: "取消"
    },
    "widget.confirm": {
      en: "Confirm",
      zh: "确认"
    },
    "widget.savedToDb": {
      en: "Saved to Database!",
      zh: "已保存到数据库！"
    },
    "widget.savedDesc": {
      en: "Your answers have been saved and will be used for auto-filling.",
      zh: "您的答案已保存，将用于自动填充。"
    },
    "widget.viewEditDb": {
      en: "View/Edit Database",
      zh: "查看/编辑数据库"
    },
    "widget.done": {
      en: "Done",
      zh: "完成"
    },
    "widget.database": {
      en: "Database",
      zh: "数据库"
    },
    "widget.openSidePanel": {
      en: "Open the side panel for full database management.",
      zh: "打开侧边栏以进行完整的数据库管理。"
    },
    "widget.clickExtIcon": {
      en: "Click the extension icon → Open Side Panel",
      zh: "点击扩展图标 → 打开侧边栏"
    },
    "widget.filling": {
      en: "Filling...",
      zh: "填充中..."
    },
    "widget.preparing": {
      en: "Preparing...",
      zh: "准备中..."
    },
    "widget.scanning": {
      en: "Scanning",
      zh: "扫描中"
    },
    "widget.thinking": {
      en: "Thinking",
      zh: "思考中"
    },
    "widget.complete": {
      en: "Complete!",
      zh: "完成！"
    },
    "widget.processing": {
      en: "Processing...",
      zh: "处理中..."
    },
    "widget.allFieldsFilled": {
      en: "All fields filled!",
      zh: "所有字段已填充！"
    },
    "widget.fieldOf": {
      en: "Field {current} of {total}",
      zh: "字段 {current}/{total}"
    },
    // AI Promotion Bubble
    "aiPromo.title": {
      en: "Enable AI to fill more fields",
      zh: "启用 AI 可填充更多字段"
    },
    "aiPromo.thisFill": {
      en: "This fill:",
      zh: "本次填充:"
    },
    "aiPromo.fields": {
      en: "{filled}/{total} fields ({rate}%)",
      zh: "{filled}/{total} 个字段 ({rate}%)"
    },
    "aiPromo.withAi": {
      en: "With AI:",
      zh: "启用 AI 后:"
    },
    "aiPromo.canRecognize": {
      en: "Can recognize ~95% fields",
      zh: "可识别 ~95% 字段"
    },
    "aiPromo.benefit1": {
      en: "Smarter field recognition",
      zh: "更智能的字段识别"
    },
    "aiPromo.benefit2": {
      en: "Support complex dropdowns",
      zh: "支持复杂下拉框"
    },
    "aiPromo.benefit3": {
      en: "Auto-learn new forms",
      zh: "自动学习新表单"
    },
    "aiPromo.dismiss": {
      en: "Don't remind for 3 days",
      zh: "3天内不再提醒"
    },
    "aiPromo.tryAi": {
      en: "Enable AI Features",
      zh: "启用 AI 功能"
    },
    "aiPromo.privacy": {
      en: "Only field labels are sent, not your data",
      zh: "仅发送字段标签，不发送您的数据"
    },
    // Toast messages
    "toast.filled": {
      en: "Filled {count} fields successfully!",
      zh: "成功填充 {count} 个字段！"
    },
    "toast.noFieldsDetected": {
      en: "No filled fields detected",
      zh: "未检测到已填充的字段"
    },
    "toast.errorDetecting": {
      en: "Error detecting fields",
      zh: "检测字段时出错"
    },
    "toast.errorFilling": {
      en: "Error filling fields",
      zh: "填充字段时出错"
    },
    "toast.errorSaving": {
      en: "Error saving fields",
      zh: "保存字段时出错"
    },
    "toast.extensionUpdated": {
      en: "Extension updated. Please refresh the page.",
      zh: "扩展已更新。请刷新页面。"
    },
    "toast.saved": {
      en: "Saved: {details}",
      zh: "已保存: {details}"
    },
    "toast.new": {
      en: "{count} new",
      zh: "{count} 个新增"
    },
    "toast.replaced": {
      en: "{count} replaced",
      zh: "{count} 个替换"
    },
    "toast.noNewFields": {
      en: "No new fields to save ({count} skipped as UNKNOWN)",
      zh: "没有新字段需要保存（{count} 个因为未知类型被跳过）"
    },
    "toast.allInDb": {
      en: "All fields already in database",
      zh: "所有字段已在数据库中"
    },
    "toast.autoFilled": {
      en: "Auto-filled {count} new field(s)",
      zh: "自动填充了 {count} 个新字段"
    },
    "toast.filledInSection": {
      en: "Filled {count} fields in new {section} entry",
      zh: "在新的{section}条目中填充了 {count} 个字段"
    },
    "toast.sidePanelHint": {
      en: "Click extension icon to open side panel",
      zh: "点击扩展图标以打开侧边栏"
    },
    "toast.sidePanelNotAvailable": {
      en: "Side panel not available",
      zh: "侧边栏不可用"
    },
    // Fill debug reasons
    "debug.autofillDisabled": {
      en: "Autofill is disabled for this site. Enable it in settings.",
      zh: "此网站的自动填充已禁用。请在设置中启用。"
    },
    "debug.noFields": {
      en: "No form fields found on this page.",
      zh: "此页面上未找到表单字段。"
    },
    "debug.unknownTypes": {
      en: "Found {count} fields but couldn't identify their types.",
      zh: "找到 {count} 个字段，但无法识别其类型。"
    },
    "debug.noAnswers": {
      en: "Found {count} fields but no matching answers in database. Save some answers first.",
      zh: "找到 {count} 个字段，但数据库中没有匹配的答案。请先保存一些答案。"
    },
    "debug.manualSelection": {
      en: "Found {count} fields requiring manual selection (see badges).",
      zh: "找到 {count} 个需要手动选择的字段（请查看标记）。"
    },
    "debug.noMatch": {
      en: "No matching fields found. Check console for debug details.",
      zh: "未找到匹配的字段。请查看控制台了解详情。"
    },
    // Login prompts
    "toast.loginForAi": {
      en: "Sign in to try AI-enhanced filling for better accuracy!",
      zh: "登录即可试用 AI 增强填充，获得更高准确率！"
    },
    "toast.loginAction": {
      en: "Sign In",
      zh: "登录"
    },
    "toast.enableAutofillPrompt": {
      en: "Enable auto-fill for this site? Next time fields will fill automatically.",
      zh: "是否为此网站启用自动填充？下次将自动填写表单。"
    },
    "toast.enableAutofillAction": {
      en: "Enable",
      zh: "启用"
    },
    "toast.autofillEnabled": {
      en: "Auto-fill enabled for this site!",
      zh: "已为此网站启用自动填充！"
    }
  };
  function t(key, params) {
    const msg = messages[key];
    if (!msg) {
      console.warn(`Missing translation key: ${key}`);
      return key;
    }
    let text = msg[currentLocale] || msg.en;
    if (params) {
      for (const [k, v] of Object.entries(params)) {
        text = text.replace(new RegExp(`\\{${k}\\}`, "g"), String(v));
      }
    }
    return text;
  }

  const ICONS = {
    sparkles: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"/></svg>`,
    check: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>`,
    database: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4"/></svg>`,
    chevronRight: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 5l7 7-7 7"/></svg>`,
    chevronLeft: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 19l-7-7 7-7"/></svg>`,
    grip: `<svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><circle cx="9" cy="6" r="2"/><circle cx="15" cy="6" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="15" cy="12" r="2"/><circle cx="9" cy="18" r="2"/><circle cx="15" cy="18" r="2"/></svg>`,
    close: `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>`,
    trash: `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>`
  };
  class FloatingWidget {
    container = null;
    styleElement = null;
    currentPhase = "widget";
    fields = [];
    callbacks = {};
    sidePanelOpen = false;
    isMinimized = false;
    position = { right: 24, bottom: 24 };
    isDragging = false;
    dragStart = { x: 0, y: 0 };
    dragStartPos = { right: 0, bottom: 0 };
    // Animation state
    fillAnimationState = {
      stage: "idle",
      currentFieldIndex: 0,
      totalFields: 0,
      currentFieldLabel: "",
      progress: 0
    };
    constructor(callbacks = {}) {
      this.callbacks = callbacks;
      this.handleMouseMove = this.handleMouseMove.bind(this);
      this.handleMouseUp = this.handleMouseUp.bind(this);
      this.checkSidePanelState();
    }
    show() {
      if (this.container) return;
      this.checkMinimizedState();
      this.injectStyles();
      this.createContainer();
      this.render();
    }
    hide() {
      this.container?.remove();
      this.container = null;
    }
    showPhase(phase) {
      this.currentPhase = phase;
      if (phase === "hidden") {
        this.hide();
      } else {
        this.render();
      }
    }
    setFields(fields) {
      this.fields = [...fields];
      if (this.currentPhase === "learning") {
        this.render();
      }
    }
    injectStyles() {
      if (this.styleElement) return;
      this.styleElement = document.createElement("style");
      this.styleElement.textContent = WIDGET_STYLES;
      document.head.appendChild(this.styleElement);
    }
    createContainer() {
      this.container = document.createElement("div");
      this.container.className = "af-widget";
      this.container.setAttribute("data-autofiller-widget", "true");
      this.updateContainerPosition();
      document.body.appendChild(this.container);
    }
    updateContainerPosition() {
      if (!this.container) return;
      this.container.style.right = `${this.position.right}px`;
      this.container.style.bottom = `${this.position.bottom}px`;
    }
    handleMouseDown(e) {
      e.preventDefault();
      this.isDragging = true;
      this.dragStart = { x: e.clientX, y: e.clientY };
      this.dragStartPos = { ...this.position };
      document.addEventListener("mousemove", this.handleMouseMove);
      document.addEventListener("mouseup", this.handleMouseUp);
      if (this.container) {
        this.container.style.transition = "none";
      }
    }
    handleMouseMove(e) {
      if (!this.isDragging) return;
      const deltaX = this.dragStart.x - e.clientX;
      const deltaY = this.dragStart.y - e.clientY;
      const maxRight = window.innerWidth - 100;
      const maxBottom = window.innerHeight - 100;
      this.position.right = Math.max(10, Math.min(maxRight, this.dragStartPos.right + deltaX));
      this.position.bottom = Math.max(10, Math.min(maxBottom, this.dragStartPos.bottom + deltaY));
      this.updateContainerPosition();
    }
    handleMouseUp() {
      this.isDragging = false;
      document.removeEventListener("mousemove", this.handleMouseMove);
      document.removeEventListener("mouseup", this.handleMouseUp);
      if (this.container) {
        this.container.style.transition = "";
      }
    }
    render() {
      if (!this.container) return;
      const widgetBar = this.renderWidgetBar();
      let popup = "";
      switch (this.currentPhase) {
        case "learning":
          popup = this.renderLearningPopup();
          break;
        case "success":
          popup = this.renderSuccessPopup();
          break;
        case "database":
          popup = this.renderDatabasePopup();
          break;
        case "filling":
          popup = this.renderFillingPopup();
          break;
      }
      this.container.innerHTML = `
      <div style="display: flex; flex-direction: column; align-items: flex-end; gap: 8px;">
        ${popup}
        ${widgetBar}
      </div>
    `;
      this.attachEventListeners();
    }
    renderWidgetBar() {
      const arrowIcon = this.sidePanelOpen ? ICONS.chevronLeft : ICONS.chevronRight;
      const buttonText = this.sidePanelOpen ? "Close Panel" : "Manage Database";
      if (this.isMinimized) {
        return `
        <div style="display: flex; flex-direction: column; align-items: flex-end; gap: 8px;">
          <button id="af-btn-restore" class="af-btn-hover" style="width: 40px; height: 40px; background: linear-gradient(to right, #3b82f6, #2563eb); border-radius: 50%; box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3); display: flex; align-items: center; justify-content: center; color: white; transition: transform 0.15s, box-shadow 0.15s;" title="Show OneFillr">
            ${ICONS.sparkles}
          </button>
        </div>
      `;
      }
      return `
      <div style="display: flex; flex-direction: column; align-items: flex-end; gap: 8px;">
        <div style="background: white; border-radius: 16px; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1); border: 1px solid #e5e7eb; overflow: hidden;">
          <div style="display: flex; align-items: center;">
            <div id="af-drag-handle" style="padding: 12px 8px; cursor: grab; color: #6b7280; border-right: 1px solid #f3f4f6; user-select: none;">
              ${ICONS.grip}
            </div>
            <button id="af-btn-save" class="af-btn-hover" style="padding: 12px 16px; font-size: 14px; font-weight: 500; color: #374151; display: flex; align-items: center; gap: 8px; transition: background 0.15s;">
              <span style="color: #3b82f6;">${ICONS.sparkles}</span>
              <span>Save</span>
            </button>
            <div style="width: 1px; height: 24px; background: #e5e7eb;"></div>
            <button id="af-btn-fill" class="af-btn-hover" style="padding: 12px 16px; font-size: 14px; font-weight: 500; color: white; background: linear-gradient(to right, #3b82f6, #2563eb); display: flex; align-items: center; gap: 8px;">
              ${ICONS.check}
              <span>Fill</span>
            </button>
            <div style="width: 1px; height: 24px; background: #e5e7eb;"></div>
            <button id="af-btn-minimize" class="af-btn-hover" style="padding: 12px 10px; font-size: 14px; color: #9ca3af; display: flex; align-items: center; transition: color 0.15s;" title="Minimize OneFillr">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M5 12h14"/></svg>
            </button>
          </div>
        </div>
        <a href="#" id="af-link-database" style="font-size: 12px; color: #6b7280; display: flex; align-items: center; gap: 4px; text-decoration: none; transition: color 0.15s; background: white; padding: 6px 10px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); border: 1px solid #e5e7eb;">
          ${ICONS.database}
          <span>${buttonText}</span>
          ${arrowIcon}
        </a>
      </div>
    `;
    }
    renderLearningPopup() {
      const fieldsList = this.fields.map((field, index) => {
        const hasConflict = field.existingValue && field.existingValue !== field.value;
        const conflictStyle = hasConflict ? "background: rgba(239,68,68,0.1); margin: 0 -8px; padding-left: 8px; padding-right: 8px; border-radius: 4px;" : "";
        const rowStyle = field.sensitive ? "background: rgba(251,191,36,0.1); margin: 0 -8px; padding-left: 8px; padding-right: 8px; border-radius: 4px;" : conflictStyle;
        return `
      <div class="af-animate-slideIn" style="display: flex; flex-direction: column; gap: 4px; padding: 8px 0; border-bottom: 1px solid #bfdbfe; animation-delay: ${index * 50}ms; ${rowStyle}" data-field-id="${field.id}">
        <div style="display: flex; align-items: center; gap: 8px;">
          <div style="width: 20px; height: 20px; border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; ${field.type === "UNKNOWN" ? "background: #fee2e2;" : hasConflict ? "background: #fef3c7;" : field.sensitive ? "background: #fef3c7;" : "background: #dcfce7;"}">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="${field.type === "UNKNOWN" ? "#dc2626" : hasConflict ? "#d97706" : field.sensitive ? "#d97706" : "#16a34a"}" stroke-width="2"><path d="M5 13l4 4L19 7"/></svg>
          </div>
          <div style="flex: 1; min-width: 0;">
            <div style="font-size: 11px; color: #6b7280; margin-bottom: 2px;">${this.escapeHtml(field.label)}</div>
            <input type="text" value="${this.escapeHtml(field.value)}" data-field-input="${field.id}" style="width: 100%; font-size: 13px; font-weight: 500; color: #1f2937; background: transparent; border: none; padding: 0; outline: none;">
          </div>
          <button data-delete-field="${field.id}" style="padding: 4px; color: #9ca3af; border-radius: 4px; transition: all 0.15s; flex-shrink: 0;">
            ${ICONS.trash}
          </button>
        </div>
        <div style="display: flex; align-items: center; gap: 4px; margin-left: 28px;">
          <span style="font-size: 10px; color: #9ca3af;">Type:</span>
          <select data-field-type="${field.id}" style="font-size: 11px; padding: 2px 4px; border: 1px solid #d1d5db; border-radius: 4px; background: white; color: ${field.type === "UNKNOWN" ? "#dc2626" : "#374151"}; outline: none; cursor: pointer;">
            ${TAXONOMY_OPTIONS.map((t2) => `<option value="${t2.value}" ${field.type === t2.value ? "selected" : ""}>${t2.label}</option>`).join("")}
          </select>
          ${field.sensitive ? '<span style="font-size: 10px; color: #d97706; margin-left: 4px;">(sensitive)</span>' : ""}
          ${hasConflict ? `<span style="font-size: 10px; color: #dc2626; margin-left: 4px;">⚠ Will replace: "${this.escapeHtml(field.existingValue || "")}"</span>` : ""}
        </div>
      </div>
    `;
      }).join("");
      return `
      <div class="af-animate-fadeIn" style="position: relative;">
        <div style="background: linear-gradient(to bottom right, #eff6ff, #e0f2fe); border-radius: 16px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); border: 1px solid #bfdbfe; width: 340px; overflow: hidden;">
          <div style="padding: 16px 16px 8px;">
            <div style="display: flex; align-items: center; gap: 8px; color: #1d4ed8; font-weight: 500;">
              ${ICONS.sparkles}
              <span>I just learned these:</span>
            </div>
            <p style="font-size: 12px; color: #6b7280; margin-top: 4px;">(Edit values and types, then confirm)</p>
          </div>
          <div id="af-fields-list" class="af-scrollbar" style="padding: 0 16px 8px; max-height: 300px; overflow-y: auto;">
            ${fieldsList}
          </div>
          <div style="padding: 12px 16px; background: rgba(255,255,255,0.5); border-top: 1px solid #bfdbfe; display: flex; justify-content: space-between; align-items: center;">
            <button id="af-btn-cancel" style="font-size: 14px; color: #6b7280; transition: color 0.15s;">Cancel</button>
            <button id="af-btn-confirm" class="af-btn-hover" style="padding: 8px 24px; background: linear-gradient(to right, #3b82f6, #2563eb); color: white; font-size: 14px; font-weight: 500; border-radius: 9999px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); display: flex; align-items: center; gap: 8px;">
              ${ICONS.check}
              <span>Confirm</span>
            </button>
          </div>
        </div>
        <div style="position: absolute; bottom: -8px; right: 32px; width: 16px; height: 16px; background: linear-gradient(to bottom right, #eff6ff, #e0f2fe); border-right: 1px solid #bfdbfe; border-bottom: 1px solid #bfdbfe; transform: rotate(45deg);"></div>
      </div>
    `;
    }
    renderSuccessPopup() {
      return `
      <div class="af-animate-fadeIn" style="position: relative;">
        <div style="background: linear-gradient(to bottom right, #f0fdf4, #ecfdf5); border-radius: 16px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); border: 1px solid #86efac; width: 288px; overflow: hidden;">
          <div style="padding: 32px 24px; text-align: center;">
            <div class="af-animate-checkBounce" style="width: 64px; height: 64px; margin: 0 auto 16px; background: linear-gradient(to bottom right, #4ade80, #10b981); border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1);">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3"><path d="M5 13l4 4L19 7"/></svg>
            </div>
            <h3 style="font-size: 18px; font-weight: 600; color: #1f2937; margin-bottom: 8px;">Saved to Database!</h3>
            <p style="font-size: 14px; color: #4b5563; margin-bottom: 16px;">Your answers have been saved and will be used for auto-filling.</p>
            <a href="#" id="af-link-view-db" style="display: inline-flex; align-items: center; gap: 4px; font-size: 14px; color: #2563eb; font-weight: 500; text-decoration: none;">
              ${ICONS.database}
              <span>View/Edit Database</span>
              ${ICONS.chevronRight}
            </a>
          </div>
          <div style="padding: 12px 16px; background: rgba(255,255,255,0.5); border-top: 1px solid #86efac; display: flex; justify-content: center;">
            <button id="af-btn-done" class="af-btn-hover" style="padding: 8px 32px; background: linear-gradient(to right, #22c55e, #10b981); color: white; font-size: 14px; font-weight: 500; border-radius: 9999px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); display: flex; align-items: center; gap: 8px;">
              ${ICONS.check}
              <span>Done</span>
            </button>
          </div>
        </div>
        <div style="position: absolute; bottom: -8px; right: 32px; width: 16px; height: 16px; background: linear-gradient(to bottom right, #f0fdf4, #ecfdf5); border-right: 1px solid #86efac; border-bottom: 1px solid #86efac; transform: rotate(45deg);"></div>
      </div>
    `;
    }
    renderDatabasePopup() {
      return `
      <div class="af-animate-fadeIn" style="position: relative;">
        <div style="background: white; border-radius: 16px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); border: 1px solid #e5e7eb; width: 384px; overflow: hidden;">
          <div style="padding: 12px 16px; border-bottom: 1px solid #f3f4f6; display: flex; align-items: center; justify-content: space-between;">
            <div style="display: flex; align-items: center; gap: 8px;">
              <div style="width: 28px; height: 28px; background: linear-gradient(to bottom right, #3b82f6, #2563eb); border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4"/></svg>
              </div>
              <span style="font-weight: 600; color: #1f2937;">Database</span>
            </div>
            <button id="af-btn-close-db" style="padding: 6px; color: #9ca3af; border-radius: 8px; transition: all 0.15s;">
              ${ICONS.close}
            </button>
          </div>
          <div style="padding: 16px; text-align: center; color: #6b7280; font-size: 14px;">
            <p>Open the side panel for full database management.</p>
            <p style="margin-top: 8px; font-size: 12px;">Click the extension icon → Open Side Panel</p>
          </div>
        </div>
        <div style="position: absolute; bottom: -8px; right: 32px; width: 16px; height: 16px; background: white; border-right: 1px solid #e5e7eb; border-bottom: 1px solid #e5e7eb; transform: rotate(45deg);"></div>
      </div>
    `;
    }
    renderFillingPopup() {
      const { stage, currentFieldIndex, totalFields, currentFieldLabel, progress } = this.fillAnimationState;
      const stageText = {
        idle: "Preparing...",
        scanning: "Scanning",
        thinking: "Thinking",
        filling: "Filling",
        done: "Complete!"
      }[stage] || "Processing...";
      const stageEmoji = {
        idle: "⏳",
        scanning: "🔍",
        thinking: "🧠",
        filling: "✍️",
        done: "✨"
      }[stage] || "⚙️";
      const dots = stage !== "done" ? '<span class="af-dot-bounce"></span><span class="af-dot-bounce"></span><span class="af-dot-bounce"></span>' : "";
      return `
      <div class="af-filling-container" style="position: relative;">
        <div class="af-filling-popup">
          <div class="af-filling-header">
            <div class="af-filling-stage" data-stage="${stage}" style="display: flex; align-items: center; justify-content: center; gap: 8px;">
              <span>${stageEmoji}</span>
              <span>${stageText}</span>
              <span style="display: inline-flex; gap: 3px; margin-left: 4px;">${dots}</span>
            </div>
            <div class="af-filling-field">
              ${stage === "filling" && currentFieldLabel ? `📝 ${this.escapeHtml(currentFieldLabel)}` : ""}
              ${stage === "done" ? "🎉 All fields filled!" : ""}
            </div>
          </div>
          <div class="af-filling-progress">
            <div class="af-progress-bar">
              <div class="af-progress-fill" style="width: ${progress}%;"></div>
            </div>
            <div class="af-filling-stats">
              <span>${stage === "filling" ? `Field ${currentFieldIndex + 1} of ${totalFields}` : ""}</span>
              <span>${Math.round(progress)}%</span>
            </div>
          </div>
        </div>
        <div style="position: absolute; bottom: -8px; right: 32px; width: 16px; height: 16px; background: linear-gradient(135deg, #1e1b4b, #312e81); border-right: 1px solid rgba(129, 140, 248, 0.3); border-bottom: 1px solid rgba(129, 140, 248, 0.3); transform: rotate(45deg);"></div>
      </div>
    `;
    }
    // Update filling animation state - only re-render on stage change
    updateFillAnimationState(state) {
      this.fillAnimationState = { ...this.fillAnimationState, ...state };
      if (this.currentPhase === "filling" && this.container) {
        const stageEl = this.container.querySelector(".af-filling-stage");
        const currentStageAttr = stageEl?.getAttribute("data-stage");
        if (state.stage && state.stage !== currentStageAttr) {
          this.render();
          return;
        }
        const fieldEl = this.container.querySelector(".af-filling-field");
        const progressEl = this.container.querySelector(".af-progress-fill");
        const statsEl = this.container.querySelector(".af-filling-stats");
        if (fieldEl && this.fillAnimationState.currentFieldLabel) {
          fieldEl.innerHTML = `📝 ${this.escapeHtml(this.fillAnimationState.currentFieldLabel)}`;
        }
        if (progressEl) {
          progressEl.style.width = `${this.fillAnimationState.progress}%`;
        }
        if (statsEl && this.fillAnimationState.stage === "filling") {
          statsEl.innerHTML = `
          <span>Field ${this.fillAnimationState.currentFieldIndex + 1} of ${this.fillAnimationState.totalFields}</span>
          <span>${Math.round(this.fillAnimationState.progress)}%</span>
        `;
        }
      }
    }
    attachEventListeners() {
      const dragHandle = document.getElementById("af-drag-handle");
      const saveBtn = document.getElementById("af-btn-save");
      const fillBtn = document.getElementById("af-btn-fill");
      const dbLink = document.getElementById("af-link-database");
      const cancelBtn = document.getElementById("af-btn-cancel");
      const confirmBtn = document.getElementById("af-btn-confirm");
      const doneBtn = document.getElementById("af-btn-done");
      const viewDbLink = document.getElementById("af-link-view-db");
      const closeDbBtn = document.getElementById("af-btn-close-db");
      const minimizeBtn = document.getElementById("af-btn-minimize");
      const restoreBtn = document.getElementById("af-btn-restore");
      dragHandle?.addEventListener("mousedown", (e) => this.handleMouseDown(e));
      saveBtn?.addEventListener("click", () => this.handleSave());
      fillBtn?.addEventListener("click", () => this.handleFill());
      dbLink?.addEventListener("click", (e) => {
        e.preventDefault();
        this.openSidePanel();
      });
      cancelBtn?.addEventListener("click", () => this.showPhase("widget"));
      confirmBtn?.addEventListener("click", () => this.handleConfirm());
      doneBtn?.addEventListener("click", () => this.showPhase("widget"));
      viewDbLink?.addEventListener("click", (e) => {
        e.preventDefault();
        this.openSidePanel();
      });
      closeDbBtn?.addEventListener("click", () => this.showPhase("widget"));
      minimizeBtn?.addEventListener("click", () => this.minimize());
      restoreBtn?.addEventListener("click", () => this.restore());
      document.querySelectorAll("[data-delete-field]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const id = btn.getAttribute("data-delete-field");
          if (id) {
            this.fields = this.fields.filter((f) => f.id !== id);
            const row = document.querySelector(`[data-field-id="${id}"]`);
            row?.remove();
            if (this.fields.length === 0) {
              this.showPhase("widget");
            }
          }
        });
      });
      document.querySelectorAll("[data-field-input]").forEach((input) => {
        input.addEventListener("change", (e) => {
          const id = e.target.getAttribute("data-field-input");
          const value = e.target.value;
          if (id) {
            const field = this.fields.find((f) => f.id === id);
            if (field) field.value = value;
          }
        });
      });
      document.querySelectorAll("[data-field-type]").forEach((select) => {
        select.addEventListener("change", (e) => {
          const id = e.target.getAttribute("data-field-type");
          const type = e.target.value;
          if (id) {
            const field = this.fields.find((f) => f.id === id);
            if (field) field.type = type;
          }
        });
      });
    }
    async handleSave() {
      if (!isExtensionContextValid()) {
        showToast("Extension updated. Please refresh the page.", "warning");
        return;
      }
      const saveBtn = document.getElementById("af-btn-save");
      if (saveBtn) {
        saveBtn.innerHTML = `<span class="af-animate-spin" style="width: 16px; height: 16px; border: 2px solid #3b82f6; border-top-color: transparent; border-radius: 50%; display: inline-block;"></span>`;
      }
      try {
        if (this.callbacks.onSave) {
          const detectedFields = await this.callbacks.onSave();
          this.fields = detectedFields;
        }
        if (this.fields.length > 0) {
          this.showPhase("learning");
        } else {
          showToast("No filled fields detected", "info");
          this.showPhase("widget");
        }
      } catch (error) {
        console.error("[AutoFiller] Save error:", error);
        if (error instanceof ExtensionContextInvalidatedError || error instanceof Error && error.message.includes("Extension context invalidated")) {
          showToast("Extension updated. Please refresh the page.", "warning");
        } else {
          showToast("Error detecting fields", "warning");
        }
        this.showPhase("widget");
      }
    }
    async handleFill() {
      const fillBtn = document.getElementById("af-btn-fill");
      if (!fillBtn) return;
      if (!isExtensionContextValid()) {
        showToast("Extension updated. Please refresh the page.", "warning");
        return;
      }
      const originalContent = fillBtn.innerHTML;
      let animationEnabled = true;
      try {
        const result = await chrome.storage.local.get("fillAnimationConfig");
        animationEnabled = result.fillAnimationConfig?.enabled ?? true;
      } catch {
      }
      if (animationEnabled) {
        this.fillAnimationState = {
          stage: "scanning",
          currentFieldIndex: 0,
          totalFields: 0,
          currentFieldLabel: "",
          progress: 0
        };
        this.showPhase("filling");
        try {
          if (this.callbacks.onFill) {
            const { count, debug } = await this.callbacks.onFill(true, (state) => {
              this.updateFillAnimationState(state);
            });
            if (count > 0) {
              this.updateFillAnimationState({ stage: "done", progress: 100 });
              showToast(`Filled ${count} fields successfully!`, "success");
              this.checkAndPromptLogin();
              this.checkAndPromptAutofill();
              setTimeout(() => {
                this.showPhase("widget");
              }, 1500);
            } else {
              const reason = this.getFailureReason(debug);
              showToast(reason, "info");
              console.log("[AutoFiller Debug]", debug);
              this.showPhase("widget");
            }
          }
        } catch (error) {
          console.error("[AutoFiller] Fill error:", error);
          this.showPhase("widget");
          if (error instanceof ExtensionContextInvalidatedError || error instanceof Error && error.message.includes("Extension context invalidated")) {
            showToast("Extension updated. Please refresh the page.", "warning");
          } else {
            showToast("Error filling fields", "warning");
          }
        }
      } else {
        fillBtn.innerHTML = `
        <span class="af-animate-spin" style="width: 16px; height: 16px; border: 2px solid rgba(255,255,255,0.3); border-top-color: white; border-radius: 50%; display: inline-block;"></span>
        <span>Filling...</span>
      `;
        fillBtn.setAttribute("disabled", "true");
        fillBtn.style.opacity = "0.8";
        try {
          if (this.callbacks.onFill) {
            const { count, debug } = await this.callbacks.onFill(false);
            if (count > 0) {
              fillBtn.innerHTML = `
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3"><path d="M5 13l4 4L19 7"/></svg>
              <span>Done!</span>
            `;
              fillBtn.style.background = "linear-gradient(to right, #22c55e, #10b981)";
              showToast(`Filled ${count} fields successfully!`, "success");
              this.checkAndPromptLogin();
              this.checkAndPromptAutofill();
              setTimeout(() => {
                fillBtn.innerHTML = originalContent;
                fillBtn.style.background = "linear-gradient(to right, #3b82f6, #2563eb)";
                fillBtn.style.opacity = "1";
                fillBtn.removeAttribute("disabled");
              }, 1500);
            } else {
              fillBtn.innerHTML = `
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>
              <span>No fields</span>
            `;
              fillBtn.style.background = "linear-gradient(to right, #6b7280, #4b5563)";
              const reason = this.getFailureReason(debug);
              showToast(reason, "info");
              console.log("[AutoFiller Debug]", debug);
              setTimeout(() => {
                fillBtn.innerHTML = originalContent;
                fillBtn.style.background = "linear-gradient(to right, #3b82f6, #2563eb)";
                fillBtn.style.opacity = "1";
                fillBtn.removeAttribute("disabled");
              }, 1500);
            }
          }
        } catch (error) {
          console.error("[AutoFiller] Fill error:", error);
          fillBtn.innerHTML = originalContent;
          fillBtn.style.opacity = "1";
          fillBtn.removeAttribute("disabled");
          if (error instanceof ExtensionContextInvalidatedError || error instanceof Error && error.message.includes("Extension context invalidated")) {
            showToast("Extension updated. Please refresh the page.", "warning");
          } else {
            showToast("Error filling fields", "warning");
          }
        }
      }
    }
    getFailureReason(debug) {
      if (!debug.autofillEnabled) {
        return "Autofill is disabled for this site. Enable it in settings.";
      }
      if (debug.fieldsScanned === 0) {
        return "No form fields found on this page.";
      }
      const unknownCount = debug.fieldsParsed.filter((f) => f.type === "UNKNOWN").length;
      const noAnswersCount = debug.fieldsParsed.filter((f) => f.reason?.includes("No matching answers")).length;
      if (unknownCount === debug.fieldsScanned) {
        return `Found ${debug.fieldsScanned} fields but couldn't identify their types.`;
      }
      if (noAnswersCount > 0 && debug.plansCreated === 0) {
        return `Found ${debug.fieldsScanned} fields but no matching answers in database. Save some answers first.`;
      }
      if (debug.suggestionsCreated > 0 || debug.sensitiveFieldsFound > 0) {
        return `Found ${debug.suggestionsCreated + debug.sensitiveFieldsFound} fields requiring manual selection (see badges).`;
      }
      return "No matching fields found. Check console for debug details.";
    }
    async checkAndPromptLogin() {
      try {
        const authStorage = new AuthStorage();
        const authState = await authStorage.getAuthState();
        if (!authState?.accessToken) {
          setTimeout(() => {
            showToast(t("toast.loginForAi"), "info", {
              action: {
                label: t("toast.loginAction"),
                onClick: () => {
                  chrome.runtime.sendMessage({ action: "openSidePanel" }).catch(() => {
                    showToast(t("toast.sidePanelHint"), "info");
                  });
                }
              }
            });
          }, 2e3);
        }
      } catch {
      }
    }
    async checkAndPromptAutofill() {
      try {
        const siteKey = this.callbacks.getSiteKey?.();
        if (!siteKey) return;
        const result = await chrome.storage.local.get("siteSettings");
        const allSettings = result.siteSettings || {};
        const siteSettings = allSettings[siteKey];
        if (siteSettings?.autofillEnabled) return;
        setTimeout(() => {
          showToast(t("toast.enableAutofillPrompt"), "info", {
            action: {
              label: t("toast.enableAutofillAction"),
              onClick: async () => {
                try {
                  const result2 = await chrome.storage.local.get("siteSettings");
                  const allSettings2 = result2.siteSettings || {};
                  const current = allSettings2[siteKey] || {
                    siteKey,
                    recordEnabled: true,
                    autofillEnabled: false,
                    createdAt: Date.now(),
                    updatedAt: Date.now()
                  };
                  current.autofillEnabled = true;
                  current.updatedAt = Date.now();
                  allSettings2[siteKey] = current;
                  await chrome.storage.local.set({ siteSettings: allSettings2 });
                  showToast(t("toast.autofillEnabled"), "success");
                } catch {
                  showToast("Failed to enable autofill", "warning");
                }
              }
            }
          });
        }, 2500);
      } catch {
      }
    }
    async handleConfirm() {
      if (!isExtensionContextValid()) {
        showToast("Extension updated. Please refresh the page.", "warning");
        this.showPhase("widget");
        return;
      }
      try {
        if (this.callbacks.onConfirm) {
          await this.callbacks.onConfirm(this.fields);
        }
        this.showPhase("success");
      } catch (error) {
        console.error("[AutoFiller] Confirm error:", error);
        if (error instanceof ExtensionContextInvalidatedError || error instanceof Error && error.message.includes("Extension context invalidated")) {
          showToast("Extension updated. Please refresh the page.", "warning");
        } else {
          showToast("Error saving fields", "warning");
        }
        this.showPhase("widget");
      }
    }
    openSidePanel() {
      if (!isExtensionContextValid()) {
        showToast("Extension updated. Please refresh the page.", "warning");
        return;
      }
      if (typeof chrome !== "undefined" && chrome.runtime?.sendMessage) {
        if (this.sidePanelOpen) {
          chrome.runtime.sendMessage({ action: "closeSidePanel" });
          this.sidePanelOpen = false;
          this.render();
          return;
        }
        chrome.runtime.sendMessage({ action: "openSidePanel" }, (response) => {
          if (response?.success) {
            this.sidePanelOpen = true;
            this.render();
          } else {
            console.error("[AutoFiller] Failed to open side panel:", response?.error);
            showToast("Click extension icon to open side panel", "info");
          }
        });
      } else {
        showToast("Side panel not available", "info");
      }
    }
    checkSidePanelState() {
      if (!isExtensionContextValid()) return;
      if (typeof chrome === "undefined" || !chrome.runtime?.sendMessage) return;
      chrome.runtime.sendMessage({ action: "getSidePanelState" }, (response) => {
        if (!response?.isOpen) return;
        this.sidePanelOpen = true;
        if (this.container) this.render();
      });
    }
    setSidePanelOpen(isOpen) {
      this.sidePanelOpen = isOpen;
      if (this.container) this.render();
    }
    minimize() {
      this.isMinimized = true;
      this.render();
      try {
        sessionStorage.setItem("af-widget-minimized", "true");
      } catch {
      }
    }
    restore() {
      this.isMinimized = false;
      this.render();
      try {
        sessionStorage.removeItem("af-widget-minimized");
      } catch {
      }
    }
    // Check if widget was minimized in this session
    checkMinimizedState() {
      try {
        this.isMinimized = sessionStorage.getItem("af-widget-minimized") === "true";
      } catch {
        this.isMinimized = false;
      }
    }
    escapeHtml(text) {
      const div = document.createElement("div");
      div.textContent = text;
      return div.innerHTML;
    }
  }

  const DEFAULT_CONFIG = {
    minFormFields: 3,
    showMode: "immediate",
    showDelay: 500,
    alwaysShowPatterns: [
      // Common job application URLs
      /\/apply/i,
      /\/application/i,
      /\/career/i,
      /\/jobs?\//i,
      /\/job-application/i,
      /\/submit-application/i,
      // ATS systems
      /greenhouse\.io/i,
      /lever\.co/i,
      /workday\.com/i,
      /icims\.com/i,
      /smartrecruiters/i,
      /ashbyhq\.com/i,
      /breezy\.hr/i,
      /recruitee/i,
      /jazz\.co/i,
      /jobvite/i,
      // Chinese job sites
      /zhaopin\.com/i,
      /51job\.com/i,
      /lagou\.com/i,
      /boss\.com/i,
      /liepin\.com/i
    ],
    neverShowPatterns: [
      // Login/auth pages
      /\/login/i,
      /\/signin/i,
      /\/signup/i,
      /\/register/i,
      /\/auth/i,
      /\/password/i,
      // Payment pages
      /\/checkout/i,
      /\/payment/i,
      /\/cart/i,
      // Settings pages
      /\/settings/i,
      /\/preferences/i,
      /\/account/i
    ]
  };
  const JOB_APPLICATION_KEYWORDS = [
    "apply",
    "application",
    "job",
    "career",
    "position",
    "resume",
    "cv",
    "candidate",
    "applicant",
    "employment",
    "hire",
    "hiring",
    "recruit",
    "申请",
    "求职",
    "简历",
    "招聘",
    "职位",
    "应聘"
  ];
  const JOB_FORM_INDICATORS = [
    /full\s*name/i,
    /first\s*name/i,
    /last\s*name/i,
    /email/i,
    /phone/i,
    /education/i,
    /school/i,
    /university/i,
    /degree/i,
    /experience/i,
    /employer/i,
    /company/i,
    /job\s*title/i,
    /resume/i,
    /cv/i,
    /cover\s*letter/i,
    /work\s*authorization/i,
    /visa/i,
    /sponsorship/i,
    /linkedin/i,
    /github/i,
    /portfolio/i,
    /姓名/i,
    /电话/i,
    /邮箱/i,
    /学历/i,
    /工作经历/i
  ];
  class WidgetVisibilityController {
    config;
    cachedDecision = null;
    lastCheckTime = 0;
    checkCacheMs = 2e3;
    // Cache decision for 2 seconds
    constructor(config = {}) {
      this.config = { ...DEFAULT_CONFIG, ...config };
    }
    /**
     * Main decision function - should the widget be shown?
     */
    async shouldShowWidget() {
      const now = Date.now();
      if (this.cachedDecision && now - this.lastCheckTime < this.checkCacheMs) {
        return this.cachedDecision;
      }
      const decision = await this.evaluateVisibility();
      this.cachedDecision = decision;
      this.lastCheckTime = now;
      return decision;
    }
    /**
     * Evaluate visibility based on multiple signals
     */
    async evaluateVisibility() {
      const url = window.location.href;
      const path = window.location.pathname;
      for (const pattern of this.config.neverShowPatterns) {
        if (pattern.test(url) || pattern.test(path)) {
          return {
            shouldShow: false,
            reason: `URL matches excluded pattern: ${pattern}`,
            confidence: 1,
            suggestedMode: "hidden",
            formFieldCount: 0
          };
        }
      }
      for (const pattern of this.config.alwaysShowPatterns) {
        if (pattern.test(url) || pattern.test(path)) {
          return {
            shouldShow: true,
            reason: `URL matches job application pattern: ${pattern}`,
            confidence: 0.95,
            suggestedMode: "full",
            formFieldCount: -1
            // Unknown, but irrelevant
          };
        }
      }
      const fields = scanFields(document.body);
      const fieldCount = fields.length;
      if (fieldCount === 0) {
        return {
          shouldShow: false,
          reason: "No form fields detected",
          confidence: 1,
          suggestedMode: "hidden",
          formFieldCount: 0
        };
      }
      const pageScore = this.calculateJobApplicationScore(fields);
      if (pageScore >= 0.7) {
        return {
          shouldShow: true,
          reason: `High job application score (${(pageScore * 100).toFixed(0)}%)`,
          confidence: pageScore,
          suggestedMode: "full",
          formFieldCount: fieldCount
        };
      }
      if (fieldCount >= this.config.minFormFields && pageScore >= 0.4) {
        return {
          shouldShow: true,
          reason: `${fieldCount} form fields with moderate job signals (${(pageScore * 100).toFixed(0)}%)`,
          confidence: pageScore,
          suggestedMode: pageScore >= 0.6 ? "full" : "minimal",
          formFieldCount: fieldCount
        };
      }
      if (fieldCount >= 8) {
        return {
          shouldShow: true,
          reason: `Large form detected (${fieldCount} fields)`,
          confidence: 0.5,
          suggestedMode: "minimal",
          formFieldCount: fieldCount
        };
      }
      return {
        shouldShow: false,
        reason: `Only ${fieldCount} fields, low job application score (${(pageScore * 100).toFixed(0)}%)`,
        confidence: 1 - pageScore,
        suggestedMode: "hidden",
        formFieldCount: fieldCount
      };
    }
    /**
     * Calculate a score indicating how likely this is a job application form
     */
    calculateJobApplicationScore(fields) {
      let score = 0;
      const pageTitle = document.title.toLowerCase();
      for (const keyword of JOB_APPLICATION_KEYWORDS) {
        if (pageTitle.includes(keyword.toLowerCase())) {
          score += 0.3;
          break;
        }
      }
      const urlPath = window.location.pathname.toLowerCase();
      for (const keyword of JOB_APPLICATION_KEYWORDS) {
        if (urlPath.includes(keyword.toLowerCase())) {
          score += 0.3;
          break;
        }
      }
      let jobFieldCount = 0;
      for (const field of fields) {
        const text = `${field.labelText} ${field.sectionTitle} ${field.attributes.placeholder || ""}`.toLowerCase();
        for (const indicator of JOB_FORM_INDICATORS) {
          if (indicator.test(text)) {
            jobFieldCount++;
            break;
          }
        }
      }
      const fieldRatio = fields.length > 0 ? jobFieldCount / fields.length : 0;
      score += fieldRatio * 0.4;
      const hasFileUpload = fields.some(
        (f) => f.attributes.type === "file" || /resume|cv|cover/i.test(f.labelText)
      );
      if (hasFileUpload) {
        score += 0.2;
      }
      const hasEducationSection = fields.some(
        (f) => /education|school|university|degree|学历|学校/i.test(f.sectionTitle)
      );
      const hasExperienceSection = fields.some(
        (f) => /experience|employment|work|工作|经历/i.test(f.sectionTitle)
      );
      if (hasEducationSection || hasExperienceSection) {
        score += 0.2;
      }
      return Math.min(1, score);
    }
    /**
     * Force re-evaluation on next check
     */
    invalidateCache() {
      this.cachedDecision = null;
      this.lastCheckTime = 0;
    }
    /**
     * Update configuration
     */
    updateConfig(config) {
      this.config = { ...this.config, ...config };
      this.invalidateCache();
    }
    /**
     * Get current config
     */
    getConfig() {
      return { ...this.config };
    }
  }
  const visibilityController = new WidgetVisibilityController();

  const THREE_DAYS_MS = 3 * 24 * 60 * 60 * 1e3;
  const STORAGE_KEY = "aiPromotionState";
  class AIPromotionBubble {
    container = null;
    async shouldShow(llmEnabled, unrecognizedCount, totalFields) {
      if (llmEnabled) return false;
      if (unrecognizedCount === 0) return false;
      if (totalFields > 0 && (totalFields - unrecognizedCount) / totalFields > 0.8) return false;
      const state = await this.getState();
      if (state.lastDismissedAt && Date.now() - state.lastDismissedAt < THREE_DAYS_MS) {
        return false;
      }
      return true;
    }
    async show(filledCount, totalFields, onTryAI) {
      this.hide();
      const state = await this.getState();
      state.impressions++;
      await this.setState(state);
      const fillRate = totalFields > 0 ? Math.round(filledCount / totalFields * 100) : 0;
      this.container = document.createElement("div");
      this.container.className = "af-ai-promo-bubble";
      this.container.innerHTML = `
      <div class="af-ai-promo-content">
        <div class="af-ai-promo-header">
          <span class="af-ai-promo-icon">✨</span>
          <span class="af-ai-promo-title">${t("aiPromo.title")}</span>
        </div>

        <div class="af-ai-promo-stats">
          <div class="af-ai-promo-stat-row">
            <span>${t("aiPromo.thisFill")}</span>
            <span class="af-ai-promo-stat-value">${t("aiPromo.fields", { filled: filledCount, total: totalFields, rate: fillRate })}</span>
          </div>
          <div class="af-ai-promo-stat-row">
            <span>${t("aiPromo.withAi")}</span>
            <span class="af-ai-promo-stat-value af-ai-promo-highlight">${t("aiPromo.canRecognize")}</span>
          </div>
        </div>

        <ul class="af-ai-promo-benefits">
          <li>• ${t("aiPromo.benefit1")}</li>
          <li>• ${t("aiPromo.benefit2")}</li>
          <li>• ${t("aiPromo.benefit3")}</li>
        </ul>

        <div class="af-ai-promo-actions">
          <button id="af-ai-promo-dismiss" class="af-ai-promo-btn-secondary">
            ${t("aiPromo.dismiss")}
          </button>
          <button id="af-ai-promo-try" class="af-ai-promo-btn-primary">
            ✨ ${t("aiPromo.tryAi")}
          </button>
        </div>

        <p class="af-ai-promo-privacy">
          ${t("aiPromo.privacy")}
        </p>
      </div>
    `;
      this.injectStyles();
      document.body.appendChild(this.container);
      const dismissBtn = this.container.querySelector("#af-ai-promo-dismiss");
      const tryBtn = this.container.querySelector("#af-ai-promo-try");
      dismissBtn?.addEventListener("click", async () => {
        const state2 = await this.getState();
        state2.lastDismissedAt = Date.now();
        await this.setState(state2);
        this.hide();
      });
      tryBtn?.addEventListener("click", async () => {
        const state2 = await this.getState();
        state2.conversions++;
        await this.setState(state2);
        this.hide();
        onTryAI();
      });
      setTimeout(() => this.hide(), 15e3);
    }
    hide() {
      this.container?.remove();
      this.container = null;
    }
    async getState() {
      try {
        const result = await chrome.storage.local.get(STORAGE_KEY);
        return result[STORAGE_KEY] || {
          lastDismissedAt: 0,
          impressions: 0,
          conversions: 0
        };
      } catch {
        return {
          lastDismissedAt: 0,
          impressions: 0,
          conversions: 0
        };
      }
    }
    async setState(state) {
      try {
        await chrome.storage.local.set({ [STORAGE_KEY]: state });
      } catch {
      }
    }
    injectStyles() {
      if (document.getElementById("af-ai-promo-styles")) return;
      const style = document.createElement("style");
      style.id = "af-ai-promo-styles";
      style.textContent = `
      .af-ai-promo-bubble {
        position: fixed;
        bottom: 100px;
        right: 24px;
        z-index: 2147483647;
        animation: af-slideUp 0.3s ease-out;
      }

      @keyframes af-slideUp {
        from {
          opacity: 0;
          transform: translateY(20px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }

      .af-ai-promo-content {
        background: linear-gradient(135deg, #1e1b4b 0%, #312e81 100%);
        border-radius: 16px;
        padding: 16px;
        width: 300px;
        color: white;
        box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3), 0 0 0 1px rgba(255, 255, 255, 0.1);
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      }

      .af-ai-promo-header {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 12px;
      }

      .af-ai-promo-icon {
        font-size: 20px;
      }

      .af-ai-promo-title {
        font-size: 14px;
        font-weight: 600;
      }

      .af-ai-promo-stats {
        background: rgba(255, 255, 255, 0.1);
        border-radius: 8px;
        padding: 10px 12px;
        margin-bottom: 12px;
      }

      .af-ai-promo-stat-row {
        display: flex;
        justify-content: space-between;
        font-size: 12px;
        margin-bottom: 4px;
      }

      .af-ai-promo-stat-row:last-child {
        margin-bottom: 0;
      }

      .af-ai-promo-stat-value {
        font-weight: 500;
      }

      .af-ai-promo-highlight {
        color: #a5b4fc;
      }

      .af-ai-promo-benefits {
        list-style: none;
        padding: 0;
        margin: 0 0 12px 0;
        font-size: 12px;
        color: rgba(255, 255, 255, 0.8);
      }

      .af-ai-promo-benefits li {
        margin-bottom: 4px;
      }

      .af-ai-promo-actions {
        display: flex;
        gap: 8px;
      }

      .af-ai-promo-btn-secondary {
        flex: 1;
        padding: 8px 12px;
        background: rgba(255, 255, 255, 0.1);
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 8px;
        color: rgba(255, 255, 255, 0.8);
        font-size: 12px;
        cursor: pointer;
        transition: all 0.15s;
      }

      .af-ai-promo-btn-secondary:hover {
        background: rgba(255, 255, 255, 0.2);
      }

      .af-ai-promo-btn-primary {
        flex: 1;
        padding: 8px 12px;
        background: linear-gradient(135deg, #818cf8 0%, #6366f1 100%);
        border: none;
        border-radius: 8px;
        color: white;
        font-size: 12px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.15s;
      }

      .af-ai-promo-btn-primary:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(99, 102, 241, 0.4);
      }

      .af-ai-promo-privacy {
        text-align: center;
        font-size: 10px;
        color: rgba(255, 255, 255, 0.5);
        margin-top: 8px;
        margin-bottom: 0;
      }
    `;
      document.head.appendChild(style);
    }
  }
  const aiPromotionBubble = new AIPromotionBubble();

  class LLMService {
    config = null;
    configLoaded = false;
    async ensureConfigLoaded() {
      if (!this.configLoaded) {
        this.config = await loadLLMConfig();
        this.configLoaded = true;
      }
      return this.config;
    }
    /**
     * Ask LLM whether to click "Add" button based on context
     */
    async shouldAddMoreEntries(context) {
      const config = await this.ensureConfigLoaded();
      if (!config?.enabled || !config.apiKey) {
        return {
          shouldAdd: context.storedExperienceCount > context.currentFormCount,
          reason: "LLM not available, using count comparison",
          confidence: 0.5
        };
      }
      const prompt = this.buildAddButtonDecisionPrompt(context);
      try {
        const response = await this.callLLMInternal(prompt, 200);
        return this.parseAddButtonDecision(response);
      } catch (error) {
        console.error("[LLMService] Add button decision error:", error);
        return {
          shouldAdd: context.storedExperienceCount > context.currentFormCount,
          reason: "LLM error, fallback to count comparison",
          confidence: 0.5
        };
      }
    }
    /**
     * Clean and normalize LinkedIn profile data
     */
    async cleanLinkedInProfile(rawProfile) {
      const config = await this.ensureConfigLoaded();
      if (!config?.enabled || !config.apiKey) {
        return this.basicCleanProfile(rawProfile);
      }
      const prompt = this.buildProfileCleaningPrompt(rawProfile);
      try {
        const response = await this.callLLMInternal(prompt, 2e3);
        const cleaned = this.parseCleanedProfile(response);
        return this.mergeWithOriginal(cleaned, rawProfile);
      } catch (error) {
        console.error("[LLMService] Profile cleaning error:", error);
        return this.basicCleanProfile(rawProfile);
      }
    }
    buildAddButtonDecisionPrompt(context) {
      const sectionName = {
        WORK: "work experience",
        EDUCATION: "education",
        PROJECT: "project"
      }[context.sectionType];
      return `You are helping fill out a job application form. Decide whether to click an "Add" button.

Context:
- Section type: ${sectionName}
- Current form entries: ${context.currentFormCount}
- User's stored ${sectionName} records: ${context.storedExperienceCount}
- Add button text: "${context.buttonText}"
- Section context: "${context.sectionContext}"
- Existing field labels in form: ${context.existingFieldLabels.slice(0, 5).join(", ")}

Should we click the add button to create a new ${sectionName} entry?

Consider:
1. Do we have more stored records than current form entries?
2. Is the section context appropriate for adding more entries?
3. Would adding more entries make sense for this job application?

Return JSON only:
{
  "shouldAdd": true/false,
  "reason": "brief explanation",
  "confidence": 0.0-1.0
}`;
    }
    buildProfileCleaningPrompt(profile) {
      return `Clean and normalize this LinkedIn profile data for use in job applications.

Raw data:
${JSON.stringify(profile, null, 2)}

Tasks:
1. Standardize name format (First Last for Western, or proper Chinese name split)
2. Normalize date formats to YYYY-MM (e.g., "Jul 2022" -> "2022-07")
3. Clean up degree names (e.g., "Bachelor's degree" -> "Bachelor's", "本科" -> "Bachelor's")
4. Extract city from location if possible
5. Standardize company/school names (remove extra text like "· Full-time")
6. Fix any encoding issues or HTML artifacts
7. Normalize phone to E.164 format if possible
8. Make job titles consistent (capitalize properly)

Return ONLY valid JSON in this exact format:
{
  "fullName": "string",
  "firstName": "string",
  "lastName": "string",
  "email": "string or null",
  "phone": "string or null",
  "location": "string or null",
  "city": "string or null",
  "workExperiences": [
    {
      "company": "string",
      "title": "string",
      "location": "string or null",
      "startDate": "YYYY-MM",
      "endDate": "YYYY-MM or present",
      "description": "string or null"
    }
  ],
  "educations": [
    {
      "school": "string",
      "degree": "string or null",
      "major": "string or null",
      "startDate": "YYYY-MM or null",
      "endDate": "YYYY-MM or null",
      "gpa": "string or null"
    }
  ],
  "skills": ["string"]
}`;
    }
    parseAddButtonDecision(response) {
      const parsed = parseJSONSafe(response, {});
      return {
        shouldAdd: !!parsed.shouldAdd,
        reason: parsed.reason || "No reason provided",
        confidence: Math.max(0, Math.min(1, parsed.confidence || 0.5))
      };
    }
    parseCleanedProfile(response) {
      return parseJSONSafe(response, {});
    }
    basicCleanProfile(profile) {
      return {
        fullName: profile.fullName,
        firstName: this.extractFirstName(profile.fullName),
        lastName: this.extractLastName(profile.fullName),
        email: profile.email,
        phone: profile.phone,
        location: profile.location,
        city: this.extractCity(profile.location),
        workExperiences: profile.workExperiences.map((w) => ({
          company: w.company,
          title: w.title,
          location: w.location,
          startDate: w.startDate,
          endDate: w.endDate,
          description: w.description
        })),
        educations: profile.educations.map((e) => ({
          school: e.school,
          degree: e.degree,
          major: e.field,
          startDate: e.startDate,
          endDate: e.endDate
        })),
        skills: profile.skills
      };
    }
    mergeWithOriginal(cleaned, original) {
      return {
        fullName: cleaned.fullName || original.fullName,
        firstName: cleaned.firstName || this.extractFirstName(original.fullName),
        lastName: cleaned.lastName || this.extractLastName(original.fullName),
        email: cleaned.email || original.email,
        phone: cleaned.phone || original.phone,
        location: cleaned.location || original.location,
        city: cleaned.city || this.extractCity(original.location),
        workExperiences: cleaned.workExperiences?.length ? cleaned.workExperiences : original.workExperiences.map((w) => ({
          company: w.company,
          title: w.title,
          location: w.location,
          startDate: w.startDate,
          endDate: w.endDate,
          description: w.description
        })),
        educations: cleaned.educations?.length ? cleaned.educations : original.educations.map((e) => ({
          school: e.school,
          degree: e.degree,
          major: e.field,
          startDate: e.startDate,
          endDate: e.endDate
        })),
        skills: cleaned.skills?.length ? cleaned.skills : original.skills
      };
    }
    extractFirstName(fullName) {
      if (!fullName) return "";
      const parts = fullName.trim().split(/\s+/);
      if (/^[\u4e00-\u9fa5]+$/.test(fullName)) {
        return fullName.slice(1);
      }
      return parts[0] || "";
    }
    extractLastName(fullName) {
      if (!fullName) return "";
      const parts = fullName.trim().split(/\s+/);
      if (/^[\u4e00-\u9fa5]+$/.test(fullName)) {
        return fullName.charAt(0);
      }
      return parts.length > 1 ? parts[parts.length - 1] : "";
    }
    extractCity(location) {
      if (!location) return void 0;
      const parts = location.split(/[,·]/);
      if (/[\u4e00-\u9fa5]/.test(location)) {
        for (let i = parts.length - 1; i >= 0; i--) {
          const part = parts[i].trim();
          if (part && !part.includes("省") && !part.includes("国")) {
            return part.replace(/[市区县]$/, "");
          }
        }
      }
      return parts[0]?.trim();
    }
    async callLLMInternal(prompt, maxTokens) {
      if (!this.config) throw new Error("LLM config not loaded");
      return callLLM(
        this.config,
        prompt,
        "You are a helpful assistant. Respond with valid JSON only.",
        { maxTokens }
      );
    }
    resetConfig() {
      this.configLoaded = false;
      this.config = null;
      resetLLMConfigCache();
    }
  }
  const llmService = new LLMService();

  const CONFIDENCE_THRESHOLD = 0.75;
  const MUTATION_DEBOUNCE_DELAY = 300;
  const ATTR_FILLED = "data-autofiller-filled";
  const ATTR_USER_MODIFIED = "data-autofiller-user-modified";
  class AutoFiller {
    recorder;
    answerStorage;
    observationStorage;
    siteSettingsStorage;
    badgeManager;
    floatingWidget;
    fillHistory = [];
    siteKey;
    pendingFormSubmit = null;
    isSubmittingProgrammatically = false;
    userInputListeners = /* @__PURE__ */ new WeakMap();
    // Dynamic form monitoring
    mutationObserver = null;
    processedFields = /* @__PURE__ */ new WeakSet();
    mutationDebounceTimer = null;
    pendingMutationNodes = /* @__PURE__ */ new Set();
    dynamicFillEnabled = true;
    // Auto-add configuration
    autoAddEnabled = true;
    maxAutoAddClicks = 5;
    // Prevent infinite loops
    constructor() {
      this.recorder = new Recorder();
      this.answerStorage = storage.answers;
      this.observationStorage = storage.observations;
      this.siteSettingsStorage = storage.siteSettings;
      this.siteKey = this.extractSiteKey();
      this.badgeManager = new BadgeManager({
        onCandidateSelect: (field, answer) => this.handleBadgeFill(field, answer),
        onUndo: (field) => this.undoField(field.element),
        onDismiss: () => {
        }
      });
      this.floatingWidget = new FloatingWidget({
        onSave: () => this.detectFieldsForWidget(),
        onFill: (animated, onProgress) => this.fillAndReturnCount(animated, onProgress),
        onConfirm: (fields) => this.handleConfirmAndSubmit(fields),
        getSiteKey: () => this.siteKey
      });
      this.setupRecorderCallbacks();
      this.setupFormSubmitListener();
    }
    extractSiteKey() {
      try {
        return new URL(window.location.href).hostname;
      } catch {
        return "unknown";
      }
    }
    setupRecorderCallbacks() {
      this.recorder.onObservation(async (observation, value, questionKey) => {
        const existingAnswer = await this.answerStorage.findByValue(questionKey.type, value);
        let answer;
        if (existingAnswer) {
          answer = existingAnswer;
          observation.answerId = existingAnswer.id;
        } else {
          answer = this.createAnswerValue(questionKey.type, value);
          await this.answerStorage.save(answer);
          observation.answerId = answer.id;
        }
        await this.observationStorage.save(observation);
        this.notifyRecorded(questionKey.type, value);
      });
      this.recorder.onPending((pending) => {
        this.notifyPending(pending.classifiedType, pending.rawValue);
      });
      this.recorder.onCommit((count) => {
        this.notifyCommitted(count);
      });
    }
    setupFormSubmitListener() {
      document.addEventListener("submit", async (e) => {
        if (this.isSubmittingProgrammatically) return;
        const form = e.target;
        if (!form || form.tagName !== "FORM") return;
        const settings = await this.siteSettingsStorage.get(this.siteKey);
        if (!settings?.recordEnabled) return;
        e.preventDefault();
        this.pendingFormSubmit = form;
        const detectedFields = await this.detectFieldsForWidget();
        if (detectedFields.length > 0) {
          this.floatingWidget.setFields(detectedFields);
          this.floatingWidget.showPhase("learning");
        } else {
          this.submitPendingForm();
        }
      }, true);
    }
    async handleConfirmAndSubmit(fields) {
      await this.confirmWidgetFields(fields);
      this.submitPendingForm();
    }
    submitPendingForm() {
      if (this.pendingFormSubmit) {
        const form = this.pendingFormSubmit;
        this.pendingFormSubmit = null;
        this.isSubmittingProgrammatically = true;
        const submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
        if (submitBtn) {
          submitBtn.click();
        } else {
          form.submit();
        }
        setTimeout(() => {
          this.isSubmittingProgrammatically = false;
        }, 100);
      }
    }
    createAnswerValue(type, value) {
      const isSensitive = SENSITIVE_TYPES.has(type);
      const now = Date.now();
      return {
        id: generateId(),
        type,
        value,
        display: value,
        aliases: [],
        sensitivity: isSensitive ? "sensitive" : "normal",
        autofillAllowed: !isSensitive,
        createdAt: now,
        updatedAt: now
      };
    }
    async initialize() {
      const settings = await this.siteSettingsStorage.getOrCreate(this.siteKey);
      if (settings.recordEnabled) {
        this.recorder.start();
      }
      if (settings.autofillEnabled) {
        this.startDynamicFormMonitoring();
      }
      await this.initializeWidgetVisibility();
    }
    /**
     * Initialize widget visibility with smart detection
     * Only shows the widget when the page appears to be a job application
     */
    async initializeWidgetVisibility() {
      await new Promise((resolve) => setTimeout(resolve, 300));
      const decision = await visibilityController.shouldShowWidget();
      console.log(`[AutoFiller] Widget visibility: ${decision.shouldShow ? "SHOW" : "HIDE"}`);
      console.log(`[AutoFiller]   Reason: ${decision.reason}`);
      console.log(`[AutoFiller]   Form fields: ${decision.formFieldCount}`);
      console.log(`[AutoFiller]   Confidence: ${(decision.confidence * 100).toFixed(0)}%`);
      console.log(`[AutoFiller]   Mode: ${decision.suggestedMode}`);
      if (decision.shouldShow) {
        this.floatingWidget.show();
        if (decision.suggestedMode === "minimal") {
          console.log("[AutoFiller] Using minimal mode (future: smaller indicator)");
        }
      } else {
        this.setupLazyWidgetActivation();
      }
    }
    /**
     * Setup lazy activation - show widget when user interacts with a form field
     */
    setupLazyWidgetActivation() {
      const handleFormFocus = async (e) => {
        const target = e.target;
        if (!target) return;
        const isFormField = target instanceof HTMLInputElement || target instanceof HTMLSelectElement || target instanceof HTMLTextAreaElement;
        if (!isFormField) return;
        visibilityController.invalidateCache();
        const decision = await visibilityController.shouldShowWidget();
        if (decision.shouldShow && decision.formFieldCount >= 3) {
          console.log("[AutoFiller] Form interaction detected, showing widget");
          this.floatingWidget.show();
          document.removeEventListener("focusin", handleFormFocus);
        }
      };
      document.addEventListener("focusin", handleFormFocus);
      const observer = new MutationObserver(async () => {
        visibilityController.invalidateCache();
        const decision = await visibilityController.shouldShowWidget();
        if (decision.shouldShow && decision.formFieldCount >= 5) {
          console.log("[AutoFiller] Form detected via DOM change, showing widget");
          this.floatingWidget.show();
          observer.disconnect();
          document.removeEventListener("focusin", handleFormFocus);
        }
      });
      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
      setTimeout(() => {
        observer.disconnect();
        document.removeEventListener("focusin", handleFormFocus);
      }, 3e4);
    }
    /**
     * Start monitoring DOM for dynamically added form fields
     * Uses MutationObserver with debouncing to efficiently detect new fields
     */
    startDynamicFormMonitoring() {
      if (this.mutationObserver) return;
      this.mutationObserver = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
          for (const node of mutation.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              this.pendingMutationNodes.add(node);
            }
          }
        }
        if (this.pendingMutationNodes.size > 0) {
          this.scheduleMutationProcessing();
        }
      });
      this.mutationObserver.observe(document.body, {
        childList: true,
        subtree: true
      });
      console.log("[AutoFiller] Dynamic form monitoring started");
    }
    /**
     * Stop monitoring DOM for dynamic form changes
     */
    stopDynamicFormMonitoring() {
      if (this.mutationObserver) {
        this.mutationObserver.disconnect();
        this.mutationObserver = null;
      }
      if (this.mutationDebounceTimer) {
        clearTimeout(this.mutationDebounceTimer);
        this.mutationDebounceTimer = null;
      }
      this.pendingMutationNodes.clear();
      console.log("[AutoFiller] Dynamic form monitoring stopped");
    }
    /**
     * Schedule debounced processing of mutation nodes
     */
    scheduleMutationProcessing() {
      if (this.mutationDebounceTimer) {
        clearTimeout(this.mutationDebounceTimer);
      }
      this.mutationDebounceTimer = setTimeout(() => {
        this.processPendingMutations();
      }, MUTATION_DEBOUNCE_DELAY);
    }
    /**
     * Process accumulated mutation nodes and fill any new form fields
     */
    async processPendingMutations() {
      if (!this.dynamicFillEnabled) {
        this.pendingMutationNodes.clear();
        return;
      }
      const settings = await this.siteSettingsStorage.get(this.siteKey);
      if (!settings?.autofillEnabled) {
        this.pendingMutationNodes.clear();
        return;
      }
      const nodesToProcess = Array.from(this.pendingMutationNodes);
      this.pendingMutationNodes.clear();
      const newFields = [];
      for (const node of nodesToProcess) {
        if (!(node instanceof HTMLElement)) continue;
        const fields = scanFields(node);
        for (const field of fields) {
          if (this.processedFields.has(field.element)) continue;
          const currentValue = this.getFieldValue(field.element);
          if (currentValue) continue;
          newFields.push(field);
          this.processedFields.add(field.element);
        }
      }
      if (newFields.length === 0) return;
      console.log(`[AutoFiller] Detected ${newFields.length} new form fields, processing...`);
      await this.fillNewFields(newFields);
    }
    /**
     * Fill newly detected form fields
     */
    async fillNewFields(fields) {
      const { plans, suggestions, sensitiveFields } = await this.createFillPlansWithDebug(fields);
      for (const plan of plans) {
        const snapshot = createFillSnapshot(plan.field.element);
        const result = await fillField(plan.field, plan.answer.value);
        if (result.success) {
          this.fillHistory.push({
            field: plan.field,
            snapshot,
            answerId: plan.answer.id,
            timestamp: Date.now()
          });
          this.markAsFilledByProgram(plan.field.element);
          this.badgeManager.showBadge(plan.field, {
            type: "filled",
            answerId: plan.answer.id,
            canUndo: true
          });
        }
        await this.yieldToMainThread();
      }
      for (const { field, candidates } of suggestions) {
        this.badgeManager.showBadge(field, {
          type: "suggest",
          candidates
        });
      }
      for (const { field, candidates } of sensitiveFields) {
        this.badgeManager.showBadge(field, {
          type: "sensitive",
          candidates
        });
      }
      if (plans.length > 0) {
        console.log(`[AutoFiller] Filled ${plans.length} new fields dynamically`);
        showToast(`Auto-filled ${plans.length} new field(s)`, "success");
      }
    }
    /**
     * Enable or disable dynamic form filling
     */
    setDynamicFillEnabled(enabled) {
      this.dynamicFillEnabled = enabled;
      console.log(`[AutoFiller] Dynamic fill ${enabled ? "enabled" : "disabled"}`);
    }
    /**
     * Clear the processed fields cache (useful for re-scanning)
     */
    clearProcessedFieldsCache() {
      this.processedFields = /* @__PURE__ */ new WeakSet();
      console.log("[AutoFiller] Processed fields cache cleared");
    }
    async detectFieldsForWidget() {
      const fields = scanFields(document.body);
      const detectedFields = [];
      const fieldsWithValues = [];
      for (const field of fields) {
        const value = this.getFieldValue(field.element);
        if (!value) continue;
        if (!this.shouldLearnField(field.element)) continue;
        fieldsWithValues.push({ field, value });
      }
      if (fieldsWithValues.length === 0) {
        return [];
      }
      const parseResults = await parseFieldsBatch(fieldsWithValues.map((f) => f.field));
      for (let i = 0; i < fieldsWithValues.length; i++) {
        const { field, value } = fieldsWithValues[i];
        const candidates = parseResults.get(i) || [{ type: Taxonomy.UNKNOWN, score: 0, reasons: ["no match"] }];
        const bestCandidate = candidates[0];
        const detectedType = bestCandidate?.type || Taxonomy.UNKNOWN;
        const isSensitive = SENSITIVE_TYPES.has(detectedType);
        const labelText = field.labelText || field.attributes.placeholder || field.attributes.name || "Field";
        if (detectedType !== Taxonomy.UNKNOWN) {
          const existingAnswers = await this.answerStorage.getByType(detectedType);
          if (existingAnswers.length > 0) {
            const existing = existingAnswers[0];
            if (existing.value === value) {
              continue;
            }
            if (this.isPartialValue(value, existing.value)) {
              continue;
            }
            detectedFields.push({
              id: generateId(),
              label: labelText,
              value,
              type: detectedType,
              sensitive: isSensitive,
              existingValue: existing.value,
              existingAnswerId: existing.id
            });
            continue;
          }
        }
        detectedFields.push({
          id: generateId(),
          label: labelText,
          value,
          type: detectedType,
          sensitive: isSensitive
        });
      }
      return detectedFields;
    }
    /**
     * 检查新值是否是现有值的部分值（不应覆盖）
     * 例如：2023-09 是 2023-09-01 的部分值
     */
    isPartialValue(newValue, existingValue) {
      if (newValue.length < existingValue.length && existingValue.startsWith(newValue)) {
        return true;
      }
      const datePartialPattern = /^\d{4}-\d{2}$/;
      const dateFullPattern = /^\d{4}-\d{2}-\d{2}$/;
      if (datePartialPattern.test(newValue) && dateFullPattern.test(existingValue)) {
        return existingValue.startsWith(newValue);
      }
      return false;
    }
    getFieldValue(element) {
      if (element instanceof HTMLInputElement) {
        if (element.type === "checkbox" || element.type === "radio") {
          return element.checked ? element.value || "true" : "";
        }
        return element.value;
      }
      if (element instanceof HTMLSelectElement) {
        return element.value;
      }
      if (element instanceof HTMLTextAreaElement) {
        return element.value;
      }
      return "";
    }
    async fillAndReturnCount(animated = false, onProgress) {
      const { results, debug } = await this.fillWithDebug(animated, onProgress);
      return { count: results.filter((r) => r.success).length, debug };
    }
    async confirmWidgetFields(fields) {
      let savedCount = 0;
      let replacedCount = 0;
      let skippedCount = 0;
      for (const field of fields) {
        const type = field.type || Taxonomy.UNKNOWN;
        if (type === Taxonomy.UNKNOWN) {
          skippedCount++;
          continue;
        }
        if (field.existingAnswerId) {
          await this.answerStorage.delete(field.existingAnswerId);
          const answer = this.createAnswerValue(type, field.value);
          await this.answerStorage.save(answer);
          replacedCount++;
        } else {
          const existingAnswer = await this.answerStorage.findByValue(type, field.value);
          if (!existingAnswer) {
            const answer = this.createAnswerValue(type, field.value);
            await this.answerStorage.save(answer);
            savedCount++;
          }
        }
      }
      const messages = [];
      if (savedCount > 0) messages.push(`${savedCount} new`);
      if (replacedCount > 0) messages.push(`${replacedCount} replaced`);
      if (messages.length > 0) {
        showToast(`Saved: ${messages.join(", ")}`, "success");
      } else if (skippedCount > 0) {
        showToast(`No new fields to save (${skippedCount} skipped as UNKNOWN)`, "info");
      } else {
        showToast("All fields already in database", "info");
      }
    }
    async enableRecording() {
      await this.siteSettingsStorage.update(this.siteKey, { recordEnabled: true });
      this.recorder.start();
    }
    async disableRecording() {
      await this.siteSettingsStorage.update(this.siteKey, { recordEnabled: false });
      this.recorder.stop();
    }
    async enableAutofill() {
      await this.siteSettingsStorage.update(this.siteKey, { autofillEnabled: true });
      this.startDynamicFormMonitoring();
    }
    async disableAutofill() {
      await this.siteSettingsStorage.update(this.siteKey, { autofillEnabled: false });
      this.stopDynamicFormMonitoring();
    }
    async fill() {
      const { results } = await this.fillWithDebug();
      return results;
    }
    async fillWithDebug(animated = false, onProgress) {
      const debug = createEmptyDebugInfo();
      const settings = await this.siteSettingsStorage.get(this.siteKey);
      debug.autofillEnabled = settings?.autofillEnabled ?? false;
      if (!settings?.autofillEnabled) {
        await saveDebugLog("fill", debug);
        return { results: [], debug };
      }
      this.badgeManager.hideAll();
      let animConfig = DEFAULT_FILL_ANIMATION_CONFIG;
      try {
        const result = await chrome.storage.local.get("fillAnimationConfig");
        if (result.fillAnimationConfig) {
          animConfig = { ...DEFAULT_FILL_ANIMATION_CONFIG, ...result.fillAnimationConfig };
        }
      } catch {
      }
      if (animated && onProgress) {
        onProgress({
          stage: "scanning",
          currentFieldIndex: 0,
          totalFields: 0,
          currentFieldLabel: "",
          progress: 5
        });
        await new Promise((resolve) => setTimeout(resolve, animConfig.stageDelays.scanning));
      }
      const fields = scanFields(document.body);
      debug.fieldsScanned = fields.length;
      for (const field of fields) {
        this.processedFields.add(field.element);
      }
      if (animated && onProgress) {
        onProgress({
          stage: "thinking",
          currentFieldIndex: 0,
          totalFields: fields.length,
          currentFieldLabel: "",
          progress: 15
        });
        await new Promise((resolve) => setTimeout(resolve, animConfig.stageDelays.thinking));
      }
      const { plans, suggestions, sensitiveFields, fieldDebug } = await this.createFillPlansWithDebug(fields);
      debug.fieldsParsed = fieldDebug;
      debug.plansCreated = plans.length;
      debug.suggestionsCreated = suggestions.length;
      debug.sensitiveFieldsFound = sensitiveFields.length;
      const results = [];
      this.fillHistory = [];
      if (animated && onProgress && plans.length > 0) {
        onProgress({
          stage: "filling",
          currentFieldIndex: 0,
          totalFields: plans.length,
          currentFieldLabel: plans[0]?.field.labelText || "Field",
          progress: 20
        });
        const animatedPlans = plans.map((p) => ({
          context: p.field,
          value: p.answer.value
        }));
        const animResults = await executeFillPlanAnimated(animatedPlans, {
          config: animConfig,
          onProgress: (fieldIndex, totalFields, currentChar, totalChars, fieldLabel) => {
            const charProgress = totalChars > 0 ? currentChar / totalChars : 0;
            const fieldContribution = 75 / totalFields;
            const progress = 20 + fieldIndex * fieldContribution + charProgress * fieldContribution;
            onProgress({
              stage: "filling",
              currentFieldIndex: fieldIndex,
              totalFields,
              currentFieldLabel: fieldLabel,
              progress: Math.min(95, progress)
            });
          }
        });
        for (let i = 0; i < animResults.length; i++) {
          const plan = plans[i];
          const result = animResults[i];
          if (result.success) {
            const snapshot = createFillSnapshot(plan.field.element);
            this.fillHistory.push({
              field: plan.field,
              snapshot,
              answerId: plan.answer.id,
              timestamp: Date.now()
            });
            this.markAsFilledByProgram(plan.field.element);
            this.badgeManager.showBadge(plan.field, {
              type: "filled",
              answerId: plan.answer.id,
              canUndo: true
            });
          }
          results.push(result);
        }
      } else {
        for (const plan of plans) {
          const snapshot = createFillSnapshot(plan.field.element);
          const result = await fillField(plan.field, plan.answer.value);
          if (result.success) {
            this.fillHistory.push({
              field: plan.field,
              snapshot,
              answerId: plan.answer.id,
              timestamp: Date.now()
            });
            this.markAsFilledByProgram(plan.field.element);
            this.badgeManager.showBadge(plan.field, {
              type: "filled",
              answerId: plan.answer.id,
              canUndo: true
            });
          }
          results.push(result);
          await this.yieldToMainThread();
        }
      }
      for (const { field, candidates } of suggestions) {
        this.badgeManager.showBadge(field, {
          type: "suggest",
          candidates
        });
      }
      for (const { field, candidates } of sensitiveFields) {
        this.badgeManager.showBadge(field, {
          type: "sensitive",
          candidates
        });
      }
      debug.fillResults = results.filter((r) => r.success).length;
      this.notifyFilled(debug.fillResults);
      await saveDebugLog("fill", debug);
      await this.maybeShowAIPromotion(debug);
      if (this.autoAddEnabled && !animated) {
        await this.tryAutoAddAndFill();
      }
      return { results, debug };
    }
    /**
     * Show AI promotion bubble if appropriate
     * Shows when LLM is disabled and there are unrecognized fields
     */
    async maybeShowAIPromotion(debug) {
      try {
        const llmEnabled = await isLLMAvailable();
        const unrecognizedCount = debug.fieldsParsed.filter(
          (f) => f.type === Taxonomy.UNKNOWN || !f.hasMatchingAnswers
        ).length;
        const totalFields = debug.fieldsScanned;
        const filledCount = debug.fillResults;
        const shouldShow = await aiPromotionBubble.shouldShow(llmEnabled, unrecognizedCount, totalFields);
        if (shouldShow) {
          setTimeout(() => {
            aiPromotionBubble.show(filledCount, totalFields, () => {
              if (chrome.runtime?.sendMessage) {
                chrome.runtime.sendMessage({ action: "openSidePanel" });
              }
            });
          }, 2e3);
        }
      } catch (error) {
        console.error("[AutoFiller] Error checking AI promotion:", error);
      }
    }
    /**
     * Check if more experience entries are available and auto-click add buttons to fill them
     */
    async tryAutoAddAndFill() {
      const sectionTypes = ["WORK", "EDUCATION", "PROJECT"];
      for (const sectionType of sectionTypes) {
        let clickCount = 0;
        while (clickCount < this.maxAutoAddClicks) {
          const shouldAdd = await this.shouldAddMoreEntries(sectionType);
          if (!shouldAdd) break;
          const addButton = findAddButtonForSection(sectionType);
          if (!addButton) {
            console.log(`[AutoFiller] No add button found for ${sectionType}`);
            break;
          }
          console.log(`[AutoFiller] Clicking add button for ${sectionType}: "${addButton.context}"`);
          const success = await clickAddButtonAndWait(addButton);
          if (!success) {
            console.log(`[AutoFiller] Add button click did not produce new fields`);
            break;
          }
          clickCount++;
          await new Promise((resolve) => setTimeout(resolve, 200));
          await this.fillNewlyAddedSection(sectionType);
        }
        if (clickCount > 0) {
          console.log(`[AutoFiller] Added and filled ${clickCount} ${sectionType} entries`);
        }
      }
    }
    /**
     * Check if we should add more entries for a section type using LLM
     */
    async shouldAddMoreEntries(sectionType) {
      const storedCount = await experienceStorage.getCountByGroupType(sectionType);
      if (storedCount === 0) return false;
      const currentSectionCount = this.countFormSections(sectionType);
      const addButton = findAddButtonForSection(sectionType);
      if (!addButton) return false;
      const fields = scanFields(document.body);
      const fieldLabels = fields.filter((f) => this.isSectionRelevant(f, sectionType)).map((f) => f.labelText).filter(Boolean).slice(0, 10);
      const sectionContext = addButton.element.closest('section, fieldset, [class*="section"]')?.textContent?.slice(0, 200) || "";
      const decision = await llmService.shouldAddMoreEntries({
        sectionType,
        currentFormCount: currentSectionCount,
        storedExperienceCount: storedCount,
        buttonText: addButton.context,
        sectionContext: sectionContext.replace(/\s+/g, " ").trim(),
        existingFieldLabels: fieldLabels
      });
      console.log(`[AutoFiller] LLM decision for ${sectionType}: ${decision.shouldAdd ? "ADD" : "SKIP"} (${decision.confidence.toFixed(2)}) - ${decision.reason}`);
      return decision.shouldAdd && decision.confidence >= 0.6;
    }
    /**
     * Check if a field is relevant to a section type
     */
    isSectionRelevant(field, sectionType) {
      const text = (field.labelText + " " + field.sectionTitle).toLowerCase();
      if (sectionType === "WORK") {
        return /company|employer|job|title|position|work|experience|职位|公司|工作/.test(text);
      } else if (sectionType === "EDUCATION") {
        return /school|university|college|degree|education|学校|学历|教育/.test(text);
      } else if (sectionType === "PROJECT") {
        return /project|项目/.test(text);
      }
      return false;
    }
    /**
     * Count how many form sections of a given type exist
     */
    countFormSections(sectionType) {
      const fields = scanFields(document.body);
      let sectionCount = 0;
      const seenSections = /* @__PURE__ */ new Set();
      for (const field of fields) {
        const sectionKey = field.sectionTitle || "_default";
        if (seenSections.has(sectionKey)) continue;
        const lowerLabel = field.labelText.toLowerCase();
        const lowerSection = field.sectionTitle.toLowerCase();
        let isRelevant = false;
        if (sectionType === "WORK") {
          isRelevant = /company|employer|job|title|position|work|experience|职位|公司|工作/.test(lowerLabel + lowerSection);
        } else if (sectionType === "EDUCATION") {
          isRelevant = /school|university|college|degree|education|学校|学历|教育/.test(lowerLabel + lowerSection);
        } else if (sectionType === "PROJECT") {
          isRelevant = /project|项目/.test(lowerLabel + lowerSection);
        }
        if (isRelevant) {
          seenSections.add(sectionKey);
          sectionCount++;
        }
      }
      return Math.max(sectionCount, seenSections.size > 0 ? 1 : 0);
    }
    /**
     * Fill fields in a newly added section
     */
    async fillNewlyAddedSection(sectionType) {
      const allFields = scanFields(document.body);
      const newFields = allFields.filter((f) => !this.processedFields.has(f.element));
      if (newFields.length === 0) {
        console.log(`[AutoFiller] No new fields found after add button click`);
        return;
      }
      console.log(`[AutoFiller] Found ${newFields.length} new fields to fill`);
      for (const field of newFields) {
        this.processedFields.add(field.element);
      }
      const { plans, suggestions, sensitiveFields } = await this.createFillPlansWithDebug(newFields);
      for (const plan of plans) {
        const snapshot = createFillSnapshot(plan.field.element);
        const result = await fillField(plan.field, plan.answer.value);
        if (result.success) {
          this.fillHistory.push({
            field: plan.field,
            snapshot,
            answerId: plan.answer.id,
            timestamp: Date.now()
          });
          this.markAsFilledByProgram(plan.field.element);
          this.badgeManager.showBadge(plan.field, {
            type: "filled",
            answerId: plan.answer.id,
            canUndo: true
          });
        }
        await this.yieldToMainThread();
      }
      for (const { field, candidates } of suggestions) {
        this.badgeManager.showBadge(field, { type: "suggest", candidates });
      }
      for (const { field, candidates } of sensitiveFields) {
        this.badgeManager.showBadge(field, { type: "sensitive", candidates });
      }
      if (plans.length > 0) {
        showToast(`Filled ${plans.length} fields in new ${sectionType.toLowerCase()} entry`, "success");
      }
    }
    /**
     * Enable or disable auto-add functionality
     */
    setAutoAddEnabled(enabled) {
      this.autoAddEnabled = enabled;
      console.log(`[AutoFiller] Auto-add ${enabled ? "enabled" : "disabled"}`);
    }
    async createFillPlansWithDebug(fields) {
      const plans = [];
      const suggestions = [];
      const sensitiveFields = [];
      const fieldDebug = [];
      const parseResults = await parseFieldsBatch(fields);
      const fieldTypeMap = /* @__PURE__ */ new Map();
      for (const [index, candidates] of parseResults) {
        if (candidates.length > 0 && candidates[0].type !== Taxonomy.UNKNOWN) {
          fieldTypeMap.set(index, candidates[0].type);
        }
      }
      const sections = detectFormSections(fields, fieldTypeMap);
      const fieldSectionMap = /* @__PURE__ */ new Map();
      for (const section of sections) {
        for (const field of section.fields) {
          fieldSectionMap.set(field, {
            groupType: section.groupType,
            blockIndex: section.blockIndex
          });
        }
      }
      for (let i = 0; i < fields.length; i++) {
        const field = fields[i];
        const candidates = parseResults.get(i) || [{ type: Taxonomy.UNKNOWN, score: 0, reasons: ["no match"] }];
        const bestCandidate = candidates[0];
        const label = field.labelText || field.attributes.placeholder || field.attributes.name || "Unknown";
        const sectionContext = fieldSectionMap.get(field);
        const answers = bestCandidate.type !== Taxonomy.UNKNOWN ? await this.findMatchingAnswers(bestCandidate, field, sectionContext) : [];
        const debugEntry = {
          label,
          type: bestCandidate.type,
          score: bestCandidate.score,
          hasMatchingAnswers: answers.length > 0,
          answersCount: answers.length
        };
        if (bestCandidate.type === Taxonomy.UNKNOWN) {
          debugEntry.reason = "UNKNOWN type - skipped";
          fieldDebug.push(debugEntry);
          continue;
        }
        if (answers.length === 0) {
          debugEntry.reason = "No matching answers in database";
          fieldDebug.push(debugEntry);
          continue;
        }
        const bestAnswer = answers[0];
        const answerValues = answers.map((a) => a.answer);
        if (SENSITIVE_TYPES.has(bestCandidate.type) || bestAnswer.answer.autofillAllowed === false) {
          debugEntry.reason = bestAnswer.answer.autofillAllowed === false ? "Autofill disabled for this answer" : "Sensitive field - requires manual selection";
          fieldDebug.push(debugEntry);
          sensitiveFields.push({ field, candidates: answerValues.slice(0, 3) });
          continue;
        }
        if (bestCandidate.score < CONFIDENCE_THRESHOLD) {
          debugEntry.reason = `Low confidence (${bestCandidate.score.toFixed(2)} < ${CONFIDENCE_THRESHOLD}) - suggestion only`;
          fieldDebug.push(debugEntry);
          suggestions.push({ field, candidates: answerValues.slice(0, 3) });
          continue;
        }
        debugEntry.reason = sectionContext?.groupType ? `Will auto-fill (${sectionContext.groupType} block ${sectionContext.blockIndex})` : "Will auto-fill";
        fieldDebug.push(debugEntry);
        plans.push({
          field,
          answer: { ...bestAnswer.answer, value: bestAnswer.transformedValue },
          confidence: bestCandidate.score
        });
      }
      return { plans, suggestions, sensitiveFields, fieldDebug };
    }
    async handleBadgeFill(field, answer) {
      const transformedValue = transformValue(answer.value, answer.type, field);
      const snapshot = createFillSnapshot(field.element);
      const result = await fillField(field, transformedValue);
      if (result.success) {
        this.fillHistory.push({
          field,
          snapshot,
          answerId: answer.id,
          timestamp: Date.now()
        });
        this.markAsFilledByProgram(field.element);
      }
    }
    /**
     * 标记元素为程序填写，并添加用户修改监听器
     */
    markAsFilledByProgram(element) {
      element.setAttribute(ATTR_FILLED, "true");
      element.removeAttribute(ATTR_USER_MODIFIED);
      if (this.userInputListeners.has(element)) return;
      const handleUserInput = () => {
        element.setAttribute(ATTR_USER_MODIFIED, "true");
      };
      element.addEventListener("input", handleUserInput);
      this.userInputListeners.set(element, handleUserInput);
    }
    /**
     * 检查字段是否应该被学习（用户主动填写或修改的）
     */
    shouldLearnField(element) {
      const wasFilled = element.hasAttribute(ATTR_FILLED);
      const wasUserModified = element.hasAttribute(ATTR_USER_MODIFIED);
      if (wasFilled) {
        return wasUserModified;
      }
      return true;
    }
    async findMatchingAnswers(candidate, field, sectionContext) {
      const results = [];
      if (sectionContext?.groupType) {
        const experienceValue = await this.getValueFromExperience(
          candidate.type,
          sectionContext.groupType,
          sectionContext.blockIndex
        );
        if (experienceValue) {
          const transformedValue = transformValue(experienceValue.value, candidate.type, field);
          results.push({
            answer: experienceValue,
            transformedValue,
            priority: 3
            // Highest priority for experience-based matches
          });
        }
      }
      const directAnswers = await this.answerStorage.getByType(candidate.type);
      for (const answer of directAnswers) {
        const transformedValue = transformValue(answer.value, answer.type, field);
        results.push({ answer, transformedValue, priority: 2 });
      }
      const relatedTypes = this.getRelatedTypes(candidate.type);
      for (const relatedType of relatedTypes) {
        const relatedAnswers = await this.answerStorage.getByType(relatedType);
        for (const answer of relatedAnswers) {
          const transformedValue = transformValue(answer.value, answer.type, field);
          if (transformedValue !== answer.value || relatedType === candidate.type) {
            results.push({ answer, transformedValue, priority: 1 });
          }
        }
      }
      return results.sort((a, b) => {
        if (a.priority !== b.priority) return b.priority - a.priority;
        return b.answer.updatedAt - a.answer.updatedAt;
      }).map(({ answer, transformedValue }) => ({ answer, transformedValue }));
    }
    /**
     * Get value from experience storage for a specific field type and block index
     */
    async getValueFromExperience(fieldType, groupType, blockIndex) {
      const experience = await experienceStorage.getByPriority(groupType, blockIndex);
      if (!experience) return null;
      const value = experience.fields[fieldType];
      if (!value) return null;
      return {
        id: `exp-${experience.id}-${fieldType}`,
        type: fieldType,
        value,
        display: value,
        aliases: [],
        sensitivity: "normal",
        autofillAllowed: true,
        createdAt: experience.createdAt,
        updatedAt: experience.updatedAt
      };
    }
    getRelatedTypes(targetType) {
      const TYPE_RELATIONS = {
        [Taxonomy.FIRST_NAME]: [Taxonomy.FULL_NAME],
        [Taxonomy.LAST_NAME]: [Taxonomy.FULL_NAME],
        [Taxonomy.FULL_NAME]: [Taxonomy.FIRST_NAME],
        [Taxonomy.GRAD_YEAR]: [Taxonomy.GRAD_DATE],
        [Taxonomy.GRAD_MONTH]: [Taxonomy.GRAD_DATE],
        [Taxonomy.COUNTRY_CODE]: [Taxonomy.PHONE]
      };
      return TYPE_RELATIONS[targetType] || [];
    }
    async yieldToMainThread() {
      return new Promise((resolve) => setTimeout(resolve, 0));
    }
    async undo() {
      for (const entry of this.fillHistory.reverse()) {
        restoreSnapshot(entry.field.element, entry.snapshot);
      }
      this.fillHistory = [];
      this.notifyUndone();
    }
    async undoField(element) {
      const entryIndex = this.fillHistory.findIndex((e) => e.field.element === element);
      if (entryIndex >= 0) {
        const entry = this.fillHistory[entryIndex];
        restoreSnapshot(element, entry.snapshot);
        this.fillHistory.splice(entryIndex, 1);
      }
    }
    async getSuggestions(field) {
      const candidates = await parseField(field);
      const suggestions = [];
      for (const candidate of candidates.slice(0, 2)) {
        if (candidate.type === Taxonomy.UNKNOWN) continue;
        const answers = await this.answerStorage.getByType(candidate.type);
        for (const answer of answers.slice(0, 2)) {
          if (!suggestions.find((s) => s.id === answer.id)) {
            suggestions.push(answer);
          }
        }
      }
      return suggestions.slice(0, 3);
    }
    setSidePanelState(isOpen) {
      this.floatingWidget.setSidePanelOpen(isOpen);
    }
    notifyRecorded(type, value) {
      window.dispatchEvent(new CustomEvent("autofiller:recorded", {
        detail: { type, value }
      }));
    }
    notifyPending(type, value) {
      window.dispatchEvent(new CustomEvent("autofiller:pending", {
        detail: { type, value }
      }));
    }
    notifyCommitted(count) {
      window.dispatchEvent(new CustomEvent("autofiller:committed", {
        detail: { count }
      }));
    }
    notifyFilled(count) {
      window.dispatchEvent(new CustomEvent("autofiller:filled", {
        detail: { count }
      }));
    }
    notifyUndone() {
      window.dispatchEvent(new CustomEvent("autofiller:undone"));
    }
    async saveNow() {
      return this.recorder.commitAllPending();
    }
    getPendingCount() {
      return this.recorder.getPendingCount();
    }
    destroy() {
      this.recorder.stop();
      this.badgeManager.hideAll();
      this.floatingWidget.hide();
      this.stopDynamicFormMonitoring();
    }
  }
  let autoFiller = null;
  function initAutoFiller() {
    if (!autoFiller) {
      autoFiller = new AutoFiller();
      autoFiller.initialize();
    }
    return autoFiller;
  }
  function getAutoFiller() {
    return autoFiller;
  }

  initAutoFiller();
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    const filler = getAutoFiller();
    if (message.action === "sidePanelClosed" || message.action === "sidePanelOpened") {
      filler?.setSidePanelState(message.action === "sidePanelOpened");
      sendResponse({ success: true });
      return true;
    }
    if (message.action === "checkLinkedInReady") {
      __vitePreload(async () => { const {LinkedInParser} = await Promise.resolve().then(() => LinkedInParser$1);return { LinkedInParser }},false?__VITE_PRELOAD__:void 0).then(({ LinkedInParser }) => {
        try {
          if (!LinkedInParser.isLinkedInProfile()) {
            sendResponse({ ready: false, reason: "not_linkedin" });
            return;
          }
          const nameEl = document.querySelector('h1.text-heading-xlarge, h1[class*="text-heading"]');
          const experienceSection = document.querySelector("#experience");
          const isReady = !!nameEl?.textContent?.trim();
          sendResponse({
            ready: isReady,
            reason: isReady ? "loaded" : "loading",
            hasExperience: !!experienceSection
          });
        } catch (err) {
          sendResponse({ ready: false, reason: "error", error: String(err) });
        }
      }).catch((err) => {
        sendResponse({ ready: false, reason: "error", error: String(err) });
      });
      return true;
    }
    if (message.action === "parseLinkedInProfile") {
      const useLLMCleaning = message.useLLMCleaning ?? false;
      __vitePreload(() => Promise.resolve().then(() => LinkedInParser$1),false?__VITE_PRELOAD__:void 0).then(async ({ LinkedInParser }) => {
        try {
          if (!LinkedInParser.isLinkedInProfile()) {
            sendResponse({ success: false, error: "Not a LinkedIn profile page" });
            return;
          }
          const parser = new LinkedInParser();
          const profile = parser.parse(document);
          const parsedProfile = await parser.toParsedProfile(profile, useLLMCleaning);
          sendResponse({ success: true, profile: parsedProfile });
        } catch (err) {
          console.error("[AutoFiller] LinkedIn parse error:", err);
          sendResponse({ success: false, error: err instanceof Error ? err.message : String(err) });
        }
      }).catch((err) => {
        console.error("[AutoFiller] LinkedIn import error:", err);
        sendResponse({ success: false, error: String(err) });
      });
      return true;
    }
    if (!filler) {
      sendResponse({ success: false, error: "AutoFiller not initialized" });
      return true;
    }
    switch (message.action) {
      case "fill":
        filler.fill().then((results) => {
          sendResponse({
            success: true,
            filled: results.filter((r) => r.success).length,
            failed: results.filter((r) => !r.success).length
          });
        });
        return true;
      case "undo":
        filler.undo().then(() => {
          sendResponse({ success: true });
        });
        return true;
      case "enableRecording":
        filler.enableRecording().then(() => {
          sendResponse({ success: true });
        });
        return true;
      case "disableRecording":
        filler.disableRecording().then(() => {
          sendResponse({ success: true });
        });
        return true;
      case "enableAutofill":
        filler.enableAutofill().then(() => {
          sendResponse({ success: true });
        });
        return true;
      case "disableAutofill":
        filler.disableAutofill().then(() => {
          sendResponse({ success: true });
        });
        return true;
      case "getStatus":
        sendResponse({
          success: true,
          recording: true,
          autofill: true
        });
        return true;
      default:
        sendResponse({ success: false, error: "Unknown action" });
        return true;
    }
  });
  window.addEventListener("autofiller:recorded", (event) => {
    const { type, value } = event.detail;
    console.log(`[AutoFiller] Recorded: ${type} = ${value}`);
  });
  window.addEventListener("autofiller:filled", (event) => {
    const { count } = event.detail;
    console.log(`[AutoFiller] Filled ${count} fields`);
  });
  window.addEventListener("autofiller:undone", () => {
    console.log("[AutoFiller] Undone all fills");
  });
  console.log("[AutoFiller] Content script loaded");

  const MONTH_MAP = {
    "jan": "01",
    "feb": "02",
    "mar": "03",
    "apr": "04",
    "may": "05",
    "jun": "06",
    "jul": "07",
    "aug": "08",
    "sep": "09",
    "oct": "10",
    "nov": "11",
    "dec": "12"
  };
  class LinkedInParser {
    /**
     * Check if the current page is a LinkedIn profile
     */
    static isLinkedInProfile(url = window.location.href) {
      return /linkedin\.com\/in\//.test(url);
    }
    /**
     * Check if this is the user's own profile (has edit buttons)
     */
    static isOwnProfile(root = document) {
      const editButton = root.querySelector('[id*="edit-profile"], [id*="add-edit"], [aria-label*="编辑"], [aria-label*="Edit"]');
      const addButton = root.querySelector('[id*="overflow-添加"], [id*="overflow-Add"]');
      return !!(editButton || addButton);
    }
    /**
     * Parse the LinkedIn profile page and return structured data
     */
    parse(root = document) {
      const profile = {
        fullName: this.extractName(root),
        headline: this.extractHeadline(root),
        location: this.extractLocation(root),
        linkedinUrl: this.extractLinkedInUrl(root),
        about: this.extractAbout(root),
        workExperiences: this.extractWorkExperiences(root),
        educations: this.extractEducation(root),
        skills: this.extractSkills(root)
      };
      const contactInfo = this.extractContactInfo(root);
      if (contactInfo.email) profile.email = contactInfo.email;
      if (contactInfo.phone) profile.phone = contactInfo.phone;
      return profile;
    }
    /**
     * Convert LinkedIn profile to ParsedProfile format for storage
     * Optionally uses LLM to clean and normalize the data
     */
    async toParsedProfile(profile, useLLMCleaning = true) {
      let cleanedData = null;
      if (useLLMCleaning) {
        try {
          cleanedData = await llmService.cleanLinkedInProfile(profile);
          console.log("[LinkedInParser] LLM cleaned profile data:", cleanedData);
        } catch (error) {
          console.warn("[LinkedInParser] LLM cleaning failed, using basic parsing:", error);
        }
      }
      const singleAnswers = [];
      const experiences = [];
      const fullName = cleanedData?.fullName || profile.fullName;
      const firstName = cleanedData?.firstName;
      const lastName = cleanedData?.lastName;
      if (fullName) {
        singleAnswers.push({ type: Taxonomy.FULL_NAME, value: fullName, confidence: 0.95 });
        if (firstName) {
          singleAnswers.push({ type: Taxonomy.FIRST_NAME, value: firstName, confidence: 0.9 });
        } else {
          const nameParts = this.splitName(fullName);
          if (nameParts.firstName) {
            singleAnswers.push({ type: Taxonomy.FIRST_NAME, value: nameParts.firstName, confidence: 0.85 });
          }
        }
        if (lastName) {
          singleAnswers.push({ type: Taxonomy.LAST_NAME, value: lastName, confidence: 0.9 });
        } else {
          const nameParts = this.splitName(fullName);
          if (nameParts.lastName) {
            singleAnswers.push({ type: Taxonomy.LAST_NAME, value: nameParts.lastName, confidence: 0.85 });
          }
        }
      }
      const fieldMappings = [
        [Taxonomy.EMAIL, cleanedData?.email || profile.email, 0.95],
        [Taxonomy.PHONE, cleanedData?.phone || profile.phone, 0.95],
        [Taxonomy.LOCATION, cleanedData?.location || profile.location, 0.9],
        [Taxonomy.LINKEDIN, profile.linkedinUrl, 0.99],
        [Taxonomy.SUMMARY, profile.about, 0.9],
        [Taxonomy.SKILLS, (cleanedData?.skills || profile.skills).length > 0 ? (cleanedData?.skills || profile.skills).join(", ") : void 0, 0.9]
      ];
      for (const [type, value, confidence] of fieldMappings) {
        if (value) {
          singleAnswers.push({ type, value, confidence });
        }
      }
      const city = cleanedData?.city || this.extractCityFromLocation(cleanedData?.location || profile.location || "");
      if (city) {
        singleAnswers.push({ type: Taxonomy.CITY, value: city, confidence: 0.8 });
      }
      if (cleanedData?.workExperiences?.length) {
        for (let i = 0; i < cleanedData.workExperiences.length; i++) {
          experiences.push(this.cleanedWorkToExperienceEntry(cleanedData.workExperiences[i], i));
        }
      } else {
        for (let i = 0; i < profile.workExperiences.length; i++) {
          experiences.push(this.workToExperienceEntry(profile.workExperiences[i], i));
        }
      }
      if (cleanedData?.educations?.length) {
        for (let i = 0; i < cleanedData.educations.length; i++) {
          experiences.push(this.cleanedEducationToExperienceEntry(cleanedData.educations[i], i));
        }
      } else {
        for (let i = 0; i < profile.educations.length; i++) {
          experiences.push(this.educationToExperienceEntry(profile.educations[i], i));
        }
      }
      return {
        source: "linkedin",
        extractedAt: Date.now(),
        singleAnswers,
        experiences
      };
    }
    cleanedWorkToExperienceEntry(work, index) {
      const now = Date.now();
      const fields = this.buildFields([
        [Taxonomy.COMPANY_NAME, work.company],
        [Taxonomy.JOB_TITLE, work.title],
        [Taxonomy.LOCATION, work.location],
        [Taxonomy.START_DATE, work.startDate],
        [Taxonomy.END_DATE, work.endDate],
        [Taxonomy.JOB_DESCRIPTION, work.description]
      ]);
      return {
        id: `linkedin-work-${now}-${index}`,
        groupType: "WORK",
        priority: index,
        startDate: work.startDate,
        endDate: work.endDate,
        fields,
        createdAt: now,
        updatedAt: now
      };
    }
    cleanedEducationToExperienceEntry(edu, index) {
      const now = Date.now();
      const fields = this.buildFields([
        [Taxonomy.SCHOOL, edu.school],
        [Taxonomy.DEGREE, edu.degree],
        [Taxonomy.MAJOR, edu.major],
        [Taxonomy.START_DATE, edu.startDate],
        [Taxonomy.END_DATE, edu.endDate],
        [Taxonomy.GRAD_DATE, edu.endDate !== "present" ? edu.endDate : void 0],
        [Taxonomy.GPA, edu.gpa]
      ]);
      return {
        id: `linkedin-edu-${now}-${index}`,
        groupType: "EDUCATION",
        priority: index,
        startDate: edu.startDate,
        endDate: edu.endDate,
        fields,
        createdAt: now,
        updatedAt: now
      };
    }
    extractName(root) {
      const selectors = [
        "h1.text-heading-xlarge",
        'h1[class*="text-heading"]',
        ".pv-text-details__left-panel h1",
        ".ph5 h1"
      ];
      for (const selector of selectors) {
        const el = root.querySelector(selector);
        if (el?.textContent) {
          return this.cleanText(el.textContent);
        }
      }
      return "";
    }
    extractHeadline(root) {
      const selectors = [
        ".text-body-medium.break-words",
        ".pv-text-details__left-panel .text-body-medium"
      ];
      for (const selector of selectors) {
        const el = root.querySelector(selector);
        if (el?.textContent) {
          return this.cleanText(el.textContent);
        }
      }
      return "";
    }
    extractLocation(root) {
      const selectors = [
        ".pv-text-details__left-panel .text-body-small:not(.break-words)",
        ".ph5 .text-body-small"
      ];
      for (const selector of selectors) {
        const elements = root.querySelectorAll(selector);
        for (const el of elements) {
          const text = this.cleanText(el.textContent || "");
          if (text && !text.includes("关注") && !text.includes("connection") && !text.includes("follower")) {
            return text;
          }
        }
      }
      return "";
    }
    extractLinkedInUrl(root) {
      const canonical = root.querySelector('link[rel="canonical"]');
      if (canonical?.href) {
        return canonical.href;
      }
      if (typeof window !== "undefined" && window.location.href.includes("linkedin.com/in/")) {
        return window.location.href.split("?")[0];
      }
      return "";
    }
    extractAbout(root) {
      const aboutSection = root.querySelector("#about")?.closest("section") || root.querySelector('[id*="about"]')?.parentElement;
      if (aboutSection) {
        const content = aboutSection.querySelector('.pv-shared-text-with-see-more span[aria-hidden="true"]') || aboutSection.querySelector('.inline-show-more-text span[aria-hidden="true"]');
        if (content?.textContent) {
          return this.cleanText(content.textContent);
        }
      }
      return "";
    }
    extractContactInfo(root) {
      const result = {};
      const emailPatterns = root.querySelectorAll('a[href^="mailto:"]');
      if (emailPatterns.length > 0) {
        const href = emailPatterns[0].href;
        result.email = href.replace("mailto:", "");
      }
      const phonePatterns = root.querySelectorAll('a[href^="tel:"]');
      if (phonePatterns.length > 0) {
        const href = phonePatterns[0].href;
        result.phone = href.replace("tel:", "");
      }
      return result;
    }
    extractWorkExperiences(root) {
      const experiences = [];
      const experienceSection = root.querySelector("#experience")?.closest("section") || root.querySelector('[id="experience"]')?.parentElement?.parentElement;
      if (!experienceSection) {
        return experiences;
      }
      const items = experienceSection.querySelectorAll('[data-view-name="profile-component-entity"]');
      items.forEach((item) => {
        const exp = this.parseWorkExperienceItem(item);
        if (exp) {
          experiences.push(exp);
        }
      });
      return experiences;
    }
    parseWorkExperienceItem(item) {
      const titleEl = item.querySelector('.t-bold span[aria-hidden="true"]') || item.querySelector('.hoverable-link-text span[aria-hidden="true"]');
      const title = titleEl ? this.cleanText(titleEl.textContent || "") : "";
      if (!title) return null;
      const companyEl = item.querySelector('.t-14.t-normal span[aria-hidden="true"]');
      let company = "";
      if (companyEl?.textContent) {
        const parts = companyEl.textContent.split("·").map((p) => this.cleanText(p));
        company = parts[0] || "";
      }
      const dateEl = item.querySelector('.t-black--light .pvs-entity__caption-wrapper[aria-hidden="true"]');
      let startDate;
      let endDate;
      let current = false;
      if (dateEl?.textContent) {
        const dateText = this.cleanText(dateEl.textContent);
        const dateResult = this.parseDateRange(dateText);
        startDate = dateResult.startDate;
        endDate = dateResult.endDate;
        current = dateResult.current;
      }
      const locationEls = item.querySelectorAll('.t-14.t-normal.t-black--light span[aria-hidden="true"]');
      let location;
      locationEls.forEach((el) => {
        const text = this.cleanText(el.textContent || "");
        if (text && !text.includes("年") && !text.includes("个月") && !text.includes("month") && !text.includes("year")) {
          location = text.split("·")[0].trim();
        }
      });
      return {
        title,
        company,
        location,
        startDate,
        endDate,
        current
      };
    }
    extractEducation(root) {
      const educations = [];
      const educationSection = root.querySelector("#education")?.closest("section") || root.querySelector('[id="education"]')?.parentElement?.parentElement;
      if (!educationSection) {
        return educations;
      }
      const items = educationSection.querySelectorAll('[data-view-name="profile-component-entity"]');
      items.forEach((item) => {
        const edu = this.parseEducationItem(item);
        if (edu) {
          educations.push(edu);
        }
      });
      return educations;
    }
    parseEducationItem(item) {
      const schoolEl = item.querySelector('.t-bold span[aria-hidden="true"]') || item.querySelector('.hoverable-link-text span[aria-hidden="true"]');
      const school = schoolEl ? this.cleanText(schoolEl.textContent || "") : "";
      if (!school) return null;
      const degreeEl = item.querySelector('.t-14.t-normal span[aria-hidden="true"]');
      let degree;
      let field;
      if (degreeEl?.textContent) {
        const text = this.cleanText(degreeEl.textContent);
        const parts = text.split(/[,·]/).map((p) => this.cleanText(p));
        degree = parts[0];
        field = parts[1];
      }
      const dateEl = item.querySelector('.t-black--light .pvs-entity__caption-wrapper[aria-hidden="true"]') || item.querySelector('.t-14.t-normal.t-black--light span[aria-hidden="true"]');
      let startDate;
      let endDate;
      if (dateEl?.textContent) {
        const dateText = this.cleanText(dateEl.textContent);
        const dateResult = this.parseDateRange(dateText);
        startDate = dateResult.startDate;
        endDate = dateResult.endDate;
      }
      return {
        school,
        degree,
        field,
        startDate,
        endDate
      };
    }
    extractSkills(root) {
      const skills = [];
      const skillsSection = root.querySelector("#skills")?.closest("section") || root.querySelector('[id="skills"]')?.parentElement?.parentElement;
      if (!skillsSection) {
        return skills;
      }
      const skillItems = skillsSection.querySelectorAll('[data-view-name="profile-component-entity"]');
      skillItems.forEach((item) => {
        const skillEl = item.querySelector('.t-bold span[aria-hidden="true"]') || item.querySelector('.hoverable-link-text span[aria-hidden="true"]');
        if (skillEl?.textContent) {
          const skill = this.cleanText(skillEl.textContent);
          if (skill && !skills.includes(skill)) {
            skills.push(skill);
          }
        }
      });
      return skills;
    }
    parseDateRange(dateText) {
      const result = { current: false };
      if (dateText.includes("至今") || dateText.toLowerCase().includes("present")) {
        result.current = true;
      }
      const chinesePattern = /(\d{4})年(\d{1,2})月/g;
      const englishPattern = /([A-Za-z]+)\s+(\d{4})/g;
      const chineseMatches = [...dateText.matchAll(chinesePattern)];
      if (chineseMatches.length >= 1) {
        result.startDate = `${chineseMatches[0][1]}-${chineseMatches[0][2].padStart(2, "0")}`;
        if (chineseMatches.length >= 2) {
          result.endDate = `${chineseMatches[1][1]}-${chineseMatches[1][2].padStart(2, "0")}`;
        } else if (result.current) {
          result.endDate = "present";
        }
        return result;
      }
      const englishMatches = [...dateText.matchAll(englishPattern)];
      if (englishMatches.length >= 1) {
        const month1 = MONTH_MAP[englishMatches[0][1].toLowerCase().slice(0, 3)] || "01";
        result.startDate = `${englishMatches[0][2]}-${month1}`;
        if (englishMatches.length >= 2) {
          const month2 = MONTH_MAP[englishMatches[1][1].toLowerCase().slice(0, 3)] || "01";
          result.endDate = `${englishMatches[1][2]}-${month2}`;
        } else if (result.current) {
          result.endDate = "present";
        }
      }
      const yearOnlyPattern = /(\d{4})\s*[-–]\s*(\d{4}|至今|present)/i;
      const yearMatch = dateText.match(yearOnlyPattern);
      if (yearMatch && !result.startDate) {
        result.startDate = `${yearMatch[1]}-01`;
        if (yearMatch[2].match(/\d{4}/)) {
          result.endDate = `${yearMatch[2]}-01`;
        } else {
          result.endDate = "present";
          result.current = true;
        }
      }
      return result;
    }
    workToExperienceEntry(work, index) {
      const now = Date.now();
      const fields = this.buildFields([
        [Taxonomy.COMPANY_NAME, work.company],
        [Taxonomy.JOB_TITLE, work.title],
        [Taxonomy.LOCATION, work.location],
        [Taxonomy.START_DATE, work.startDate],
        [Taxonomy.END_DATE, work.endDate],
        [Taxonomy.JOB_DESCRIPTION, work.description]
      ]);
      return {
        id: `linkedin-work-${now}-${index}`,
        groupType: "WORK",
        priority: index,
        startDate: work.startDate,
        endDate: work.endDate,
        fields,
        createdAt: now,
        updatedAt: now
      };
    }
    educationToExperienceEntry(edu, index) {
      const now = Date.now();
      const fields = this.buildFields([
        [Taxonomy.SCHOOL, edu.school],
        [Taxonomy.DEGREE, edu.degree],
        [Taxonomy.MAJOR, edu.field],
        [Taxonomy.START_DATE, edu.startDate],
        [Taxonomy.END_DATE, edu.endDate],
        [Taxonomy.GRAD_DATE, edu.endDate !== "present" ? edu.endDate : void 0]
      ]);
      return {
        id: `linkedin-edu-${now}-${index}`,
        groupType: "EDUCATION",
        priority: index,
        startDate: edu.startDate,
        endDate: edu.endDate,
        fields,
        createdAt: now,
        updatedAt: now
      };
    }
    /**
     * Build fields object from array of [Taxonomy, value] pairs, filtering out undefined values
     */
    buildFields(pairs) {
      const fields = {};
      for (const [type, value] of pairs) {
        if (value) {
          fields[type] = value;
        }
      }
      return fields;
    }
    splitName(fullName) {
      const parts = fullName.trim().split(/\s+/);
      if (parts.length === 0) return {};
      if (parts.length === 1 && /^[\u4e00-\u9fa5]+$/.test(fullName)) {
        return {
          lastName: fullName.charAt(0),
          firstName: fullName.slice(1)
        };
      }
      return {
        firstName: parts[0],
        lastName: parts.length > 1 ? parts[parts.length - 1] : void 0
      };
    }
    extractCityFromLocation(location) {
      const parts = location.split(/[,·]/);
      if (/[\u4e00-\u9fa5]/.test(location)) {
        for (let i = parts.length - 1; i >= 0; i--) {
          const part = this.cleanText(parts[i]);
          if (part && !part.includes("省") && !part.includes("国")) {
            return part.replace(/[市区县]$/, "");
          }
        }
      }
      return this.cleanText(parts[0]);
    }
    cleanText(text) {
      return text.replace(/<!---->/g, "").replace(/\s+/g, " ").trim();
    }
  }
  const linkedInParser = new LinkedInParser();

  const LinkedInParser$1 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    LinkedInParser,
    linkedInParser
  }, Symbol.toStringTag, { value: 'Module' }));

})();
//# sourceMappingURL=content.js.map
