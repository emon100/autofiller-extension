const CONSENT_VERSION = "1.0";
const STORAGE_KEY_CONSENT = "userConsent";

async function getConsentState() {
  try {
    const result = await chrome.storage.local.get(STORAGE_KEY_CONSENT);
    return result[STORAGE_KEY_CONSENT] || null;
  } catch {
    return null;
  }
}
async function setConsentState(prefs) {
  await chrome.storage.local.set({ [STORAGE_KEY_CONSENT]: prefs });
}
async function hasValidConsent() {
  const consent = await getConsentState();
  if (!consent) return false;
  if (consent.version !== CONSENT_VERSION) return false;
  if (!consent.dataCollection) return false;
  return true;
}
function createConsentPreferences(options) {
  return {
    version: CONSENT_VERSION,
    timestamp: Date.now(),
    dataCollection: options.dataCollection,
    llmDataSharing: options.llmDataSharing,
    acknowledgedPrivacyPolicy: options.acknowledgedPrivacyPolicy
  };
}

export { createConsentPreferences as c, getConsentState as g, hasValidConsent as h, setConsentState as s };
//# sourceMappingURL=index-D0pbUIir.js.map
