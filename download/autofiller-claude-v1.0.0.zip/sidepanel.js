const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["chunks/pdf-DM9BqXBE.js","chunks/index-D0pbUIir.js"])))=>i.map(i=>d[i]);
import { g as getConsentState, c as createConsentPreferences, s as setConsentState, h as hasValidConsent } from './chunks/index-D0pbUIir.js';

var commonjsGlobal = typeof globalThis !== 'undefined' ? globalThis : typeof window !== 'undefined' ? window : typeof global !== 'undefined' ? global : typeof self !== 'undefined' ? self : {};

function getDefaultExportFromCjs (x) {
	return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
}

function getAugmentedNamespace(n) {
  if (n.__esModule) return n;
  var f = n.default;
	if (typeof f == "function") {
		var a = function a () {
			if (this instanceof a) {
        return Reflect.construct(f, arguments, this.constructor);
			}
			return f.apply(this, arguments);
		};
		a.prototype = f.prototype;
  } else a = {};
  Object.defineProperty(a, '__esModule', {value: true});
	Object.keys(n).forEach(function (k) {
		var d = Object.getOwnPropertyDescriptor(n, k);
		Object.defineProperty(a, k, d.get ? d : {
			enumerable: true,
			get: function () {
				return n[k];
			}
		});
	});
	return a;
}

var jsxRuntime = {exports: {}};

var reactJsxRuntime_production_min = {};

var react = {exports: {}};

var react_production_min = {};

/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var l$3=Symbol.for("react.element"),n$3=Symbol.for("react.portal"),p$3=Symbol.for("react.fragment"),q$1=Symbol.for("react.strict_mode"),r$2=Symbol.for("react.profiler"),t$3=Symbol.for("react.provider"),u$2=Symbol.for("react.context"),v$2=Symbol.for("react.forward_ref"),w$1=Symbol.for("react.suspense"),x$1=Symbol.for("react.memo"),y$1=Symbol.for("react.lazy"),z$2=Symbol.iterator;function A$3(a){if(null===a||"object"!==typeof a)return null;a=z$2&&a[z$2]||a["@@iterator"];return "function"===typeof a?a:null}
var B$1={isMounted:function(){return  false},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},C$3=Object.assign,D$2={};function E$3(a,b,e){this.props=a;this.context=b;this.refs=D$2;this.updater=e||B$1;}E$3.prototype.isReactComponent={};
E$3.prototype.setState=function(a,b){if("object"!==typeof a&&"function"!==typeof a&&null!=a)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,a,b,"setState");};E$3.prototype.forceUpdate=function(a){this.updater.enqueueForceUpdate(this,a,"forceUpdate");};function F$1(){}F$1.prototype=E$3.prototype;function G$2(a,b,e){this.props=a;this.context=b;this.refs=D$2;this.updater=e||B$1;}var H$2=G$2.prototype=new F$1;
H$2.constructor=G$2;C$3(H$2,E$3.prototype);H$2.isPureReactComponent=true;var I$3=Array.isArray,J=Object.prototype.hasOwnProperty,K$2={current:null},L$1={key:true,ref:true,__self:true,__source:true};
function M$1(a,b,e){var d,c={},k=null,h=null;if(null!=b)for(d in void 0!==b.ref&&(h=b.ref),void 0!==b.key&&(k=""+b.key),b)J.call(b,d)&&!L$1.hasOwnProperty(d)&&(c[d]=b[d]);var g=arguments.length-2;if(1===g)c.children=e;else if(1<g){for(var f=Array(g),m=0;m<g;m++)f[m]=arguments[m+2];c.children=f;}if(a&&a.defaultProps)for(d in g=a.defaultProps,g) void 0===c[d]&&(c[d]=g[d]);return {$$typeof:l$3,type:a,key:k,ref:h,props:c,_owner:K$2.current}}
function N$1(a,b){return {$$typeof:l$3,type:a.type,key:b,ref:a.ref,props:a.props,_owner:a._owner}}function O$2(a){return "object"===typeof a&&null!==a&&a.$$typeof===l$3}function escape(a){var b={"=":"=0",":":"=2"};return "$"+a.replace(/[=:]/g,function(a){return b[a]})}var P$4=/\/+/g;function Q$2(a,b){return "object"===typeof a&&null!==a&&null!=a.key?escape(""+a.key):b.toString(36)}
function R$1(a,b,e,d,c){var k=typeof a;if("undefined"===k||"boolean"===k)a=null;var h=false;if(null===a)h=true;else switch(k){case "string":case "number":h=true;break;case "object":switch(a.$$typeof){case l$3:case n$3:h=true;}}if(h)return h=a,c=c(h),a=""===d?"."+Q$2(h,0):d,I$3(c)?(e="",null!=a&&(e=a.replace(P$4,"$&/")+"/"),R$1(c,b,e,"",function(a){return a})):null!=c&&(O$2(c)&&(c=N$1(c,e+(!c.key||h&&h.key===c.key?"":(""+c.key).replace(P$4,"$&/")+"/")+a)),b.push(c)),1;h=0;d=""===d?".":d+":";if(I$3(a))for(var g=0;g<a.length;g++){k=
a[g];var f=d+Q$2(k,g);h+=R$1(k,b,e,f,c);}else if(f=A$3(a),"function"===typeof f)for(a=f.call(a),g=0;!(k=a.next()).done;)k=k.value,f=d+Q$2(k,g++),h+=R$1(k,b,e,f,c);else if("object"===k)throw b=String(a),Error("Objects are not valid as a React child (found: "+("[object Object]"===b?"object with keys {"+Object.keys(a).join(", ")+"}":b)+"). If you meant to render a collection of children, use an array instead.");return h}
function S$2(a,b,e){if(null==a)return a;var d=[],c=0;R$1(a,d,"","",function(a){return b.call(e,a,c++)});return d}function T$2(a){if(-1===a._status){var b=a._result;b=b();b.then(function(b){if(0===a._status||-1===a._status)a._status=1,a._result=b;},function(b){if(0===a._status||-1===a._status)a._status=2,a._result=b;});-1===a._status&&(a._status=0,a._result=b);}if(1===a._status)return a._result.default;throw a._result;}
var U$2={current:null},V$3={transition:null},W$1={ReactCurrentDispatcher:U$2,ReactCurrentBatchConfig:V$3,ReactCurrentOwner:K$2};function X$2(){throw Error("act(...) is not supported in production builds of React.");}
react_production_min.Children={map:S$2,forEach:function(a,b,e){S$2(a,function(){b.apply(this,arguments);},e);},count:function(a){var b=0;S$2(a,function(){b++;});return b},toArray:function(a){return S$2(a,function(a){return a})||[]},only:function(a){if(!O$2(a))throw Error("React.Children.only expected to receive a single React element child.");return a}};react_production_min.Component=E$3;react_production_min.Fragment=p$3;react_production_min.Profiler=r$2;react_production_min.PureComponent=G$2;react_production_min.StrictMode=q$1;react_production_min.Suspense=w$1;
react_production_min.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=W$1;react_production_min.act=X$2;
react_production_min.cloneElement=function(a,b,e){if(null===a||void 0===a)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+a+".");var d=C$3({},a.props),c=a.key,k=a.ref,h=a._owner;if(null!=b){ void 0!==b.ref&&(k=b.ref,h=K$2.current);void 0!==b.key&&(c=""+b.key);if(a.type&&a.type.defaultProps)var g=a.type.defaultProps;for(f in b)J.call(b,f)&&!L$1.hasOwnProperty(f)&&(d[f]=void 0===b[f]&&void 0!==g?g[f]:b[f]);}var f=arguments.length-2;if(1===f)d.children=e;else if(1<f){g=Array(f);
for(var m=0;m<f;m++)g[m]=arguments[m+2];d.children=g;}return {$$typeof:l$3,type:a.type,key:c,ref:k,props:d,_owner:h}};react_production_min.createContext=function(a){a={$$typeof:u$2,_currentValue:a,_currentValue2:a,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null};a.Provider={$$typeof:t$3,_context:a};return a.Consumer=a};react_production_min.createElement=M$1;react_production_min.createFactory=function(a){var b=M$1.bind(null,a);b.type=a;return b};react_production_min.createRef=function(){return {current:null}};
react_production_min.forwardRef=function(a){return {$$typeof:v$2,render:a}};react_production_min.isValidElement=O$2;react_production_min.lazy=function(a){return {$$typeof:y$1,_payload:{_status:-1,_result:a},_init:T$2}};react_production_min.memo=function(a,b){return {$$typeof:x$1,type:a,compare:void 0===b?null:b}};react_production_min.startTransition=function(a){var b=V$3.transition;V$3.transition={};try{a();}finally{V$3.transition=b;}};react_production_min.unstable_act=X$2;react_production_min.useCallback=function(a,b){return U$2.current.useCallback(a,b)};react_production_min.useContext=function(a){return U$2.current.useContext(a)};
react_production_min.useDebugValue=function(){};react_production_min.useDeferredValue=function(a){return U$2.current.useDeferredValue(a)};react_production_min.useEffect=function(a,b){return U$2.current.useEffect(a,b)};react_production_min.useId=function(){return U$2.current.useId()};react_production_min.useImperativeHandle=function(a,b,e){return U$2.current.useImperativeHandle(a,b,e)};react_production_min.useInsertionEffect=function(a,b){return U$2.current.useInsertionEffect(a,b)};react_production_min.useLayoutEffect=function(a,b){return U$2.current.useLayoutEffect(a,b)};
react_production_min.useMemo=function(a,b){return U$2.current.useMemo(a,b)};react_production_min.useReducer=function(a,b,e){return U$2.current.useReducer(a,b,e)};react_production_min.useRef=function(a){return U$2.current.useRef(a)};react_production_min.useState=function(a){return U$2.current.useState(a)};react_production_min.useSyncExternalStore=function(a,b,e){return U$2.current.useSyncExternalStore(a,b,e)};react_production_min.useTransition=function(){return U$2.current.useTransition()};react_production_min.version="18.3.1";

{
  react.exports = react_production_min;
}

var reactExports = react.exports;
const React = /*@__PURE__*/getDefaultExportFromCjs(reactExports);

/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var f$3=reactExports,k=Symbol.for("react.element"),l$2=Symbol.for("react.fragment"),m$2=Object.prototype.hasOwnProperty,n$2=f$3.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,p$2={key:true,ref:true,__self:true,__source:true};
function q(c,a,g){var b,d={},e=null,h=null;void 0!==g&&(e=""+g);void 0!==a.key&&(e=""+a.key);void 0!==a.ref&&(h=a.ref);for(b in a)m$2.call(a,b)&&!p$2.hasOwnProperty(b)&&(d[b]=a[b]);if(c&&c.defaultProps)for(b in a=c.defaultProps,a) void 0===d[b]&&(d[b]=a[b]);return {$$typeof:k,type:c,key:e,ref:h,props:d,_owner:n$2.current}}reactJsxRuntime_production_min.Fragment=l$2;reactJsxRuntime_production_min.jsx=q;reactJsxRuntime_production_min.jsxs=q;

{
  jsxRuntime.exports = reactJsxRuntime_production_min;
}

var jsxRuntimeExports = jsxRuntime.exports;

var client = {};

var reactDom = {exports: {}};

var reactDom_production_min = {};

var scheduler = {exports: {}};

var scheduler_production_min = {};

/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

(function (exports$1) {
function f(a,b){var c=a.length;a.push(b);a:for(;0<c;){var d=c-1>>>1,e=a[d];if(0<g(e,b))a[d]=b,a[c]=e,c=d;else break a}}function h(a){return 0===a.length?null:a[0]}function k(a){if(0===a.length)return null;var b=a[0],c=a.pop();if(c!==b){a[0]=c;a:for(var d=0,e=a.length,w=e>>>1;d<w;){var m=2*(d+1)-1,C=a[m],n=m+1,x=a[n];if(0>g(C,c))n<e&&0>g(x,C)?(a[d]=x,a[n]=c,d=n):(a[d]=C,a[m]=c,d=m);else if(n<e&&0>g(x,c))a[d]=x,a[n]=c,d=n;else break a}}return b}
	function g(a,b){var c=a.sortIndex-b.sortIndex;return 0!==c?c:a.id-b.id}if("object"===typeof performance&&"function"===typeof performance.now){var l=performance;exports$1.unstable_now=function(){return l.now()};}else {var p=Date,q=p.now();exports$1.unstable_now=function(){return p.now()-q};}var r=[],t=[],u=1,v=null,y=3,z=false,A=false,B=false,D="function"===typeof setTimeout?setTimeout:null,E="function"===typeof clearTimeout?clearTimeout:null,F="undefined"!==typeof setImmediate?setImmediate:null;
	"undefined"!==typeof navigator&&void 0!==navigator.scheduling&&void 0!==navigator.scheduling.isInputPending&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function G(a){for(var b=h(t);null!==b;){if(null===b.callback)k(t);else if(b.startTime<=a)k(t),b.sortIndex=b.expirationTime,f(r,b);else break;b=h(t);}}function H(a){B=false;G(a);if(!A)if(null!==h(r))A=true,I(J);else {var b=h(t);null!==b&&K(H,b.startTime-a);}}
	function J(a,b){A=false;B&&(B=false,E(L),L=-1);z=true;var c=y;try{G(b);for(v=h(r);null!==v&&(!(v.expirationTime>b)||a&&!M());){var d=v.callback;if("function"===typeof d){v.callback=null;y=v.priorityLevel;var e=d(v.expirationTime<=b);b=exports$1.unstable_now();"function"===typeof e?v.callback=e:v===h(r)&&k(r);G(b);}else k(r);v=h(r);}if(null!==v)var w=!0;else {var m=h(t);null!==m&&K(H,m.startTime-b);w=!1;}return w}finally{v=null,y=c,z=false;}}var N=false,O=null,L=-1,P=5,Q=-1;
	function M(){return exports$1.unstable_now()-Q<P?false:true}function R(){if(null!==O){var a=exports$1.unstable_now();Q=a;var b=true;try{b=O(!0,a);}finally{b?S():(N=false,O=null);}}else N=false;}var S;if("function"===typeof F)S=function(){F(R);};else if("undefined"!==typeof MessageChannel){var T=new MessageChannel,U=T.port2;T.port1.onmessage=R;S=function(){U.postMessage(null);};}else S=function(){D(R,0);};function I(a){O=a;N||(N=true,S());}function K(a,b){L=D(function(){a(exports$1.unstable_now());},b);}
	exports$1.unstable_IdlePriority=5;exports$1.unstable_ImmediatePriority=1;exports$1.unstable_LowPriority=4;exports$1.unstable_NormalPriority=3;exports$1.unstable_Profiling=null;exports$1.unstable_UserBlockingPriority=2;exports$1.unstable_cancelCallback=function(a){a.callback=null;};exports$1.unstable_continueExecution=function(){A||z||(A=true,I(J));};
	exports$1.unstable_forceFrameRate=function(a){0>a||125<a?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):P=0<a?Math.floor(1E3/a):5;};exports$1.unstable_getCurrentPriorityLevel=function(){return y};exports$1.unstable_getFirstCallbackNode=function(){return h(r)};exports$1.unstable_next=function(a){switch(y){case 1:case 2:case 3:var b=3;break;default:b=y;}var c=y;y=b;try{return a()}finally{y=c;}};exports$1.unstable_pauseExecution=function(){};
	exports$1.unstable_requestPaint=function(){};exports$1.unstable_runWithPriority=function(a,b){switch(a){case 1:case 2:case 3:case 4:case 5:break;default:a=3;}var c=y;y=a;try{return b()}finally{y=c;}};
	exports$1.unstable_scheduleCallback=function(a,b,c){var d=exports$1.unstable_now();"object"===typeof c&&null!==c?(c=c.delay,c="number"===typeof c&&0<c?d+c:d):c=d;switch(a){case 1:var e=-1;break;case 2:e=250;break;case 5:e=1073741823;break;case 4:e=1E4;break;default:e=5E3;}e=c+e;a={id:u++,callback:b,priorityLevel:a,startTime:c,expirationTime:e,sortIndex:-1};c>d?(a.sortIndex=c,f(t,a),null===h(r)&&a===h(t)&&(B?(E(L),L=-1):B=true,K(H,c-d))):(a.sortIndex=e,f(r,a),A||z||(A=true,I(J)));return a};
	exports$1.unstable_shouldYield=M;exports$1.unstable_wrapCallback=function(a){var b=y;return function(){var c=y;y=b;try{return a.apply(this,arguments)}finally{y=c;}}}; 
} (scheduler_production_min));

{
  scheduler.exports = scheduler_production_min;
}

var schedulerExports = scheduler.exports;

/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var aa=reactExports,ca=schedulerExports;function p$1(a){for(var b="https://reactjs.org/docs/error-decoder.html?invariant="+a,c=1;c<arguments.length;c++)b+="&args[]="+encodeURIComponent(arguments[c]);return "Minified React error #"+a+"; visit "+b+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var da=new Set,ea={};function fa(a,b){ha(a,b);ha(a+"Capture",b);}
function ha(a,b){ea[a]=b;for(a=0;a<b.length;a++)da.add(b[a]);}
var ia=!("undefined"===typeof window||"undefined"===typeof window.document||"undefined"===typeof window.document.createElement),ja=Object.prototype.hasOwnProperty,ka=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,la=
{},ma={};function oa(a){if(ja.call(ma,a))return  true;if(ja.call(la,a))return  false;if(ka.test(a))return ma[a]=true;la[a]=true;return  false}function pa(a,b,c,d){if(null!==c&&0===c.type)return  false;switch(typeof b){case "function":case "symbol":return  true;case "boolean":if(d)return  false;if(null!==c)return !c.acceptsBooleans;a=a.toLowerCase().slice(0,5);return "data-"!==a&&"aria-"!==a;default:return  false}}
function qa(a,b,c,d){if(null===b||"undefined"===typeof b||pa(a,b,c,d))return  true;if(d)return  false;if(null!==c)switch(c.type){case 3:return !b;case 4:return  false===b;case 5:return isNaN(b);case 6:return isNaN(b)||1>b}return  false}function v$1(a,b,c,d,e,f,g){this.acceptsBooleans=2===b||3===b||4===b;this.attributeName=d;this.attributeNamespace=e;this.mustUseProperty=c;this.propertyName=a;this.type=b;this.sanitizeURL=f;this.removeEmptyString=g;}var z$1={};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(a){z$1[a]=new v$1(a,0,false,a,null,false,false);});[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(a){var b=a[0];z$1[b]=new v$1(b,1,false,a[1],null,false,false);});["contentEditable","draggable","spellCheck","value"].forEach(function(a){z$1[a]=new v$1(a,2,false,a.toLowerCase(),null,false,false);});
["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(a){z$1[a]=new v$1(a,2,false,a,null,false,false);});"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(a){z$1[a]=new v$1(a,3,false,a.toLowerCase(),null,false,false);});
["checked","multiple","muted","selected"].forEach(function(a){z$1[a]=new v$1(a,3,true,a,null,false,false);});["capture","download"].forEach(function(a){z$1[a]=new v$1(a,4,false,a,null,false,false);});["cols","rows","size","span"].forEach(function(a){z$1[a]=new v$1(a,6,false,a,null,false,false);});["rowSpan","start"].forEach(function(a){z$1[a]=new v$1(a,5,false,a.toLowerCase(),null,false,false);});var ra=/[\-:]([a-z])/g;function sa(a){return a[1].toUpperCase()}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(a){var b=a.replace(ra,
sa);z$1[b]=new v$1(b,1,false,a,null,false,false);});"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(a){var b=a.replace(ra,sa);z$1[b]=new v$1(b,1,false,a,"http://www.w3.org/1999/xlink",false,false);});["xml:base","xml:lang","xml:space"].forEach(function(a){var b=a.replace(ra,sa);z$1[b]=new v$1(b,1,false,a,"http://www.w3.org/XML/1998/namespace",false,false);});["tabIndex","crossOrigin"].forEach(function(a){z$1[a]=new v$1(a,1,false,a.toLowerCase(),null,false,false);});
z$1.xlinkHref=new v$1("xlinkHref",1,false,"xlink:href","http://www.w3.org/1999/xlink",true,false);["src","href","action","formAction"].forEach(function(a){z$1[a]=new v$1(a,1,false,a.toLowerCase(),null,true,true);});
function ta(a,b,c,d){var e=z$1.hasOwnProperty(b)?z$1[b]:null;if(null!==e?0!==e.type:d||!(2<b.length)||"o"!==b[0]&&"O"!==b[0]||"n"!==b[1]&&"N"!==b[1])qa(b,c,e,d)&&(c=null),d||null===e?oa(b)&&(null===c?a.removeAttribute(b):a.setAttribute(b,""+c)):e.mustUseProperty?a[e.propertyName]=null===c?3===e.type?false:"":c:(b=e.attributeName,d=e.attributeNamespace,null===c?a.removeAttribute(b):(e=e.type,c=3===e||4===e&&true===c?"":""+c,d?a.setAttributeNS(d,b,c):a.setAttribute(b,c)));}
var ua=aa.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,va=Symbol.for("react.element"),wa=Symbol.for("react.portal"),ya=Symbol.for("react.fragment"),za=Symbol.for("react.strict_mode"),Aa=Symbol.for("react.profiler"),Ba=Symbol.for("react.provider"),Ca=Symbol.for("react.context"),Da=Symbol.for("react.forward_ref"),Ea=Symbol.for("react.suspense"),Fa=Symbol.for("react.suspense_list"),Ga=Symbol.for("react.memo"),Ha=Symbol.for("react.lazy");var Ia=Symbol.for("react.offscreen");var Ja=Symbol.iterator;function Ka(a){if(null===a||"object"!==typeof a)return null;a=Ja&&a[Ja]||a["@@iterator"];return "function"===typeof a?a:null}var A$2=Object.assign,La;function Ma(a){if(void 0===La)try{throw Error();}catch(c){var b=c.stack.trim().match(/\n( *(at )?)/);La=b&&b[1]||"";}return "\n"+La+a}var Na=false;
function Oa(a,b){if(!a||Na)return "";Na=true;var c=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(b)if(b=function(){throw Error();},Object.defineProperty(b.prototype,"props",{set:function(){throw Error();}}),"object"===typeof Reflect&&Reflect.construct){try{Reflect.construct(b,[]);}catch(l){var d=l;}Reflect.construct(a,[],b);}else {try{b.call();}catch(l){d=l;}a.call(b.prototype);}else {try{throw Error();}catch(l){d=l;}a();}}catch(l){if(l&&d&&"string"===typeof l.stack){for(var e=l.stack.split("\n"),
f=d.stack.split("\n"),g=e.length-1,h=f.length-1;1<=g&&0<=h&&e[g]!==f[h];)h--;for(;1<=g&&0<=h;g--,h--)if(e[g]!==f[h]){if(1!==g||1!==h){do if(g--,h--,0>h||e[g]!==f[h]){var k="\n"+e[g].replace(" at new "," at ");a.displayName&&k.includes("<anonymous>")&&(k=k.replace("<anonymous>",a.displayName));return k}while(1<=g&&0<=h)}break}}}finally{Na=false,Error.prepareStackTrace=c;}return (a=a?a.displayName||a.name:"")?Ma(a):""}
function Pa(a){switch(a.tag){case 5:return Ma(a.type);case 16:return Ma("Lazy");case 13:return Ma("Suspense");case 19:return Ma("SuspenseList");case 0:case 2:case 15:return a=Oa(a.type,false),a;case 11:return a=Oa(a.type.render,false),a;case 1:return a=Oa(a.type,true),a;default:return ""}}
function Qa(a){if(null==a)return null;if("function"===typeof a)return a.displayName||a.name||null;if("string"===typeof a)return a;switch(a){case ya:return "Fragment";case wa:return "Portal";case Aa:return "Profiler";case za:return "StrictMode";case Ea:return "Suspense";case Fa:return "SuspenseList"}if("object"===typeof a)switch(a.$$typeof){case Ca:return (a.displayName||"Context")+".Consumer";case Ba:return (a._context.displayName||"Context")+".Provider";case Da:var b=a.render;a=a.displayName;a||(a=b.displayName||
b.name||"",a=""!==a?"ForwardRef("+a+")":"ForwardRef");return a;case Ga:return b=a.displayName||null,null!==b?b:Qa(a.type)||"Memo";case Ha:b=a._payload;a=a._init;try{return Qa(a(b))}catch(c){}}return null}
function Ra(a){var b=a.type;switch(a.tag){case 24:return "Cache";case 9:return (b.displayName||"Context")+".Consumer";case 10:return (b._context.displayName||"Context")+".Provider";case 18:return "DehydratedFragment";case 11:return a=b.render,a=a.displayName||a.name||"",b.displayName||(""!==a?"ForwardRef("+a+")":"ForwardRef");case 7:return "Fragment";case 5:return b;case 4:return "Portal";case 3:return "Root";case 6:return "Text";case 16:return Qa(b);case 8:return b===za?"StrictMode":"Mode";case 22:return "Offscreen";
case 12:return "Profiler";case 21:return "Scope";case 13:return "Suspense";case 19:return "SuspenseList";case 25:return "TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if("function"===typeof b)return b.displayName||b.name||null;if("string"===typeof b)return b}return null}function Sa(a){switch(typeof a){case "boolean":case "number":case "string":case "undefined":return a;case "object":return a;default:return ""}}
function Ta(a){var b=a.type;return (a=a.nodeName)&&"input"===a.toLowerCase()&&("checkbox"===b||"radio"===b)}
function Ua(a){var b=Ta(a)?"checked":"value",c=Object.getOwnPropertyDescriptor(a.constructor.prototype,b),d=""+a[b];if(!a.hasOwnProperty(b)&&"undefined"!==typeof c&&"function"===typeof c.get&&"function"===typeof c.set){var e=c.get,f=c.set;Object.defineProperty(a,b,{configurable:true,get:function(){return e.call(this)},set:function(a){d=""+a;f.call(this,a);}});Object.defineProperty(a,b,{enumerable:c.enumerable});return {getValue:function(){return d},setValue:function(a){d=""+a;},stopTracking:function(){a._valueTracker=
null;delete a[b];}}}}function Va(a){a._valueTracker||(a._valueTracker=Ua(a));}function Wa(a){if(!a)return  false;var b=a._valueTracker;if(!b)return  true;var c=b.getValue();var d="";a&&(d=Ta(a)?a.checked?"true":"false":a.value);a=d;return a!==c?(b.setValue(a),true):false}function Xa(a){a=a||("undefined"!==typeof document?document:void 0);if("undefined"===typeof a)return null;try{return a.activeElement||a.body}catch(b){return a.body}}
function Ya(a,b){var c=b.checked;return A$2({},b,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:null!=c?c:a._wrapperState.initialChecked})}function Za(a,b){var c=null==b.defaultValue?"":b.defaultValue,d=null!=b.checked?b.checked:b.defaultChecked;c=Sa(null!=b.value?b.value:c);a._wrapperState={initialChecked:d,initialValue:c,controlled:"checkbox"===b.type||"radio"===b.type?null!=b.checked:null!=b.value};}function ab(a,b){b=b.checked;null!=b&&ta(a,"checked",b,false);}
function bb(a,b){ab(a,b);var c=Sa(b.value),d=b.type;if(null!=c)if("number"===d){if(0===c&&""===a.value||a.value!=c)a.value=""+c;}else a.value!==""+c&&(a.value=""+c);else if("submit"===d||"reset"===d){a.removeAttribute("value");return}b.hasOwnProperty("value")?cb(a,b.type,c):b.hasOwnProperty("defaultValue")&&cb(a,b.type,Sa(b.defaultValue));null==b.checked&&null!=b.defaultChecked&&(a.defaultChecked=!!b.defaultChecked);}
function db(a,b,c){if(b.hasOwnProperty("value")||b.hasOwnProperty("defaultValue")){var d=b.type;if(!("submit"!==d&&"reset"!==d||void 0!==b.value&&null!==b.value))return;b=""+a._wrapperState.initialValue;c||b===a.value||(a.value=b);a.defaultValue=b;}c=a.name;""!==c&&(a.name="");a.defaultChecked=!!a._wrapperState.initialChecked;""!==c&&(a.name=c);}
function cb(a,b,c){if("number"!==b||Xa(a.ownerDocument)!==a)null==c?a.defaultValue=""+a._wrapperState.initialValue:a.defaultValue!==""+c&&(a.defaultValue=""+c);}var eb=Array.isArray;
function fb(a,b,c,d){a=a.options;if(b){b={};for(var e=0;e<c.length;e++)b["$"+c[e]]=true;for(c=0;c<a.length;c++)e=b.hasOwnProperty("$"+a[c].value),a[c].selected!==e&&(a[c].selected=e),e&&d&&(a[c].defaultSelected=true);}else {c=""+Sa(c);b=null;for(e=0;e<a.length;e++){if(a[e].value===c){a[e].selected=true;d&&(a[e].defaultSelected=true);return}null!==b||a[e].disabled||(b=a[e]);}null!==b&&(b.selected=true);}}
function gb(a,b){if(null!=b.dangerouslySetInnerHTML)throw Error(p$1(91));return A$2({},b,{value:void 0,defaultValue:void 0,children:""+a._wrapperState.initialValue})}function hb(a,b){var c=b.value;if(null==c){c=b.children;b=b.defaultValue;if(null!=c){if(null!=b)throw Error(p$1(92));if(eb(c)){if(1<c.length)throw Error(p$1(93));c=c[0];}b=c;}null==b&&(b="");c=b;}a._wrapperState={initialValue:Sa(c)};}
function ib(a,b){var c=Sa(b.value),d=Sa(b.defaultValue);null!=c&&(c=""+c,c!==a.value&&(a.value=c),null==b.defaultValue&&a.defaultValue!==c&&(a.defaultValue=c));null!=d&&(a.defaultValue=""+d);}function jb(a){var b=a.textContent;b===a._wrapperState.initialValue&&""!==b&&null!==b&&(a.value=b);}function kb(a){switch(a){case "svg":return "http://www.w3.org/2000/svg";case "math":return "http://www.w3.org/1998/Math/MathML";default:return "http://www.w3.org/1999/xhtml"}}
function lb(a,b){return null==a||"http://www.w3.org/1999/xhtml"===a?kb(b):"http://www.w3.org/2000/svg"===a&&"foreignObject"===b?"http://www.w3.org/1999/xhtml":a}
var mb,nb=function(a){return "undefined"!==typeof MSApp&&MSApp.execUnsafeLocalFunction?function(b,c,d,e){MSApp.execUnsafeLocalFunction(function(){return a(b,c,d,e)});}:a}(function(a,b){if("http://www.w3.org/2000/svg"!==a.namespaceURI||"innerHTML"in a)a.innerHTML=b;else {mb=mb||document.createElement("div");mb.innerHTML="<svg>"+b.valueOf().toString()+"</svg>";for(b=mb.firstChild;a.firstChild;)a.removeChild(a.firstChild);for(;b.firstChild;)a.appendChild(b.firstChild);}});
function ob(a,b){if(b){var c=a.firstChild;if(c&&c===a.lastChild&&3===c.nodeType){c.nodeValue=b;return}}a.textContent=b;}
var pb={animationIterationCount:true,aspectRatio:true,borderImageOutset:true,borderImageSlice:true,borderImageWidth:true,boxFlex:true,boxFlexGroup:true,boxOrdinalGroup:true,columnCount:true,columns:true,flex:true,flexGrow:true,flexPositive:true,flexShrink:true,flexNegative:true,flexOrder:true,gridArea:true,gridRow:true,gridRowEnd:true,gridRowSpan:true,gridRowStart:true,gridColumn:true,gridColumnEnd:true,gridColumnSpan:true,gridColumnStart:true,fontWeight:true,lineClamp:true,lineHeight:true,opacity:true,order:true,orphans:true,tabSize:true,widows:true,zIndex:true,
zoom:true,fillOpacity:true,floodOpacity:true,stopOpacity:true,strokeDasharray:true,strokeDashoffset:true,strokeMiterlimit:true,strokeOpacity:true,strokeWidth:true},qb=["Webkit","ms","Moz","O"];Object.keys(pb).forEach(function(a){qb.forEach(function(b){b=b+a.charAt(0).toUpperCase()+a.substring(1);pb[b]=pb[a];});});function rb(a,b,c){return null==b||"boolean"===typeof b||""===b?"":c||"number"!==typeof b||0===b||pb.hasOwnProperty(a)&&pb[a]?(""+b).trim():b+"px"}
function sb(a,b){a=a.style;for(var c in b)if(b.hasOwnProperty(c)){var d=0===c.indexOf("--"),e=rb(c,b[c],d);"float"===c&&(c="cssFloat");d?a.setProperty(c,e):a[c]=e;}}var tb=A$2({menuitem:true},{area:true,base:true,br:true,col:true,embed:true,hr:true,img:true,input:true,keygen:true,link:true,meta:true,param:true,source:true,track:true,wbr:true});
function ub(a,b){if(b){if(tb[a]&&(null!=b.children||null!=b.dangerouslySetInnerHTML))throw Error(p$1(137,a));if(null!=b.dangerouslySetInnerHTML){if(null!=b.children)throw Error(p$1(60));if("object"!==typeof b.dangerouslySetInnerHTML||!("__html"in b.dangerouslySetInnerHTML))throw Error(p$1(61));}if(null!=b.style&&"object"!==typeof b.style)throw Error(p$1(62));}}
function vb(a,b){if(-1===a.indexOf("-"))return "string"===typeof b.is;switch(a){case "annotation-xml":case "color-profile":case "font-face":case "font-face-src":case "font-face-uri":case "font-face-format":case "font-face-name":case "missing-glyph":return  false;default:return  true}}var wb=null;function xb(a){a=a.target||a.srcElement||window;a.correspondingUseElement&&(a=a.correspondingUseElement);return 3===a.nodeType?a.parentNode:a}var yb=null,zb=null,Ab=null;
function Bb(a){if(a=Cb(a)){if("function"!==typeof yb)throw Error(p$1(280));var b=a.stateNode;b&&(b=Db(b),yb(a.stateNode,a.type,b));}}function Eb(a){zb?Ab?Ab.push(a):Ab=[a]:zb=a;}function Fb(){if(zb){var a=zb,b=Ab;Ab=zb=null;Bb(a);if(b)for(a=0;a<b.length;a++)Bb(b[a]);}}function Gb(a,b){return a(b)}function Hb(){}var Ib=false;function Jb(a,b,c){if(Ib)return a(b,c);Ib=true;try{return Gb(a,b,c)}finally{if(Ib=false,null!==zb||null!==Ab)Hb(),Fb();}}
function Kb(a,b){var c=a.stateNode;if(null===c)return null;var d=Db(c);if(null===d)return null;c=d[b];a:switch(b){case "onClick":case "onClickCapture":case "onDoubleClick":case "onDoubleClickCapture":case "onMouseDown":case "onMouseDownCapture":case "onMouseMove":case "onMouseMoveCapture":case "onMouseUp":case "onMouseUpCapture":case "onMouseEnter":(d=!d.disabled)||(a=a.type,d=!("button"===a||"input"===a||"select"===a||"textarea"===a));a=!d;break a;default:a=false;}if(a)return null;if(c&&"function"!==
typeof c)throw Error(p$1(231,b,typeof c));return c}var Lb=false;if(ia)try{var Mb={};Object.defineProperty(Mb,"passive",{get:function(){Lb=!0;}});window.addEventListener("test",Mb,Mb);window.removeEventListener("test",Mb,Mb);}catch(a){Lb=false;}function Nb(a,b,c,d,e,f,g,h,k){var l=Array.prototype.slice.call(arguments,3);try{b.apply(c,l);}catch(m){this.onError(m);}}var Ob=false,Pb=null,Qb=false,Rb=null,Sb={onError:function(a){Ob=true;Pb=a;}};function Tb(a,b,c,d,e,f,g,h,k){Ob=false;Pb=null;Nb.apply(Sb,arguments);}
function Ub(a,b,c,d,e,f,g,h,k){Tb.apply(this,arguments);if(Ob){if(Ob){var l=Pb;Ob=false;Pb=null;}else throw Error(p$1(198));Qb||(Qb=true,Rb=l);}}function Vb(a){var b=a,c=a;if(a.alternate)for(;b.return;)b=b.return;else {a=b;do b=a,0!==(b.flags&4098)&&(c=b.return),a=b.return;while(a)}return 3===b.tag?c:null}function Wb(a){if(13===a.tag){var b=a.memoizedState;null===b&&(a=a.alternate,null!==a&&(b=a.memoizedState));if(null!==b)return b.dehydrated}return null}function Xb(a){if(Vb(a)!==a)throw Error(p$1(188));}
function Yb(a){var b=a.alternate;if(!b){b=Vb(a);if(null===b)throw Error(p$1(188));return b!==a?null:a}for(var c=a,d=b;;){var e=c.return;if(null===e)break;var f=e.alternate;if(null===f){d=e.return;if(null!==d){c=d;continue}break}if(e.child===f.child){for(f=e.child;f;){if(f===c)return Xb(e),a;if(f===d)return Xb(e),b;f=f.sibling;}throw Error(p$1(188));}if(c.return!==d.return)c=e,d=f;else {for(var g=false,h=e.child;h;){if(h===c){g=true;c=e;d=f;break}if(h===d){g=true;d=e;c=f;break}h=h.sibling;}if(!g){for(h=f.child;h;){if(h===
c){g=true;c=f;d=e;break}if(h===d){g=true;d=f;c=e;break}h=h.sibling;}if(!g)throw Error(p$1(189));}}if(c.alternate!==d)throw Error(p$1(190));}if(3!==c.tag)throw Error(p$1(188));return c.stateNode.current===c?a:b}function Zb(a){a=Yb(a);return null!==a?$b(a):null}function $b(a){if(5===a.tag||6===a.tag)return a;for(a=a.child;null!==a;){var b=$b(a);if(null!==b)return b;a=a.sibling;}return null}
var ac=ca.unstable_scheduleCallback,bc=ca.unstable_cancelCallback,cc=ca.unstable_shouldYield,dc=ca.unstable_requestPaint,B=ca.unstable_now,ec=ca.unstable_getCurrentPriorityLevel,fc=ca.unstable_ImmediatePriority,gc=ca.unstable_UserBlockingPriority,hc=ca.unstable_NormalPriority,ic=ca.unstable_LowPriority,jc=ca.unstable_IdlePriority,kc=null,lc=null;function mc(a){if(lc&&"function"===typeof lc.onCommitFiberRoot)try{lc.onCommitFiberRoot(kc,a,void 0,128===(a.current.flags&128));}catch(b){}}
var oc=Math.clz32?Math.clz32:nc,pc=Math.log,qc=Math.LN2;function nc(a){a>>>=0;return 0===a?32:31-(pc(a)/qc|0)|0}var rc=64,sc=4194304;
function tc(a){switch(a&-a){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return a&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return a&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;
default:return a}}function uc(a,b){var c=a.pendingLanes;if(0===c)return 0;var d=0,e=a.suspendedLanes,f=a.pingedLanes,g=c&268435455;if(0!==g){var h=g&~e;0!==h?d=tc(h):(f&=g,0!==f&&(d=tc(f)));}else g=c&~e,0!==g?d=tc(g):0!==f&&(d=tc(f));if(0===d)return 0;if(0!==b&&b!==d&&0===(b&e)&&(e=d&-d,f=b&-b,e>=f||16===e&&0!==(f&4194240)))return b;0!==(d&4)&&(d|=c&16);b=a.entangledLanes;if(0!==b)for(a=a.entanglements,b&=d;0<b;)c=31-oc(b),e=1<<c,d|=a[c],b&=~e;return d}
function vc(a,b){switch(a){case 1:case 2:case 4:return b+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return b+5E3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return  -1;case 134217728:case 268435456:case 536870912:case 1073741824:return  -1;default:return  -1}}
function wc(a,b){for(var c=a.suspendedLanes,d=a.pingedLanes,e=a.expirationTimes,f=a.pendingLanes;0<f;){var g=31-oc(f),h=1<<g,k=e[g];if(-1===k){if(0===(h&c)||0!==(h&d))e[g]=vc(h,b);}else k<=b&&(a.expiredLanes|=h);f&=~h;}}function xc(a){a=a.pendingLanes&-1073741825;return 0!==a?a:a&1073741824?1073741824:0}function yc(){var a=rc;rc<<=1;0===(rc&4194240)&&(rc=64);return a}function zc(a){for(var b=[],c=0;31>c;c++)b.push(a);return b}
function Ac(a,b,c){a.pendingLanes|=b;536870912!==b&&(a.suspendedLanes=0,a.pingedLanes=0);a=a.eventTimes;b=31-oc(b);a[b]=c;}function Bc(a,b){var c=a.pendingLanes&~b;a.pendingLanes=b;a.suspendedLanes=0;a.pingedLanes=0;a.expiredLanes&=b;a.mutableReadLanes&=b;a.entangledLanes&=b;b=a.entanglements;var d=a.eventTimes;for(a=a.expirationTimes;0<c;){var e=31-oc(c),f=1<<e;b[e]=0;d[e]=-1;a[e]=-1;c&=~f;}}
function Cc(a,b){var c=a.entangledLanes|=b;for(a=a.entanglements;c;){var d=31-oc(c),e=1<<d;e&b|a[d]&b&&(a[d]|=b);c&=~e;}}var C$2=0;function Dc(a){a&=-a;return 1<a?4<a?0!==(a&268435455)?16:536870912:4:1}var Ec,Fc,Gc,Hc,Ic,Jc=false,Kc=[],Lc=null,Mc=null,Nc=null,Oc=new Map,Pc=new Map,Qc=[],Rc="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");
function Sc(a,b){switch(a){case "focusin":case "focusout":Lc=null;break;case "dragenter":case "dragleave":Mc=null;break;case "mouseover":case "mouseout":Nc=null;break;case "pointerover":case "pointerout":Oc.delete(b.pointerId);break;case "gotpointercapture":case "lostpointercapture":Pc.delete(b.pointerId);}}
function Tc(a,b,c,d,e,f){if(null===a||a.nativeEvent!==f)return a={blockedOn:b,domEventName:c,eventSystemFlags:d,nativeEvent:f,targetContainers:[e]},null!==b&&(b=Cb(b),null!==b&&Fc(b)),a;a.eventSystemFlags|=d;b=a.targetContainers;null!==e&&-1===b.indexOf(e)&&b.push(e);return a}
function Uc(a,b,c,d,e){switch(b){case "focusin":return Lc=Tc(Lc,a,b,c,d,e),true;case "dragenter":return Mc=Tc(Mc,a,b,c,d,e),true;case "mouseover":return Nc=Tc(Nc,a,b,c,d,e),true;case "pointerover":var f=e.pointerId;Oc.set(f,Tc(Oc.get(f)||null,a,b,c,d,e));return  true;case "gotpointercapture":return f=e.pointerId,Pc.set(f,Tc(Pc.get(f)||null,a,b,c,d,e)),true}return  false}
function Vc(a){var b=Wc(a.target);if(null!==b){var c=Vb(b);if(null!==c)if(b=c.tag,13===b){if(b=Wb(c),null!==b){a.blockedOn=b;Ic(a.priority,function(){Gc(c);});return}}else if(3===b&&c.stateNode.current.memoizedState.isDehydrated){a.blockedOn=3===c.tag?c.stateNode.containerInfo:null;return}}a.blockedOn=null;}
function Xc(a){if(null!==a.blockedOn)return  false;for(var b=a.targetContainers;0<b.length;){var c=Yc(a.domEventName,a.eventSystemFlags,b[0],a.nativeEvent);if(null===c){c=a.nativeEvent;var d=new c.constructor(c.type,c);wb=d;c.target.dispatchEvent(d);wb=null;}else return b=Cb(c),null!==b&&Fc(b),a.blockedOn=c,false;b.shift();}return  true}function Zc(a,b,c){Xc(a)&&c.delete(b);}function $c(){Jc=false;null!==Lc&&Xc(Lc)&&(Lc=null);null!==Mc&&Xc(Mc)&&(Mc=null);null!==Nc&&Xc(Nc)&&(Nc=null);Oc.forEach(Zc);Pc.forEach(Zc);}
function ad(a,b){a.blockedOn===b&&(a.blockedOn=null,Jc||(Jc=true,ca.unstable_scheduleCallback(ca.unstable_NormalPriority,$c)));}
function bd(a){function b(b){return ad(b,a)}if(0<Kc.length){ad(Kc[0],a);for(var c=1;c<Kc.length;c++){var d=Kc[c];d.blockedOn===a&&(d.blockedOn=null);}}null!==Lc&&ad(Lc,a);null!==Mc&&ad(Mc,a);null!==Nc&&ad(Nc,a);Oc.forEach(b);Pc.forEach(b);for(c=0;c<Qc.length;c++)d=Qc[c],d.blockedOn===a&&(d.blockedOn=null);for(;0<Qc.length&&(c=Qc[0],null===c.blockedOn);)Vc(c),null===c.blockedOn&&Qc.shift();}var cd=ua.ReactCurrentBatchConfig,dd=true;
function ed(a,b,c,d){var e=C$2,f=cd.transition;cd.transition=null;try{C$2=1,fd(a,b,c,d);}finally{C$2=e,cd.transition=f;}}function gd(a,b,c,d){var e=C$2,f=cd.transition;cd.transition=null;try{C$2=4,fd(a,b,c,d);}finally{C$2=e,cd.transition=f;}}
function fd(a,b,c,d){if(dd){var e=Yc(a,b,c,d);if(null===e)hd(a,b,d,id,c),Sc(a,d);else if(Uc(e,a,b,c,d))d.stopPropagation();else if(Sc(a,d),b&4&&-1<Rc.indexOf(a)){for(;null!==e;){var f=Cb(e);null!==f&&Ec(f);f=Yc(a,b,c,d);null===f&&hd(a,b,d,id,c);if(f===e)break;e=f;}null!==e&&d.stopPropagation();}else hd(a,b,d,null,c);}}var id=null;
function Yc(a,b,c,d){id=null;a=xb(d);a=Wc(a);if(null!==a)if(b=Vb(a),null===b)a=null;else if(c=b.tag,13===c){a=Wb(b);if(null!==a)return a;a=null;}else if(3===c){if(b.stateNode.current.memoizedState.isDehydrated)return 3===b.tag?b.stateNode.containerInfo:null;a=null;}else b!==a&&(a=null);id=a;return null}
function jd(a){switch(a){case "cancel":case "click":case "close":case "contextmenu":case "copy":case "cut":case "auxclick":case "dblclick":case "dragend":case "dragstart":case "drop":case "focusin":case "focusout":case "input":case "invalid":case "keydown":case "keypress":case "keyup":case "mousedown":case "mouseup":case "paste":case "pause":case "play":case "pointercancel":case "pointerdown":case "pointerup":case "ratechange":case "reset":case "resize":case "seeked":case "submit":case "touchcancel":case "touchend":case "touchstart":case "volumechange":case "change":case "selectionchange":case "textInput":case "compositionstart":case "compositionend":case "compositionupdate":case "beforeblur":case "afterblur":case "beforeinput":case "blur":case "fullscreenchange":case "focus":case "hashchange":case "popstate":case "select":case "selectstart":return 1;case "drag":case "dragenter":case "dragexit":case "dragleave":case "dragover":case "mousemove":case "mouseout":case "mouseover":case "pointermove":case "pointerout":case "pointerover":case "scroll":case "toggle":case "touchmove":case "wheel":case "mouseenter":case "mouseleave":case "pointerenter":case "pointerleave":return 4;
case "message":switch(ec()){case fc:return 1;case gc:return 4;case hc:case ic:return 16;case jc:return 536870912;default:return 16}default:return 16}}var kd=null,ld=null,md=null;function nd(){if(md)return md;var a,b=ld,c=b.length,d,e="value"in kd?kd.value:kd.textContent,f=e.length;for(a=0;a<c&&b[a]===e[a];a++);var g=c-a;for(d=1;d<=g&&b[c-d]===e[f-d];d++);return md=e.slice(a,1<d?1-d:void 0)}
function od(a){var b=a.keyCode;"charCode"in a?(a=a.charCode,0===a&&13===b&&(a=13)):a=b;10===a&&(a=13);return 32<=a||13===a?a:0}function pd(){return  true}function qd(){return  false}
function rd(a){function b(b,d,e,f,g){this._reactName=b;this._targetInst=e;this.type=d;this.nativeEvent=f;this.target=g;this.currentTarget=null;for(var c in a)a.hasOwnProperty(c)&&(b=a[c],this[c]=b?b(f):f[c]);this.isDefaultPrevented=(null!=f.defaultPrevented?f.defaultPrevented:false===f.returnValue)?pd:qd;this.isPropagationStopped=qd;return this}A$2(b.prototype,{preventDefault:function(){this.defaultPrevented=true;var a=this.nativeEvent;a&&(a.preventDefault?a.preventDefault():"unknown"!==typeof a.returnValue&&
(a.returnValue=false),this.isDefaultPrevented=pd);},stopPropagation:function(){var a=this.nativeEvent;a&&(a.stopPropagation?a.stopPropagation():"unknown"!==typeof a.cancelBubble&&(a.cancelBubble=true),this.isPropagationStopped=pd);},persist:function(){},isPersistent:pd});return b}
var sd={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(a){return a.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},td=rd(sd),ud=A$2({},sd,{view:0,detail:0}),vd=rd(ud),wd,xd,yd,Ad=A$2({},ud,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:zd,button:0,buttons:0,relatedTarget:function(a){return void 0===a.relatedTarget?a.fromElement===a.srcElement?a.toElement:a.fromElement:a.relatedTarget},movementX:function(a){if("movementX"in
a)return a.movementX;a!==yd&&(yd&&"mousemove"===a.type?(wd=a.screenX-yd.screenX,xd=a.screenY-yd.screenY):xd=wd=0,yd=a);return wd},movementY:function(a){return "movementY"in a?a.movementY:xd}}),Bd=rd(Ad),Cd=A$2({},Ad,{dataTransfer:0}),Dd=rd(Cd),Ed=A$2({},ud,{relatedTarget:0}),Fd=rd(Ed),Gd=A$2({},sd,{animationName:0,elapsedTime:0,pseudoElement:0}),Hd=rd(Gd),Id=A$2({},sd,{clipboardData:function(a){return "clipboardData"in a?a.clipboardData:window.clipboardData}}),Jd=rd(Id),Kd=A$2({},sd,{data:0}),Ld=rd(Kd),Md={Esc:"Escape",
Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Nd={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",
119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Od={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Pd(a){var b=this.nativeEvent;return b.getModifierState?b.getModifierState(a):(a=Od[a])?!!b[a]:false}function zd(){return Pd}
var Qd=A$2({},ud,{key:function(a){if(a.key){var b=Md[a.key]||a.key;if("Unidentified"!==b)return b}return "keypress"===a.type?(a=od(a),13===a?"Enter":String.fromCharCode(a)):"keydown"===a.type||"keyup"===a.type?Nd[a.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:zd,charCode:function(a){return "keypress"===a.type?od(a):0},keyCode:function(a){return "keydown"===a.type||"keyup"===a.type?a.keyCode:0},which:function(a){return "keypress"===
a.type?od(a):"keydown"===a.type||"keyup"===a.type?a.keyCode:0}}),Rd=rd(Qd),Sd=A$2({},Ad,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Td=rd(Sd),Ud=A$2({},ud,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:zd}),Vd=rd(Ud),Wd=A$2({},sd,{propertyName:0,elapsedTime:0,pseudoElement:0}),Xd=rd(Wd),Yd=A$2({},Ad,{deltaX:function(a){return "deltaX"in a?a.deltaX:"wheelDeltaX"in a?-a.wheelDeltaX:0},
deltaY:function(a){return "deltaY"in a?a.deltaY:"wheelDeltaY"in a?-a.wheelDeltaY:"wheelDelta"in a?-a.wheelDelta:0},deltaZ:0,deltaMode:0}),Zd=rd(Yd),$d=[9,13,27,32],ae=ia&&"CompositionEvent"in window,be=null;ia&&"documentMode"in document&&(be=document.documentMode);var ce=ia&&"TextEvent"in window&&!be,de=ia&&(!ae||be&&8<be&&11>=be),ee=String.fromCharCode(32),fe=false;
function ge(a,b){switch(a){case "keyup":return  -1!==$d.indexOf(b.keyCode);case "keydown":return 229!==b.keyCode;case "keypress":case "mousedown":case "focusout":return  true;default:return  false}}function he$1(a){a=a.detail;return "object"===typeof a&&"data"in a?a.data:null}var ie=false;function je$1(a,b){switch(a){case "compositionend":return he$1(b);case "keypress":if(32!==b.which)return null;fe=true;return ee;case "textInput":return a=b.data,a===ee&&fe?null:a;default:return null}}
function ke$1(a,b){if(ie)return "compositionend"===a||!ae&&ge(a,b)?(a=nd(),md=ld=kd=null,ie=false,a):null;switch(a){case "paste":return null;case "keypress":if(!(b.ctrlKey||b.altKey||b.metaKey)||b.ctrlKey&&b.altKey){if(b.char&&1<b.char.length)return b.char;if(b.which)return String.fromCharCode(b.which)}return null;case "compositionend":return de&&"ko"!==b.locale?null:b.data;default:return null}}
var le={color:true,date:true,datetime:true,"datetime-local":true,email:true,month:true,number:true,password:true,range:true,search:true,tel:true,text:true,time:true,url:true,week:true};function me(a){var b=a&&a.nodeName&&a.nodeName.toLowerCase();return "input"===b?!!le[a.type]:"textarea"===b?true:false}function ne(a,b,c,d){Eb(d);b=oe(b,"onChange");0<b.length&&(c=new td("onChange","change",null,c,d),a.push({event:c,listeners:b}));}var pe=null,qe=null;function re(a){se(a,0);}function te(a){var b=ue(a);if(Wa(b))return a}
function ve$1(a,b){if("change"===a)return b}var we$1=false;if(ia){var xe;if(ia){var ye="oninput"in document;if(!ye){var ze=document.createElement("div");ze.setAttribute("oninput","return;");ye="function"===typeof ze.oninput;}xe=ye;}else xe=false;we$1=xe&&(!document.documentMode||9<document.documentMode);}function Ae(){pe&&(pe.detachEvent("onpropertychange",Be$1),qe=pe=null);}function Be$1(a){if("value"===a.propertyName&&te(qe)){var b=[];ne(b,qe,a,xb(a));Jb(re,b);}}
function Ce$1(a,b,c){"focusin"===a?(Ae(),pe=b,qe=c,pe.attachEvent("onpropertychange",Be$1)):"focusout"===a&&Ae();}function De$1(a){if("selectionchange"===a||"keyup"===a||"keydown"===a)return te(qe)}function Ee(a,b){if("click"===a)return te(b)}function Fe$1(a,b){if("input"===a||"change"===a)return te(b)}function Ge$1(a,b){return a===b&&(0!==a||1/a===1/b)||a!==a&&b!==b}var He$1="function"===typeof Object.is?Object.is:Ge$1;
function Ie$1(a,b){if(He$1(a,b))return  true;if("object"!==typeof a||null===a||"object"!==typeof b||null===b)return  false;var c=Object.keys(a),d=Object.keys(b);if(c.length!==d.length)return  false;for(d=0;d<c.length;d++){var e=c[d];if(!ja.call(b,e)||!He$1(a[e],b[e]))return  false}return  true}function Je(a){for(;a&&a.firstChild;)a=a.firstChild;return a}
function Ke$1(a,b){var c=Je(a);a=0;for(var d;c;){if(3===c.nodeType){d=a+c.textContent.length;if(a<=b&&d>=b)return {node:c,offset:b-a};a=d;}a:{for(;c;){if(c.nextSibling){c=c.nextSibling;break a}c=c.parentNode;}c=void 0;}c=Je(c);}}function Le$1(a,b){return a&&b?a===b?true:a&&3===a.nodeType?false:b&&3===b.nodeType?Le$1(a,b.parentNode):"contains"in a?a.contains(b):a.compareDocumentPosition?!!(a.compareDocumentPosition(b)&16):false:false}
function Me$1(){for(var a=window,b=Xa();b instanceof a.HTMLIFrameElement;){try{var c="string"===typeof b.contentWindow.location.href;}catch(d){c=false;}if(c)a=b.contentWindow;else break;b=Xa(a.document);}return b}function Ne$1(a){var b=a&&a.nodeName&&a.nodeName.toLowerCase();return b&&("input"===b&&("text"===a.type||"search"===a.type||"tel"===a.type||"url"===a.type||"password"===a.type)||"textarea"===b||"true"===a.contentEditable)}
function Oe$1(a){var b=Me$1(),c=a.focusedElem,d=a.selectionRange;if(b!==c&&c&&c.ownerDocument&&Le$1(c.ownerDocument.documentElement,c)){if(null!==d&&Ne$1(c))if(b=d.start,a=d.end,void 0===a&&(a=b),"selectionStart"in c)c.selectionStart=b,c.selectionEnd=Math.min(a,c.value.length);else if(a=(b=c.ownerDocument||document)&&b.defaultView||window,a.getSelection){a=a.getSelection();var e=c.textContent.length,f=Math.min(d.start,e);d=void 0===d.end?f:Math.min(d.end,e);!a.extend&&f>d&&(e=d,d=f,f=e);e=Ke$1(c,f);var g=Ke$1(c,
d);e&&g&&(1!==a.rangeCount||a.anchorNode!==e.node||a.anchorOffset!==e.offset||a.focusNode!==g.node||a.focusOffset!==g.offset)&&(b=b.createRange(),b.setStart(e.node,e.offset),a.removeAllRanges(),f>d?(a.addRange(b),a.extend(g.node,g.offset)):(b.setEnd(g.node,g.offset),a.addRange(b)));}b=[];for(a=c;a=a.parentNode;)1===a.nodeType&&b.push({element:a,left:a.scrollLeft,top:a.scrollTop});"function"===typeof c.focus&&c.focus();for(c=0;c<b.length;c++)a=b[c],a.element.scrollLeft=a.left,a.element.scrollTop=a.top;}}
var Pe=ia&&"documentMode"in document&&11>=document.documentMode,Qe=null,Re=null,Se$1=null,Te=false;
function Ue$1(a,b,c){var d=c.window===c?c.document:9===c.nodeType?c:c.ownerDocument;Te||null==Qe||Qe!==Xa(d)||(d=Qe,"selectionStart"in d&&Ne$1(d)?d={start:d.selectionStart,end:d.selectionEnd}:(d=(d.ownerDocument&&d.ownerDocument.defaultView||window).getSelection(),d={anchorNode:d.anchorNode,anchorOffset:d.anchorOffset,focusNode:d.focusNode,focusOffset:d.focusOffset}),Se$1&&Ie$1(Se$1,d)||(Se$1=d,d=oe(Re,"onSelect"),0<d.length&&(b=new td("onSelect","select",null,b,c),a.push({event:b,listeners:d}),b.target=Qe)));}
function Ve(a,b){var c={};c[a.toLowerCase()]=b.toLowerCase();c["Webkit"+a]="webkit"+b;c["Moz"+a]="moz"+b;return c}var We$1={animationend:Ve("Animation","AnimationEnd"),animationiteration:Ve("Animation","AnimationIteration"),animationstart:Ve("Animation","AnimationStart"),transitionend:Ve("Transition","TransitionEnd")},Xe={},Ye={};
ia&&(Ye=document.createElement("div").style,"AnimationEvent"in window||(delete We$1.animationend.animation,delete We$1.animationiteration.animation,delete We$1.animationstart.animation),"TransitionEvent"in window||delete We$1.transitionend.transition);function Ze(a){if(Xe[a])return Xe[a];if(!We$1[a])return a;var b=We$1[a],c;for(c in b)if(b.hasOwnProperty(c)&&c in Ye)return Xe[a]=b[c];return a}var $e=Ze("animationend"),af=Ze("animationiteration"),bf=Ze("animationstart"),cf=Ze("transitionend"),df=new Map,ef="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");
function ff(a,b){df.set(a,b);fa(b,[a]);}for(var gf=0;gf<ef.length;gf++){var hf=ef[gf],jf=hf.toLowerCase(),kf=hf[0].toUpperCase()+hf.slice(1);ff(jf,"on"+kf);}ff($e,"onAnimationEnd");ff(af,"onAnimationIteration");ff(bf,"onAnimationStart");ff("dblclick","onDoubleClick");ff("focusin","onFocus");ff("focusout","onBlur");ff(cf,"onTransitionEnd");ha("onMouseEnter",["mouseout","mouseover"]);ha("onMouseLeave",["mouseout","mouseover"]);ha("onPointerEnter",["pointerout","pointerover"]);
ha("onPointerLeave",["pointerout","pointerover"]);fa("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));fa("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));fa("onBeforeInput",["compositionend","keypress","textInput","paste"]);fa("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));fa("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));
fa("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var lf="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),mf=new Set("cancel close invalid load scroll toggle".split(" ").concat(lf));
function nf(a,b,c){var d=a.type||"unknown-event";a.currentTarget=c;Ub(d,b,void 0,a);a.currentTarget=null;}
function se(a,b){b=0!==(b&4);for(var c=0;c<a.length;c++){var d=a[c],e=d.event;d=d.listeners;a:{var f=void 0;if(b)for(var g=d.length-1;0<=g;g--){var h=d[g],k=h.instance,l=h.currentTarget;h=h.listener;if(k!==f&&e.isPropagationStopped())break a;nf(e,h,l);f=k;}else for(g=0;g<d.length;g++){h=d[g];k=h.instance;l=h.currentTarget;h=h.listener;if(k!==f&&e.isPropagationStopped())break a;nf(e,h,l);f=k;}}}if(Qb)throw a=Rb,Qb=false,Rb=null,a;}
function D$1(a,b){var c=b[of];void 0===c&&(c=b[of]=new Set);var d=a+"__bubble";c.has(d)||(pf(b,a,2,false),c.add(d));}function qf(a,b,c){var d=0;b&&(d|=4);pf(c,a,d,b);}var rf="_reactListening"+Math.random().toString(36).slice(2);function sf(a){if(!a[rf]){a[rf]=true;da.forEach(function(b){"selectionchange"!==b&&(mf.has(b)||qf(b,false,a),qf(b,true,a));});var b=9===a.nodeType?a:a.ownerDocument;null===b||b[rf]||(b[rf]=true,qf("selectionchange",false,b));}}
function pf(a,b,c,d){switch(jd(b)){case 1:var e=ed;break;case 4:e=gd;break;default:e=fd;}c=e.bind(null,b,c,a);e=void 0;!Lb||"touchstart"!==b&&"touchmove"!==b&&"wheel"!==b||(e=true);d?void 0!==e?a.addEventListener(b,c,{capture:true,passive:e}):a.addEventListener(b,c,true):void 0!==e?a.addEventListener(b,c,{passive:e}):a.addEventListener(b,c,false);}
function hd(a,b,c,d,e){var f=d;if(0===(b&1)&&0===(b&2)&&null!==d)a:for(;;){if(null===d)return;var g=d.tag;if(3===g||4===g){var h=d.stateNode.containerInfo;if(h===e||8===h.nodeType&&h.parentNode===e)break;if(4===g)for(g=d.return;null!==g;){var k=g.tag;if(3===k||4===k)if(k=g.stateNode.containerInfo,k===e||8===k.nodeType&&k.parentNode===e)return;g=g.return;}for(;null!==h;){g=Wc(h);if(null===g)return;k=g.tag;if(5===k||6===k){d=f=g;continue a}h=h.parentNode;}}d=d.return;}Jb(function(){var d=f,e=xb(c),g=[];
a:{var h=df.get(a);if(void 0!==h){var k=td,n=a;switch(a){case "keypress":if(0===od(c))break a;case "keydown":case "keyup":k=Rd;break;case "focusin":n="focus";k=Fd;break;case "focusout":n="blur";k=Fd;break;case "beforeblur":case "afterblur":k=Fd;break;case "click":if(2===c.button)break a;case "auxclick":case "dblclick":case "mousedown":case "mousemove":case "mouseup":case "mouseout":case "mouseover":case "contextmenu":k=Bd;break;case "drag":case "dragend":case "dragenter":case "dragexit":case "dragleave":case "dragover":case "dragstart":case "drop":k=
Dd;break;case "touchcancel":case "touchend":case "touchmove":case "touchstart":k=Vd;break;case $e:case af:case bf:k=Hd;break;case cf:k=Xd;break;case "scroll":k=vd;break;case "wheel":k=Zd;break;case "copy":case "cut":case "paste":k=Jd;break;case "gotpointercapture":case "lostpointercapture":case "pointercancel":case "pointerdown":case "pointermove":case "pointerout":case "pointerover":case "pointerup":k=Td;}var t=0!==(b&4),J=!t&&"scroll"===a,x=t?null!==h?h+"Capture":null:h;t=[];for(var w=d,u;null!==
w;){u=w;var F=u.stateNode;5===u.tag&&null!==F&&(u=F,null!==x&&(F=Kb(w,x),null!=F&&t.push(tf(w,F,u))));if(J)break;w=w.return;}0<t.length&&(h=new k(h,n,null,c,e),g.push({event:h,listeners:t}));}}if(0===(b&7)){a:{h="mouseover"===a||"pointerover"===a;k="mouseout"===a||"pointerout"===a;if(h&&c!==wb&&(n=c.relatedTarget||c.fromElement)&&(Wc(n)||n[uf]))break a;if(k||h){h=e.window===e?e:(h=e.ownerDocument)?h.defaultView||h.parentWindow:window;if(k){if(n=c.relatedTarget||c.toElement,k=d,n=n?Wc(n):null,null!==
n&&(J=Vb(n),n!==J||5!==n.tag&&6!==n.tag))n=null;}else k=null,n=d;if(k!==n){t=Bd;F="onMouseLeave";x="onMouseEnter";w="mouse";if("pointerout"===a||"pointerover"===a)t=Td,F="onPointerLeave",x="onPointerEnter",w="pointer";J=null==k?h:ue(k);u=null==n?h:ue(n);h=new t(F,w+"leave",k,c,e);h.target=J;h.relatedTarget=u;F=null;Wc(e)===d&&(t=new t(x,w+"enter",n,c,e),t.target=u,t.relatedTarget=J,F=t);J=F;if(k&&n)b:{t=k;x=n;w=0;for(u=t;u;u=vf(u))w++;u=0;for(F=x;F;F=vf(F))u++;for(;0<w-u;)t=vf(t),w--;for(;0<u-w;)x=
vf(x),u--;for(;w--;){if(t===x||null!==x&&t===x.alternate)break b;t=vf(t);x=vf(x);}t=null;}else t=null;null!==k&&wf(g,h,k,t,false);null!==n&&null!==J&&wf(g,J,n,t,true);}}}a:{h=d?ue(d):window;k=h.nodeName&&h.nodeName.toLowerCase();if("select"===k||"input"===k&&"file"===h.type)var na=ve$1;else if(me(h))if(we$1)na=Fe$1;else {na=De$1;var xa=Ce$1;}else (k=h.nodeName)&&"input"===k.toLowerCase()&&("checkbox"===h.type||"radio"===h.type)&&(na=Ee);if(na&&(na=na(a,d))){ne(g,na,c,e);break a}xa&&xa(a,h,d);"focusout"===a&&(xa=h._wrapperState)&&
xa.controlled&&"number"===h.type&&cb(h,"number",h.value);}xa=d?ue(d):window;switch(a){case "focusin":if(me(xa)||"true"===xa.contentEditable)Qe=xa,Re=d,Se$1=null;break;case "focusout":Se$1=Re=Qe=null;break;case "mousedown":Te=true;break;case "contextmenu":case "mouseup":case "dragend":Te=false;Ue$1(g,c,e);break;case "selectionchange":if(Pe)break;case "keydown":case "keyup":Ue$1(g,c,e);}var $a;if(ae)b:{switch(a){case "compositionstart":var ba="onCompositionStart";break b;case "compositionend":ba="onCompositionEnd";
break b;case "compositionupdate":ba="onCompositionUpdate";break b}ba=void 0;}else ie?ge(a,c)&&(ba="onCompositionEnd"):"keydown"===a&&229===c.keyCode&&(ba="onCompositionStart");ba&&(de&&"ko"!==c.locale&&(ie||"onCompositionStart"!==ba?"onCompositionEnd"===ba&&ie&&($a=nd()):(kd=e,ld="value"in kd?kd.value:kd.textContent,ie=true)),xa=oe(d,ba),0<xa.length&&(ba=new Ld(ba,a,null,c,e),g.push({event:ba,listeners:xa}),$a?ba.data=$a:($a=he$1(c),null!==$a&&(ba.data=$a))));if($a=ce?je$1(a,c):ke$1(a,c))d=oe(d,"onBeforeInput"),
0<d.length&&(e=new Ld("onBeforeInput","beforeinput",null,c,e),g.push({event:e,listeners:d}),e.data=$a);}se(g,b);});}function tf(a,b,c){return {instance:a,listener:b,currentTarget:c}}function oe(a,b){for(var c=b+"Capture",d=[];null!==a;){var e=a,f=e.stateNode;5===e.tag&&null!==f&&(e=f,f=Kb(a,c),null!=f&&d.unshift(tf(a,f,e)),f=Kb(a,b),null!=f&&d.push(tf(a,f,e)));a=a.return;}return d}function vf(a){if(null===a)return null;do a=a.return;while(a&&5!==a.tag);return a?a:null}
function wf(a,b,c,d,e){for(var f=b._reactName,g=[];null!==c&&c!==d;){var h=c,k=h.alternate,l=h.stateNode;if(null!==k&&k===d)break;5===h.tag&&null!==l&&(h=l,e?(k=Kb(c,f),null!=k&&g.unshift(tf(c,k,h))):e||(k=Kb(c,f),null!=k&&g.push(tf(c,k,h))));c=c.return;}0!==g.length&&a.push({event:b,listeners:g});}var xf=/\r\n?/g,yf=/\u0000|\uFFFD/g;function zf(a){return ("string"===typeof a?a:""+a).replace(xf,"\n").replace(yf,"")}function Af(a,b,c){b=zf(b);if(zf(a)!==b&&c)throw Error(p$1(425));}function Bf(){}
var Cf=null,Df=null;function Ef(a,b){return "textarea"===a||"noscript"===a||"string"===typeof b.children||"number"===typeof b.children||"object"===typeof b.dangerouslySetInnerHTML&&null!==b.dangerouslySetInnerHTML&&null!=b.dangerouslySetInnerHTML.__html}
var Ff="function"===typeof setTimeout?setTimeout:void 0,Gf="function"===typeof clearTimeout?clearTimeout:void 0,Hf="function"===typeof Promise?Promise:void 0,Jf="function"===typeof queueMicrotask?queueMicrotask:"undefined"!==typeof Hf?function(a){return Hf.resolve(null).then(a).catch(If)}:Ff;function If(a){setTimeout(function(){throw a;});}
function Kf(a,b){var c=b,d=0;do{var e=c.nextSibling;a.removeChild(c);if(e&&8===e.nodeType)if(c=e.data,"/$"===c){if(0===d){a.removeChild(e);bd(b);return}d--;}else "$"!==c&&"$?"!==c&&"$!"!==c||d++;c=e;}while(c);bd(b);}function Lf(a){for(;null!=a;a=a.nextSibling){var b=a.nodeType;if(1===b||3===b)break;if(8===b){b=a.data;if("$"===b||"$!"===b||"$?"===b)break;if("/$"===b)return null}}return a}
function Mf(a){a=a.previousSibling;for(var b=0;a;){if(8===a.nodeType){var c=a.data;if("$"===c||"$!"===c||"$?"===c){if(0===b)return a;b--;}else "/$"===c&&b++;}a=a.previousSibling;}return null}var Nf=Math.random().toString(36).slice(2),Of="__reactFiber$"+Nf,Pf="__reactProps$"+Nf,uf="__reactContainer$"+Nf,of="__reactEvents$"+Nf,Qf="__reactListeners$"+Nf,Rf="__reactHandles$"+Nf;
function Wc(a){var b=a[Of];if(b)return b;for(var c=a.parentNode;c;){if(b=c[uf]||c[Of]){c=b.alternate;if(null!==b.child||null!==c&&null!==c.child)for(a=Mf(a);null!==a;){if(c=a[Of])return c;a=Mf(a);}return b}a=c;c=a.parentNode;}return null}function Cb(a){a=a[Of]||a[uf];return !a||5!==a.tag&&6!==a.tag&&13!==a.tag&&3!==a.tag?null:a}function ue(a){if(5===a.tag||6===a.tag)return a.stateNode;throw Error(p$1(33));}function Db(a){return a[Pf]||null}var Sf=[],Tf=-1;function Uf(a){return {current:a}}
function E$2(a){0>Tf||(a.current=Sf[Tf],Sf[Tf]=null,Tf--);}function G$1(a,b){Tf++;Sf[Tf]=a.current;a.current=b;}var Vf={},H$1=Uf(Vf),Wf=Uf(false),Xf=Vf;function Yf(a,b){var c=a.type.contextTypes;if(!c)return Vf;var d=a.stateNode;if(d&&d.__reactInternalMemoizedUnmaskedChildContext===b)return d.__reactInternalMemoizedMaskedChildContext;var e={},f;for(f in c)e[f]=b[f];d&&(a=a.stateNode,a.__reactInternalMemoizedUnmaskedChildContext=b,a.__reactInternalMemoizedMaskedChildContext=e);return e}
function Zf(a){a=a.childContextTypes;return null!==a&&void 0!==a}function $f(){E$2(Wf);E$2(H$1);}function ag(a,b,c){if(H$1.current!==Vf)throw Error(p$1(168));G$1(H$1,b);G$1(Wf,c);}function bg(a,b,c){var d=a.stateNode;b=b.childContextTypes;if("function"!==typeof d.getChildContext)return c;d=d.getChildContext();for(var e in d)if(!(e in b))throw Error(p$1(108,Ra(a)||"Unknown",e));return A$2({},c,d)}
function cg(a){a=(a=a.stateNode)&&a.__reactInternalMemoizedMergedChildContext||Vf;Xf=H$1.current;G$1(H$1,a);G$1(Wf,Wf.current);return  true}function dg(a,b,c){var d=a.stateNode;if(!d)throw Error(p$1(169));c?(a=bg(a,b,Xf),d.__reactInternalMemoizedMergedChildContext=a,E$2(Wf),E$2(H$1),G$1(H$1,a)):E$2(Wf);G$1(Wf,c);}var eg=null,fg=false,gg=false;function hg(a){null===eg?eg=[a]:eg.push(a);}function ig(a){fg=true;hg(a);}
function jg(){if(!gg&&null!==eg){gg=true;var a=0,b=C$2;try{var c=eg;for(C$2=1;a<c.length;a++){var d=c[a];do d=d(!0);while(null!==d)}eg=null;fg=!1;}catch(e){throw null!==eg&&(eg=eg.slice(a+1)),ac(fc,jg),e;}finally{C$2=b,gg=false;}}return null}var kg=[],lg=0,mg=null,ng=0,og=[],pg=0,qg=null,rg=1,sg="";function tg(a,b){kg[lg++]=ng;kg[lg++]=mg;mg=a;ng=b;}
function ug(a,b,c){og[pg++]=rg;og[pg++]=sg;og[pg++]=qg;qg=a;var d=rg;a=sg;var e=32-oc(d)-1;d&=~(1<<e);c+=1;var f=32-oc(b)+e;if(30<f){var g=e-e%5;f=(d&(1<<g)-1).toString(32);d>>=g;e-=g;rg=1<<32-oc(b)+e|c<<e|d;sg=f+a;}else rg=1<<f|c<<e|d,sg=a;}function vg(a){null!==a.return&&(tg(a,1),ug(a,1,0));}function wg(a){for(;a===mg;)mg=kg[--lg],kg[lg]=null,ng=kg[--lg],kg[lg]=null;for(;a===qg;)qg=og[--pg],og[pg]=null,sg=og[--pg],og[pg]=null,rg=og[--pg],og[pg]=null;}var xg=null,yg=null,I$2=false,zg=null;
function Ag(a,b){var c=Bg(5,null,null,0);c.elementType="DELETED";c.stateNode=b;c.return=a;b=a.deletions;null===b?(a.deletions=[c],a.flags|=16):b.push(c);}
function Cg(a,b){switch(a.tag){case 5:var c=a.type;b=1!==b.nodeType||c.toLowerCase()!==b.nodeName.toLowerCase()?null:b;return null!==b?(a.stateNode=b,xg=a,yg=Lf(b.firstChild),true):false;case 6:return b=""===a.pendingProps||3!==b.nodeType?null:b,null!==b?(a.stateNode=b,xg=a,yg=null,true):false;case 13:return b=8!==b.nodeType?null:b,null!==b?(c=null!==qg?{id:rg,overflow:sg}:null,a.memoizedState={dehydrated:b,treeContext:c,retryLane:1073741824},c=Bg(18,null,null,0),c.stateNode=b,c.return=a,a.child=c,xg=a,yg=
null,true):false;default:return  false}}function Dg(a){return 0!==(a.mode&1)&&0===(a.flags&128)}function Eg(a){if(I$2){var b=yg;if(b){var c=b;if(!Cg(a,b)){if(Dg(a))throw Error(p$1(418));b=Lf(c.nextSibling);var d=xg;b&&Cg(a,b)?Ag(d,c):(a.flags=a.flags&-4097|2,I$2=false,xg=a);}}else {if(Dg(a))throw Error(p$1(418));a.flags=a.flags&-4097|2;I$2=false;xg=a;}}}function Fg(a){for(a=a.return;null!==a&&5!==a.tag&&3!==a.tag&&13!==a.tag;)a=a.return;xg=a;}
function Gg(a){if(a!==xg)return  false;if(!I$2)return Fg(a),I$2=true,false;var b;(b=3!==a.tag)&&!(b=5!==a.tag)&&(b=a.type,b="head"!==b&&"body"!==b&&!Ef(a.type,a.memoizedProps));if(b&&(b=yg)){if(Dg(a))throw Hg(),Error(p$1(418));for(;b;)Ag(a,b),b=Lf(b.nextSibling);}Fg(a);if(13===a.tag){a=a.memoizedState;a=null!==a?a.dehydrated:null;if(!a)throw Error(p$1(317));a:{a=a.nextSibling;for(b=0;a;){if(8===a.nodeType){var c=a.data;if("/$"===c){if(0===b){yg=Lf(a.nextSibling);break a}b--;}else "$"!==c&&"$!"!==c&&"$?"!==c||b++;}a=a.nextSibling;}yg=
null;}}else yg=xg?Lf(a.stateNode.nextSibling):null;return  true}function Hg(){for(var a=yg;a;)a=Lf(a.nextSibling);}function Ig(){yg=xg=null;I$2=false;}function Jg(a){null===zg?zg=[a]:zg.push(a);}var Kg=ua.ReactCurrentBatchConfig;
function Lg(a,b,c){a=c.ref;if(null!==a&&"function"!==typeof a&&"object"!==typeof a){if(c._owner){c=c._owner;if(c){if(1!==c.tag)throw Error(p$1(309));var d=c.stateNode;}if(!d)throw Error(p$1(147,a));var e=d,f=""+a;if(null!==b&&null!==b.ref&&"function"===typeof b.ref&&b.ref._stringRef===f)return b.ref;b=function(a){var b=e.refs;null===a?delete b[f]:b[f]=a;};b._stringRef=f;return b}if("string"!==typeof a)throw Error(p$1(284));if(!c._owner)throw Error(p$1(290,a));}return a}
function Mg(a,b){a=Object.prototype.toString.call(b);throw Error(p$1(31,"[object Object]"===a?"object with keys {"+Object.keys(b).join(", ")+"}":a));}function Ng(a){var b=a._init;return b(a._payload)}
function Og(a){function b(b,c){if(a){var d=b.deletions;null===d?(b.deletions=[c],b.flags|=16):d.push(c);}}function c(c,d){if(!a)return null;for(;null!==d;)b(c,d),d=d.sibling;return null}function d(a,b){for(a=new Map;null!==b;)null!==b.key?a.set(b.key,b):a.set(b.index,b),b=b.sibling;return a}function e(a,b){a=Pg(a,b);a.index=0;a.sibling=null;return a}function f(b,c,d){b.index=d;if(!a)return b.flags|=1048576,c;d=b.alternate;if(null!==d)return d=d.index,d<c?(b.flags|=2,c):d;b.flags|=2;return c}function g(b){a&&
null===b.alternate&&(b.flags|=2);return b}function h(a,b,c,d){if(null===b||6!==b.tag)return b=Qg(c,a.mode,d),b.return=a,b;b=e(b,c);b.return=a;return b}function k(a,b,c,d){var f=c.type;if(f===ya)return m(a,b,c.props.children,d,c.key);if(null!==b&&(b.elementType===f||"object"===typeof f&&null!==f&&f.$$typeof===Ha&&Ng(f)===b.type))return d=e(b,c.props),d.ref=Lg(a,b,c),d.return=a,d;d=Rg(c.type,c.key,c.props,null,a.mode,d);d.ref=Lg(a,b,c);d.return=a;return d}function l(a,b,c,d){if(null===b||4!==b.tag||
b.stateNode.containerInfo!==c.containerInfo||b.stateNode.implementation!==c.implementation)return b=Sg(c,a.mode,d),b.return=a,b;b=e(b,c.children||[]);b.return=a;return b}function m(a,b,c,d,f){if(null===b||7!==b.tag)return b=Tg(c,a.mode,d,f),b.return=a,b;b=e(b,c);b.return=a;return b}function q(a,b,c){if("string"===typeof b&&""!==b||"number"===typeof b)return b=Qg(""+b,a.mode,c),b.return=a,b;if("object"===typeof b&&null!==b){switch(b.$$typeof){case va:return c=Rg(b.type,b.key,b.props,null,a.mode,c),
c.ref=Lg(a,null,b),c.return=a,c;case wa:return b=Sg(b,a.mode,c),b.return=a,b;case Ha:var d=b._init;return q(a,d(b._payload),c)}if(eb(b)||Ka(b))return b=Tg(b,a.mode,c,null),b.return=a,b;Mg(a,b);}return null}function r(a,b,c,d){var e=null!==b?b.key:null;if("string"===typeof c&&""!==c||"number"===typeof c)return null!==e?null:h(a,b,""+c,d);if("object"===typeof c&&null!==c){switch(c.$$typeof){case va:return c.key===e?k(a,b,c,d):null;case wa:return c.key===e?l(a,b,c,d):null;case Ha:return e=c._init,r(a,
b,e(c._payload),d)}if(eb(c)||Ka(c))return null!==e?null:m(a,b,c,d,null);Mg(a,c);}return null}function y(a,b,c,d,e){if("string"===typeof d&&""!==d||"number"===typeof d)return a=a.get(c)||null,h(b,a,""+d,e);if("object"===typeof d&&null!==d){switch(d.$$typeof){case va:return a=a.get(null===d.key?c:d.key)||null,k(b,a,d,e);case wa:return a=a.get(null===d.key?c:d.key)||null,l(b,a,d,e);case Ha:var f=d._init;return y(a,b,c,f(d._payload),e)}if(eb(d)||Ka(d))return a=a.get(c)||null,m(b,a,d,e,null);Mg(b,d);}return null}
function n(e,g,h,k){for(var l=null,m=null,u=g,w=g=0,x=null;null!==u&&w<h.length;w++){u.index>w?(x=u,u=null):x=u.sibling;var n=r(e,u,h[w],k);if(null===n){null===u&&(u=x);break}a&&u&&null===n.alternate&&b(e,u);g=f(n,g,w);null===m?l=n:m.sibling=n;m=n;u=x;}if(w===h.length)return c(e,u),I$2&&tg(e,w),l;if(null===u){for(;w<h.length;w++)u=q(e,h[w],k),null!==u&&(g=f(u,g,w),null===m?l=u:m.sibling=u,m=u);I$2&&tg(e,w);return l}for(u=d(e,u);w<h.length;w++)x=y(u,e,w,h[w],k),null!==x&&(a&&null!==x.alternate&&u.delete(null===
x.key?w:x.key),g=f(x,g,w),null===m?l=x:m.sibling=x,m=x);a&&u.forEach(function(a){return b(e,a)});I$2&&tg(e,w);return l}function t(e,g,h,k){var l=Ka(h);if("function"!==typeof l)throw Error(p$1(150));h=l.call(h);if(null==h)throw Error(p$1(151));for(var u=l=null,m=g,w=g=0,x=null,n=h.next();null!==m&&!n.done;w++,n=h.next()){m.index>w?(x=m,m=null):x=m.sibling;var t=r(e,m,n.value,k);if(null===t){null===m&&(m=x);break}a&&m&&null===t.alternate&&b(e,m);g=f(t,g,w);null===u?l=t:u.sibling=t;u=t;m=x;}if(n.done)return c(e,
m),I$2&&tg(e,w),l;if(null===m){for(;!n.done;w++,n=h.next())n=q(e,n.value,k),null!==n&&(g=f(n,g,w),null===u?l=n:u.sibling=n,u=n);I$2&&tg(e,w);return l}for(m=d(e,m);!n.done;w++,n=h.next())n=y(m,e,w,n.value,k),null!==n&&(a&&null!==n.alternate&&m.delete(null===n.key?w:n.key),g=f(n,g,w),null===u?l=n:u.sibling=n,u=n);a&&m.forEach(function(a){return b(e,a)});I$2&&tg(e,w);return l}function J(a,d,f,h){"object"===typeof f&&null!==f&&f.type===ya&&null===f.key&&(f=f.props.children);if("object"===typeof f&&null!==f){switch(f.$$typeof){case va:a:{for(var k=
f.key,l=d;null!==l;){if(l.key===k){k=f.type;if(k===ya){if(7===l.tag){c(a,l.sibling);d=e(l,f.props.children);d.return=a;a=d;break a}}else if(l.elementType===k||"object"===typeof k&&null!==k&&k.$$typeof===Ha&&Ng(k)===l.type){c(a,l.sibling);d=e(l,f.props);d.ref=Lg(a,l,f);d.return=a;a=d;break a}c(a,l);break}else b(a,l);l=l.sibling;}f.type===ya?(d=Tg(f.props.children,a.mode,h,f.key),d.return=a,a=d):(h=Rg(f.type,f.key,f.props,null,a.mode,h),h.ref=Lg(a,d,f),h.return=a,a=h);}return g(a);case wa:a:{for(l=f.key;null!==
d;){if(d.key===l)if(4===d.tag&&d.stateNode.containerInfo===f.containerInfo&&d.stateNode.implementation===f.implementation){c(a,d.sibling);d=e(d,f.children||[]);d.return=a;a=d;break a}else {c(a,d);break}else b(a,d);d=d.sibling;}d=Sg(f,a.mode,h);d.return=a;a=d;}return g(a);case Ha:return l=f._init,J(a,d,l(f._payload),h)}if(eb(f))return n(a,d,f,h);if(Ka(f))return t(a,d,f,h);Mg(a,f);}return "string"===typeof f&&""!==f||"number"===typeof f?(f=""+f,null!==d&&6===d.tag?(c(a,d.sibling),d=e(d,f),d.return=a,a=d):
(c(a,d),d=Qg(f,a.mode,h),d.return=a,a=d),g(a)):c(a,d)}return J}var Ug=Og(true),Vg=Og(false),Wg=Uf(null),Xg=null,Yg=null,Zg=null;function $g(){Zg=Yg=Xg=null;}function ah(a){var b=Wg.current;E$2(Wg);a._currentValue=b;}function bh(a,b,c){for(;null!==a;){var d=a.alternate;(a.childLanes&b)!==b?(a.childLanes|=b,null!==d&&(d.childLanes|=b)):null!==d&&(d.childLanes&b)!==b&&(d.childLanes|=b);if(a===c)break;a=a.return;}}
function ch(a,b){Xg=a;Zg=Yg=null;a=a.dependencies;null!==a&&null!==a.firstContext&&(0!==(a.lanes&b)&&(dh=true),a.firstContext=null);}function eh(a){var b=a._currentValue;if(Zg!==a)if(a={context:a,memoizedValue:b,next:null},null===Yg){if(null===Xg)throw Error(p$1(308));Yg=a;Xg.dependencies={lanes:0,firstContext:a};}else Yg=Yg.next=a;return b}var fh=null;function gh(a){null===fh?fh=[a]:fh.push(a);}
function hh(a,b,c,d){var e=b.interleaved;null===e?(c.next=c,gh(b)):(c.next=e.next,e.next=c);b.interleaved=c;return ih(a,d)}function ih(a,b){a.lanes|=b;var c=a.alternate;null!==c&&(c.lanes|=b);c=a;for(a=a.return;null!==a;)a.childLanes|=b,c=a.alternate,null!==c&&(c.childLanes|=b),c=a,a=a.return;return 3===c.tag?c.stateNode:null}var jh=false;function kh(a){a.updateQueue={baseState:a.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null};}
function lh(a,b){a=a.updateQueue;b.updateQueue===a&&(b.updateQueue={baseState:a.baseState,firstBaseUpdate:a.firstBaseUpdate,lastBaseUpdate:a.lastBaseUpdate,shared:a.shared,effects:a.effects});}function mh(a,b){return {eventTime:a,lane:b,tag:0,payload:null,callback:null,next:null}}
function nh(a,b,c){var d=a.updateQueue;if(null===d)return null;d=d.shared;if(0!==(K$1&2)){var e=d.pending;null===e?b.next=b:(b.next=e.next,e.next=b);d.pending=b;return ih(a,c)}e=d.interleaved;null===e?(b.next=b,gh(d)):(b.next=e.next,e.next=b);d.interleaved=b;return ih(a,c)}function oh(a,b,c){b=b.updateQueue;if(null!==b&&(b=b.shared,0!==(c&4194240))){var d=b.lanes;d&=a.pendingLanes;c|=d;b.lanes=c;Cc(a,c);}}
function ph(a,b){var c=a.updateQueue,d=a.alternate;if(null!==d&&(d=d.updateQueue,c===d)){var e=null,f=null;c=c.firstBaseUpdate;if(null!==c){do{var g={eventTime:c.eventTime,lane:c.lane,tag:c.tag,payload:c.payload,callback:c.callback,next:null};null===f?e=f=g:f=f.next=g;c=c.next;}while(null!==c);null===f?e=f=b:f=f.next=b;}else e=f=b;c={baseState:d.baseState,firstBaseUpdate:e,lastBaseUpdate:f,shared:d.shared,effects:d.effects};a.updateQueue=c;return}a=c.lastBaseUpdate;null===a?c.firstBaseUpdate=b:a.next=
b;c.lastBaseUpdate=b;}
function qh(a,b,c,d){var e=a.updateQueue;jh=false;var f=e.firstBaseUpdate,g=e.lastBaseUpdate,h=e.shared.pending;if(null!==h){e.shared.pending=null;var k=h,l=k.next;k.next=null;null===g?f=l:g.next=l;g=k;var m=a.alternate;null!==m&&(m=m.updateQueue,h=m.lastBaseUpdate,h!==g&&(null===h?m.firstBaseUpdate=l:h.next=l,m.lastBaseUpdate=k));}if(null!==f){var q=e.baseState;g=0;m=l=k=null;h=f;do{var r=h.lane,y=h.eventTime;if((d&r)===r){null!==m&&(m=m.next={eventTime:y,lane:0,tag:h.tag,payload:h.payload,callback:h.callback,
next:null});a:{var n=a,t=h;r=b;y=c;switch(t.tag){case 1:n=t.payload;if("function"===typeof n){q=n.call(y,q,r);break a}q=n;break a;case 3:n.flags=n.flags&-65537|128;case 0:n=t.payload;r="function"===typeof n?n.call(y,q,r):n;if(null===r||void 0===r)break a;q=A$2({},q,r);break a;case 2:jh=true;}}null!==h.callback&&0!==h.lane&&(a.flags|=64,r=e.effects,null===r?e.effects=[h]:r.push(h));}else y={eventTime:y,lane:r,tag:h.tag,payload:h.payload,callback:h.callback,next:null},null===m?(l=m=y,k=q):m=m.next=y,g|=r;
h=h.next;if(null===h)if(h=e.shared.pending,null===h)break;else r=h,h=r.next,r.next=null,e.lastBaseUpdate=r,e.shared.pending=null;}while(1);null===m&&(k=q);e.baseState=k;e.firstBaseUpdate=l;e.lastBaseUpdate=m;b=e.shared.interleaved;if(null!==b){e=b;do g|=e.lane,e=e.next;while(e!==b)}else null===f&&(e.shared.lanes=0);rh|=g;a.lanes=g;a.memoizedState=q;}}
function sh(a,b,c){a=b.effects;b.effects=null;if(null!==a)for(b=0;b<a.length;b++){var d=a[b],e=d.callback;if(null!==e){d.callback=null;d=c;if("function"!==typeof e)throw Error(p$1(191,e));e.call(d);}}}var th={},uh=Uf(th),vh=Uf(th),wh=Uf(th);function xh(a){if(a===th)throw Error(p$1(174));return a}
function yh(a,b){G$1(wh,b);G$1(vh,a);G$1(uh,th);a=b.nodeType;switch(a){case 9:case 11:b=(b=b.documentElement)?b.namespaceURI:lb(null,"");break;default:a=8===a?b.parentNode:b,b=a.namespaceURI||null,a=a.tagName,b=lb(b,a);}E$2(uh);G$1(uh,b);}function zh(){E$2(uh);E$2(vh);E$2(wh);}function Ah(a){xh(wh.current);var b=xh(uh.current);var c=lb(b,a.type);b!==c&&(G$1(vh,a),G$1(uh,c));}function Bh(a){vh.current===a&&(E$2(uh),E$2(vh));}var L=Uf(0);
function Ch(a){for(var b=a;null!==b;){if(13===b.tag){var c=b.memoizedState;if(null!==c&&(c=c.dehydrated,null===c||"$?"===c.data||"$!"===c.data))return b}else if(19===b.tag&&void 0!==b.memoizedProps.revealOrder){if(0!==(b.flags&128))return b}else if(null!==b.child){b.child.return=b;b=b.child;continue}if(b===a)break;for(;null===b.sibling;){if(null===b.return||b.return===a)return null;b=b.return;}b.sibling.return=b.return;b=b.sibling;}return null}var Dh=[];
function Eh(){for(var a=0;a<Dh.length;a++)Dh[a]._workInProgressVersionPrimary=null;Dh.length=0;}var Fh=ua.ReactCurrentDispatcher,Gh=ua.ReactCurrentBatchConfig,Hh=0,M=null,N=null,O$1=null,Ih=false,Jh=false,Kh=0,Lh=0;function P$3(){throw Error(p$1(321));}function Mh(a,b){if(null===b)return  false;for(var c=0;c<b.length&&c<a.length;c++)if(!He$1(a[c],b[c]))return  false;return  true}
function Nh(a,b,c,d,e,f){Hh=f;M=b;b.memoizedState=null;b.updateQueue=null;b.lanes=0;Fh.current=null===a||null===a.memoizedState?Oh:Ph;a=c(d,e);if(Jh){f=0;do{Jh=false;Kh=0;if(25<=f)throw Error(p$1(301));f+=1;O$1=N=null;b.updateQueue=null;Fh.current=Qh;a=c(d,e);}while(Jh)}Fh.current=Rh;b=null!==N&&null!==N.next;Hh=0;O$1=N=M=null;Ih=false;if(b)throw Error(p$1(300));return a}function Sh(){var a=0!==Kh;Kh=0;return a}
function Th(){var a={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};null===O$1?M.memoizedState=O$1=a:O$1=O$1.next=a;return O$1}function Uh(){if(null===N){var a=M.alternate;a=null!==a?a.memoizedState:null;}else a=N.next;var b=null===O$1?M.memoizedState:O$1.next;if(null!==b)O$1=b,N=a;else {if(null===a)throw Error(p$1(310));N=a;a={memoizedState:N.memoizedState,baseState:N.baseState,baseQueue:N.baseQueue,queue:N.queue,next:null};null===O$1?M.memoizedState=O$1=a:O$1=O$1.next=a;}return O$1}
function Vh(a,b){return "function"===typeof b?b(a):b}
function Wh(a){var b=Uh(),c=b.queue;if(null===c)throw Error(p$1(311));c.lastRenderedReducer=a;var d=N,e=d.baseQueue,f=c.pending;if(null!==f){if(null!==e){var g=e.next;e.next=f.next;f.next=g;}d.baseQueue=e=f;c.pending=null;}if(null!==e){f=e.next;d=d.baseState;var h=g=null,k=null,l=f;do{var m=l.lane;if((Hh&m)===m)null!==k&&(k=k.next={lane:0,action:l.action,hasEagerState:l.hasEagerState,eagerState:l.eagerState,next:null}),d=l.hasEagerState?l.eagerState:a(d,l.action);else {var q={lane:m,action:l.action,hasEagerState:l.hasEagerState,
eagerState:l.eagerState,next:null};null===k?(h=k=q,g=d):k=k.next=q;M.lanes|=m;rh|=m;}l=l.next;}while(null!==l&&l!==f);null===k?g=d:k.next=h;He$1(d,b.memoizedState)||(dh=true);b.memoizedState=d;b.baseState=g;b.baseQueue=k;c.lastRenderedState=d;}a=c.interleaved;if(null!==a){e=a;do f=e.lane,M.lanes|=f,rh|=f,e=e.next;while(e!==a)}else null===e&&(c.lanes=0);return [b.memoizedState,c.dispatch]}
function Xh(a){var b=Uh(),c=b.queue;if(null===c)throw Error(p$1(311));c.lastRenderedReducer=a;var d=c.dispatch,e=c.pending,f=b.memoizedState;if(null!==e){c.pending=null;var g=e=e.next;do f=a(f,g.action),g=g.next;while(g!==e);He$1(f,b.memoizedState)||(dh=true);b.memoizedState=f;null===b.baseQueue&&(b.baseState=f);c.lastRenderedState=f;}return [f,d]}function Yh(){}
function Zh(a,b){var c=M,d=Uh(),e=b(),f=!He$1(d.memoizedState,e);f&&(d.memoizedState=e,dh=true);d=d.queue;$h(ai.bind(null,c,d,a),[a]);if(d.getSnapshot!==b||f||null!==O$1&&O$1.memoizedState.tag&1){c.flags|=2048;bi(9,ci.bind(null,c,d,e,b),void 0,null);if(null===Q$1)throw Error(p$1(349));0!==(Hh&30)||di(c,b,e);}return e}function di(a,b,c){a.flags|=16384;a={getSnapshot:b,value:c};b=M.updateQueue;null===b?(b={lastEffect:null,stores:null},M.updateQueue=b,b.stores=[a]):(c=b.stores,null===c?b.stores=[a]:c.push(a));}
function ci(a,b,c,d){b.value=c;b.getSnapshot=d;ei(b)&&fi(a);}function ai(a,b,c){return c(function(){ei(b)&&fi(a);})}function ei(a){var b=a.getSnapshot;a=a.value;try{var c=b();return !He$1(a,c)}catch(d){return  true}}function fi(a){var b=ih(a,1);null!==b&&gi(b,a,1,-1);}
function hi(a){var b=Th();"function"===typeof a&&(a=a());b.memoizedState=b.baseState=a;a={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:Vh,lastRenderedState:a};b.queue=a;a=a.dispatch=ii.bind(null,M,a);return [b.memoizedState,a]}
function bi(a,b,c,d){a={tag:a,create:b,destroy:c,deps:d,next:null};b=M.updateQueue;null===b?(b={lastEffect:null,stores:null},M.updateQueue=b,b.lastEffect=a.next=a):(c=b.lastEffect,null===c?b.lastEffect=a.next=a:(d=c.next,c.next=a,a.next=d,b.lastEffect=a));return a}function ji(){return Uh().memoizedState}function ki(a,b,c,d){var e=Th();M.flags|=a;e.memoizedState=bi(1|b,c,void 0,void 0===d?null:d);}
function li(a,b,c,d){var e=Uh();d=void 0===d?null:d;var f=void 0;if(null!==N){var g=N.memoizedState;f=g.destroy;if(null!==d&&Mh(d,g.deps)){e.memoizedState=bi(b,c,f,d);return}}M.flags|=a;e.memoizedState=bi(1|b,c,f,d);}function mi(a,b){return ki(8390656,8,a,b)}function $h(a,b){return li(2048,8,a,b)}function ni(a,b){return li(4,2,a,b)}function oi(a,b){return li(4,4,a,b)}
function pi(a,b){if("function"===typeof b)return a=a(),b(a),function(){b(null);};if(null!==b&&void 0!==b)return a=a(),b.current=a,function(){b.current=null;}}function qi(a,b,c){c=null!==c&&void 0!==c?c.concat([a]):null;return li(4,4,pi.bind(null,b,a),c)}function ri(){}function si(a,b){var c=Uh();b=void 0===b?null:b;var d=c.memoizedState;if(null!==d&&null!==b&&Mh(b,d[1]))return d[0];c.memoizedState=[a,b];return a}
function ti(a,b){var c=Uh();b=void 0===b?null:b;var d=c.memoizedState;if(null!==d&&null!==b&&Mh(b,d[1]))return d[0];a=a();c.memoizedState=[a,b];return a}function ui(a,b,c){if(0===(Hh&21))return a.baseState&&(a.baseState=false,dh=true),a.memoizedState=c;He$1(c,b)||(c=yc(),M.lanes|=c,rh|=c,a.baseState=true);return b}function vi(a,b){var c=C$2;C$2=0!==c&&4>c?c:4;a(true);var d=Gh.transition;Gh.transition={};try{a(!1),b();}finally{C$2=c,Gh.transition=d;}}function wi(){return Uh().memoizedState}
function xi(a,b,c){var d=yi(a);c={lane:d,action:c,hasEagerState:false,eagerState:null,next:null};if(zi(a))Ai(b,c);else if(c=hh(a,b,c,d),null!==c){var e=R();gi(c,a,d,e);Bi(c,b,d);}}
function ii(a,b,c){var d=yi(a),e={lane:d,action:c,hasEagerState:false,eagerState:null,next:null};if(zi(a))Ai(b,e);else {var f=a.alternate;if(0===a.lanes&&(null===f||0===f.lanes)&&(f=b.lastRenderedReducer,null!==f))try{var g=b.lastRenderedState,h=f(g,c);e.hasEagerState=!0;e.eagerState=h;if(He$1(h,g)){var k=b.interleaved;null===k?(e.next=e,gh(b)):(e.next=k.next,k.next=e);b.interleaved=e;return}}catch(l){}finally{}c=hh(a,b,e,d);null!==c&&(e=R(),gi(c,a,d,e),Bi(c,b,d));}}
function zi(a){var b=a.alternate;return a===M||null!==b&&b===M}function Ai(a,b){Jh=Ih=true;var c=a.pending;null===c?b.next=b:(b.next=c.next,c.next=b);a.pending=b;}function Bi(a,b,c){if(0!==(c&4194240)){var d=b.lanes;d&=a.pendingLanes;c|=d;b.lanes=c;Cc(a,c);}}
var Rh={readContext:eh,useCallback:P$3,useContext:P$3,useEffect:P$3,useImperativeHandle:P$3,useInsertionEffect:P$3,useLayoutEffect:P$3,useMemo:P$3,useReducer:P$3,useRef:P$3,useState:P$3,useDebugValue:P$3,useDeferredValue:P$3,useTransition:P$3,useMutableSource:P$3,useSyncExternalStore:P$3,useId:P$3,unstable_isNewReconciler:false},Oh={readContext:eh,useCallback:function(a,b){Th().memoizedState=[a,void 0===b?null:b];return a},useContext:eh,useEffect:mi,useImperativeHandle:function(a,b,c){c=null!==c&&void 0!==c?c.concat([a]):null;return ki(4194308,
4,pi.bind(null,b,a),c)},useLayoutEffect:function(a,b){return ki(4194308,4,a,b)},useInsertionEffect:function(a,b){return ki(4,2,a,b)},useMemo:function(a,b){var c=Th();b=void 0===b?null:b;a=a();c.memoizedState=[a,b];return a},useReducer:function(a,b,c){var d=Th();b=void 0!==c?c(b):b;d.memoizedState=d.baseState=b;a={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:a,lastRenderedState:b};d.queue=a;a=a.dispatch=xi.bind(null,M,a);return [d.memoizedState,a]},useRef:function(a){var b=
Th();a={current:a};return b.memoizedState=a},useState:hi,useDebugValue:ri,useDeferredValue:function(a){return Th().memoizedState=a},useTransition:function(){var a=hi(false),b=a[0];a=vi.bind(null,a[1]);Th().memoizedState=a;return [b,a]},useMutableSource:function(){},useSyncExternalStore:function(a,b,c){var d=M,e=Th();if(I$2){if(void 0===c)throw Error(p$1(407));c=c();}else {c=b();if(null===Q$1)throw Error(p$1(349));0!==(Hh&30)||di(d,b,c);}e.memoizedState=c;var f={value:c,getSnapshot:b};e.queue=f;mi(ai.bind(null,d,
f,a),[a]);d.flags|=2048;bi(9,ci.bind(null,d,f,c,b),void 0,null);return c},useId:function(){var a=Th(),b=Q$1.identifierPrefix;if(I$2){var c=sg;var d=rg;c=(d&~(1<<32-oc(d)-1)).toString(32)+c;b=":"+b+"R"+c;c=Kh++;0<c&&(b+="H"+c.toString(32));b+=":";}else c=Lh++,b=":"+b+"r"+c.toString(32)+":";return a.memoizedState=b},unstable_isNewReconciler:false},Ph={readContext:eh,useCallback:si,useContext:eh,useEffect:$h,useImperativeHandle:qi,useInsertionEffect:ni,useLayoutEffect:oi,useMemo:ti,useReducer:Wh,useRef:ji,useState:function(){return Wh(Vh)},
useDebugValue:ri,useDeferredValue:function(a){var b=Uh();return ui(b,N.memoizedState,a)},useTransition:function(){var a=Wh(Vh)[0],b=Uh().memoizedState;return [a,b]},useMutableSource:Yh,useSyncExternalStore:Zh,useId:wi,unstable_isNewReconciler:false},Qh={readContext:eh,useCallback:si,useContext:eh,useEffect:$h,useImperativeHandle:qi,useInsertionEffect:ni,useLayoutEffect:oi,useMemo:ti,useReducer:Xh,useRef:ji,useState:function(){return Xh(Vh)},useDebugValue:ri,useDeferredValue:function(a){var b=Uh();return null===
N?b.memoizedState=a:ui(b,N.memoizedState,a)},useTransition:function(){var a=Xh(Vh)[0],b=Uh().memoizedState;return [a,b]},useMutableSource:Yh,useSyncExternalStore:Zh,useId:wi,unstable_isNewReconciler:false};function Ci(a,b){if(a&&a.defaultProps){b=A$2({},b);a=a.defaultProps;for(var c in a) void 0===b[c]&&(b[c]=a[c]);return b}return b}function Di(a,b,c,d){b=a.memoizedState;c=c(d,b);c=null===c||void 0===c?b:A$2({},b,c);a.memoizedState=c;0===a.lanes&&(a.updateQueue.baseState=c);}
var Ei={isMounted:function(a){return (a=a._reactInternals)?Vb(a)===a:false},enqueueSetState:function(a,b,c){a=a._reactInternals;var d=R(),e=yi(a),f=mh(d,e);f.payload=b;void 0!==c&&null!==c&&(f.callback=c);b=nh(a,f,e);null!==b&&(gi(b,a,e,d),oh(b,a,e));},enqueueReplaceState:function(a,b,c){a=a._reactInternals;var d=R(),e=yi(a),f=mh(d,e);f.tag=1;f.payload=b;void 0!==c&&null!==c&&(f.callback=c);b=nh(a,f,e);null!==b&&(gi(b,a,e,d),oh(b,a,e));},enqueueForceUpdate:function(a,b){a=a._reactInternals;var c=R(),d=
yi(a),e=mh(c,d);e.tag=2;void 0!==b&&null!==b&&(e.callback=b);b=nh(a,e,d);null!==b&&(gi(b,a,d,c),oh(b,a,d));}};function Fi(a,b,c,d,e,f,g){a=a.stateNode;return "function"===typeof a.shouldComponentUpdate?a.shouldComponentUpdate(d,f,g):b.prototype&&b.prototype.isPureReactComponent?!Ie$1(c,d)||!Ie$1(e,f):true}
function Gi(a,b,c){var d=false,e=Vf;var f=b.contextType;"object"===typeof f&&null!==f?f=eh(f):(e=Zf(b)?Xf:H$1.current,d=b.contextTypes,f=(d=null!==d&&void 0!==d)?Yf(a,e):Vf);b=new b(c,f);a.memoizedState=null!==b.state&&void 0!==b.state?b.state:null;b.updater=Ei;a.stateNode=b;b._reactInternals=a;d&&(a=a.stateNode,a.__reactInternalMemoizedUnmaskedChildContext=e,a.__reactInternalMemoizedMaskedChildContext=f);return b}
function Hi(a,b,c,d){a=b.state;"function"===typeof b.componentWillReceiveProps&&b.componentWillReceiveProps(c,d);"function"===typeof b.UNSAFE_componentWillReceiveProps&&b.UNSAFE_componentWillReceiveProps(c,d);b.state!==a&&Ei.enqueueReplaceState(b,b.state,null);}
function Ii(a,b,c,d){var e=a.stateNode;e.props=c;e.state=a.memoizedState;e.refs={};kh(a);var f=b.contextType;"object"===typeof f&&null!==f?e.context=eh(f):(f=Zf(b)?Xf:H$1.current,e.context=Yf(a,f));e.state=a.memoizedState;f=b.getDerivedStateFromProps;"function"===typeof f&&(Di(a,b,f,c),e.state=a.memoizedState);"function"===typeof b.getDerivedStateFromProps||"function"===typeof e.getSnapshotBeforeUpdate||"function"!==typeof e.UNSAFE_componentWillMount&&"function"!==typeof e.componentWillMount||(b=e.state,
"function"===typeof e.componentWillMount&&e.componentWillMount(),"function"===typeof e.UNSAFE_componentWillMount&&e.UNSAFE_componentWillMount(),b!==e.state&&Ei.enqueueReplaceState(e,e.state,null),qh(a,c,e,d),e.state=a.memoizedState);"function"===typeof e.componentDidMount&&(a.flags|=4194308);}function Ji(a,b){try{var c="",d=b;do c+=Pa(d),d=d.return;while(d);var e=c;}catch(f){e="\nError generating stack: "+f.message+"\n"+f.stack;}return {value:a,source:b,stack:e,digest:null}}
function Ki(a,b,c){return {value:a,source:null,stack:null!=c?c:null,digest:null!=b?b:null}}function Li(a,b){try{console.error(b.value);}catch(c){setTimeout(function(){throw c;});}}var Mi="function"===typeof WeakMap?WeakMap:Map;function Ni(a,b,c){c=mh(-1,c);c.tag=3;c.payload={element:null};var d=b.value;c.callback=function(){Oi||(Oi=true,Pi=d);Li(a,b);};return c}
function Qi(a,b,c){c=mh(-1,c);c.tag=3;var d=a.type.getDerivedStateFromError;if("function"===typeof d){var e=b.value;c.payload=function(){return d(e)};c.callback=function(){Li(a,b);};}var f=a.stateNode;null!==f&&"function"===typeof f.componentDidCatch&&(c.callback=function(){Li(a,b);"function"!==typeof d&&(null===Ri?Ri=new Set([this]):Ri.add(this));var c=b.stack;this.componentDidCatch(b.value,{componentStack:null!==c?c:""});});return c}
function Si(a,b,c){var d=a.pingCache;if(null===d){d=a.pingCache=new Mi;var e=new Set;d.set(b,e);}else e=d.get(b),void 0===e&&(e=new Set,d.set(b,e));e.has(c)||(e.add(c),a=Ti.bind(null,a,b,c),b.then(a,a));}function Ui(a){do{var b;if(b=13===a.tag)b=a.memoizedState,b=null!==b?null!==b.dehydrated?true:false:true;if(b)return a;a=a.return;}while(null!==a);return null}
function Vi(a,b,c,d,e){if(0===(a.mode&1))return a===b?a.flags|=65536:(a.flags|=128,c.flags|=131072,c.flags&=-52805,1===c.tag&&(null===c.alternate?c.tag=17:(b=mh(-1,1),b.tag=2,nh(c,b,1))),c.lanes|=1),a;a.flags|=65536;a.lanes=e;return a}var Wi=ua.ReactCurrentOwner,dh=false;function Xi(a,b,c,d){b.child=null===a?Vg(b,null,c,d):Ug(b,a.child,c,d);}
function Yi(a,b,c,d,e){c=c.render;var f=b.ref;ch(b,e);d=Nh(a,b,c,d,f,e);c=Sh();if(null!==a&&!dh)return b.updateQueue=a.updateQueue,b.flags&=-2053,a.lanes&=~e,Zi(a,b,e);I$2&&c&&vg(b);b.flags|=1;Xi(a,b,d,e);return b.child}
function $i(a,b,c,d,e){if(null===a){var f=c.type;if("function"===typeof f&&!aj(f)&&void 0===f.defaultProps&&null===c.compare&&void 0===c.defaultProps)return b.tag=15,b.type=f,bj(a,b,f,d,e);a=Rg(c.type,null,d,b,b.mode,e);a.ref=b.ref;a.return=b;return b.child=a}f=a.child;if(0===(a.lanes&e)){var g=f.memoizedProps;c=c.compare;c=null!==c?c:Ie$1;if(c(g,d)&&a.ref===b.ref)return Zi(a,b,e)}b.flags|=1;a=Pg(f,d);a.ref=b.ref;a.return=b;return b.child=a}
function bj(a,b,c,d,e){if(null!==a){var f=a.memoizedProps;if(Ie$1(f,d)&&a.ref===b.ref)if(dh=false,b.pendingProps=d=f,0!==(a.lanes&e))0!==(a.flags&131072)&&(dh=true);else return b.lanes=a.lanes,Zi(a,b,e)}return cj(a,b,c,d,e)}
function dj(a,b,c){var d=b.pendingProps,e=d.children,f=null!==a?a.memoizedState:null;if("hidden"===d.mode)if(0===(b.mode&1))b.memoizedState={baseLanes:0,cachePool:null,transitions:null},G$1(ej,fj),fj|=c;else {if(0===(c&1073741824))return a=null!==f?f.baseLanes|c:c,b.lanes=b.childLanes=1073741824,b.memoizedState={baseLanes:a,cachePool:null,transitions:null},b.updateQueue=null,G$1(ej,fj),fj|=a,null;b.memoizedState={baseLanes:0,cachePool:null,transitions:null};d=null!==f?f.baseLanes:c;G$1(ej,fj);fj|=d;}else null!==
f?(d=f.baseLanes|c,b.memoizedState=null):d=c,G$1(ej,fj),fj|=d;Xi(a,b,e,c);return b.child}function gj(a,b){var c=b.ref;if(null===a&&null!==c||null!==a&&a.ref!==c)b.flags|=512,b.flags|=2097152;}function cj(a,b,c,d,e){var f=Zf(c)?Xf:H$1.current;f=Yf(b,f);ch(b,e);c=Nh(a,b,c,d,f,e);d=Sh();if(null!==a&&!dh)return b.updateQueue=a.updateQueue,b.flags&=-2053,a.lanes&=~e,Zi(a,b,e);I$2&&d&&vg(b);b.flags|=1;Xi(a,b,c,e);return b.child}
function hj(a,b,c,d,e){if(Zf(c)){var f=true;cg(b);}else f=false;ch(b,e);if(null===b.stateNode)ij(a,b),Gi(b,c,d),Ii(b,c,d,e),d=true;else if(null===a){var g=b.stateNode,h=b.memoizedProps;g.props=h;var k=g.context,l=c.contextType;"object"===typeof l&&null!==l?l=eh(l):(l=Zf(c)?Xf:H$1.current,l=Yf(b,l));var m=c.getDerivedStateFromProps,q="function"===typeof m||"function"===typeof g.getSnapshotBeforeUpdate;q||"function"!==typeof g.UNSAFE_componentWillReceiveProps&&"function"!==typeof g.componentWillReceiveProps||
(h!==d||k!==l)&&Hi(b,g,d,l);jh=false;var r=b.memoizedState;g.state=r;qh(b,d,g,e);k=b.memoizedState;h!==d||r!==k||Wf.current||jh?("function"===typeof m&&(Di(b,c,m,d),k=b.memoizedState),(h=jh||Fi(b,c,h,d,r,k,l))?(q||"function"!==typeof g.UNSAFE_componentWillMount&&"function"!==typeof g.componentWillMount||("function"===typeof g.componentWillMount&&g.componentWillMount(),"function"===typeof g.UNSAFE_componentWillMount&&g.UNSAFE_componentWillMount()),"function"===typeof g.componentDidMount&&(b.flags|=4194308)):
("function"===typeof g.componentDidMount&&(b.flags|=4194308),b.memoizedProps=d,b.memoizedState=k),g.props=d,g.state=k,g.context=l,d=h):("function"===typeof g.componentDidMount&&(b.flags|=4194308),d=false);}else {g=b.stateNode;lh(a,b);h=b.memoizedProps;l=b.type===b.elementType?h:Ci(b.type,h);g.props=l;q=b.pendingProps;r=g.context;k=c.contextType;"object"===typeof k&&null!==k?k=eh(k):(k=Zf(c)?Xf:H$1.current,k=Yf(b,k));var y=c.getDerivedStateFromProps;(m="function"===typeof y||"function"===typeof g.getSnapshotBeforeUpdate)||
"function"!==typeof g.UNSAFE_componentWillReceiveProps&&"function"!==typeof g.componentWillReceiveProps||(h!==q||r!==k)&&Hi(b,g,d,k);jh=false;r=b.memoizedState;g.state=r;qh(b,d,g,e);var n=b.memoizedState;h!==q||r!==n||Wf.current||jh?("function"===typeof y&&(Di(b,c,y,d),n=b.memoizedState),(l=jh||Fi(b,c,l,d,r,n,k)||false)?(m||"function"!==typeof g.UNSAFE_componentWillUpdate&&"function"!==typeof g.componentWillUpdate||("function"===typeof g.componentWillUpdate&&g.componentWillUpdate(d,n,k),"function"===typeof g.UNSAFE_componentWillUpdate&&
g.UNSAFE_componentWillUpdate(d,n,k)),"function"===typeof g.componentDidUpdate&&(b.flags|=4),"function"===typeof g.getSnapshotBeforeUpdate&&(b.flags|=1024)):("function"!==typeof g.componentDidUpdate||h===a.memoizedProps&&r===a.memoizedState||(b.flags|=4),"function"!==typeof g.getSnapshotBeforeUpdate||h===a.memoizedProps&&r===a.memoizedState||(b.flags|=1024),b.memoizedProps=d,b.memoizedState=n),g.props=d,g.state=n,g.context=k,d=l):("function"!==typeof g.componentDidUpdate||h===a.memoizedProps&&r===
a.memoizedState||(b.flags|=4),"function"!==typeof g.getSnapshotBeforeUpdate||h===a.memoizedProps&&r===a.memoizedState||(b.flags|=1024),d=false);}return jj(a,b,c,d,f,e)}
function jj(a,b,c,d,e,f){gj(a,b);var g=0!==(b.flags&128);if(!d&&!g)return e&&dg(b,c,false),Zi(a,b,f);d=b.stateNode;Wi.current=b;var h=g&&"function"!==typeof c.getDerivedStateFromError?null:d.render();b.flags|=1;null!==a&&g?(b.child=Ug(b,a.child,null,f),b.child=Ug(b,null,h,f)):Xi(a,b,h,f);b.memoizedState=d.state;e&&dg(b,c,true);return b.child}function kj(a){var b=a.stateNode;b.pendingContext?ag(a,b.pendingContext,b.pendingContext!==b.context):b.context&&ag(a,b.context,false);yh(a,b.containerInfo);}
function lj(a,b,c,d,e){Ig();Jg(e);b.flags|=256;Xi(a,b,c,d);return b.child}var mj={dehydrated:null,treeContext:null,retryLane:0};function nj(a){return {baseLanes:a,cachePool:null,transitions:null}}
function oj(a,b,c){var d=b.pendingProps,e=L.current,f=false,g=0!==(b.flags&128),h;(h=g)||(h=null!==a&&null===a.memoizedState?false:0!==(e&2));if(h)f=true,b.flags&=-129;else if(null===a||null!==a.memoizedState)e|=1;G$1(L,e&1);if(null===a){Eg(b);a=b.memoizedState;if(null!==a&&(a=a.dehydrated,null!==a))return 0===(b.mode&1)?b.lanes=1:"$!"===a.data?b.lanes=8:b.lanes=1073741824,null;g=d.children;a=d.fallback;return f?(d=b.mode,f=b.child,g={mode:"hidden",children:g},0===(d&1)&&null!==f?(f.childLanes=0,f.pendingProps=
g):f=pj(g,d,0,null),a=Tg(a,d,c,null),f.return=b,a.return=b,f.sibling=a,b.child=f,b.child.memoizedState=nj(c),b.memoizedState=mj,a):qj(b,g)}e=a.memoizedState;if(null!==e&&(h=e.dehydrated,null!==h))return rj(a,b,g,d,h,e,c);if(f){f=d.fallback;g=b.mode;e=a.child;h=e.sibling;var k={mode:"hidden",children:d.children};0===(g&1)&&b.child!==e?(d=b.child,d.childLanes=0,d.pendingProps=k,b.deletions=null):(d=Pg(e,k),d.subtreeFlags=e.subtreeFlags&14680064);null!==h?f=Pg(h,f):(f=Tg(f,g,c,null),f.flags|=2);f.return=
b;d.return=b;d.sibling=f;b.child=d;d=f;f=b.child;g=a.child.memoizedState;g=null===g?nj(c):{baseLanes:g.baseLanes|c,cachePool:null,transitions:g.transitions};f.memoizedState=g;f.childLanes=a.childLanes&~c;b.memoizedState=mj;return d}f=a.child;a=f.sibling;d=Pg(f,{mode:"visible",children:d.children});0===(b.mode&1)&&(d.lanes=c);d.return=b;d.sibling=null;null!==a&&(c=b.deletions,null===c?(b.deletions=[a],b.flags|=16):c.push(a));b.child=d;b.memoizedState=null;return d}
function qj(a,b){b=pj({mode:"visible",children:b},a.mode,0,null);b.return=a;return a.child=b}function sj(a,b,c,d){null!==d&&Jg(d);Ug(b,a.child,null,c);a=qj(b,b.pendingProps.children);a.flags|=2;b.memoizedState=null;return a}
function rj(a,b,c,d,e,f,g){if(c){if(b.flags&256)return b.flags&=-257,d=Ki(Error(p$1(422))),sj(a,b,g,d);if(null!==b.memoizedState)return b.child=a.child,b.flags|=128,null;f=d.fallback;e=b.mode;d=pj({mode:"visible",children:d.children},e,0,null);f=Tg(f,e,g,null);f.flags|=2;d.return=b;f.return=b;d.sibling=f;b.child=d;0!==(b.mode&1)&&Ug(b,a.child,null,g);b.child.memoizedState=nj(g);b.memoizedState=mj;return f}if(0===(b.mode&1))return sj(a,b,g,null);if("$!"===e.data){d=e.nextSibling&&e.nextSibling.dataset;
if(d)var h=d.dgst;d=h;f=Error(p$1(419));d=Ki(f,d,void 0);return sj(a,b,g,d)}h=0!==(g&a.childLanes);if(dh||h){d=Q$1;if(null!==d){switch(g&-g){case 4:e=2;break;case 16:e=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:e=32;break;case 536870912:e=268435456;break;default:e=0;}e=0!==(e&(d.suspendedLanes|g))?0:e;
0!==e&&e!==f.retryLane&&(f.retryLane=e,ih(a,e),gi(d,a,e,-1));}tj();d=Ki(Error(p$1(421)));return sj(a,b,g,d)}if("$?"===e.data)return b.flags|=128,b.child=a.child,b=uj.bind(null,a),e._reactRetry=b,null;a=f.treeContext;yg=Lf(e.nextSibling);xg=b;I$2=true;zg=null;null!==a&&(og[pg++]=rg,og[pg++]=sg,og[pg++]=qg,rg=a.id,sg=a.overflow,qg=b);b=qj(b,d.children);b.flags|=4096;return b}function vj(a,b,c){a.lanes|=b;var d=a.alternate;null!==d&&(d.lanes|=b);bh(a.return,b,c);}
function wj(a,b,c,d,e){var f=a.memoizedState;null===f?a.memoizedState={isBackwards:b,rendering:null,renderingStartTime:0,last:d,tail:c,tailMode:e}:(f.isBackwards=b,f.rendering=null,f.renderingStartTime=0,f.last=d,f.tail=c,f.tailMode=e);}
function xj(a,b,c){var d=b.pendingProps,e=d.revealOrder,f=d.tail;Xi(a,b,d.children,c);d=L.current;if(0!==(d&2))d=d&1|2,b.flags|=128;else {if(null!==a&&0!==(a.flags&128))a:for(a=b.child;null!==a;){if(13===a.tag)null!==a.memoizedState&&vj(a,c,b);else if(19===a.tag)vj(a,c,b);else if(null!==a.child){a.child.return=a;a=a.child;continue}if(a===b)break a;for(;null===a.sibling;){if(null===a.return||a.return===b)break a;a=a.return;}a.sibling.return=a.return;a=a.sibling;}d&=1;}G$1(L,d);if(0===(b.mode&1))b.memoizedState=
null;else switch(e){case "forwards":c=b.child;for(e=null;null!==c;)a=c.alternate,null!==a&&null===Ch(a)&&(e=c),c=c.sibling;c=e;null===c?(e=b.child,b.child=null):(e=c.sibling,c.sibling=null);wj(b,false,e,c,f);break;case "backwards":c=null;e=b.child;for(b.child=null;null!==e;){a=e.alternate;if(null!==a&&null===Ch(a)){b.child=e;break}a=e.sibling;e.sibling=c;c=e;e=a;}wj(b,true,c,null,f);break;case "together":wj(b,false,null,null,void 0);break;default:b.memoizedState=null;}return b.child}
function ij(a,b){0===(b.mode&1)&&null!==a&&(a.alternate=null,b.alternate=null,b.flags|=2);}function Zi(a,b,c){null!==a&&(b.dependencies=a.dependencies);rh|=b.lanes;if(0===(c&b.childLanes))return null;if(null!==a&&b.child!==a.child)throw Error(p$1(153));if(null!==b.child){a=b.child;c=Pg(a,a.pendingProps);b.child=c;for(c.return=b;null!==a.sibling;)a=a.sibling,c=c.sibling=Pg(a,a.pendingProps),c.return=b;c.sibling=null;}return b.child}
function yj(a,b,c){switch(b.tag){case 3:kj(b);Ig();break;case 5:Ah(b);break;case 1:Zf(b.type)&&cg(b);break;case 4:yh(b,b.stateNode.containerInfo);break;case 10:var d=b.type._context,e=b.memoizedProps.value;G$1(Wg,d._currentValue);d._currentValue=e;break;case 13:d=b.memoizedState;if(null!==d){if(null!==d.dehydrated)return G$1(L,L.current&1),b.flags|=128,null;if(0!==(c&b.child.childLanes))return oj(a,b,c);G$1(L,L.current&1);a=Zi(a,b,c);return null!==a?a.sibling:null}G$1(L,L.current&1);break;case 19:d=0!==(c&
b.childLanes);if(0!==(a.flags&128)){if(d)return xj(a,b,c);b.flags|=128;}e=b.memoizedState;null!==e&&(e.rendering=null,e.tail=null,e.lastEffect=null);G$1(L,L.current);if(d)break;else return null;case 22:case 23:return b.lanes=0,dj(a,b,c)}return Zi(a,b,c)}var zj,Aj,Bj,Cj;
zj=function(a,b){for(var c=b.child;null!==c;){if(5===c.tag||6===c.tag)a.appendChild(c.stateNode);else if(4!==c.tag&&null!==c.child){c.child.return=c;c=c.child;continue}if(c===b)break;for(;null===c.sibling;){if(null===c.return||c.return===b)return;c=c.return;}c.sibling.return=c.return;c=c.sibling;}};Aj=function(){};
Bj=function(a,b,c,d){var e=a.memoizedProps;if(e!==d){a=b.stateNode;xh(uh.current);var f=null;switch(c){case "input":e=Ya(a,e);d=Ya(a,d);f=[];break;case "select":e=A$2({},e,{value:void 0});d=A$2({},d,{value:void 0});f=[];break;case "textarea":e=gb(a,e);d=gb(a,d);f=[];break;default:"function"!==typeof e.onClick&&"function"===typeof d.onClick&&(a.onclick=Bf);}ub(c,d);var g;c=null;for(l in e)if(!d.hasOwnProperty(l)&&e.hasOwnProperty(l)&&null!=e[l])if("style"===l){var h=e[l];for(g in h)h.hasOwnProperty(g)&&
(c||(c={}),c[g]="");}else "dangerouslySetInnerHTML"!==l&&"children"!==l&&"suppressContentEditableWarning"!==l&&"suppressHydrationWarning"!==l&&"autoFocus"!==l&&(ea.hasOwnProperty(l)?f||(f=[]):(f=f||[]).push(l,null));for(l in d){var k=d[l];h=null!=e?e[l]:void 0;if(d.hasOwnProperty(l)&&k!==h&&(null!=k||null!=h))if("style"===l)if(h){for(g in h)!h.hasOwnProperty(g)||k&&k.hasOwnProperty(g)||(c||(c={}),c[g]="");for(g in k)k.hasOwnProperty(g)&&h[g]!==k[g]&&(c||(c={}),c[g]=k[g]);}else c||(f||(f=[]),f.push(l,
c)),c=k;else "dangerouslySetInnerHTML"===l?(k=k?k.__html:void 0,h=h?h.__html:void 0,null!=k&&h!==k&&(f=f||[]).push(l,k)):"children"===l?"string"!==typeof k&&"number"!==typeof k||(f=f||[]).push(l,""+k):"suppressContentEditableWarning"!==l&&"suppressHydrationWarning"!==l&&(ea.hasOwnProperty(l)?(null!=k&&"onScroll"===l&&D$1("scroll",a),f||h===k||(f=[])):(f=f||[]).push(l,k));}c&&(f=f||[]).push("style",c);var l=f;if(b.updateQueue=l)b.flags|=4;}};Cj=function(a,b,c,d){c!==d&&(b.flags|=4);};
function Dj(a,b){if(!I$2)switch(a.tailMode){case "hidden":b=a.tail;for(var c=null;null!==b;)null!==b.alternate&&(c=b),b=b.sibling;null===c?a.tail=null:c.sibling=null;break;case "collapsed":c=a.tail;for(var d=null;null!==c;)null!==c.alternate&&(d=c),c=c.sibling;null===d?b||null===a.tail?a.tail=null:a.tail.sibling=null:d.sibling=null;}}
function S$1(a){var b=null!==a.alternate&&a.alternate.child===a.child,c=0,d=0;if(b)for(var e=a.child;null!==e;)c|=e.lanes|e.childLanes,d|=e.subtreeFlags&14680064,d|=e.flags&14680064,e.return=a,e=e.sibling;else for(e=a.child;null!==e;)c|=e.lanes|e.childLanes,d|=e.subtreeFlags,d|=e.flags,e.return=a,e=e.sibling;a.subtreeFlags|=d;a.childLanes=c;return b}
function Ej(a,b,c){var d=b.pendingProps;wg(b);switch(b.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return S$1(b),null;case 1:return Zf(b.type)&&$f(),S$1(b),null;case 3:d=b.stateNode;zh();E$2(Wf);E$2(H$1);Eh();d.pendingContext&&(d.context=d.pendingContext,d.pendingContext=null);if(null===a||null===a.child)Gg(b)?b.flags|=4:null===a||a.memoizedState.isDehydrated&&0===(b.flags&256)||(b.flags|=1024,null!==zg&&(Fj(zg),zg=null));Aj(a,b);S$1(b);return null;case 5:Bh(b);var e=xh(wh.current);
c=b.type;if(null!==a&&null!=b.stateNode)Bj(a,b,c,d,e),a.ref!==b.ref&&(b.flags|=512,b.flags|=2097152);else {if(!d){if(null===b.stateNode)throw Error(p$1(166));S$1(b);return null}a=xh(uh.current);if(Gg(b)){d=b.stateNode;c=b.type;var f=b.memoizedProps;d[Of]=b;d[Pf]=f;a=0!==(b.mode&1);switch(c){case "dialog":D$1("cancel",d);D$1("close",d);break;case "iframe":case "object":case "embed":D$1("load",d);break;case "video":case "audio":for(e=0;e<lf.length;e++)D$1(lf[e],d);break;case "source":D$1("error",d);break;case "img":case "image":case "link":D$1("error",
d);D$1("load",d);break;case "details":D$1("toggle",d);break;case "input":Za(d,f);D$1("invalid",d);break;case "select":d._wrapperState={wasMultiple:!!f.multiple};D$1("invalid",d);break;case "textarea":hb(d,f),D$1("invalid",d);}ub(c,f);e=null;for(var g in f)if(f.hasOwnProperty(g)){var h=f[g];"children"===g?"string"===typeof h?d.textContent!==h&&(true!==f.suppressHydrationWarning&&Af(d.textContent,h,a),e=["children",h]):"number"===typeof h&&d.textContent!==""+h&&(true!==f.suppressHydrationWarning&&Af(d.textContent,
h,a),e=["children",""+h]):ea.hasOwnProperty(g)&&null!=h&&"onScroll"===g&&D$1("scroll",d);}switch(c){case "input":Va(d);db(d,f,true);break;case "textarea":Va(d);jb(d);break;case "select":case "option":break;default:"function"===typeof f.onClick&&(d.onclick=Bf);}d=e;b.updateQueue=d;null!==d&&(b.flags|=4);}else {g=9===e.nodeType?e:e.ownerDocument;"http://www.w3.org/1999/xhtml"===a&&(a=kb(c));"http://www.w3.org/1999/xhtml"===a?"script"===c?(a=g.createElement("div"),a.innerHTML="<script>\x3c/script>",a=a.removeChild(a.firstChild)):
"string"===typeof d.is?a=g.createElement(c,{is:d.is}):(a=g.createElement(c),"select"===c&&(g=a,d.multiple?g.multiple=true:d.size&&(g.size=d.size))):a=g.createElementNS(a,c);a[Of]=b;a[Pf]=d;zj(a,b,false,false);b.stateNode=a;a:{g=vb(c,d);switch(c){case "dialog":D$1("cancel",a);D$1("close",a);e=d;break;case "iframe":case "object":case "embed":D$1("load",a);e=d;break;case "video":case "audio":for(e=0;e<lf.length;e++)D$1(lf[e],a);e=d;break;case "source":D$1("error",a);e=d;break;case "img":case "image":case "link":D$1("error",
a);D$1("load",a);e=d;break;case "details":D$1("toggle",a);e=d;break;case "input":Za(a,d);e=Ya(a,d);D$1("invalid",a);break;case "option":e=d;break;case "select":a._wrapperState={wasMultiple:!!d.multiple};e=A$2({},d,{value:void 0});D$1("invalid",a);break;case "textarea":hb(a,d);e=gb(a,d);D$1("invalid",a);break;default:e=d;}ub(c,e);h=e;for(f in h)if(h.hasOwnProperty(f)){var k=h[f];"style"===f?sb(a,k):"dangerouslySetInnerHTML"===f?(k=k?k.__html:void 0,null!=k&&nb(a,k)):"children"===f?"string"===typeof k?("textarea"!==
c||""!==k)&&ob(a,k):"number"===typeof k&&ob(a,""+k):"suppressContentEditableWarning"!==f&&"suppressHydrationWarning"!==f&&"autoFocus"!==f&&(ea.hasOwnProperty(f)?null!=k&&"onScroll"===f&&D$1("scroll",a):null!=k&&ta(a,f,k,g));}switch(c){case "input":Va(a);db(a,d,false);break;case "textarea":Va(a);jb(a);break;case "option":null!=d.value&&a.setAttribute("value",""+Sa(d.value));break;case "select":a.multiple=!!d.multiple;f=d.value;null!=f?fb(a,!!d.multiple,f,false):null!=d.defaultValue&&fb(a,!!d.multiple,d.defaultValue,
true);break;default:"function"===typeof e.onClick&&(a.onclick=Bf);}switch(c){case "button":case "input":case "select":case "textarea":d=!!d.autoFocus;break a;case "img":d=true;break a;default:d=false;}}d&&(b.flags|=4);}null!==b.ref&&(b.flags|=512,b.flags|=2097152);}S$1(b);return null;case 6:if(a&&null!=b.stateNode)Cj(a,b,a.memoizedProps,d);else {if("string"!==typeof d&&null===b.stateNode)throw Error(p$1(166));c=xh(wh.current);xh(uh.current);if(Gg(b)){d=b.stateNode;c=b.memoizedProps;d[Of]=b;if(f=d.nodeValue!==c)if(a=
xg,null!==a)switch(a.tag){case 3:Af(d.nodeValue,c,0!==(a.mode&1));break;case 5:true!==a.memoizedProps.suppressHydrationWarning&&Af(d.nodeValue,c,0!==(a.mode&1));}f&&(b.flags|=4);}else d=(9===c.nodeType?c:c.ownerDocument).createTextNode(d),d[Of]=b,b.stateNode=d;}S$1(b);return null;case 13:E$2(L);d=b.memoizedState;if(null===a||null!==a.memoizedState&&null!==a.memoizedState.dehydrated){if(I$2&&null!==yg&&0!==(b.mode&1)&&0===(b.flags&128))Hg(),Ig(),b.flags|=98560,f=false;else if(f=Gg(b),null!==d&&null!==d.dehydrated){if(null===
a){if(!f)throw Error(p$1(318));f=b.memoizedState;f=null!==f?f.dehydrated:null;if(!f)throw Error(p$1(317));f[Of]=b;}else Ig(),0===(b.flags&128)&&(b.memoizedState=null),b.flags|=4;S$1(b);f=false;}else null!==zg&&(Fj(zg),zg=null),f=true;if(!f)return b.flags&65536?b:null}if(0!==(b.flags&128))return b.lanes=c,b;d=null!==d;d!==(null!==a&&null!==a.memoizedState)&&d&&(b.child.flags|=8192,0!==(b.mode&1)&&(null===a||0!==(L.current&1)?0===T$1&&(T$1=3):tj()));null!==b.updateQueue&&(b.flags|=4);S$1(b);return null;case 4:return zh(),
Aj(a,b),null===a&&sf(b.stateNode.containerInfo),S$1(b),null;case 10:return ah(b.type._context),S$1(b),null;case 17:return Zf(b.type)&&$f(),S$1(b),null;case 19:E$2(L);f=b.memoizedState;if(null===f)return S$1(b),null;d=0!==(b.flags&128);g=f.rendering;if(null===g)if(d)Dj(f,false);else {if(0!==T$1||null!==a&&0!==(a.flags&128))for(a=b.child;null!==a;){g=Ch(a);if(null!==g){b.flags|=128;Dj(f,false);d=g.updateQueue;null!==d&&(b.updateQueue=d,b.flags|=4);b.subtreeFlags=0;d=c;for(c=b.child;null!==c;)f=c,a=d,f.flags&=14680066,
g=f.alternate,null===g?(f.childLanes=0,f.lanes=a,f.child=null,f.subtreeFlags=0,f.memoizedProps=null,f.memoizedState=null,f.updateQueue=null,f.dependencies=null,f.stateNode=null):(f.childLanes=g.childLanes,f.lanes=g.lanes,f.child=g.child,f.subtreeFlags=0,f.deletions=null,f.memoizedProps=g.memoizedProps,f.memoizedState=g.memoizedState,f.updateQueue=g.updateQueue,f.type=g.type,a=g.dependencies,f.dependencies=null===a?null:{lanes:a.lanes,firstContext:a.firstContext}),c=c.sibling;G$1(L,L.current&1|2);return b.child}a=
a.sibling;}null!==f.tail&&B()>Gj&&(b.flags|=128,d=true,Dj(f,false),b.lanes=4194304);}else {if(!d)if(a=Ch(g),null!==a){if(b.flags|=128,d=true,c=a.updateQueue,null!==c&&(b.updateQueue=c,b.flags|=4),Dj(f,true),null===f.tail&&"hidden"===f.tailMode&&!g.alternate&&!I$2)return S$1(b),null}else 2*B()-f.renderingStartTime>Gj&&1073741824!==c&&(b.flags|=128,d=true,Dj(f,false),b.lanes=4194304);f.isBackwards?(g.sibling=b.child,b.child=g):(c=f.last,null!==c?c.sibling=g:b.child=g,f.last=g);}if(null!==f.tail)return b=f.tail,f.rendering=
b,f.tail=b.sibling,f.renderingStartTime=B(),b.sibling=null,c=L.current,G$1(L,d?c&1|2:c&1),b;S$1(b);return null;case 22:case 23:return Hj(),d=null!==b.memoizedState,null!==a&&null!==a.memoizedState!==d&&(b.flags|=8192),d&&0!==(b.mode&1)?0!==(fj&1073741824)&&(S$1(b),b.subtreeFlags&6&&(b.flags|=8192)):S$1(b),null;case 24:return null;case 25:return null}throw Error(p$1(156,b.tag));}
function Ij(a,b){wg(b);switch(b.tag){case 1:return Zf(b.type)&&$f(),a=b.flags,a&65536?(b.flags=a&-65537|128,b):null;case 3:return zh(),E$2(Wf),E$2(H$1),Eh(),a=b.flags,0!==(a&65536)&&0===(a&128)?(b.flags=a&-65537|128,b):null;case 5:return Bh(b),null;case 13:E$2(L);a=b.memoizedState;if(null!==a&&null!==a.dehydrated){if(null===b.alternate)throw Error(p$1(340));Ig();}a=b.flags;return a&65536?(b.flags=a&-65537|128,b):null;case 19:return E$2(L),null;case 4:return zh(),null;case 10:return ah(b.type._context),null;case 22:case 23:return Hj(),
null;case 24:return null;default:return null}}var Jj=false,U$1=false,Kj="function"===typeof WeakSet?WeakSet:Set,V$2=null;function Lj(a,b){var c=a.ref;if(null!==c)if("function"===typeof c)try{c(null);}catch(d){W(a,b,d);}else c.current=null;}function Mj(a,b,c){try{c();}catch(d){W(a,b,d);}}var Nj=false;
function Oj(a,b){Cf=dd;a=Me$1();if(Ne$1(a)){if("selectionStart"in a)var c={start:a.selectionStart,end:a.selectionEnd};else a:{c=(c=a.ownerDocument)&&c.defaultView||window;var d=c.getSelection&&c.getSelection();if(d&&0!==d.rangeCount){c=d.anchorNode;var e=d.anchorOffset,f=d.focusNode;d=d.focusOffset;try{c.nodeType,f.nodeType;}catch(F){c=null;break a}var g=0,h=-1,k=-1,l=0,m=0,q=a,r=null;b:for(;;){for(var y;;){q!==c||0!==e&&3!==q.nodeType||(h=g+e);q!==f||0!==d&&3!==q.nodeType||(k=g+d);3===q.nodeType&&(g+=
q.nodeValue.length);if(null===(y=q.firstChild))break;r=q;q=y;}for(;;){if(q===a)break b;r===c&&++l===e&&(h=g);r===f&&++m===d&&(k=g);if(null!==(y=q.nextSibling))break;q=r;r=q.parentNode;}q=y;}c=-1===h||-1===k?null:{start:h,end:k};}else c=null;}c=c||{start:0,end:0};}else c=null;Df={focusedElem:a,selectionRange:c};dd=false;for(V$2=b;null!==V$2;)if(b=V$2,a=b.child,0!==(b.subtreeFlags&1028)&&null!==a)a.return=b,V$2=a;else for(;null!==V$2;){b=V$2;try{var n=b.alternate;if(0!==(b.flags&1024))switch(b.tag){case 0:case 11:case 15:break;
case 1:if(null!==n){var t=n.memoizedProps,J=n.memoizedState,x=b.stateNode,w=x.getSnapshotBeforeUpdate(b.elementType===b.type?t:Ci(b.type,t),J);x.__reactInternalSnapshotBeforeUpdate=w;}break;case 3:var u=b.stateNode.containerInfo;1===u.nodeType?u.textContent="":9===u.nodeType&&u.documentElement&&u.removeChild(u.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(p$1(163));}}catch(F){W(b,b.return,F);}a=b.sibling;if(null!==a){a.return=b.return;V$2=a;break}V$2=b.return;}n=Nj;Nj=false;return n}
function Pj(a,b,c){var d=b.updateQueue;d=null!==d?d.lastEffect:null;if(null!==d){var e=d=d.next;do{if((e.tag&a)===a){var f=e.destroy;e.destroy=void 0;void 0!==f&&Mj(b,c,f);}e=e.next;}while(e!==d)}}function Qj(a,b){b=b.updateQueue;b=null!==b?b.lastEffect:null;if(null!==b){var c=b=b.next;do{if((c.tag&a)===a){var d=c.create;c.destroy=d();}c=c.next;}while(c!==b)}}function Rj(a){var b=a.ref;if(null!==b){var c=a.stateNode;switch(a.tag){case 5:a=c;break;default:a=c;}"function"===typeof b?b(a):b.current=a;}}
function Sj(a){var b=a.alternate;null!==b&&(a.alternate=null,Sj(b));a.child=null;a.deletions=null;a.sibling=null;5===a.tag&&(b=a.stateNode,null!==b&&(delete b[Of],delete b[Pf],delete b[of],delete b[Qf],delete b[Rf]));a.stateNode=null;a.return=null;a.dependencies=null;a.memoizedProps=null;a.memoizedState=null;a.pendingProps=null;a.stateNode=null;a.updateQueue=null;}function Tj(a){return 5===a.tag||3===a.tag||4===a.tag}
function Uj(a){a:for(;;){for(;null===a.sibling;){if(null===a.return||Tj(a.return))return null;a=a.return;}a.sibling.return=a.return;for(a=a.sibling;5!==a.tag&&6!==a.tag&&18!==a.tag;){if(a.flags&2)continue a;if(null===a.child||4===a.tag)continue a;else a.child.return=a,a=a.child;}if(!(a.flags&2))return a.stateNode}}
function Vj(a,b,c){var d=a.tag;if(5===d||6===d)a=a.stateNode,b?8===c.nodeType?c.parentNode.insertBefore(a,b):c.insertBefore(a,b):(8===c.nodeType?(b=c.parentNode,b.insertBefore(a,c)):(b=c,b.appendChild(a)),c=c._reactRootContainer,null!==c&&void 0!==c||null!==b.onclick||(b.onclick=Bf));else if(4!==d&&(a=a.child,null!==a))for(Vj(a,b,c),a=a.sibling;null!==a;)Vj(a,b,c),a=a.sibling;}
function Wj(a,b,c){var d=a.tag;if(5===d||6===d)a=a.stateNode,b?c.insertBefore(a,b):c.appendChild(a);else if(4!==d&&(a=a.child,null!==a))for(Wj(a,b,c),a=a.sibling;null!==a;)Wj(a,b,c),a=a.sibling;}var X$1=null,Xj=false;function Yj(a,b,c){for(c=c.child;null!==c;)Zj(a,b,c),c=c.sibling;}
function Zj(a,b,c){if(lc&&"function"===typeof lc.onCommitFiberUnmount)try{lc.onCommitFiberUnmount(kc,c);}catch(h){}switch(c.tag){case 5:U$1||Lj(c,b);case 6:var d=X$1,e=Xj;X$1=null;Yj(a,b,c);X$1=d;Xj=e;null!==X$1&&(Xj?(a=X$1,c=c.stateNode,8===a.nodeType?a.parentNode.removeChild(c):a.removeChild(c)):X$1.removeChild(c.stateNode));break;case 18:null!==X$1&&(Xj?(a=X$1,c=c.stateNode,8===a.nodeType?Kf(a.parentNode,c):1===a.nodeType&&Kf(a,c),bd(a)):Kf(X$1,c.stateNode));break;case 4:d=X$1;e=Xj;X$1=c.stateNode.containerInfo;Xj=true;
Yj(a,b,c);X$1=d;Xj=e;break;case 0:case 11:case 14:case 15:if(!U$1&&(d=c.updateQueue,null!==d&&(d=d.lastEffect,null!==d))){e=d=d.next;do{var f=e,g=f.destroy;f=f.tag;void 0!==g&&(0!==(f&2)?Mj(c,b,g):0!==(f&4)&&Mj(c,b,g));e=e.next;}while(e!==d)}Yj(a,b,c);break;case 1:if(!U$1&&(Lj(c,b),d=c.stateNode,"function"===typeof d.componentWillUnmount))try{d.props=c.memoizedProps,d.state=c.memoizedState,d.componentWillUnmount();}catch(h){W(c,b,h);}Yj(a,b,c);break;case 21:Yj(a,b,c);break;case 22:c.mode&1?(U$1=(d=U$1)||null!==
c.memoizedState,Yj(a,b,c),U$1=d):Yj(a,b,c);break;default:Yj(a,b,c);}}function ak(a){var b=a.updateQueue;if(null!==b){a.updateQueue=null;var c=a.stateNode;null===c&&(c=a.stateNode=new Kj);b.forEach(function(b){var d=bk.bind(null,a,b);c.has(b)||(c.add(b),b.then(d,d));});}}
function ck(a,b){var c=b.deletions;if(null!==c)for(var d=0;d<c.length;d++){var e=c[d];try{var f=a,g=b,h=g;a:for(;null!==h;){switch(h.tag){case 5:X$1=h.stateNode;Xj=!1;break a;case 3:X$1=h.stateNode.containerInfo;Xj=!0;break a;case 4:X$1=h.stateNode.containerInfo;Xj=!0;break a}h=h.return;}if(null===X$1)throw Error(p$1(160));Zj(f,g,e);X$1=null;Xj=!1;var k=e.alternate;null!==k&&(k.return=null);e.return=null;}catch(l){W(e,b,l);}}if(b.subtreeFlags&12854)for(b=b.child;null!==b;)dk(b,a),b=b.sibling;}
function dk(a,b){var c=a.alternate,d=a.flags;switch(a.tag){case 0:case 11:case 14:case 15:ck(b,a);ek(a);if(d&4){try{Pj(3,a,a.return),Qj(3,a);}catch(t){W(a,a.return,t);}try{Pj(5,a,a.return);}catch(t){W(a,a.return,t);}}break;case 1:ck(b,a);ek(a);d&512&&null!==c&&Lj(c,c.return);break;case 5:ck(b,a);ek(a);d&512&&null!==c&&Lj(c,c.return);if(a.flags&32){var e=a.stateNode;try{ob(e,"");}catch(t){W(a,a.return,t);}}if(d&4&&(e=a.stateNode,null!=e)){var f=a.memoizedProps,g=null!==c?c.memoizedProps:f,h=a.type,k=a.updateQueue;
a.updateQueue=null;if(null!==k)try{"input"===h&&"radio"===f.type&&null!=f.name&&ab(e,f);vb(h,g);var l=vb(h,f);for(g=0;g<k.length;g+=2){var m=k[g],q=k[g+1];"style"===m?sb(e,q):"dangerouslySetInnerHTML"===m?nb(e,q):"children"===m?ob(e,q):ta(e,m,q,l);}switch(h){case "input":bb(e,f);break;case "textarea":ib(e,f);break;case "select":var r=e._wrapperState.wasMultiple;e._wrapperState.wasMultiple=!!f.multiple;var y=f.value;null!=y?fb(e,!!f.multiple,y,!1):r!==!!f.multiple&&(null!=f.defaultValue?fb(e,!!f.multiple,
f.defaultValue,!0):fb(e,!!f.multiple,f.multiple?[]:"",!1));}e[Pf]=f;}catch(t){W(a,a.return,t);}}break;case 6:ck(b,a);ek(a);if(d&4){if(null===a.stateNode)throw Error(p$1(162));e=a.stateNode;f=a.memoizedProps;try{e.nodeValue=f;}catch(t){W(a,a.return,t);}}break;case 3:ck(b,a);ek(a);if(d&4&&null!==c&&c.memoizedState.isDehydrated)try{bd(b.containerInfo);}catch(t){W(a,a.return,t);}break;case 4:ck(b,a);ek(a);break;case 13:ck(b,a);ek(a);e=a.child;e.flags&8192&&(f=null!==e.memoizedState,e.stateNode.isHidden=f,!f||
null!==e.alternate&&null!==e.alternate.memoizedState||(fk=B()));d&4&&ak(a);break;case 22:m=null!==c&&null!==c.memoizedState;a.mode&1?(U$1=(l=U$1)||m,ck(b,a),U$1=l):ck(b,a);ek(a);if(d&8192){l=null!==a.memoizedState;if((a.stateNode.isHidden=l)&&!m&&0!==(a.mode&1))for(V$2=a,m=a.child;null!==m;){for(q=V$2=m;null!==V$2;){r=V$2;y=r.child;switch(r.tag){case 0:case 11:case 14:case 15:Pj(4,r,r.return);break;case 1:Lj(r,r.return);var n=r.stateNode;if("function"===typeof n.componentWillUnmount){d=r;c=r.return;try{b=d,n.props=
b.memoizedProps,n.state=b.memoizedState,n.componentWillUnmount();}catch(t){W(d,c,t);}}break;case 5:Lj(r,r.return);break;case 22:if(null!==r.memoizedState){gk(q);continue}}null!==y?(y.return=r,V$2=y):gk(q);}m=m.sibling;}a:for(m=null,q=a;;){if(5===q.tag){if(null===m){m=q;try{e=q.stateNode,l?(f=e.style,"function"===typeof f.setProperty?f.setProperty("display","none","important"):f.display="none"):(h=q.stateNode,k=q.memoizedProps.style,g=void 0!==k&&null!==k&&k.hasOwnProperty("display")?k.display:null,h.style.display=
rb("display",g));}catch(t){W(a,a.return,t);}}}else if(6===q.tag){if(null===m)try{q.stateNode.nodeValue=l?"":q.memoizedProps;}catch(t){W(a,a.return,t);}}else if((22!==q.tag&&23!==q.tag||null===q.memoizedState||q===a)&&null!==q.child){q.child.return=q;q=q.child;continue}if(q===a)break a;for(;null===q.sibling;){if(null===q.return||q.return===a)break a;m===q&&(m=null);q=q.return;}m===q&&(m=null);q.sibling.return=q.return;q=q.sibling;}}break;case 19:ck(b,a);ek(a);d&4&&ak(a);break;case 21:break;default:ck(b,
a),ek(a);}}function ek(a){var b=a.flags;if(b&2){try{a:{for(var c=a.return;null!==c;){if(Tj(c)){var d=c;break a}c=c.return;}throw Error(p$1(160));}switch(d.tag){case 5:var e=d.stateNode;d.flags&32&&(ob(e,""),d.flags&=-33);var f=Uj(a);Wj(a,f,e);break;case 3:case 4:var g=d.stateNode.containerInfo,h=Uj(a);Vj(a,h,g);break;default:throw Error(p$1(161));}}catch(k){W(a,a.return,k);}a.flags&=-3;}b&4096&&(a.flags&=-4097);}function hk(a,b,c){V$2=a;ik(a);}
function ik(a,b,c){for(var d=0!==(a.mode&1);null!==V$2;){var e=V$2,f=e.child;if(22===e.tag&&d){var g=null!==e.memoizedState||Jj;if(!g){var h=e.alternate,k=null!==h&&null!==h.memoizedState||U$1;h=Jj;var l=U$1;Jj=g;if((U$1=k)&&!l)for(V$2=e;null!==V$2;)g=V$2,k=g.child,22===g.tag&&null!==g.memoizedState?jk(e):null!==k?(k.return=g,V$2=k):jk(e);for(;null!==f;)V$2=f,ik(f),f=f.sibling;V$2=e;Jj=h;U$1=l;}kk(a);}else 0!==(e.subtreeFlags&8772)&&null!==f?(f.return=e,V$2=f):kk(a);}}
function kk(a){for(;null!==V$2;){var b=V$2;if(0!==(b.flags&8772)){var c=b.alternate;try{if(0!==(b.flags&8772))switch(b.tag){case 0:case 11:case 15:U$1||Qj(5,b);break;case 1:var d=b.stateNode;if(b.flags&4&&!U$1)if(null===c)d.componentDidMount();else {var e=b.elementType===b.type?c.memoizedProps:Ci(b.type,c.memoizedProps);d.componentDidUpdate(e,c.memoizedState,d.__reactInternalSnapshotBeforeUpdate);}var f=b.updateQueue;null!==f&&sh(b,f,d);break;case 3:var g=b.updateQueue;if(null!==g){c=null;if(null!==b.child)switch(b.child.tag){case 5:c=
b.child.stateNode;break;case 1:c=b.child.stateNode;}sh(b,g,c);}break;case 5:var h=b.stateNode;if(null===c&&b.flags&4){c=h;var k=b.memoizedProps;switch(b.type){case "button":case "input":case "select":case "textarea":k.autoFocus&&c.focus();break;case "img":k.src&&(c.src=k.src);}}break;case 6:break;case 4:break;case 12:break;case 13:if(null===b.memoizedState){var l=b.alternate;if(null!==l){var m=l.memoizedState;if(null!==m){var q=m.dehydrated;null!==q&&bd(q);}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;
default:throw Error(p$1(163));}U$1||b.flags&512&&Rj(b);}catch(r){W(b,b.return,r);}}if(b===a){V$2=null;break}c=b.sibling;if(null!==c){c.return=b.return;V$2=c;break}V$2=b.return;}}function gk(a){for(;null!==V$2;){var b=V$2;if(b===a){V$2=null;break}var c=b.sibling;if(null!==c){c.return=b.return;V$2=c;break}V$2=b.return;}}
function jk(a){for(;null!==V$2;){var b=V$2;try{switch(b.tag){case 0:case 11:case 15:var c=b.return;try{Qj(4,b);}catch(k){W(b,c,k);}break;case 1:var d=b.stateNode;if("function"===typeof d.componentDidMount){var e=b.return;try{d.componentDidMount();}catch(k){W(b,e,k);}}var f=b.return;try{Rj(b);}catch(k){W(b,f,k);}break;case 5:var g=b.return;try{Rj(b);}catch(k){W(b,g,k);}}}catch(k){W(b,b.return,k);}if(b===a){V$2=null;break}var h=b.sibling;if(null!==h){h.return=b.return;V$2=h;break}V$2=b.return;}}
var lk=Math.ceil,mk=ua.ReactCurrentDispatcher,nk=ua.ReactCurrentOwner,ok=ua.ReactCurrentBatchConfig,K$1=0,Q$1=null,Y$1=null,Z=0,fj=0,ej=Uf(0),T$1=0,pk=null,rh=0,qk=0,rk=0,sk=null,tk=null,fk=0,Gj=Infinity,uk=null,Oi=false,Pi=null,Ri=null,vk=false,wk=null,xk=0,yk=0,zk=null,Ak=-1,Bk=0;function R(){return 0!==(K$1&6)?B():-1!==Ak?Ak:Ak=B()}
function yi(a){if(0===(a.mode&1))return 1;if(0!==(K$1&2)&&0!==Z)return Z&-Z;if(null!==Kg.transition)return 0===Bk&&(Bk=yc()),Bk;a=C$2;if(0!==a)return a;a=window.event;a=void 0===a?16:jd(a.type);return a}function gi(a,b,c,d){if(50<yk)throw yk=0,zk=null,Error(p$1(185));Ac(a,c,d);if(0===(K$1&2)||a!==Q$1)a===Q$1&&(0===(K$1&2)&&(qk|=c),4===T$1&&Ck(a,Z)),Dk(a,d),1===c&&0===K$1&&0===(b.mode&1)&&(Gj=B()+500,fg&&jg());}
function Dk(a,b){var c=a.callbackNode;wc(a,b);var d=uc(a,a===Q$1?Z:0);if(0===d)null!==c&&bc(c),a.callbackNode=null,a.callbackPriority=0;else if(b=d&-d,a.callbackPriority!==b){null!=c&&bc(c);if(1===b)0===a.tag?ig(Ek.bind(null,a)):hg(Ek.bind(null,a)),Jf(function(){0===(K$1&6)&&jg();}),c=null;else {switch(Dc(d)){case 1:c=fc;break;case 4:c=gc;break;case 16:c=hc;break;case 536870912:c=jc;break;default:c=hc;}c=Fk(c,Gk.bind(null,a));}a.callbackPriority=b;a.callbackNode=c;}}
function Gk(a,b){Ak=-1;Bk=0;if(0!==(K$1&6))throw Error(p$1(327));var c=a.callbackNode;if(Hk()&&a.callbackNode!==c)return null;var d=uc(a,a===Q$1?Z:0);if(0===d)return null;if(0!==(d&30)||0!==(d&a.expiredLanes)||b)b=Ik(a,d);else {b=d;var e=K$1;K$1|=2;var f=Jk();if(Q$1!==a||Z!==b)uk=null,Gj=B()+500,Kk(a,b);do try{Lk();break}catch(h){Mk(a,h);}while(1);$g();mk.current=f;K$1=e;null!==Y$1?b=0:(Q$1=null,Z=0,b=T$1);}if(0!==b){2===b&&(e=xc(a),0!==e&&(d=e,b=Nk(a,e)));if(1===b)throw c=pk,Kk(a,0),Ck(a,d),Dk(a,B()),c;if(6===b)Ck(a,d);
else {e=a.current.alternate;if(0===(d&30)&&!Ok(e)&&(b=Ik(a,d),2===b&&(f=xc(a),0!==f&&(d=f,b=Nk(a,f))),1===b))throw c=pk,Kk(a,0),Ck(a,d),Dk(a,B()),c;a.finishedWork=e;a.finishedLanes=d;switch(b){case 0:case 1:throw Error(p$1(345));case 2:Pk(a,tk,uk);break;case 3:Ck(a,d);if((d&130023424)===d&&(b=fk+500-B(),10<b)){if(0!==uc(a,0))break;e=a.suspendedLanes;if((e&d)!==d){R();a.pingedLanes|=a.suspendedLanes&e;break}a.timeoutHandle=Ff(Pk.bind(null,a,tk,uk),b);break}Pk(a,tk,uk);break;case 4:Ck(a,d);if((d&4194240)===
d)break;b=a.eventTimes;for(e=-1;0<d;){var g=31-oc(d);f=1<<g;g=b[g];g>e&&(e=g);d&=~f;}d=e;d=B()-d;d=(120>d?120:480>d?480:1080>d?1080:1920>d?1920:3E3>d?3E3:4320>d?4320:1960*lk(d/1960))-d;if(10<d){a.timeoutHandle=Ff(Pk.bind(null,a,tk,uk),d);break}Pk(a,tk,uk);break;case 5:Pk(a,tk,uk);break;default:throw Error(p$1(329));}}}Dk(a,B());return a.callbackNode===c?Gk.bind(null,a):null}
function Nk(a,b){var c=sk;a.current.memoizedState.isDehydrated&&(Kk(a,b).flags|=256);a=Ik(a,b);2!==a&&(b=tk,tk=c,null!==b&&Fj(b));return a}function Fj(a){null===tk?tk=a:tk.push.apply(tk,a);}
function Ok(a){for(var b=a;;){if(b.flags&16384){var c=b.updateQueue;if(null!==c&&(c=c.stores,null!==c))for(var d=0;d<c.length;d++){var e=c[d],f=e.getSnapshot;e=e.value;try{if(!He$1(f(),e))return !1}catch(g){return  false}}}c=b.child;if(b.subtreeFlags&16384&&null!==c)c.return=b,b=c;else {if(b===a)break;for(;null===b.sibling;){if(null===b.return||b.return===a)return  true;b=b.return;}b.sibling.return=b.return;b=b.sibling;}}return  true}
function Ck(a,b){b&=~rk;b&=~qk;a.suspendedLanes|=b;a.pingedLanes&=~b;for(a=a.expirationTimes;0<b;){var c=31-oc(b),d=1<<c;a[c]=-1;b&=~d;}}function Ek(a){if(0!==(K$1&6))throw Error(p$1(327));Hk();var b=uc(a,0);if(0===(b&1))return Dk(a,B()),null;var c=Ik(a,b);if(0!==a.tag&&2===c){var d=xc(a);0!==d&&(b=d,c=Nk(a,d));}if(1===c)throw c=pk,Kk(a,0),Ck(a,b),Dk(a,B()),c;if(6===c)throw Error(p$1(345));a.finishedWork=a.current.alternate;a.finishedLanes=b;Pk(a,tk,uk);Dk(a,B());return null}
function Qk(a,b){var c=K$1;K$1|=1;try{return a(b)}finally{K$1=c,0===K$1&&(Gj=B()+500,fg&&jg());}}function Rk(a){null!==wk&&0===wk.tag&&0===(K$1&6)&&Hk();var b=K$1;K$1|=1;var c=ok.transition,d=C$2;try{if(ok.transition=null,C$2=1,a)return a()}finally{C$2=d,ok.transition=c,K$1=b,0===(K$1&6)&&jg();}}function Hj(){fj=ej.current;E$2(ej);}
function Kk(a,b){a.finishedWork=null;a.finishedLanes=0;var c=a.timeoutHandle;-1!==c&&(a.timeoutHandle=-1,Gf(c));if(null!==Y$1)for(c=Y$1.return;null!==c;){var d=c;wg(d);switch(d.tag){case 1:d=d.type.childContextTypes;null!==d&&void 0!==d&&$f();break;case 3:zh();E$2(Wf);E$2(H$1);Eh();break;case 5:Bh(d);break;case 4:zh();break;case 13:E$2(L);break;case 19:E$2(L);break;case 10:ah(d.type._context);break;case 22:case 23:Hj();}c=c.return;}Q$1=a;Y$1=a=Pg(a.current,null);Z=fj=b;T$1=0;pk=null;rk=qk=rh=0;tk=sk=null;if(null!==fh){for(b=
0;b<fh.length;b++)if(c=fh[b],d=c.interleaved,null!==d){c.interleaved=null;var e=d.next,f=c.pending;if(null!==f){var g=f.next;f.next=e;d.next=g;}c.pending=d;}fh=null;}return a}
function Mk(a,b){do{var c=Y$1;try{$g();Fh.current=Rh;if(Ih){for(var d=M.memoizedState;null!==d;){var e=d.queue;null!==e&&(e.pending=null);d=d.next;}Ih=!1;}Hh=0;O$1=N=M=null;Jh=!1;Kh=0;nk.current=null;if(null===c||null===c.return){T$1=1;pk=b;Y$1=null;break}a:{var f=a,g=c.return,h=c,k=b;b=Z;h.flags|=32768;if(null!==k&&"object"===typeof k&&"function"===typeof k.then){var l=k,m=h,q=m.tag;if(0===(m.mode&1)&&(0===q||11===q||15===q)){var r=m.alternate;r?(m.updateQueue=r.updateQueue,m.memoizedState=r.memoizedState,
m.lanes=r.lanes):(m.updateQueue=null,m.memoizedState=null);}var y=Ui(g);if(null!==y){y.flags&=-257;Vi(y,g,h,f,b);y.mode&1&&Si(f,l,b);b=y;k=l;var n=b.updateQueue;if(null===n){var t=new Set;t.add(k);b.updateQueue=t;}else n.add(k);break a}else {if(0===(b&1)){Si(f,l,b);tj();break a}k=Error(p$1(426));}}else if(I$2&&h.mode&1){var J=Ui(g);if(null!==J){0===(J.flags&65536)&&(J.flags|=256);Vi(J,g,h,f,b);Jg(Ji(k,h));break a}}f=k=Ji(k,h);4!==T$1&&(T$1=2);null===sk?sk=[f]:sk.push(f);f=g;do{switch(f.tag){case 3:f.flags|=65536;
b&=-b;f.lanes|=b;var x=Ni(f,k,b);ph(f,x);break a;case 1:h=k;var w=f.type,u=f.stateNode;if(0===(f.flags&128)&&("function"===typeof w.getDerivedStateFromError||null!==u&&"function"===typeof u.componentDidCatch&&(null===Ri||!Ri.has(u)))){f.flags|=65536;b&=-b;f.lanes|=b;var F=Qi(f,h,b);ph(f,F);break a}}f=f.return;}while(null!==f)}Sk(c);}catch(na){b=na;Y$1===c&&null!==c&&(Y$1=c=c.return);continue}break}while(1)}function Jk(){var a=mk.current;mk.current=Rh;return null===a?Rh:a}
function tj(){if(0===T$1||3===T$1||2===T$1)T$1=4;null===Q$1||0===(rh&268435455)&&0===(qk&268435455)||Ck(Q$1,Z);}function Ik(a,b){var c=K$1;K$1|=2;var d=Jk();if(Q$1!==a||Z!==b)uk=null,Kk(a,b);do try{Tk();break}catch(e){Mk(a,e);}while(1);$g();K$1=c;mk.current=d;if(null!==Y$1)throw Error(p$1(261));Q$1=null;Z=0;return T$1}function Tk(){for(;null!==Y$1;)Uk(Y$1);}function Lk(){for(;null!==Y$1&&!cc();)Uk(Y$1);}function Uk(a){var b=Vk(a.alternate,a,fj);a.memoizedProps=a.pendingProps;null===b?Sk(a):Y$1=b;nk.current=null;}
function Sk(a){var b=a;do{var c=b.alternate;a=b.return;if(0===(b.flags&32768)){if(c=Ej(c,b,fj),null!==c){Y$1=c;return}}else {c=Ij(c,b);if(null!==c){c.flags&=32767;Y$1=c;return}if(null!==a)a.flags|=32768,a.subtreeFlags=0,a.deletions=null;else {T$1=6;Y$1=null;return}}b=b.sibling;if(null!==b){Y$1=b;return}Y$1=b=a;}while(null!==b);0===T$1&&(T$1=5);}function Pk(a,b,c){var d=C$2,e=ok.transition;try{ok.transition=null,C$2=1,Wk(a,b,c,d);}finally{ok.transition=e,C$2=d;}return null}
function Wk(a,b,c,d){do Hk();while(null!==wk);if(0!==(K$1&6))throw Error(p$1(327));c=a.finishedWork;var e=a.finishedLanes;if(null===c)return null;a.finishedWork=null;a.finishedLanes=0;if(c===a.current)throw Error(p$1(177));a.callbackNode=null;a.callbackPriority=0;var f=c.lanes|c.childLanes;Bc(a,f);a===Q$1&&(Y$1=Q$1=null,Z=0);0===(c.subtreeFlags&2064)&&0===(c.flags&2064)||vk||(vk=true,Fk(hc,function(){Hk();return null}));f=0!==(c.flags&15990);if(0!==(c.subtreeFlags&15990)||f){f=ok.transition;ok.transition=null;
var g=C$2;C$2=1;var h=K$1;K$1|=4;nk.current=null;Oj(a,c);dk(c,a);Oe$1(Df);dd=!!Cf;Df=Cf=null;a.current=c;hk(c);dc();K$1=h;C$2=g;ok.transition=f;}else a.current=c;vk&&(vk=false,wk=a,xk=e);f=a.pendingLanes;0===f&&(Ri=null);mc(c.stateNode);Dk(a,B());if(null!==b)for(d=a.onRecoverableError,c=0;c<b.length;c++)e=b[c],d(e.value,{componentStack:e.stack,digest:e.digest});if(Oi)throw Oi=false,a=Pi,Pi=null,a;0!==(xk&1)&&0!==a.tag&&Hk();f=a.pendingLanes;0!==(f&1)?a===zk?yk++:(yk=0,zk=a):yk=0;jg();return null}
function Hk(){if(null!==wk){var a=Dc(xk),b=ok.transition,c=C$2;try{ok.transition=null;C$2=16>a?16:a;if(null===wk)var d=!1;else {a=wk;wk=null;xk=0;if(0!==(K$1&6))throw Error(p$1(331));var e=K$1;K$1|=4;for(V$2=a.current;null!==V$2;){var f=V$2,g=f.child;if(0!==(V$2.flags&16)){var h=f.deletions;if(null!==h){for(var k=0;k<h.length;k++){var l=h[k];for(V$2=l;null!==V$2;){var m=V$2;switch(m.tag){case 0:case 11:case 15:Pj(8,m,f);}var q=m.child;if(null!==q)q.return=m,V$2=q;else for(;null!==V$2;){m=V$2;var r=m.sibling,y=m.return;Sj(m);if(m===
l){V$2=null;break}if(null!==r){r.return=y;V$2=r;break}V$2=y;}}}var n=f.alternate;if(null!==n){var t=n.child;if(null!==t){n.child=null;do{var J=t.sibling;t.sibling=null;t=J;}while(null!==t)}}V$2=f;}}if(0!==(f.subtreeFlags&2064)&&null!==g)g.return=f,V$2=g;else b:for(;null!==V$2;){f=V$2;if(0!==(f.flags&2048))switch(f.tag){case 0:case 11:case 15:Pj(9,f,f.return);}var x=f.sibling;if(null!==x){x.return=f.return;V$2=x;break b}V$2=f.return;}}var w=a.current;for(V$2=w;null!==V$2;){g=V$2;var u=g.child;if(0!==(g.subtreeFlags&2064)&&null!==
u)u.return=g,V$2=u;else b:for(g=w;null!==V$2;){h=V$2;if(0!==(h.flags&2048))try{switch(h.tag){case 0:case 11:case 15:Qj(9,h);}}catch(na){W(h,h.return,na);}if(h===g){V$2=null;break b}var F=h.sibling;if(null!==F){F.return=h.return;V$2=F;break b}V$2=h.return;}}K$1=e;jg();if(lc&&"function"===typeof lc.onPostCommitFiberRoot)try{lc.onPostCommitFiberRoot(kc,a);}catch(na){}d=!0;}return d}finally{C$2=c,ok.transition=b;}}return  false}function Xk(a,b,c){b=Ji(c,b);b=Ni(a,b,1);a=nh(a,b,1);b=R();null!==a&&(Ac(a,1,b),Dk(a,b));}
function W(a,b,c){if(3===a.tag)Xk(a,a,c);else for(;null!==b;){if(3===b.tag){Xk(b,a,c);break}else if(1===b.tag){var d=b.stateNode;if("function"===typeof b.type.getDerivedStateFromError||"function"===typeof d.componentDidCatch&&(null===Ri||!Ri.has(d))){a=Ji(c,a);a=Qi(b,a,1);b=nh(b,a,1);a=R();null!==b&&(Ac(b,1,a),Dk(b,a));break}}b=b.return;}}
function Ti(a,b,c){var d=a.pingCache;null!==d&&d.delete(b);b=R();a.pingedLanes|=a.suspendedLanes&c;Q$1===a&&(Z&c)===c&&(4===T$1||3===T$1&&(Z&130023424)===Z&&500>B()-fk?Kk(a,0):rk|=c);Dk(a,b);}function Yk(a,b){0===b&&(0===(a.mode&1)?b=1:(b=sc,sc<<=1,0===(sc&130023424)&&(sc=4194304)));var c=R();a=ih(a,b);null!==a&&(Ac(a,b,c),Dk(a,c));}function uj(a){var b=a.memoizedState,c=0;null!==b&&(c=b.retryLane);Yk(a,c);}
function bk(a,b){var c=0;switch(a.tag){case 13:var d=a.stateNode;var e=a.memoizedState;null!==e&&(c=e.retryLane);break;case 19:d=a.stateNode;break;default:throw Error(p$1(314));}null!==d&&d.delete(b);Yk(a,c);}var Vk;
Vk=function(a,b,c){if(null!==a)if(a.memoizedProps!==b.pendingProps||Wf.current)dh=true;else {if(0===(a.lanes&c)&&0===(b.flags&128))return dh=false,yj(a,b,c);dh=0!==(a.flags&131072)?true:false;}else dh=false,I$2&&0!==(b.flags&1048576)&&ug(b,ng,b.index);b.lanes=0;switch(b.tag){case 2:var d=b.type;ij(a,b);a=b.pendingProps;var e=Yf(b,H$1.current);ch(b,c);e=Nh(null,b,d,a,e,c);var f=Sh();b.flags|=1;"object"===typeof e&&null!==e&&"function"===typeof e.render&&void 0===e.$$typeof?(b.tag=1,b.memoizedState=null,b.updateQueue=
null,Zf(d)?(f=true,cg(b)):f=false,b.memoizedState=null!==e.state&&void 0!==e.state?e.state:null,kh(b),e.updater=Ei,b.stateNode=e,e._reactInternals=b,Ii(b,d,a,c),b=jj(null,b,d,true,f,c)):(b.tag=0,I$2&&f&&vg(b),Xi(null,b,e,c),b=b.child);return b;case 16:d=b.elementType;a:{ij(a,b);a=b.pendingProps;e=d._init;d=e(d._payload);b.type=d;e=b.tag=Zk(d);a=Ci(d,a);switch(e){case 0:b=cj(null,b,d,a,c);break a;case 1:b=hj(null,b,d,a,c);break a;case 11:b=Yi(null,b,d,a,c);break a;case 14:b=$i(null,b,d,Ci(d.type,a),c);break a}throw Error(p$1(306,
d,""));}return b;case 0:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:Ci(d,e),cj(a,b,d,e,c);case 1:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:Ci(d,e),hj(a,b,d,e,c);case 3:a:{kj(b);if(null===a)throw Error(p$1(387));d=b.pendingProps;f=b.memoizedState;e=f.element;lh(a,b);qh(b,d,null,c);var g=b.memoizedState;d=g.element;if(f.isDehydrated)if(f={element:d,isDehydrated:false,cache:g.cache,pendingSuspenseBoundaries:g.pendingSuspenseBoundaries,transitions:g.transitions},b.updateQueue.baseState=
f,b.memoizedState=f,b.flags&256){e=Ji(Error(p$1(423)),b);b=lj(a,b,d,c,e);break a}else if(d!==e){e=Ji(Error(p$1(424)),b);b=lj(a,b,d,c,e);break a}else for(yg=Lf(b.stateNode.containerInfo.firstChild),xg=b,I$2=true,zg=null,c=Vg(b,null,d,c),b.child=c;c;)c.flags=c.flags&-3|4096,c=c.sibling;else {Ig();if(d===e){b=Zi(a,b,c);break a}Xi(a,b,d,c);}b=b.child;}return b;case 5:return Ah(b),null===a&&Eg(b),d=b.type,e=b.pendingProps,f=null!==a?a.memoizedProps:null,g=e.children,Ef(d,e)?g=null:null!==f&&Ef(d,f)&&(b.flags|=32),
gj(a,b),Xi(a,b,g,c),b.child;case 6:return null===a&&Eg(b),null;case 13:return oj(a,b,c);case 4:return yh(b,b.stateNode.containerInfo),d=b.pendingProps,null===a?b.child=Ug(b,null,d,c):Xi(a,b,d,c),b.child;case 11:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:Ci(d,e),Yi(a,b,d,e,c);case 7:return Xi(a,b,b.pendingProps,c),b.child;case 8:return Xi(a,b,b.pendingProps.children,c),b.child;case 12:return Xi(a,b,b.pendingProps.children,c),b.child;case 10:a:{d=b.type._context;e=b.pendingProps;f=b.memoizedProps;
g=e.value;G$1(Wg,d._currentValue);d._currentValue=g;if(null!==f)if(He$1(f.value,g)){if(f.children===e.children&&!Wf.current){b=Zi(a,b,c);break a}}else for(f=b.child,null!==f&&(f.return=b);null!==f;){var h=f.dependencies;if(null!==h){g=f.child;for(var k=h.firstContext;null!==k;){if(k.context===d){if(1===f.tag){k=mh(-1,c&-c);k.tag=2;var l=f.updateQueue;if(null!==l){l=l.shared;var m=l.pending;null===m?k.next=k:(k.next=m.next,m.next=k);l.pending=k;}}f.lanes|=c;k=f.alternate;null!==k&&(k.lanes|=c);bh(f.return,
c,b);h.lanes|=c;break}k=k.next;}}else if(10===f.tag)g=f.type===b.type?null:f.child;else if(18===f.tag){g=f.return;if(null===g)throw Error(p$1(341));g.lanes|=c;h=g.alternate;null!==h&&(h.lanes|=c);bh(g,c,b);g=f.sibling;}else g=f.child;if(null!==g)g.return=f;else for(g=f;null!==g;){if(g===b){g=null;break}f=g.sibling;if(null!==f){f.return=g.return;g=f;break}g=g.return;}f=g;}Xi(a,b,e.children,c);b=b.child;}return b;case 9:return e=b.type,d=b.pendingProps.children,ch(b,c),e=eh(e),d=d(e),b.flags|=1,Xi(a,b,d,c),
b.child;case 14:return d=b.type,e=Ci(d,b.pendingProps),e=Ci(d.type,e),$i(a,b,d,e,c);case 15:return bj(a,b,b.type,b.pendingProps,c);case 17:return d=b.type,e=b.pendingProps,e=b.elementType===d?e:Ci(d,e),ij(a,b),b.tag=1,Zf(d)?(a=true,cg(b)):a=false,ch(b,c),Gi(b,d,e),Ii(b,d,e,c),jj(null,b,d,true,a,c);case 19:return xj(a,b,c);case 22:return dj(a,b,c)}throw Error(p$1(156,b.tag));};function Fk(a,b){return ac(a,b)}
function $k(a,b,c,d){this.tag=a;this.key=c;this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null;this.index=0;this.ref=null;this.pendingProps=b;this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null;this.mode=d;this.subtreeFlags=this.flags=0;this.deletions=null;this.childLanes=this.lanes=0;this.alternate=null;}function Bg(a,b,c,d){return new $k(a,b,c,d)}function aj(a){a=a.prototype;return !(!a||!a.isReactComponent)}
function Zk(a){if("function"===typeof a)return aj(a)?1:0;if(void 0!==a&&null!==a){a=a.$$typeof;if(a===Da)return 11;if(a===Ga)return 14}return 2}
function Pg(a,b){var c=a.alternate;null===c?(c=Bg(a.tag,b,a.key,a.mode),c.elementType=a.elementType,c.type=a.type,c.stateNode=a.stateNode,c.alternate=a,a.alternate=c):(c.pendingProps=b,c.type=a.type,c.flags=0,c.subtreeFlags=0,c.deletions=null);c.flags=a.flags&14680064;c.childLanes=a.childLanes;c.lanes=a.lanes;c.child=a.child;c.memoizedProps=a.memoizedProps;c.memoizedState=a.memoizedState;c.updateQueue=a.updateQueue;b=a.dependencies;c.dependencies=null===b?null:{lanes:b.lanes,firstContext:b.firstContext};
c.sibling=a.sibling;c.index=a.index;c.ref=a.ref;return c}
function Rg(a,b,c,d,e,f){var g=2;d=a;if("function"===typeof a)aj(a)&&(g=1);else if("string"===typeof a)g=5;else a:switch(a){case ya:return Tg(c.children,e,f,b);case za:g=8;e|=8;break;case Aa:return a=Bg(12,c,b,e|2),a.elementType=Aa,a.lanes=f,a;case Ea:return a=Bg(13,c,b,e),a.elementType=Ea,a.lanes=f,a;case Fa:return a=Bg(19,c,b,e),a.elementType=Fa,a.lanes=f,a;case Ia:return pj(c,e,f,b);default:if("object"===typeof a&&null!==a)switch(a.$$typeof){case Ba:g=10;break a;case Ca:g=9;break a;case Da:g=11;
break a;case Ga:g=14;break a;case Ha:g=16;d=null;break a}throw Error(p$1(130,null==a?a:typeof a,""));}b=Bg(g,c,b,e);b.elementType=a;b.type=d;b.lanes=f;return b}function Tg(a,b,c,d){a=Bg(7,a,d,b);a.lanes=c;return a}function pj(a,b,c,d){a=Bg(22,a,d,b);a.elementType=Ia;a.lanes=c;a.stateNode={isHidden:false};return a}function Qg(a,b,c){a=Bg(6,a,null,b);a.lanes=c;return a}
function Sg(a,b,c){b=Bg(4,null!==a.children?a.children:[],a.key,b);b.lanes=c;b.stateNode={containerInfo:a.containerInfo,pendingChildren:null,implementation:a.implementation};return b}
function al(a,b,c,d,e){this.tag=b;this.containerInfo=a;this.finishedWork=this.pingCache=this.current=this.pendingChildren=null;this.timeoutHandle=-1;this.callbackNode=this.pendingContext=this.context=null;this.callbackPriority=0;this.eventTimes=zc(0);this.expirationTimes=zc(-1);this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0;this.entanglements=zc(0);this.identifierPrefix=d;this.onRecoverableError=e;this.mutableSourceEagerHydrationData=
null;}function bl(a,b,c,d,e,f,g,h,k){a=new al(a,b,c,h,k);1===b?(b=1,true===f&&(b|=8)):b=0;f=Bg(3,null,null,b);a.current=f;f.stateNode=a;f.memoizedState={element:d,isDehydrated:c,cache:null,transitions:null,pendingSuspenseBoundaries:null};kh(f);return a}function cl(a,b,c){var d=3<arguments.length&&void 0!==arguments[3]?arguments[3]:null;return {$$typeof:wa,key:null==d?null:""+d,children:a,containerInfo:b,implementation:c}}
function dl(a){if(!a)return Vf;a=a._reactInternals;a:{if(Vb(a)!==a||1!==a.tag)throw Error(p$1(170));var b=a;do{switch(b.tag){case 3:b=b.stateNode.context;break a;case 1:if(Zf(b.type)){b=b.stateNode.__reactInternalMemoizedMergedChildContext;break a}}b=b.return;}while(null!==b);throw Error(p$1(171));}if(1===a.tag){var c=a.type;if(Zf(c))return bg(a,c,b)}return b}
function el(a,b,c,d,e,f,g,h,k){a=bl(c,d,true,a,e,f,g,h,k);a.context=dl(null);c=a.current;d=R();e=yi(c);f=mh(d,e);f.callback=void 0!==b&&null!==b?b:null;nh(c,f,e);a.current.lanes=e;Ac(a,e,d);Dk(a,d);return a}function fl(a,b,c,d){var e=b.current,f=R(),g=yi(e);c=dl(c);null===b.context?b.context=c:b.pendingContext=c;b=mh(f,g);b.payload={element:a};d=void 0===d?null:d;null!==d&&(b.callback=d);a=nh(e,b,g);null!==a&&(gi(a,e,g,f),oh(a,e,g));return g}
function gl(a){a=a.current;if(!a.child)return null;switch(a.child.tag){case 5:return a.child.stateNode;default:return a.child.stateNode}}function hl(a,b){a=a.memoizedState;if(null!==a&&null!==a.dehydrated){var c=a.retryLane;a.retryLane=0!==c&&c<b?c:b;}}function il(a,b){hl(a,b);(a=a.alternate)&&hl(a,b);}function jl(){return null}var kl="function"===typeof reportError?reportError:function(a){console.error(a);};function ll(a){this._internalRoot=a;}
ml.prototype.render=ll.prototype.render=function(a){var b=this._internalRoot;if(null===b)throw Error(p$1(409));fl(a,b,null,null);};ml.prototype.unmount=ll.prototype.unmount=function(){var a=this._internalRoot;if(null!==a){this._internalRoot=null;var b=a.containerInfo;Rk(function(){fl(null,a,null,null);});b[uf]=null;}};function ml(a){this._internalRoot=a;}
ml.prototype.unstable_scheduleHydration=function(a){if(a){var b=Hc();a={blockedOn:null,target:a,priority:b};for(var c=0;c<Qc.length&&0!==b&&b<Qc[c].priority;c++);Qc.splice(c,0,a);0===c&&Vc(a);}};function nl(a){return !(!a||1!==a.nodeType&&9!==a.nodeType&&11!==a.nodeType)}function ol(a){return !(!a||1!==a.nodeType&&9!==a.nodeType&&11!==a.nodeType&&(8!==a.nodeType||" react-mount-point-unstable "!==a.nodeValue))}function pl(){}
function ql(a,b,c,d,e){if(e){if("function"===typeof d){var f=d;d=function(){var a=gl(g);f.call(a);};}var g=el(b,d,a,0,null,false,false,"",pl);a._reactRootContainer=g;a[uf]=g.current;sf(8===a.nodeType?a.parentNode:a);Rk();return g}for(;e=a.lastChild;)a.removeChild(e);if("function"===typeof d){var h=d;d=function(){var a=gl(k);h.call(a);};}var k=bl(a,0,false,null,null,false,false,"",pl);a._reactRootContainer=k;a[uf]=k.current;sf(8===a.nodeType?a.parentNode:a);Rk(function(){fl(b,k,c,d);});return k}
function rl(a,b,c,d,e){var f=c._reactRootContainer;if(f){var g=f;if("function"===typeof e){var h=e;e=function(){var a=gl(g);h.call(a);};}fl(b,g,a,e);}else g=ql(c,b,a,e,d);return gl(g)}Ec=function(a){switch(a.tag){case 3:var b=a.stateNode;if(b.current.memoizedState.isDehydrated){var c=tc(b.pendingLanes);0!==c&&(Cc(b,c|1),Dk(b,B()),0===(K$1&6)&&(Gj=B()+500,jg()));}break;case 13:Rk(function(){var b=ih(a,1);if(null!==b){var c=R();gi(b,a,1,c);}}),il(a,1);}};
Fc=function(a){if(13===a.tag){var b=ih(a,134217728);if(null!==b){var c=R();gi(b,a,134217728,c);}il(a,134217728);}};Gc=function(a){if(13===a.tag){var b=yi(a),c=ih(a,b);if(null!==c){var d=R();gi(c,a,b,d);}il(a,b);}};Hc=function(){return C$2};Ic=function(a,b){var c=C$2;try{return C$2=a,b()}finally{C$2=c;}};
yb=function(a,b,c){switch(b){case "input":bb(a,c);b=c.name;if("radio"===c.type&&null!=b){for(c=a;c.parentNode;)c=c.parentNode;c=c.querySelectorAll("input[name="+JSON.stringify(""+b)+'][type="radio"]');for(b=0;b<c.length;b++){var d=c[b];if(d!==a&&d.form===a.form){var e=Db(d);if(!e)throw Error(p$1(90));Wa(d);bb(d,e);}}}break;case "textarea":ib(a,c);break;case "select":b=c.value,null!=b&&fb(a,!!c.multiple,b,false);}};Gb=Qk;Hb=Rk;
var sl={usingClientEntryPoint:false,Events:[Cb,ue,Db,Eb,Fb,Qk]},tl={findFiberByHostInstance:Wc,bundleType:0,version:"18.3.1",rendererPackageName:"react-dom"};
var ul={bundleType:tl.bundleType,version:tl.version,rendererPackageName:tl.rendererPackageName,rendererConfig:tl.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:ua.ReactCurrentDispatcher,findHostInstanceByFiber:function(a){a=Zb(a);return null===a?null:a.stateNode},findFiberByHostInstance:tl.findFiberByHostInstance||
jl,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.3.1-next-f1338f8080-20240426"};if("undefined"!==typeof __REACT_DEVTOOLS_GLOBAL_HOOK__){var vl=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!vl.isDisabled&&vl.supportsFiber)try{kc=vl.inject(ul),lc=vl;}catch(a){}}reactDom_production_min.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=sl;
reactDom_production_min.createPortal=function(a,b){var c=2<arguments.length&&void 0!==arguments[2]?arguments[2]:null;if(!nl(b))throw Error(p$1(200));return cl(a,b,null,c)};reactDom_production_min.createRoot=function(a,b){if(!nl(a))throw Error(p$1(299));var c=false,d="",e=kl;null!==b&&void 0!==b&&(true===b.unstable_strictMode&&(c=true),void 0!==b.identifierPrefix&&(d=b.identifierPrefix),void 0!==b.onRecoverableError&&(e=b.onRecoverableError));b=bl(a,1,false,null,null,c,false,d,e);a[uf]=b.current;sf(8===a.nodeType?a.parentNode:a);return new ll(b)};
reactDom_production_min.findDOMNode=function(a){if(null==a)return null;if(1===a.nodeType)return a;var b=a._reactInternals;if(void 0===b){if("function"===typeof a.render)throw Error(p$1(188));a=Object.keys(a).join(",");throw Error(p$1(268,a));}a=Zb(b);a=null===a?null:a.stateNode;return a};reactDom_production_min.flushSync=function(a){return Rk(a)};reactDom_production_min.hydrate=function(a,b,c){if(!ol(b))throw Error(p$1(200));return rl(null,a,b,true,c)};
reactDom_production_min.hydrateRoot=function(a,b,c){if(!nl(a))throw Error(p$1(405));var d=null!=c&&c.hydratedSources||null,e=false,f="",g=kl;null!==c&&void 0!==c&&(true===c.unstable_strictMode&&(e=true),void 0!==c.identifierPrefix&&(f=c.identifierPrefix),void 0!==c.onRecoverableError&&(g=c.onRecoverableError));b=el(b,null,a,1,null!=c?c:null,e,false,f,g);a[uf]=b.current;sf(a);if(d)for(a=0;a<d.length;a++)c=d[a],e=c._getVersion,e=e(c._source),null==b.mutableSourceEagerHydrationData?b.mutableSourceEagerHydrationData=[c,e]:b.mutableSourceEagerHydrationData.push(c,
e);return new ml(b)};reactDom_production_min.render=function(a,b,c){if(!ol(b))throw Error(p$1(200));return rl(null,a,b,false,c)};reactDom_production_min.unmountComponentAtNode=function(a){if(!ol(a))throw Error(p$1(40));return a._reactRootContainer?(Rk(function(){rl(null,null,a,!1,function(){a._reactRootContainer=null;a[uf]=null;});}),true):false};reactDom_production_min.unstable_batchedUpdates=Qk;
reactDom_production_min.unstable_renderSubtreeIntoContainer=function(a,b,c,d){if(!ol(c))throw Error(p$1(200));if(null==a||void 0===a._reactInternals)throw Error(p$1(38));return rl(a,b,c,false,d)};reactDom_production_min.version="18.3.1-next-f1338f8080-20240426";

function checkDCE() {
  if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== "function") {
    return;
  }
  try {
    __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
  } catch (err) {
    console.error(err);
  }
}
{
  checkDCE();
  reactDom.exports = reactDom_production_min;
}

var reactDomExports = reactDom.exports;

var m$1 = reactDomExports;
{
  client.createRoot = m$1.createRoot;
  client.hydrateRoot = m$1.hydrateRoot;
}

/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ 
const $f0a04ccd8dbdd83b$export$e5c5a5f917a5871c = typeof document !== 'undefined' ? (React).useLayoutEffect : ()=>{};

const $431fbd86ca7dc216$export$b204af158042fbac = (el)=>{
    var _el_ownerDocument;
    return (_el_ownerDocument = el === null || el === void 0 ? void 0 : el.ownerDocument) !== null && _el_ownerDocument !== void 0 ? _el_ownerDocument : document;
};
const $431fbd86ca7dc216$export$f21a1ffae260145a = (el)=>{
    if (el && 'window' in el && el.window === el) return el;
    const doc = $431fbd86ca7dc216$export$b204af158042fbac(el);
    return doc.defaultView || window;
};
/**
 * Type guard that checks if a value is a Node. Verifies the presence and type of the nodeType property.
 */ function $431fbd86ca7dc216$var$isNode(value) {
    return value !== null && typeof value === 'object' && 'nodeType' in value && typeof value.nodeType === 'number';
}
function $431fbd86ca7dc216$export$af51f0f06c0f328a(node) {
    return $431fbd86ca7dc216$var$isNode(node) && node.nodeType === Node.DOCUMENT_FRAGMENT_NODE && 'host' in node;
}

let $f4e2df6bd15f8569$var$_shadowDOM = false;
function $f4e2df6bd15f8569$export$98658e8c59125e6a() {
    return $f4e2df6bd15f8569$var$_shadowDOM;
}

// Source: https://github.com/microsoft/tabster/blob/a89fc5d7e332d48f68d03b1ca6e344489d1c3898/src/Shadowdomize/DOMFunctions.ts#L16


function $d4ee10de306f2510$export$4282f70798064fe0(node, otherNode) {
    if (!($f4e2df6bd15f8569$export$98658e8c59125e6a)()) return otherNode && node ? node.contains(otherNode) : false;
    if (!node || !otherNode) return false;
    let currentNode = otherNode;
    while(currentNode !== null){
        if (currentNode === node) return true;
        if (currentNode.tagName === 'SLOT' && currentNode.assignedSlot) // Element is slotted
        currentNode = currentNode.assignedSlot.parentNode;
        else if (($431fbd86ca7dc216$export$af51f0f06c0f328a)(currentNode)) // Element is in shadow root
        currentNode = currentNode.host;
        else currentNode = currentNode.parentNode;
    }
    return false;
}
const $d4ee10de306f2510$export$cd4e5573fbe2b576 = (doc = document)=>{
    var _activeElement_shadowRoot;
    if (!($f4e2df6bd15f8569$export$98658e8c59125e6a)()) return doc.activeElement;
    let activeElement = doc.activeElement;
    while(activeElement && 'shadowRoot' in activeElement && ((_activeElement_shadowRoot = activeElement.shadowRoot) === null || _activeElement_shadowRoot === void 0 ? void 0 : _activeElement_shadowRoot.activeElement))activeElement = activeElement.shadowRoot.activeElement;
    return activeElement;
};
function $d4ee10de306f2510$export$e58f029f0fbfdb29(event) {
    if (($f4e2df6bd15f8569$export$98658e8c59125e6a)() && event.target.shadowRoot) {
        if (event.composedPath) return event.composedPath()[0];
    }
    return event.target;
}

/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ function $7215afc6de606d6b$export$de79e2c695e052f3(element) {
    if ($7215afc6de606d6b$var$supportsPreventScroll()) element.focus({
        preventScroll: true
    });
    else {
        let scrollableElements = $7215afc6de606d6b$var$getScrollableElements(element);
        element.focus();
        $7215afc6de606d6b$var$restoreScrollPosition(scrollableElements);
    }
}
let $7215afc6de606d6b$var$supportsPreventScrollCached = null;
function $7215afc6de606d6b$var$supportsPreventScroll() {
    if ($7215afc6de606d6b$var$supportsPreventScrollCached == null) {
        $7215afc6de606d6b$var$supportsPreventScrollCached = false;
        try {
            let focusElem = document.createElement('div');
            focusElem.focus({
                get preventScroll () {
                    $7215afc6de606d6b$var$supportsPreventScrollCached = true;
                    return true;
                }
            });
        } catch  {
        // Ignore
        }
    }
    return $7215afc6de606d6b$var$supportsPreventScrollCached;
}
function $7215afc6de606d6b$var$getScrollableElements(element) {
    let parent = element.parentNode;
    let scrollableElements = [];
    let rootScrollingElement = document.scrollingElement || document.documentElement;
    while(parent instanceof HTMLElement && parent !== rootScrollingElement){
        if (parent.offsetHeight < parent.scrollHeight || parent.offsetWidth < parent.scrollWidth) scrollableElements.push({
            element: parent,
            scrollTop: parent.scrollTop,
            scrollLeft: parent.scrollLeft
        });
        parent = parent.parentNode;
    }
    if (rootScrollingElement instanceof HTMLElement) scrollableElements.push({
        element: rootScrollingElement,
        scrollTop: rootScrollingElement.scrollTop,
        scrollLeft: rootScrollingElement.scrollLeft
    });
    return scrollableElements;
}
function $7215afc6de606d6b$var$restoreScrollPosition(scrollableElements) {
    for (let { element: element, scrollTop: scrollTop, scrollLeft: scrollLeft } of scrollableElements){
        element.scrollTop = scrollTop;
        element.scrollLeft = scrollLeft;
    }
}

function $c87311424ea30a05$var$testUserAgent(re) {
  var _window_navigator_userAgentData;
  if (typeof window === "undefined" || window.navigator == null) return false;
  let brands = (_window_navigator_userAgentData = window.navigator["userAgentData"]) === null || _window_navigator_userAgentData === void 0 ? void 0 : _window_navigator_userAgentData.brands;
  return Array.isArray(brands) && brands.some((brand) => re.test(brand.brand)) || re.test(window.navigator.userAgent);
}
function $c87311424ea30a05$var$testPlatform(re) {
  var _window_navigator_userAgentData;
  return typeof window !== "undefined" && window.navigator != null ? re.test(((_window_navigator_userAgentData = window.navigator["userAgentData"]) === null || _window_navigator_userAgentData === void 0 ? void 0 : _window_navigator_userAgentData.platform) || window.navigator.platform) : false;
}
function $c87311424ea30a05$var$cached(fn) {
  let res = null;
  return () => {
    if (res == null) res = fn();
    return res;
  };
}
const $c87311424ea30a05$export$9ac100e40613ea10 = $c87311424ea30a05$var$cached(function() {
  return $c87311424ea30a05$var$testPlatform(/^Mac/i);
});
const $c87311424ea30a05$export$7bef049ce92e4224 = $c87311424ea30a05$var$cached(function() {
  return $c87311424ea30a05$var$testPlatform(/^iPad/i) || // iPadOS 13 lies and says it's a Mac, but we can distinguish by detecting touch support.
  $c87311424ea30a05$export$9ac100e40613ea10() && navigator.maxTouchPoints > 1;
});
const $c87311424ea30a05$export$78551043582a6a98 = $c87311424ea30a05$var$cached(function() {
  return $c87311424ea30a05$var$testUserAgent(/AppleWebKit/i) && !$c87311424ea30a05$export$6446a186d09e379e();
});
const $c87311424ea30a05$export$6446a186d09e379e = $c87311424ea30a05$var$cached(function() {
  return $c87311424ea30a05$var$testUserAgent(/Chrome/i);
});
const $c87311424ea30a05$export$a11b0059900ceec8 = $c87311424ea30a05$var$cached(function() {
  return $c87311424ea30a05$var$testUserAgent(/Android/i);
});
const $c87311424ea30a05$export$b7d78993b74f766d = $c87311424ea30a05$var$cached(function() {
  return $c87311424ea30a05$var$testUserAgent(/Firefox/i);
});

function $ea8dcbcb9ea1b556$export$95185d699e05d4d7(target, modifiers, setOpening = true) {
  var _window_event_type, _window_event;
  let { metaKey, ctrlKey, altKey, shiftKey } = modifiers;
  if (($c87311424ea30a05$export$b7d78993b74f766d)() && ((_window_event = window.event) === null || _window_event === void 0 ? void 0 : (_window_event_type = _window_event.type) === null || _window_event_type === void 0 ? void 0 : _window_event_type.startsWith("key")) && target.target === "_blank") {
    if (($c87311424ea30a05$export$9ac100e40613ea10)()) metaKey = true;
    else ctrlKey = true;
  }
  let event = ($c87311424ea30a05$export$78551043582a6a98)() && ($c87311424ea30a05$export$9ac100e40613ea10)() && !($c87311424ea30a05$export$7bef049ce92e4224)() && true ? new KeyboardEvent("keydown", {
    keyIdentifier: "Enter",
    metaKey,
    ctrlKey,
    altKey,
    shiftKey
  }) : new MouseEvent("click", {
    metaKey,
    ctrlKey,
    altKey,
    shiftKey,
    detail: 1,
    bubbles: true,
    cancelable: true
  });
  $ea8dcbcb9ea1b556$export$95185d699e05d4d7.isOpening = setOpening;
  ($7215afc6de606d6b$export$de79e2c695e052f3)(target);
  target.dispatchEvent(event);
  $ea8dcbcb9ea1b556$export$95185d699e05d4d7.isOpening = false;
}
$ea8dcbcb9ea1b556$export$95185d699e05d4d7.isOpening = false;

/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ 
function $03deb23ff14920c4$export$4eaf04e54aa8eed6() {
    let globalListeners = (reactExports.useRef)(new Map());
    let addGlobalListener = (reactExports.useCallback)((eventTarget, type, listener, options)=>{
        // Make sure we remove the listener after it is called with the `once` option.
        let fn = (options === null || options === void 0 ? void 0 : options.once) ? (...args)=>{
            globalListeners.current.delete(listener);
            listener(...args);
        } : listener;
        globalListeners.current.set(listener, {
            type: type,
            eventTarget: eventTarget,
            fn: fn,
            options: options
        });
        eventTarget.addEventListener(type, fn, options);
    }, []);
    let removeGlobalListener = (reactExports.useCallback)((eventTarget, type, listener, options)=>{
        var _globalListeners_current_get;
        let fn = ((_globalListeners_current_get = globalListeners.current.get(listener)) === null || _globalListeners_current_get === void 0 ? void 0 : _globalListeners_current_get.fn) || listener;
        eventTarget.removeEventListener(type, fn, options);
        globalListeners.current.delete(listener);
    }, []);
    let removeAllGlobalListeners = (reactExports.useCallback)(()=>{
        globalListeners.current.forEach((value, key)=>{
            removeGlobalListener(value.eventTarget, value.type, key, value.options);
        });
    }, [
        removeGlobalListener
    ]);
    (reactExports.useEffect)(()=>{
        return removeAllGlobalListeners;
    }, [
        removeAllGlobalListeners
    ]);
    return {
        addGlobalListener: addGlobalListener,
        removeGlobalListener: removeGlobalListener,
        removeAllGlobalListeners: removeAllGlobalListeners
    };
}

/*
 * Copyright 2022 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ 
function $6a7db85432448f7f$export$60278871457622de(event) {
    // JAWS/NVDA with Firefox.
    if (event.pointerType === '' && event.isTrusted) return true;
    // Android TalkBack's detail value varies depending on the event listener providing the event so we have specific logic here instead
    // If pointerType is defined, event is from a click listener. For events from mousedown listener, detail === 0 is a sufficient check
    // to detect TalkBack virtual clicks.
    if (($c87311424ea30a05$export$a11b0059900ceec8)() && event.pointerType) return event.type === 'click' && event.buttons === 1;
    return event.detail === 0 && !event.pointerType;
}

/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ 

function $8a9cb279dc87e130$export$525bc4921d56d4a(nativeEvent) {
    let event = nativeEvent;
    event.nativeEvent = nativeEvent;
    event.isDefaultPrevented = ()=>event.defaultPrevented;
    // cancelBubble is technically deprecated in the spec, but still supported in all browsers.
    event.isPropagationStopped = ()=>event.cancelBubble;
    event.persist = ()=>{};
    return event;
}
function $8a9cb279dc87e130$export$c2b7abe5d61ec696(event, target) {
    Object.defineProperty(event, 'target', {
        value: target
    });
    Object.defineProperty(event, 'currentTarget', {
        value: target
    });
}
function $8a9cb279dc87e130$export$715c682d09d639cc(onBlur) {
    let stateRef = (reactExports.useRef)({
        isFocused: false,
        observer: null
    });
    // Clean up MutationObserver on unmount. See below.
    ($f0a04ccd8dbdd83b$export$e5c5a5f917a5871c)(()=>{
        const state = stateRef.current;
        return ()=>{
            if (state.observer) {
                state.observer.disconnect();
                state.observer = null;
            }
        };
    }, []);
    // This function is called during a React onFocus event.
    return (reactExports.useCallback)((e)=>{
        // React does not fire onBlur when an element is disabled. https://github.com/facebook/react/issues/9142
        // Most browsers fire a native focusout event in this case, except for Firefox. In that case, we use a
        // MutationObserver to watch for the disabled attribute, and dispatch these events ourselves.
        // For browsers that do, focusout fires before the MutationObserver, so onBlur should not fire twice.
        if (e.target instanceof HTMLButtonElement || e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement || e.target instanceof HTMLSelectElement) {
            stateRef.current.isFocused = true;
            let target = e.target;
            let onBlurHandler = (e)=>{
                stateRef.current.isFocused = false;
                if (target.disabled) {
                    // For backward compatibility, dispatch a (fake) React synthetic event.
                    let event = $8a9cb279dc87e130$export$525bc4921d56d4a(e);
                    onBlur === null || onBlur === void 0 ? void 0 : onBlur(event);
                }
                // We no longer need the MutationObserver once the target is blurred.
                if (stateRef.current.observer) {
                    stateRef.current.observer.disconnect();
                    stateRef.current.observer = null;
                }
            };
            target.addEventListener('focusout', onBlurHandler, {
                once: true
            });
            stateRef.current.observer = new MutationObserver(()=>{
                if (stateRef.current.isFocused && target.disabled) {
                    var _stateRef_current_observer;
                    (_stateRef_current_observer = stateRef.current.observer) === null || _stateRef_current_observer === void 0 ? void 0 : _stateRef_current_observer.disconnect();
                    let relatedTargetEl = target === document.activeElement ? null : document.activeElement;
                    target.dispatchEvent(new FocusEvent('blur', {
                        relatedTarget: relatedTargetEl
                    }));
                    target.dispatchEvent(new FocusEvent('focusout', {
                        bubbles: true,
                        relatedTarget: relatedTargetEl
                    }));
                }
            });
            stateRef.current.observer.observe(target, {
                attributes: true,
                attributeFilter: [
                    'disabled'
                ]
            });
        }
    }, [
        onBlur
    ]);
}
let $8a9cb279dc87e130$export$fda7da73ab5d4c48 = false;

let $507fabe10e71c6fb$var$currentModality = null;
let $507fabe10e71c6fb$var$changeHandlers = /* @__PURE__ */ new Set();
let $507fabe10e71c6fb$export$d90243b58daecda7 = /* @__PURE__ */ new Map();
let $507fabe10e71c6fb$var$hasEventBeforeFocus = false;
let $507fabe10e71c6fb$var$hasBlurredWindowRecently = false;
const $507fabe10e71c6fb$var$FOCUS_VISIBLE_INPUT_KEYS = {
  Tab: true,
  Escape: true
};
function $507fabe10e71c6fb$var$triggerChangeHandlers(modality, e) {
  for (let handler of $507fabe10e71c6fb$var$changeHandlers) handler(modality, e);
}
function $507fabe10e71c6fb$var$isValidKey(e) {
  return !(e.metaKey || !($c87311424ea30a05$export$9ac100e40613ea10)() && e.altKey || e.ctrlKey || e.key === "Control" || e.key === "Shift" || e.key === "Meta");
}
function $507fabe10e71c6fb$var$handleKeyboardEvent(e) {
  $507fabe10e71c6fb$var$hasEventBeforeFocus = true;
  if (!($ea8dcbcb9ea1b556$export$95185d699e05d4d7).isOpening && $507fabe10e71c6fb$var$isValidKey(e)) {
    $507fabe10e71c6fb$var$currentModality = "keyboard";
    $507fabe10e71c6fb$var$triggerChangeHandlers("keyboard", e);
  }
}
function $507fabe10e71c6fb$var$handlePointerEvent(e) {
  $507fabe10e71c6fb$var$currentModality = "pointer";
  "pointerType" in e ? e.pointerType : "mouse";
  if (e.type === "mousedown" || e.type === "pointerdown") {
    $507fabe10e71c6fb$var$hasEventBeforeFocus = true;
    $507fabe10e71c6fb$var$triggerChangeHandlers("pointer", e);
  }
}
function $507fabe10e71c6fb$var$handleClickEvent(e) {
  if (!($ea8dcbcb9ea1b556$export$95185d699e05d4d7).isOpening && ($6a7db85432448f7f$export$60278871457622de)(e)) {
    $507fabe10e71c6fb$var$hasEventBeforeFocus = true;
    $507fabe10e71c6fb$var$currentModality = "virtual";
  }
}
function $507fabe10e71c6fb$var$handleFocusEvent(e) {
  if (e.target === window || e.target === document || ($8a9cb279dc87e130$export$fda7da73ab5d4c48) || !e.isTrusted) return;
  if (!$507fabe10e71c6fb$var$hasEventBeforeFocus && !$507fabe10e71c6fb$var$hasBlurredWindowRecently) {
    $507fabe10e71c6fb$var$currentModality = "virtual";
    $507fabe10e71c6fb$var$triggerChangeHandlers("virtual", e);
  }
  $507fabe10e71c6fb$var$hasEventBeforeFocus = false;
  $507fabe10e71c6fb$var$hasBlurredWindowRecently = false;
}
function $507fabe10e71c6fb$var$handleWindowBlur() {
  $507fabe10e71c6fb$var$hasEventBeforeFocus = false;
  $507fabe10e71c6fb$var$hasBlurredWindowRecently = true;
}
function $507fabe10e71c6fb$var$setupGlobalFocusEvents(element) {
  if (typeof window === "undefined" || typeof document === "undefined" || $507fabe10e71c6fb$export$d90243b58daecda7.get(($431fbd86ca7dc216$export$f21a1ffae260145a)(element))) return;
  const windowObject = ($431fbd86ca7dc216$export$f21a1ffae260145a)(element);
  const documentObject = ($431fbd86ca7dc216$export$b204af158042fbac)(element);
  let focus = windowObject.HTMLElement.prototype.focus;
  windowObject.HTMLElement.prototype.focus = function() {
    $507fabe10e71c6fb$var$hasEventBeforeFocus = true;
    focus.apply(this, arguments);
  };
  documentObject.addEventListener("keydown", $507fabe10e71c6fb$var$handleKeyboardEvent, true);
  documentObject.addEventListener("keyup", $507fabe10e71c6fb$var$handleKeyboardEvent, true);
  documentObject.addEventListener("click", $507fabe10e71c6fb$var$handleClickEvent, true);
  windowObject.addEventListener("focus", $507fabe10e71c6fb$var$handleFocusEvent, true);
  windowObject.addEventListener("blur", $507fabe10e71c6fb$var$handleWindowBlur, false);
  if (typeof PointerEvent !== "undefined") {
    documentObject.addEventListener("pointerdown", $507fabe10e71c6fb$var$handlePointerEvent, true);
    documentObject.addEventListener("pointermove", $507fabe10e71c6fb$var$handlePointerEvent, true);
    documentObject.addEventListener("pointerup", $507fabe10e71c6fb$var$handlePointerEvent, true);
  }
  windowObject.addEventListener("beforeunload", () => {
    $507fabe10e71c6fb$var$tearDownWindowFocusTracking(element);
  }, {
    once: true
  });
  $507fabe10e71c6fb$export$d90243b58daecda7.set(windowObject, {
    focus
  });
}
const $507fabe10e71c6fb$var$tearDownWindowFocusTracking = (element, loadListener) => {
  const windowObject = ($431fbd86ca7dc216$export$f21a1ffae260145a)(element);
  const documentObject = ($431fbd86ca7dc216$export$b204af158042fbac)(element);
  if (loadListener) documentObject.removeEventListener("DOMContentLoaded", loadListener);
  if (!$507fabe10e71c6fb$export$d90243b58daecda7.has(windowObject)) return;
  windowObject.HTMLElement.prototype.focus = $507fabe10e71c6fb$export$d90243b58daecda7.get(windowObject).focus;
  documentObject.removeEventListener("keydown", $507fabe10e71c6fb$var$handleKeyboardEvent, true);
  documentObject.removeEventListener("keyup", $507fabe10e71c6fb$var$handleKeyboardEvent, true);
  documentObject.removeEventListener("click", $507fabe10e71c6fb$var$handleClickEvent, true);
  windowObject.removeEventListener("focus", $507fabe10e71c6fb$var$handleFocusEvent, true);
  windowObject.removeEventListener("blur", $507fabe10e71c6fb$var$handleWindowBlur, false);
  if (typeof PointerEvent !== "undefined") {
    documentObject.removeEventListener("pointerdown", $507fabe10e71c6fb$var$handlePointerEvent, true);
    documentObject.removeEventListener("pointermove", $507fabe10e71c6fb$var$handlePointerEvent, true);
    documentObject.removeEventListener("pointerup", $507fabe10e71c6fb$var$handlePointerEvent, true);
  }
  $507fabe10e71c6fb$export$d90243b58daecda7.delete(windowObject);
};
function $507fabe10e71c6fb$export$2f1888112f558a7d(element) {
  const documentObject = ($431fbd86ca7dc216$export$b204af158042fbac)(element);
  let loadListener;
  if (documentObject.readyState !== "loading") $507fabe10e71c6fb$var$setupGlobalFocusEvents(element);
  else {
    loadListener = () => {
      $507fabe10e71c6fb$var$setupGlobalFocusEvents(element);
    };
    documentObject.addEventListener("DOMContentLoaded", loadListener);
  }
  return () => $507fabe10e71c6fb$var$tearDownWindowFocusTracking(element, loadListener);
}
if (typeof document !== "undefined") $507fabe10e71c6fb$export$2f1888112f558a7d();
function $507fabe10e71c6fb$export$b9b3dfddab17db27() {
  return $507fabe10e71c6fb$var$currentModality !== "pointer";
}
const $507fabe10e71c6fb$var$nonTextInputTypes = /* @__PURE__ */ new Set([
  "checkbox",
  "radio",
  "range",
  "color",
  "file",
  "image",
  "button",
  "submit",
  "reset"
]);
function $507fabe10e71c6fb$var$isKeyboardFocusEvent(isTextInput, modality, e) {
  let document1 = ($431fbd86ca7dc216$export$b204af158042fbac)(e === null || e === void 0 ? void 0 : e.target);
  const IHTMLInputElement = typeof window !== "undefined" ? ($431fbd86ca7dc216$export$f21a1ffae260145a)(e === null || e === void 0 ? void 0 : e.target).HTMLInputElement : HTMLInputElement;
  const IHTMLTextAreaElement = typeof window !== "undefined" ? ($431fbd86ca7dc216$export$f21a1ffae260145a)(e === null || e === void 0 ? void 0 : e.target).HTMLTextAreaElement : HTMLTextAreaElement;
  const IHTMLElement = typeof window !== "undefined" ? ($431fbd86ca7dc216$export$f21a1ffae260145a)(e === null || e === void 0 ? void 0 : e.target).HTMLElement : HTMLElement;
  const IKeyboardEvent = typeof window !== "undefined" ? ($431fbd86ca7dc216$export$f21a1ffae260145a)(e === null || e === void 0 ? void 0 : e.target).KeyboardEvent : KeyboardEvent;
  isTextInput = isTextInput || document1.activeElement instanceof IHTMLInputElement && !$507fabe10e71c6fb$var$nonTextInputTypes.has(document1.activeElement.type) || document1.activeElement instanceof IHTMLTextAreaElement || document1.activeElement instanceof IHTMLElement && document1.activeElement.isContentEditable;
  return !(isTextInput && modality === "keyboard" && e instanceof IKeyboardEvent && !$507fabe10e71c6fb$var$FOCUS_VISIBLE_INPUT_KEYS[e.key]);
}
function $507fabe10e71c6fb$export$ec71b4b83ac08ec3(fn, deps, opts) {
  $507fabe10e71c6fb$var$setupGlobalFocusEvents();
  (reactExports.useEffect)(() => {
    let handler = (modality, e) => {
      if (!$507fabe10e71c6fb$var$isKeyboardFocusEvent(!!(opts === null || opts === void 0 ? void 0 : opts.isTextInput), modality, e)) return;
      fn($507fabe10e71c6fb$export$b9b3dfddab17db27());
    };
    $507fabe10e71c6fb$var$changeHandlers.add(handler);
    return () => {
      $507fabe10e71c6fb$var$changeHandlers.delete(handler);
    };
  }, deps);
}

/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ // Portions of the code in this file are based on code from react.
// Original licensing for the following can be found in the
// NOTICE file in the root directory of this source tree.
// See https://github.com/facebook/react/tree/cc7c1aece46a6b69b41958d731e0fd27c94bfc6c/packages/react-interactions



function $a1ea59d68270f0dd$export$f8168d8dd8fd66e6(props) {
    let { isDisabled: isDisabled, onFocus: onFocusProp, onBlur: onBlurProp, onFocusChange: onFocusChange } = props;
    const onBlur = (reactExports.useCallback)((e)=>{
        if (e.target === e.currentTarget) {
            if (onBlurProp) onBlurProp(e);
            if (onFocusChange) onFocusChange(false);
            return true;
        }
    }, [
        onBlurProp,
        onFocusChange
    ]);
    const onSyntheticFocus = ($8a9cb279dc87e130$export$715c682d09d639cc)(onBlur);
    const onFocus = (reactExports.useCallback)((e)=>{
        // Double check that document.activeElement actually matches e.target in case a previously chained
        // focus handler already moved focus somewhere else.
        const ownerDocument = ($431fbd86ca7dc216$export$b204af158042fbac)(e.target);
        const activeElement = ownerDocument ? ($d4ee10de306f2510$export$cd4e5573fbe2b576)(ownerDocument) : ($d4ee10de306f2510$export$cd4e5573fbe2b576)();
        if (e.target === e.currentTarget && activeElement === ($d4ee10de306f2510$export$e58f029f0fbfdb29)(e.nativeEvent)) {
            if (onFocusProp) onFocusProp(e);
            if (onFocusChange) onFocusChange(true);
            onSyntheticFocus(e);
        }
    }, [
        onFocusChange,
        onFocusProp,
        onSyntheticFocus
    ]);
    return {
        focusProps: {
            onFocus: !isDisabled && (onFocusProp || onFocusChange || onBlurProp) ? onFocus : undefined,
            onBlur: !isDisabled && (onBlurProp || onFocusChange) ? onBlur : undefined
        }
    };
}

/*
 * Copyright 2020 Adobe. All rights reserved.
 * This file is licensed to you under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License. You may obtain a copy
 * of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under
 * the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR REPRESENTATIONS
 * OF ANY KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */ // Portions of the code in this file are based on code from react.
// Original licensing for the following can be found in the
// NOTICE file in the root directory of this source tree.
// See https://github.com/facebook/react/tree/cc7c1aece46a6b69b41958d731e0fd27c94bfc6c/packages/react-interactions



function $9ab94262bd0047c7$export$420e68273165f4ec(props) {
    let { isDisabled: isDisabled, onBlurWithin: onBlurWithin, onFocusWithin: onFocusWithin, onFocusWithinChange: onFocusWithinChange } = props;
    let state = (reactExports.useRef)({
        isFocusWithin: false
    });
    let { addGlobalListener: addGlobalListener, removeAllGlobalListeners: removeAllGlobalListeners } = ($03deb23ff14920c4$export$4eaf04e54aa8eed6)();
    let onBlur = (reactExports.useCallback)((e)=>{
        // Ignore events bubbling through portals.
        if (!e.currentTarget.contains(e.target)) return;
        // We don't want to trigger onBlurWithin and then immediately onFocusWithin again
        // when moving focus inside the element. Only trigger if the currentTarget doesn't
        // include the relatedTarget (where focus is moving).
        if (state.current.isFocusWithin && !e.currentTarget.contains(e.relatedTarget)) {
            state.current.isFocusWithin = false;
            removeAllGlobalListeners();
            if (onBlurWithin) onBlurWithin(e);
            if (onFocusWithinChange) onFocusWithinChange(false);
        }
    }, [
        onBlurWithin,
        onFocusWithinChange,
        state,
        removeAllGlobalListeners
    ]);
    let onSyntheticFocus = ($8a9cb279dc87e130$export$715c682d09d639cc)(onBlur);
    let onFocus = (reactExports.useCallback)((e)=>{
        // Ignore events bubbling through portals.
        if (!e.currentTarget.contains(e.target)) return;
        // Double check that document.activeElement actually matches e.target in case a previously chained
        // focus handler already moved focus somewhere else.
        const ownerDocument = ($431fbd86ca7dc216$export$b204af158042fbac)(e.target);
        const activeElement = ($d4ee10de306f2510$export$cd4e5573fbe2b576)(ownerDocument);
        if (!state.current.isFocusWithin && activeElement === ($d4ee10de306f2510$export$e58f029f0fbfdb29)(e.nativeEvent)) {
            if (onFocusWithin) onFocusWithin(e);
            if (onFocusWithinChange) onFocusWithinChange(true);
            state.current.isFocusWithin = true;
            onSyntheticFocus(e);
            // Browsers don't fire blur events when elements are removed from the DOM.
            // However, if a focus event occurs outside the element we're tracking, we
            // can manually fire onBlur.
            let currentTarget = e.currentTarget;
            addGlobalListener(ownerDocument, 'focus', (e)=>{
                if (state.current.isFocusWithin && !($d4ee10de306f2510$export$4282f70798064fe0)(currentTarget, e.target)) {
                    let nativeEvent = new ownerDocument.defaultView.FocusEvent('blur', {
                        relatedTarget: e.target
                    });
                    ($8a9cb279dc87e130$export$c2b7abe5d61ec696)(nativeEvent, currentTarget);
                    let event = ($8a9cb279dc87e130$export$525bc4921d56d4a)(nativeEvent);
                    onBlur(event);
                }
            }, {
                capture: true
            });
        }
    }, [
        onFocusWithin,
        onFocusWithinChange,
        onSyntheticFocus,
        addGlobalListener,
        onBlur
    ]);
    if (isDisabled) return {
        focusWithinProps: {
            // These cannot be null, that would conflict in mergeProps
            onFocus: undefined,
            onBlur: undefined
        }
    };
    return {
        focusWithinProps: {
            onFocus: onFocus,
            onBlur: onBlur
        }
    };
}

let $6179b936705e76d3$var$globalIgnoreEmulatedMouseEvents = false;
let $6179b936705e76d3$var$hoverCount = 0;
function $6179b936705e76d3$var$setGlobalIgnoreEmulatedMouseEvents() {
  $6179b936705e76d3$var$globalIgnoreEmulatedMouseEvents = true;
  setTimeout(() => {
    $6179b936705e76d3$var$globalIgnoreEmulatedMouseEvents = false;
  }, 50);
}
function $6179b936705e76d3$var$handleGlobalPointerEvent(e) {
  if (e.pointerType === "touch") $6179b936705e76d3$var$setGlobalIgnoreEmulatedMouseEvents();
}
function $6179b936705e76d3$var$setupGlobalTouchEvents() {
  if (typeof document === "undefined") return;
  if ($6179b936705e76d3$var$hoverCount === 0) {
    if (typeof PointerEvent !== "undefined") document.addEventListener("pointerup", $6179b936705e76d3$var$handleGlobalPointerEvent);
  }
  $6179b936705e76d3$var$hoverCount++;
  return () => {
    $6179b936705e76d3$var$hoverCount--;
    if ($6179b936705e76d3$var$hoverCount > 0) return;
    if (typeof PointerEvent !== "undefined") document.removeEventListener("pointerup", $6179b936705e76d3$var$handleGlobalPointerEvent);
  };
}
function $6179b936705e76d3$export$ae780daf29e6d456(props) {
  let { onHoverStart, onHoverChange, onHoverEnd, isDisabled } = props;
  let [isHovered, setHovered] = (reactExports.useState)(false);
  let state = (reactExports.useRef)({
    isHovered: false,
    ignoreEmulatedMouseEvents: false,
    pointerType: "",
    target: null
  }).current;
  (reactExports.useEffect)($6179b936705e76d3$var$setupGlobalTouchEvents, []);
  let { addGlobalListener, removeAllGlobalListeners } = ($03deb23ff14920c4$export$4eaf04e54aa8eed6)();
  let { hoverProps, triggerHoverEnd } = (reactExports.useMemo)(() => {
    let triggerHoverStart = (event, pointerType) => {
      state.pointerType = pointerType;
      if (isDisabled || pointerType === "touch" || state.isHovered || !event.currentTarget.contains(event.target)) return;
      state.isHovered = true;
      let target = event.currentTarget;
      state.target = target;
      addGlobalListener(($431fbd86ca7dc216$export$b204af158042fbac)(event.target), "pointerover", (e) => {
        if (state.isHovered && state.target && !($d4ee10de306f2510$export$4282f70798064fe0)(state.target, e.target)) triggerHoverEnd2(e, e.pointerType);
      }, {
        capture: true
      });
      if (onHoverStart) onHoverStart({
        type: "hoverstart",
        target,
        pointerType
      });
      if (onHoverChange) onHoverChange(true);
      setHovered(true);
    };
    let triggerHoverEnd2 = (event, pointerType) => {
      let target = state.target;
      state.pointerType = "";
      state.target = null;
      if (pointerType === "touch" || !state.isHovered || !target) return;
      state.isHovered = false;
      removeAllGlobalListeners();
      if (onHoverEnd) onHoverEnd({
        type: "hoverend",
        target,
        pointerType
      });
      if (onHoverChange) onHoverChange(false);
      setHovered(false);
    };
    let hoverProps2 = {};
    if (typeof PointerEvent !== "undefined") {
      hoverProps2.onPointerEnter = (e) => {
        if ($6179b936705e76d3$var$globalIgnoreEmulatedMouseEvents && e.pointerType === "mouse") return;
        triggerHoverStart(e, e.pointerType);
      };
      hoverProps2.onPointerLeave = (e) => {
        if (!isDisabled && e.currentTarget.contains(e.target)) triggerHoverEnd2(e, e.pointerType);
      };
    }
    return {
      hoverProps: hoverProps2,
      triggerHoverEnd: triggerHoverEnd2
    };
  }, [
    onHoverStart,
    onHoverChange,
    onHoverEnd,
    isDisabled,
    state,
    addGlobalListener,
    removeAllGlobalListeners
  ]);
  (reactExports.useEffect)(() => {
    if (isDisabled) triggerHoverEnd({
      currentTarget: state.target
    }, state.pointerType);
  }, [
    isDisabled
  ]);
  return {
    hoverProps,
    isHovered
  };
}

function $f7dceffc5ad7768b$export$4e328f61c538687f(props = {}) {
    let { autoFocus: autoFocus = false, isTextInput: isTextInput, within: within } = props;
    let state = (reactExports.useRef)({
        isFocused: false,
        isFocusVisible: autoFocus || ($507fabe10e71c6fb$export$b9b3dfddab17db27)()
    });
    let [isFocused, setFocused] = (reactExports.useState)(false);
    let [isFocusVisibleState, setFocusVisible] = (reactExports.useState)(()=>state.current.isFocused && state.current.isFocusVisible);
    let updateState = (reactExports.useCallback)(()=>setFocusVisible(state.current.isFocused && state.current.isFocusVisible), []);
    let onFocusChange = (reactExports.useCallback)((isFocused)=>{
        state.current.isFocused = isFocused;
        setFocused(isFocused);
        updateState();
    }, [
        updateState
    ]);
    ($507fabe10e71c6fb$export$ec71b4b83ac08ec3)((isFocusVisible)=>{
        state.current.isFocusVisible = isFocusVisible;
        updateState();
    }, [], {
        isTextInput: isTextInput
    });
    let { focusProps: focusProps } = ($a1ea59d68270f0dd$export$f8168d8dd8fd66e6)({
        isDisabled: within,
        onFocusChange: onFocusChange
    });
    let { focusWithinProps: focusWithinProps } = ($9ab94262bd0047c7$export$420e68273165f4ec)({
        isDisabled: !within,
        onFocusWithinChange: onFocusChange
    });
    return {
        isFocused: isFocused,
        isFocusVisible: isFocusVisibleState,
        focusProps: within ? focusWithinProps : focusProps
    };
}

var i=Object.defineProperty;var d=(t,e,n)=>e in t?i(t,e,{enumerable:true,configurable:true,writable:true,value:n}):t[e]=n;var r$1=(t,e,n)=>(d(t,typeof e!="symbol"?e+"":e,n),n);let o$3 = class o{constructor(){r$1(this,"current",this.detect());r$1(this,"handoffState","pending");r$1(this,"currentId",0);}set(e){this.current!==e&&(this.handoffState="pending",this.currentId=0,this.current=e);}reset(){this.set(this.detect());}nextId(){return ++this.currentId}get isServer(){return this.current==="server"}get isClient(){return this.current==="client"}detect(){return typeof window=="undefined"||typeof document=="undefined"?"server":"client"}handoff(){this.handoffState==="pending"&&(this.handoffState="complete");}get isHandoffComplete(){return this.handoffState==="complete"}};let s$3=new o$3;

function l$1(n){var u;return s$3.isServer?null:n==null?document:(u=n==null?void 0:n.ownerDocument)!=null?u:document}function r(n){var u,o;return s$3.isServer?null:n==null?document:(o=(u=n==null?void 0:n.getRootNode)==null?void 0:u.call(n))!=null?o:document}function e$1(n){var u,o;return (o=(u=r(n))==null?void 0:u.activeElement)!=null?o:null}

function t$2(e){typeof queueMicrotask=="function"?queueMicrotask(e):Promise.resolve().then(e).catch(o=>setTimeout(()=>{throw o}));}

function o$2(){let s=[],r={addEventListener(e,t,n,i){return e.addEventListener(t,n,i),r.add(()=>e.removeEventListener(t,n,i))},requestAnimationFrame(...e){let t=requestAnimationFrame(...e);return r.add(()=>cancelAnimationFrame(t))},nextFrame(...e){return r.requestAnimationFrame(()=>r.requestAnimationFrame(...e))},setTimeout(...e){let t=setTimeout(...e);return r.add(()=>clearTimeout(t))},microTask(...e){let t={current:true};return t$2(()=>{t.current&&e[0]();}),r.add(()=>{t.current=false;})},style(e,t,n){let i=e.style.getPropertyValue(t);return Object.assign(e.style,{[t]:n}),this.add(()=>{Object.assign(e.style,{[t]:i});})},group(e){let t=o$2();return e(t),this.add(()=>t.dispose())},add(e){return s.includes(e)||s.push(e),()=>{let t=s.indexOf(e);if(t>=0)for(let n of s.splice(t,1))n();}},dispose(){for(let e of s.splice(0))e();}};return r}

function p(){let[e]=reactExports.useState(o$2);return reactExports.useEffect(()=>()=>e.dispose(),[e]),e}

let n$1=(e,t)=>{s$3.isServer?reactExports.useEffect(e,t):reactExports.useLayoutEffect(e,t);};

function s$2(e){let r=reactExports.useRef(e);return n$1(()=>{r.current=e;},[e]),r}

let o$1=function(t){let e=s$2(t);return React.useCallback((...r)=>e.current(...r),[e])};

function E$1(e){let t=e.width/2,n=e.height/2;return {top:e.clientY-n,right:e.clientX+t,bottom:e.clientY+n,left:e.clientX-t}}function P$2(e,t){return !(!e||!t||e.right<t.left||e.left>t.right||e.bottom<t.top||e.top>t.bottom)}function w({disabled:e=false}={}){let t=reactExports.useRef(null),[n,l]=reactExports.useState(false),r=p(),o=o$1(()=>{t.current=null,l(false),r.dispose();}),f=o$1(s=>{if(r.dispose(),t.current===null){t.current=s.currentTarget,l(true);{let i=l$1(s.currentTarget);r.addEventListener(i,"pointerup",o,false),r.addEventListener(i,"pointermove",c=>{if(t.current){let p=E$1(c);l(P$2(p,t.current.getBoundingClientRect()));}},false),r.addEventListener(i,"pointercancel",o,false);}}});return {pressed:n,pressProps:e?{}:{onPointerDown:f,onPointerUp:o,onClick:o}}}

function n(e){return reactExports.useMemo(()=>e,Object.values(e))}

function t$1(...r){return Array.from(new Set(r.flatMap(n=>typeof n=="string"?n.split(" "):[]))).filter(Boolean).join(" ")}

function u$1(r,n,...a){if(r in n){let e=n[r];return typeof e=="function"?e(...a):e}let t=new Error(`Tried to handle "${r}" but there is no handler defined. Only defined handlers are: ${Object.keys(n).map(e=>`"${e}"`).join(", ")}.`);throw Error.captureStackTrace&&Error.captureStackTrace(t,u$1),t}

var A$1=(a=>(a[a.None=0]="None",a[a.RenderStrategy=1]="RenderStrategy",a[a.Static=2]="Static",a))(A$1||{}),C$1=(e=>(e[e.Unmount=0]="Unmount",e[e.Hidden=1]="Hidden",e))(C$1||{});function K(){let n=$();return reactExports.useCallback(r=>U({mergeRefs:n,...r}),[n])}function U({ourProps:n,theirProps:r,slot:e,defaultTag:a,features:s,visible:t=true,name:l,mergeRefs:i}){i=i!=null?i:I$1;let o=P$1(r,n);if(t)return F(o,e,a,l,i);let y=s!=null?s:0;if(y&2){let{static:f=false,...u}=o;if(f)return F(u,e,a,l,i)}if(y&1){let{unmount:f=true,...u}=o;return u$1(f?0:1,{[0](){return null},[1](){return F({...u,hidden:true,style:{display:"none"}},e,a,l,i)}})}return F(o,e,a,l,i)}function F(n,r={},e,a,s){let{as:t=e,children:l,refName:i="ref",...o}=h$2(n,["unmount","static"]),y=n.ref!==void 0?{[i]:n.ref}:{},f=typeof l=="function"?l(r):l;"className"in o&&o.className&&typeof o.className=="function"&&(o.className=o.className(r)),o["aria-labelledby"]&&o["aria-labelledby"]===o.id&&(o["aria-labelledby"]=void 0);let u={};if(r){let d=false,p=[];for(let[c,T]of Object.entries(r))typeof T=="boolean"&&(d=true),T===true&&p.push(c.replace(/([A-Z])/g,g=>`-${g.toLowerCase()}`));if(d){u["data-headlessui-state"]=p.join(" ");for(let c of p)u[`data-${c}`]="";}}if(b$1(t)&&(Object.keys(m(o)).length>0||Object.keys(m(u)).length>0))if(!reactExports.isValidElement(f)||Array.isArray(f)&&f.length>1||D(f)){if(Object.keys(m(o)).length>0)throw new Error(['Passing props on "Fragment"!',"",`The current component <${a} /> is rendering a "Fragment".`,"However we need to passthrough the following props:",Object.keys(m(o)).concat(Object.keys(m(u))).map(d=>`  - ${d}`).join(`
`),"","You can apply a few solutions:",['Add an `as="..."` prop, to ensure that we render an actual element instead of a "Fragment".',"Render a single element as the child so that we can forward the props onto that element."].map(d=>`  - ${d}`).join(`
`)].join(`
`))}else {let d=f.props,p=d==null?void 0:d.className,c=typeof p=="function"?(...R)=>t$1(p(...R),o.className):t$1(p,o.className),T=c?{className:c}:{},g=P$1(f.props,m(h$2(o,["ref"])));for(let R in u)R in g&&delete u[R];return reactExports.cloneElement(f,Object.assign({},g,u,y,{ref:s(H(f),y.ref)},T))}return reactExports.createElement(t,Object.assign({},h$2(o,["ref"]),!b$1(t)&&y,!b$1(t)&&u),f)}function $(){let n=reactExports.useRef([]),r=reactExports.useCallback(e=>{for(let a of n.current)a!=null&&(typeof a=="function"?a(e):a.current=e);},[]);return (...e)=>{if(!e.every(a=>a==null))return n.current=e,r}}function I$1(...n){return n.every(r=>r==null)?void 0:r=>{for(let e of n)e!=null&&(typeof e=="function"?e(r):e.current=r);}}function P$1(...n){if(n.length===0)return {};if(n.length===1)return n[0];let r={},e={};for(let s of n)for(let t in s)t.startsWith("on")&&typeof s[t]=="function"?((e[t])!=null||(e[t]=[]),e[t].push(s[t])):r[t]=s[t];if(r.disabled||r["aria-disabled"])for(let s in e)/^(on(?:Click|Pointer|Mouse|Key)(?:Down|Up|Press)?)$/.test(s)&&(e[s]=[t=>{var l;return (l=t==null?void 0:t.preventDefault)==null?void 0:l.call(t)}]);for(let s in e)Object.assign(r,{[s](t,...l){let i=e[s];for(let o of i){if((t instanceof Event||(t==null?void 0:t.nativeEvent)instanceof Event)&&t.defaultPrevented)return;o(t,...l);}}});return r}function V$1(...n){if(n.length===0)return {};if(n.length===1)return n[0];let r={},e={};for(let s of n)for(let t in s)t.startsWith("on")&&typeof s[t]=="function"?((e[t])!=null||(e[t]=[]),e[t].push(s[t])):r[t]=s[t];for(let s in e)Object.assign(r,{[s](...t){let l=e[s];for(let i of l)i==null||i(...t);}});return r}function Y(n){var r;return Object.assign(reactExports.forwardRef(n),{displayName:(r=n.displayName)!=null?r:n.name})}function m(n){let r=Object.assign({},n);for(let e in r)r[e]===void 0&&delete r[e];return r}function h$2(n,r=[]){let e=Object.assign({},n);for(let a of r)a in e&&delete e[a];return e}function H(n){return React.version.split(".")[0]>="19"?n.props.ref:n.ref}function b$1(n){return n===reactExports.Fragment||n===Symbol.for("react.fragment")}function D(n){return b$1(n.type)}

let a$1="span";var s$1=(e=>(e[e.None=1]="None",e[e.Focusable=2]="Focusable",e[e.Hidden=4]="Hidden",e))(s$1||{});function l(t,r){var n;let{features:d=1,...e}=t,o={ref:r,"aria-hidden":(d&2)===2?true:(n=e["aria-hidden"])!=null?n:void 0,hidden:(d&4)===4?true:void 0,style:{position:"fixed",top:1,left:1,width:1,height:0,padding:0,margin:-1,overflow:"hidden",clip:"rect(0, 0, 0, 0)",whiteSpace:"nowrap",borderWidth:"0",...(d&4)===4&&(d&2)!==2&&{display:"none"}}};return K()({ourProps:o,theirProps:e,slot:{},defaultTag:a$1,name:"Hidden"})}let f$2=Y(l);

let u=Symbol();function y(...t){let n=reactExports.useRef(t);reactExports.useEffect(()=>{n.current=t;},[t]);let c=o$1(e=>{for(let o of n.current)o!=null&&(typeof o=="function"?o(e):o.current=e);});return t.every(e=>e==null||(e==null?void 0:e[u]))?void 0:c}

var o=(r=>(r.Space=" ",r.Enter="Enter",r.Escape="Escape",r.Backspace="Backspace",r.Delete="Delete",r.ArrowLeft="ArrowLeft",r.ArrowUp="ArrowUp",r.ArrowRight="ArrowRight",r.ArrowDown="ArrowDown",r.Home="Home",r.End="End",r.PageUp="PageUp",r.PageDown="PageDown",r.Tab="Tab",r))(o||{});

let E=["[contentEditable=true]","[tabindex]","a[href]","area[href]","button:not([disabled])","iframe","input:not([disabled])","select:not([disabled])","details>summary","textarea:not([disabled])"].map(e=>`${e}:not([tabindex='-1'])`).join(","),S=["[data-autofocus]"].map(e=>`${e}:not([tabindex='-1'])`).join(",");var T=(o=>(o[o.First=1]="First",o[o.Previous=2]="Previous",o[o.Next=4]="Next",o[o.Last=8]="Last",o[o.WrapAround=16]="WrapAround",o[o.NoScroll=32]="NoScroll",o[o.AutoFocus=64]="AutoFocus",o))(T||{}),A=(n=>(n[n.Error=0]="Error",n[n.Overflow=1]="Overflow",n[n.Success=2]="Success",n[n.Underflow=3]="Underflow",n))(A||{}),O=(t=>(t[t.Previous=-1]="Previous",t[t.Next=1]="Next",t))(O||{});function x(e=document.body){return e==null?[]:Array.from(e.querySelectorAll(E)).sort((r,t)=>Math.sign((r.tabIndex||Number.MAX_SAFE_INTEGER)-(t.tabIndex||Number.MAX_SAFE_INTEGER)))}function h$1(e=document.body){return e==null?[]:Array.from(e.querySelectorAll(S)).sort((r,t)=>Math.sign((r.tabIndex||Number.MAX_SAFE_INTEGER)-(t.tabIndex||Number.MAX_SAFE_INTEGER)))}var I=(t=>(t[t.Strict=0]="Strict",t[t.Loose=1]="Loose",t))(I||{});var g=(t=>(t[t.Keyboard=0]="Keyboard",t[t.Mouse=1]="Mouse",t))(g||{});typeof window!="undefined"&&typeof document!="undefined"&&(document.addEventListener("keydown",e=>{e.metaKey||e.altKey||e.ctrlKey||(document.documentElement.dataset.headlessuiFocusVisible="");},true),document.addEventListener("click",e=>{e.detail===1?delete document.documentElement.dataset.headlessuiFocusVisible:e.detail===0&&(document.documentElement.dataset.headlessuiFocusVisible="");},true));let _=["textarea","input"].join(",");function P(e){var r,t;return (t=(r=e==null?void 0:e.matches)==null?void 0:r.call(e,_))!=null?t:false}function G(e,r=t=>t){return e.slice().sort((t,l)=>{let n=r(t),a=r(l);if(n===null||a===null)return 0;let u=n.compareDocumentPosition(a);return u&Node.DOCUMENT_POSITION_FOLLOWING?-1:u&Node.DOCUMENT_POSITION_PRECEDING?1:0})}function v(e,r$1,{sorted:t=true,relativeTo:l=null,skipElements:n=[]}={}){let a=Array.isArray(e)?e.length>0?r(e[0]):document:r(e),u=Array.isArray(e)?t?G(e):e:r$1&64?h$1(e):x(e);n.length>0&&u.length>1&&(u=u.filter(i=>!n.some(d=>d!=null&&"current"in d?(d==null?void 0:d.current)===i:d===i))),l=l!=null?l:a==null?void 0:a.activeElement;let o=(()=>{if(r$1&5)return 1;if(r$1&10)return  -1;throw new Error("Missing Focus.First, Focus.Previous, Focus.Next or Focus.Last")})(),M=(()=>{if(r$1&1)return 0;if(r$1&2)return Math.max(0,u.indexOf(l))-1;if(r$1&4)return Math.max(0,u.indexOf(l))+1;if(r$1&8)return u.length-1;throw new Error("Missing Focus.First, Focus.Previous, Focus.Next or Focus.Last")})(),N=r$1&32?{preventScroll:true}:{},m=0,c=u.length,s;do{if(m>=c||m+c<=0)return 0;let i=M+m;if(r$1&16)i=(i+c)%c;else {if(i<0)return 3;if(i>=c)return 1}s=u[i],s==null||s.focus(N),m+=o;}while(s!==e$1(s));return r$1&6&&P(s)&&s.select(),2}

function e(t,u){return reactExports.useMemo(()=>{var n;if(t.type)return t.type;let r=(n=t.as)!=null?n:"button";if(typeof r=="string"&&r.toLowerCase()==="button"||(u==null?void 0:u.tagName)==="BUTTON"&&!u.hasAttribute("type"))return "button"},[t.type,t.as,u])}

function f$1(){let e=reactExports.useRef(false);return n$1(()=>(e.current=true,()=>{e.current=false;}),[]),e}

function b({onFocus:n}){let[r,o]=reactExports.useState(true),u=f$1();return r?React.createElement(f$2,{as:"button",type:"button",features:s$1.Focusable,onFocus:a=>{a.preventDefault();let e,i=50;function t(){if(i--<=0){e&&cancelAnimationFrame(e);return}if(n()){if(cancelAnimationFrame(e),!u.current)return;o(false);return}e=requestAnimationFrame(t);}e=requestAnimationFrame(t);}}):null}

const s=reactExports.createContext(null);function a(){return {groups:new Map,get(o,e){var i;let t=this.groups.get(o);t||(t=new Map,this.groups.set(o,t));let n=(i=t.get(e))!=null?i:0;t.set(e,n+1);let r=Array.from(t.keys()).indexOf(e);function u(){let c=t.get(e);c>1?t.set(e,c-1):t.delete(e);}return [r,u]}}}function f({children:o}){let e=reactExports.useRef(a());return reactExports.createElement(s.Provider,{value:e},o)}function C(o){let e=reactExports.useContext(s);if(!e)throw new Error("You must wrap your component in a <StableCollection>");let t=reactExports.useId(),[n,r]=e.current.get(o,t);return reactExports.useEffect(()=>r,[]),n}

var Le=(t=>(t[t.Forwards=0]="Forwards",t[t.Backwards=1]="Backwards",t))(Le||{}),_e=(l=>(l[l.Less=-1]="Less",l[l.Equal=0]="Equal",l[l.Greater=1]="Greater",l))(_e||{}),Se=(n=>(n[n.SetSelectedIndex=0]="SetSelectedIndex",n[n.RegisterTab=1]="RegisterTab",n[n.UnregisterTab=2]="UnregisterTab",n[n.RegisterPanel=3]="RegisterPanel",n[n.UnregisterPanel=4]="UnregisterPanel",n))(Se||{});let De={[0](e,r){var d;let t=G(e.tabs,u=>u.current),l=G(e.panels,u=>u.current),a=t.filter(u=>{var T;return !((T=u.current)!=null&&T.hasAttribute("disabled"))}),n={...e,tabs:t,panels:l};if(r.index<0||r.index>t.length-1){let u=u$1(Math.sign(r.index-e.selectedIndex),{[-1]:()=>1,[0]:()=>u$1(Math.sign(r.index),{[-1]:()=>0,[0]:()=>0,[1]:()=>1}),[1]:()=>0});if(a.length===0)return n;let T=u$1(u,{[0]:()=>t.indexOf(a[0]),[1]:()=>t.indexOf(a[a.length-1])});return {...n,selectedIndex:T===-1?e.selectedIndex:T}}let s=t.slice(0,r.index),f=[...t.slice(r.index),...s].find(u=>a.includes(u));if(!f)return n;let b=(d=t.indexOf(f))!=null?d:e.selectedIndex;return b===-1&&(b=e.selectedIndex),{...n,selectedIndex:b}},[1](e,r){if(e.tabs.includes(r.tab))return e;let t=e.tabs[e.selectedIndex],l=G([...e.tabs,r.tab],n=>n.current),a=e.selectedIndex;return e.info.current.isControlled||(a=l.indexOf(t),a===-1&&(a=e.selectedIndex)),{...e,tabs:l,selectedIndex:a}},[2](e,r){return {...e,tabs:e.tabs.filter(t=>t!==r.tab)}},[3](e,r){return e.panels.includes(r.panel)?e:{...e,panels:G([...e.panels,r.panel],t=>t.current)}},[4](e,r){return {...e,panels:e.panels.filter(t=>t!==r.panel)}}},z=reactExports.createContext(null);z.displayName="TabsDataContext";function h(e){let r=reactExports.useContext(z);if(r===null){let t=new Error(`<${e} /> is missing a parent <Tab.Group /> component.`);throw Error.captureStackTrace&&Error.captureStackTrace(t,h),t}return r}let V=reactExports.createContext(null);V.displayName="TabsActionsContext";function Q(e){let r=reactExports.useContext(V);if(r===null){let t=new Error(`<${e} /> is missing a parent <Tab.Group /> component.`);throw Error.captureStackTrace&&Error.captureStackTrace(t,Q),t}return r}function Fe(e,r){return u$1(r.type,De,e,r)}let Ie="div";function he(e,r){let{defaultIndex:t=0,vertical:l=false,manual:a=false,onChange:n$2,selectedIndex:s=null,...g}=e;const f$1=l?"vertical":"horizontal",b$1=a?"manual":"auto";let d=s!==null,u=s$2({isControlled:d}),T=y(r),[p,c]=reactExports.useReducer(Fe,{info:u,selectedIndex:s!=null?s:t,tabs:[],panels:[]}),v=n({selectedIndex:p.selectedIndex}),m=s$2(n$2||(()=>{})),C=s$2(p.tabs),D=reactExports.useMemo(()=>({orientation:f$1,activation:b$1,...p}),[f$1,b$1,p]),P=o$1(i=>(c({type:1,tab:i}),()=>c({type:2,tab:i}))),R=o$1(i=>(c({type:3,panel:i}),()=>c({type:4,panel:i}))),A=o$1(i=>{L.current!==i&&m.current(i),d||c({type:0,index:i});}),L=s$2(d?e.selectedIndex:p.selectedIndex),_=reactExports.useMemo(()=>({registerTab:P,registerPanel:R,change:A}),[]);n$1(()=>{c({type:0,index:s!=null?s:t});},[s]),n$1(()=>{if(L.current===void 0||p.tabs.length<=0)return;let i=G(p.tabs,S=>S.current);i.some((S,$)=>p.tabs[$]!==S)&&A(i.indexOf(p.tabs[L.current]));});let J={ref:T},X=K();return React.createElement(f,null,React.createElement(V.Provider,{value:_},React.createElement(z.Provider,{value:D},D.tabs.length<=0&&React.createElement(b,{onFocus:()=>{var i,M;for(let S of C.current)if(((i=S.current)==null?void 0:i.tabIndex)===0)return (M=S.current)==null||M.focus(),true;return  false}}),X({ourProps:J,theirProps:g,slot:v,defaultTag:Ie,name:"Tabs"}))))}let ve="div";function Ce(e,r){let{orientation:t,selectedIndex:l}=h("Tab.List"),a=y(r),n$1=n({selectedIndex:l}),s=e,g={ref:a,role:"tablist","aria-orientation":t};return K()({ourProps:g,theirProps:s,slot:n$1,defaultTag:ve,name:"Tabs.List"})}let Me="button";function Ge(e$2,r){var Y,Z;let t=reactExports.useId(),{id:l=`headlessui-tabs-tab-${t}`,disabled:a=false,autoFocus:n$2=false,...s}=e$2,{orientation:g,activation:f,selectedIndex:b,tabs:d,panels:u}=h("Tab"),T$1=Q("Tab"),p=h("Tab"),[c,v$1]=reactExports.useState(null),m=reactExports.useRef(null),C$1=y(m,r,v$1);n$1(()=>T$1.registerTab(m),[T$1,m]);let D=C("tabs"),P=d.indexOf(m);P===-1&&(P=D);let R=P===b,A$1=o$1(o=>{let E=o();if(E===A.Success&&f==="auto"){let ee=e$1(m.current),B=p.tabs.findIndex(ce=>ce.current===ee);B!==-1&&T$1.change(B);}return E}),L=o$1(o$1=>{let E=d.map(B=>B.current).filter(Boolean);if(o$1.key===o.Space||o$1.key===o.Enter){o$1.preventDefault(),o$1.stopPropagation(),T$1.change(P);return}switch(o$1.key){case o.Home:case o.PageUp:return o$1.preventDefault(),o$1.stopPropagation(),A$1(()=>v(E,T.First));case o.End:case o.PageDown:return o$1.preventDefault(),o$1.stopPropagation(),A$1(()=>v(E,T.Last))}if(A$1(()=>u$1(g,{vertical(){return o$1.key===o.ArrowUp?v(E,T.Previous|T.WrapAround):o$1.key===o.ArrowDown?v(E,T.Next|T.WrapAround):A.Error},horizontal(){return o$1.key===o.ArrowLeft?v(E,T.Previous|T.WrapAround):o$1.key===o.ArrowRight?v(E,T.Next|T.WrapAround):A.Error}}))===A.Success)return o$1.preventDefault()}),_=reactExports.useRef(false),J=o$1(()=>{var o;_.current||(_.current=true,(o=m.current)==null||o.focus({preventScroll:true}),T$1.change(P),t$2(()=>{_.current=false;}));}),X=o$1(o=>{o.preventDefault();}),{isFocusVisible:i,focusProps:M}=$f7dceffc5ad7768b$export$4e328f61c538687f({autoFocus:n$2}),{isHovered:S,hoverProps:$}=$6179b936705e76d3$export$ae780daf29e6d456({isDisabled:a}),{pressed:pe,pressProps:ue}=w({disabled:a}),Te=n({selected:R,hover:S,active:pe,focus:i,autofocus:n$2,disabled:a}),de=V$1({ref:C$1,onKeyDown:L,onMouseDown:X,onClick:J,id:l,role:"tab",type:e(e$2,c),"aria-controls":(Z=(Y=u[P])==null?void 0:Y.current)==null?void 0:Z.id,"aria-selected":R,tabIndex:R?0:-1,disabled:a||void 0,autoFocus:n$2},M,$,ue);return K()({ourProps:de,theirProps:s,slot:Te,defaultTag:Me,name:"Tabs.Tab"})}let Ue="div";function He(e,r){let{selectedIndex:t}=h("Tab.Panels"),l=y(r),a=n({selectedIndex:t}),n$1=e,s={ref:l};return K()({ourProps:s,theirProps:n$1,slot:a,defaultTag:Ue,name:"Tabs.Panels"})}let we="div",Oe=A$1.RenderStrategy|A$1.Static;function Ne(e,r){var R,A,L,_;let t=reactExports.useId(),{id:l=`headlessui-tabs-panel-${t}`,tabIndex:a=0,...n$2}=e,{selectedIndex:s,tabs:g,panels:f}=h("Tab.Panel"),b=Q("Tab.Panel"),d=reactExports.useRef(null),u=y(d,r);n$1(()=>b.registerPanel(d),[b,d]);let T=C("panels"),p=f.indexOf(d);p===-1&&(p=T);let c=p===s,{isFocusVisible:v,focusProps:m}=$f7dceffc5ad7768b$export$4e328f61c538687f(),C$1=n({selected:c,focus:v}),D=V$1({ref:u,id:l,role:"tabpanel","aria-labelledby":(A=(R=g[p])==null?void 0:R.current)==null?void 0:A.id,tabIndex:c?a:-1},m),P=K();return !c&&((L=n$2.unmount)==null||L)&&!((_=n$2.static)!=null&&_)?React.createElement(f$2,{"aria-hidden":"true",...D}):P({ourProps:D,theirProps:n$2,slot:C$1,defaultTag:we,features:Oe,visible:c,name:"Tabs.Panel"})}let ke=Y(Ge),Be=Y(he),We=Y(Ce),je=Y(He),Ke=Y(Ne),dt=Object.assign(ke,{Group:Be,List:We,Panels:je,Panel:Ke});

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

const toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
const toCamelCase = (string) => string.replace(
  /^([A-Z])|[\s-_]+(\w)/g,
  (match, p1, p2) => p2 ? p2.toUpperCase() : p1.toLowerCase()
);
const toPascalCase = (string) => {
  const camelCase = toCamelCase(string);
  return camelCase.charAt(0).toUpperCase() + camelCase.slice(1);
};
const mergeClasses = (...classes) => classes.filter((className, index, array) => {
  return Boolean(className) && className.trim() !== "" && array.indexOf(className) === index;
}).join(" ").trim();
const hasA11yProp = (props) => {
  for (const prop in props) {
    if (prop.startsWith("aria-") || prop === "role" || prop === "title") {
      return true;
    }
  }
};

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */

var defaultAttributes = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round"
};

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Icon = reactExports.forwardRef(
  ({
    color = "currentColor",
    size = 24,
    strokeWidth = 2,
    absoluteStrokeWidth,
    className = "",
    children,
    iconNode,
    ...rest
  }, ref) => reactExports.createElement(
    "svg",
    {
      ref,
      ...defaultAttributes,
      width: size,
      height: size,
      stroke: color,
      strokeWidth: absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size) : strokeWidth,
      className: mergeClasses("lucide", className),
      ...!children && !hasA11yProp(rest) && { "aria-hidden": "true" },
      ...rest
    },
    [
      ...iconNode.map(([tag, attrs]) => reactExports.createElement(tag, attrs)),
      ...Array.isArray(children) ? children : [children]
    ]
  )
);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const createLucideIcon = (iconName, iconNode) => {
  const Component = reactExports.forwardRef(
    ({ className, ...props }, ref) => reactExports.createElement(Icon, {
      ref,
      iconNode,
      className: mergeClasses(
        `lucide-${toKebabCase(toPascalCase(iconName))}`,
        `lucide-${iconName}`,
        className
      ),
      ...props
    })
  );
  Component.displayName = toPascalCase(iconName);
  return Component;
};

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$O = [
  [
    "path",
    {
      d: "M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",
      key: "169zse"
    }
  ]
];
const Activity = createLucideIcon("activity", __iconNode$O);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$N = [
  ["path", { d: "m12 19-7-7 7-7", key: "1l729n" }],
  ["path", { d: "M19 12H5", key: "x3x0zl" }]
];
const ArrowLeft = createLucideIcon("arrow-left", __iconNode$N);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$M = [
  ["path", { d: "M5 12h14", key: "1ays0h" }],
  ["path", { d: "m12 5 7 7-7 7", key: "xquz4c" }]
];
const ArrowRight = createLucideIcon("arrow-right", __iconNode$M);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$L = [
  ["path", { d: "M12 8V4H8", key: "hb8ula" }],
  ["rect", { width: "16", height: "12", x: "4", y: "8", rx: "2", key: "enze0r" }],
  ["path", { d: "M2 14h2", key: "vft8re" }],
  ["path", { d: "M20 14h2", key: "4cs60a" }],
  ["path", { d: "M15 13v2", key: "1xurst" }],
  ["path", { d: "M9 13v2", key: "rq6x2g" }]
];
const Bot = createLucideIcon("bot", __iconNode$L);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$K = [
  ["path", { d: "M12 18V5", key: "adv99a" }],
  ["path", { d: "M15 13a4.17 4.17 0 0 1-3-4 4.17 4.17 0 0 1-3 4", key: "1e3is1" }],
  ["path", { d: "M17.598 6.5A3 3 0 1 0 12 5a3 3 0 1 0-5.598 1.5", key: "1gqd8o" }],
  ["path", { d: "M17.997 5.125a4 4 0 0 1 2.526 5.77", key: "iwvgf7" }],
  ["path", { d: "M18 18a4 4 0 0 0 2-7.464", key: "efp6ie" }],
  ["path", { d: "M19.967 17.483A4 4 0 1 1 12 18a4 4 0 1 1-7.967-.517", key: "1gq6am" }],
  ["path", { d: "M6 18a4 4 0 0 1-2-7.464", key: "k1g0md" }],
  ["path", { d: "M6.003 5.125a4 4 0 0 0-2.526 5.77", key: "q97ue3" }]
];
const Brain = createLucideIcon("brain", __iconNode$K);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$J = [
  ["path", { d: "M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16", key: "jecpp" }],
  ["rect", { width: "20", height: "14", x: "2", y: "6", rx: "2", key: "i6l2r4" }]
];
const Briefcase = createLucideIcon("briefcase", __iconNode$J);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$I = [
  ["path", { d: "M10 12h4", key: "a56b0p" }],
  ["path", { d: "M10 8h4", key: "1sr2af" }],
  ["path", { d: "M14 21v-3a2 2 0 0 0-4 0v3", key: "1rgiei" }],
  [
    "path",
    {
      d: "M6 10H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2",
      key: "secmi2"
    }
  ],
  ["path", { d: "M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16", key: "16ra0t" }]
];
const Building2 = createLucideIcon("building-2", __iconNode$I);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$H = [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]];
const Check = createLucideIcon("check", __iconNode$H);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$G = [["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]];
const ChevronDown = createLucideIcon("chevron-down", __iconNode$G);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$F = [["path", { d: "m18 15-6-6-6 6", key: "153udz" }]];
const ChevronUp = createLucideIcon("chevron-up", __iconNode$F);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$E = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["line", { x1: "12", x2: "12", y1: "8", y2: "12", key: "1pkeuh" }],
  ["line", { x1: "12", x2: "12.01", y1: "16", y2: "16", key: "4dfq90" }]
];
const CircleAlert = createLucideIcon("circle-alert", __iconNode$E);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$D = [
  ["path", { d: "M21.801 10A10 10 0 1 1 17 3.335", key: "yps3ct" }],
  ["path", { d: "m9 11 3 3L22 4", key: "1pflzl" }]
];
const CircleCheckBig = createLucideIcon("circle-check-big", __iconNode$D);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$C = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m9 12 2 2 4-4", key: "dzmm74" }]
];
const CircleCheck = createLucideIcon("circle-check", __iconNode$C);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$B = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m15 9-6 6", key: "1uzhvr" }],
  ["path", { d: "m9 9 6 6", key: "z0biqf" }]
];
const CircleX = createLucideIcon("circle-x", __iconNode$B);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$A = [
  ["path", { d: "M12 6v6l4 2", key: "mmk7yg" }],
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }]
];
const Clock = createLucideIcon("clock", __iconNode$A);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$z = [
  ["path", { d: "M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z", key: "p7xjir" }]
];
const Cloud = createLucideIcon("cloud", __iconNode$z);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$y = [
  ["path", { d: "m18 16 4-4-4-4", key: "1inbqp" }],
  ["path", { d: "m6 8-4 4 4 4", key: "15zrgr" }],
  ["path", { d: "m14.5 4-5 16", key: "e7oirm" }]
];
const CodeXml = createLucideIcon("code-xml", __iconNode$y);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$x = [
  ["rect", { width: "20", height: "14", x: "2", y: "5", rx: "2", key: "ynyp8z" }],
  ["line", { x1: "2", x2: "22", y1: "10", y2: "10", key: "1b3vmo" }]
];
const CreditCard = createLucideIcon("credit-card", __iconNode$x);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$w = [
  ["ellipse", { cx: "12", cy: "5", rx: "9", ry: "3", key: "msslwz" }],
  ["path", { d: "M3 5V19A9 3 0 0 0 21 19V5", key: "1wlel7" }],
  ["path", { d: "M3 12A9 3 0 0 0 21 12", key: "mv7ke4" }]
];
const Database = createLucideIcon("database", __iconNode$w);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$v = [
  ["path", { d: "M12 15V3", key: "m9g1x1" }],
  ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" }],
  ["path", { d: "m7 10 5 5 5-5", key: "brsn70" }]
];
const Download = createLucideIcon("download", __iconNode$v);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$u = [
  ["path", { d: "M15 3h6v6", key: "1q9fwt" }],
  ["path", { d: "M10 14 21 3", key: "gplh6r" }],
  ["path", { d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6", key: "a6xqqp" }]
];
const ExternalLink = createLucideIcon("external-link", __iconNode$u);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$t = [
  [
    "path",
    {
      d: "M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",
      key: "1oefj6"
    }
  ],
  ["path", { d: "M14 2v5a1 1 0 0 0 1 1h5", key: "wfsgrz" }],
  ["path", { d: "M10 9H8", key: "b1mrlr" }],
  ["path", { d: "M16 13H8", key: "t4e002" }],
  ["path", { d: "M16 17H8", key: "z1uh3a" }]
];
const FileText = createLucideIcon("file-text", __iconNode$t);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$s = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20", key: "13o1zl" }],
  ["path", { d: "M2 12h20", key: "9i4pu4" }]
];
const Globe = createLucideIcon("globe", __iconNode$s);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$r = [
  [
    "path",
    {
      d: "M21.42 10.922a1 1 0 0 0-.019-1.838L12.83 5.18a2 2 0 0 0-1.66 0L2.6 9.08a1 1 0 0 0 0 1.832l8.57 3.908a2 2 0 0 0 1.66 0z",
      key: "j76jl0"
    }
  ],
  ["path", { d: "M22 10v6", key: "1lu8f3" }],
  ["path", { d: "M6 12.5V16a6 3 0 0 0 12 0v-3.5", key: "1r8lef" }]
];
const GraduationCap = createLucideIcon("graduation-cap", __iconNode$r);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$q = [
  ["line", { x1: "22", x2: "2", y1: "12", y2: "12", key: "1y58io" }],
  [
    "path",
    {
      d: "M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z",
      key: "oot6mr"
    }
  ],
  ["line", { x1: "6", x2: "6.01", y1: "16", y2: "16", key: "sgf278" }],
  ["line", { x1: "10", x2: "10.01", y1: "16", y2: "16", key: "1l4acy" }]
];
const HardDrive = createLucideIcon("hard-drive", __iconNode$q);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$p = [
  ["path", { d: "M6 16c5 0 7-8 12-8a4 4 0 0 1 0 8c-5 0-7-8-12-8a4 4 0 1 0 0 8", key: "18ogeb" }]
];
const Infinity$1 = createLucideIcon("infinity", __iconNode$p);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$o = [
  ["path", { d: "m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4", key: "g0fldk" }],
  ["path", { d: "m21 2-9.6 9.6", key: "1j0ho8" }],
  ["circle", { cx: "7.5", cy: "15.5", r: "5.5", key: "yqb3hr" }]
];
const Key = createLucideIcon("key", __iconNode$o);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$n = [
  [
    "path",
    {
      d: "M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z",
      key: "c2jq9f"
    }
  ],
  ["rect", { width: "4", height: "12", x: "2", y: "9", key: "mk3on5" }],
  ["circle", { cx: "4", cy: "4", r: "2", key: "bt5ra8" }]
];
const Linkedin = createLucideIcon("linkedin", __iconNode$n);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$m = [["path", { d: "M21 12a9 9 0 1 1-6.219-8.56", key: "13zald" }]];
const LoaderCircle = createLucideIcon("loader-circle", __iconNode$m);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$l = [
  ["rect", { width: "18", height: "11", x: "3", y: "11", rx: "2", ry: "2", key: "1w4ew1" }],
  ["path", { d: "M7 11V7a5 5 0 0 1 10 0v4", key: "fwvmzm" }]
];
const Lock = createLucideIcon("lock", __iconNode$l);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$k = [
  ["path", { d: "m10 17 5-5-5-5", key: "1bsop3" }],
  ["path", { d: "M15 12H3", key: "6jk70r" }],
  ["path", { d: "M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4", key: "u53s6r" }]
];
const LogIn = createLucideIcon("log-in", __iconNode$k);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$j = [
  ["path", { d: "m16 17 5-5-5-5", key: "1bji2h" }],
  ["path", { d: "M21 12H9", key: "dn1m92" }],
  ["path", { d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4", key: "1uf3rs" }]
];
const LogOut = createLucideIcon("log-out", __iconNode$j);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$i = [
  [
    "path",
    {
      d: "M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",
      key: "18887p"
    }
  ]
];
const MessageSquare = createLucideIcon("message-square", __iconNode$i);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$h = [
  [
    "path",
    {
      d: "M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",
      key: "1a8usu"
    }
  ],
  ["path", { d: "m15 5 4 4", key: "1mk7zo" }]
];
const Pencil = createLucideIcon("pencil", __iconNode$h);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$g = [
  [
    "path",
    {
      d: "M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",
      key: "10ikf1"
    }
  ]
];
const Play = createLucideIcon("play", __iconNode$g);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$f = [
  ["rect", { width: "20", height: "12", x: "2", y: "6", rx: "2", key: "9lu3g6" }],
  ["path", { d: "M12 12h.01", key: "1mp3jc" }],
  ["path", { d: "M17 12h.01", key: "1m0b6t" }],
  ["path", { d: "M7 12h.01", key: "eqddd0" }]
];
const RectangleEllipsis = createLucideIcon("rectangle-ellipsis", __iconNode$f);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$e = [
  ["path", { d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8", key: "v9h5vc" }],
  ["path", { d: "M21 3v5h-5", key: "1q7to0" }],
  ["path", { d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16", key: "3uifl3" }],
  ["path", { d: "M8 16H3v5", key: "1cv678" }]
];
const RefreshCw = createLucideIcon("refresh-cw", __iconNode$e);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$d = [
  ["path", { d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", key: "1357e3" }],
  ["path", { d: "M3 3v5h5", key: "1xhq8a" }]
];
const RotateCcw = createLucideIcon("rotate-ccw", __iconNode$d);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$c = [
  ["path", { d: "m21 21-4.34-4.34", key: "14j7rj" }],
  ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }]
];
const Search = createLucideIcon("search", __iconNode$c);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$b = [
  [
    "path",
    {
      d: "M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",
      key: "1ffxy3"
    }
  ],
  ["path", { d: "m21.854 2.147-10.94 10.939", key: "12cjpa" }]
];
const Send = createLucideIcon("send", __iconNode$b);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$a = [
  ["rect", { width: "20", height: "8", x: "2", y: "2", rx: "2", ry: "2", key: "ngkwjq" }],
  ["rect", { width: "20", height: "8", x: "2", y: "14", rx: "2", ry: "2", key: "iecqi9" }],
  ["line", { x1: "6", x2: "6.01", y1: "6", y2: "6", key: "16zg32" }],
  ["line", { x1: "6", x2: "6.01", y1: "18", y2: "18", key: "nzw8ys" }]
];
const Server = createLucideIcon("server", __iconNode$a);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$9 = [
  [
    "path",
    {
      d: "M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915",
      key: "1i5ecw"
    }
  ],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }]
];
const Settings$1 = createLucideIcon("settings", __iconNode$9);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$8 = [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y"
    }
  ]
];
const Shield = createLucideIcon("shield", __iconNode$8);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$7 = [
  [
    "path",
    {
      d: "M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",
      key: "1s2grr"
    }
  ],
  ["path", { d: "M20 2v4", key: "1rf3ol" }],
  ["path", { d: "M22 4h-4", key: "gwowj6" }],
  ["circle", { cx: "4", cy: "20", r: "2", key: "6kqj1y" }]
];
const Sparkles = createLucideIcon("sparkles", __iconNode$7);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$6 = [
  ["path", { d: "M10 11v6", key: "nco0om" }],
  ["path", { d: "M14 11v6", key: "outv1u" }],
  ["path", { d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6", key: "miytrc" }],
  ["path", { d: "M3 6h18", key: "d0wm0j" }],
  ["path", { d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2", key: "e791ji" }]
];
const Trash2 = createLucideIcon("trash-2", __iconNode$6);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$5 = [
  [
    "path",
    {
      d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
      key: "wmoenq"
    }
  ],
  ["path", { d: "M12 9v4", key: "juzpu7" }],
  ["path", { d: "M12 17h.01", key: "p32p05" }]
];
const TriangleAlert = createLucideIcon("triangle-alert", __iconNode$5);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$4 = [
  ["path", { d: "M12 4v16", key: "1654pz" }],
  ["path", { d: "M4 7V5a1 1 0 0 1 1-1h14a1 1 0 0 1 1 1v2", key: "e0r10z" }],
  ["path", { d: "M9 20h6", key: "s66wpe" }]
];
const Type = createLucideIcon("type", __iconNode$4);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$3 = [
  ["path", { d: "M12 3v12", key: "1x0j5s" }],
  ["path", { d: "m17 8-5-5-5 5", key: "7q97r8" }],
  ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" }]
];
const Upload = createLucideIcon("upload", __iconNode$3);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$2 = [
  ["path", { d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2", key: "975kel" }],
  ["circle", { cx: "12", cy: "7", r: "4", key: "17ys0d" }]
];
const User = createLucideIcon("user", __iconNode$2);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode$1 = [
  ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
  ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
];
const X = createLucideIcon("x", __iconNode$1);

/**
 * @license lucide-react v0.562.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const __iconNode = [
  [
    "path",
    {
      d: "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",
      key: "1xq2db"
    }
  ]
];
const Zap = createLucideIcon("zap", __iconNode);

const TYPE_LABELS = {
  FULL_NAME: "Full Name",
  FIRST_NAME: "First Name",
  LAST_NAME: "Last Name",
  EMAIL: "Email",
  PHONE: "Phone",
  COUNTRY_CODE: "Country Code",
  SCHOOL: "School",
  DEGREE: "Degree",
  MAJOR: "Major",
  GPA: "GPA",
  GRAD_DATE: "Graduation Date",
  GRAD_YEAR: "Graduation Year",
  GRAD_MONTH: "Graduation Month",
  LINKEDIN: "LinkedIn",
  GITHUB: "GitHub",
  PORTFOLIO: "Portfolio",
  LOCATION: "Location",
  CITY: "City",
  COMPANY_NAME: "Company Name",
  JOB_TITLE: "Job Title",
  JOB_DESCRIPTION: "Job Description",
  START_DATE: "Start Date",
  END_DATE: "End Date",
  WORK_AUTH: "Work Authorization",
  NEED_SPONSORSHIP: "Need Sponsorship",
  EEO_GENDER: "Gender (EEO)",
  EEO_ETHNICITY: "Ethnicity (EEO)",
  EEO_VETERAN: "Veteran Status (EEO)",
  EEO_DISABILITY: "Disability (EEO)",
  GOV_ID: "Government ID",
  SALARY: "Salary",
  SUMMARY: "Summary",
  SKILLS: "Skills",
  UNKNOWN: "Unknown"
};
function getTypeLabel(type) {
  return TYPE_LABELS[type] || type;
}
Object.entries(TYPE_LABELS).map(
  ([value, label]) => ({ value, label })
);

const CATEGORIES = [
  {
    name: "Personal",
    icon: User,
    iconColor: "text-blue-500",
    taxonomies: ["FULL_NAME", "FIRST_NAME", "LAST_NAME", "EMAIL", "PHONE", "COUNTRY_CODE", "LINKEDIN", "GITHUB", "PORTFOLIO", "SUMMARY", "SKILLS", "LOCATION", "CITY"]
  },
  {
    name: "Education",
    icon: GraduationCap,
    iconColor: "text-green-500",
    taxonomies: ["SCHOOL", "DEGREE", "MAJOR", "GPA", "GRAD_DATE", "GRAD_YEAR", "GRAD_MONTH"]
  },
  {
    name: "Sensitive",
    icon: TriangleAlert,
    iconColor: "text-amber-500",
    taxonomies: ["EEO_GENDER", "EEO_ETHNICITY", "EEO_VETERAN", "EEO_DISABILITY", "GOV_ID", "WORK_AUTH", "NEED_SPONSORSHIP", "SALARY"],
    isSensitive: true
  }
];
function SavedAnswers() {
  const [answers, setAnswers] = reactExports.useState([]);
  const [experiences, setExperiences] = reactExports.useState([]);
  const [expandedCategories, setExpandedCategories] = reactExports.useState(/* @__PURE__ */ new Set(["Personal"]));
  const [searchQuery, setSearchQuery] = reactExports.useState("");
  const [loading, setLoading] = reactExports.useState(true);
  const [editingAnswer, setEditingAnswer] = reactExports.useState(null);
  reactExports.useEffect(() => {
    loadData();
  }, []);
  async function loadData() {
    try {
      const [answersResult, experiencesResult] = await Promise.all([
        chrome.storage.local.get("answers"),
        chrome.storage.local.get("experiences")
      ]);
      setAnswers(Object.values(answersResult.answers || {}));
      setExperiences(Object.values(experiencesResult.experiences || {}));
    } catch {
      setAnswers([]);
      setExperiences([]);
    } finally {
      setLoading(false);
    }
  }
  function toggleCategory(categoryName) {
    setExpandedCategories((prev) => {
      const next = new Set(prev);
      if (next.has(categoryName)) {
        next.delete(categoryName);
      } else {
        next.add(categoryName);
      }
      return next;
    });
  }
  function getAnswersForCategory(taxonomies) {
    return answers.filter((a) => taxonomies.includes(a.type)).filter((a) => {
      if (!searchQuery) return true;
      const query = searchQuery.toLowerCase();
      return a.type.toLowerCase().includes(query) || a.value.toLowerCase().includes(query);
    });
  }
  async function handleToggleAutofill(id, allowed) {
    const result = await chrome.storage.local.get("answers");
    const storedAnswers = result.answers || {};
    if (storedAnswers[id]) {
      storedAnswers[id].autofillAllowed = allowed;
      storedAnswers[id].updatedAt = Date.now();
      await chrome.storage.local.set({ answers: storedAnswers });
      loadData();
    }
  }
  async function handleDelete(id) {
    if (!confirm("Delete this answer?")) return;
    const result = await chrome.storage.local.get("answers");
    const storedAnswers = result.answers || {};
    delete storedAnswers[id];
    await chrome.storage.local.set({ answers: storedAnswers });
    loadData();
  }
  async function handleDeleteExperience(id) {
    if (!confirm("Delete this experience?")) return;
    const result = await chrome.storage.local.get("experiences");
    const storedExperiences = result.experiences || {};
    delete storedExperiences[id];
    await chrome.storage.local.set({ experiences: storedExperiences });
    loadData();
  }
  async function handleSaveEdit(id, newValue) {
    const result = await chrome.storage.local.get("answers");
    const storedAnswers = result.answers || {};
    if (storedAnswers[id]) {
      storedAnswers[id].value = newValue;
      storedAnswers[id].display = newValue;
      storedAnswers[id].updatedAt = Date.now();
      await chrome.storage.local.set({ answers: storedAnswers });
      loadData();
    }
    setEditingAnswer(null);
  }
  function getExperiencesByType(type) {
    return experiences.filter((e) => e.groupType === type).sort((a, b) => a.priority - b.priority).filter((e) => {
      if (!searchQuery) return true;
      const query = searchQuery.toLowerCase();
      return Object.values(e.fields).some((v) => v?.toLowerCase().includes(query));
    });
  }
  if (loading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center py-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-gray-500 text-sm", children: "Loading..." }) });
  }
  const workExperiences = getExperiencesByType("WORK");
  const educationExperiences = getExperiencesByType("EDUCATION");
  const hasAnyData = answers.length > 0 || experiences.length > 0;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 relative", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "text",
          placeholder: "Search...",
          value: searchQuery,
          onChange: (e) => setSearchQuery(e.target.value),
          className: "w-full pl-8 pr-2.5 py-1.5 text-sm border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        }
      )
    ] }) }),
    !hasAnyData ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 mx-auto bg-gray-100 rounded-full flex items-center justify-center mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-6 h-6 text-gray-400" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-medium text-gray-900", children: "No saved answers" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-gray-500", children: "Fill out forms to save your answers automatically." })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      (workExperiences.length > 0 || searchQuery) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border border-purple-200 rounded-xl overflow-hidden", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: () => toggleCategory("Work Experience"),
            className: "w-full px-3 py-2 flex items-center justify-between bg-purple-50 hover:bg-purple-100 transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Briefcase, { className: "w-4 h-4 text-purple-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-medium text-gray-700", children: "Work Experience" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-gray-400", children: workExperiences.length })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                ChevronDown,
                {
                  className: `w-4 h-4 text-gray-400 transition-transform ${!expandedCategories.has("Work Experience") ? "-rotate-90" : ""}`
                }
              )
            ]
          }
        ),
        expandedCategories.has("Work Experience") && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "divide-y divide-purple-100", children: [
          workExperiences.map((exp, index) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            ExperienceItem$1,
            {
              experience: exp,
              index,
              onDelete: () => handleDeleteExperience(exp.id)
            },
            exp.id
          )),
          workExperiences.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 py-4 text-center text-xs text-gray-400", children: "No work experiences" })
        ] })
      ] }),
      (educationExperiences.length > 0 || searchQuery) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border border-green-200 rounded-xl overflow-hidden", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: () => toggleCategory("Education Experience"),
            className: "w-full px-3 py-2 flex items-center justify-between bg-green-50 hover:bg-green-100 transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(GraduationCap, { className: "w-4 h-4 text-green-500" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-medium text-gray-700", children: "Education Experience" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-gray-400", children: educationExperiences.length })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                ChevronDown,
                {
                  className: `w-4 h-4 text-gray-400 transition-transform ${!expandedCategories.has("Education Experience") ? "-rotate-90" : ""}`
                }
              )
            ]
          }
        ),
        expandedCategories.has("Education Experience") && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "divide-y divide-green-100", children: [
          educationExperiences.map((exp, index) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            ExperienceItem$1,
            {
              experience: exp,
              index,
              onDelete: () => handleDeleteExperience(exp.id)
            },
            exp.id
          )),
          educationExperiences.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 py-4 text-center text-xs text-gray-400", children: "No education experiences" })
        ] })
      ] }),
      CATEGORIES.map((category) => {
        const categoryAnswers = getAnswersForCategory(category.taxonomies);
        if (categoryAnswers.length === 0 && !searchQuery) return null;
        const isExpanded = expandedCategories.has(category.name);
        const Icon = category.icon;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: `border rounded-xl overflow-hidden ${category.isSensitive ? "border-amber-200 bg-amber-50/30" : "border-gray-200"}`,
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  onClick: () => toggleCategory(category.name),
                  className: `w-full px-3 py-2 flex items-center justify-between hover:bg-gray-100 transition-colors ${category.isSensitive ? "bg-amber-50 hover:bg-amber-100" : "bg-gray-50"}`,
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: `w-4 h-4 ${category.iconColor}` }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-medium text-gray-700", children: category.name }),
                      category.isSensitive ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-amber-600", children: "no auto-fill" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-gray-400", children: categoryAnswers.length })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      ChevronDown,
                      {
                        className: `w-4 h-4 text-gray-400 transition-transform ${!isExpanded ? "-rotate-90" : ""}`
                      }
                    )
                  ]
                }
              ),
              isExpanded && categoryAnswers.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `divide-y ${category.isSensitive ? "divide-amber-100" : "divide-gray-100"}`, children: categoryAnswers.map((answer) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                AnswerItem,
                {
                  answer,
                  isSensitive: category.isSensitive,
                  isEditing: editingAnswer?.id === answer.id,
                  onToggleAutofill: (allowed) => handleToggleAutofill(answer.id, allowed),
                  onEdit: () => setEditingAnswer(answer),
                  onDelete: () => handleDelete(answer.id),
                  onSaveEdit: (newValue) => handleSaveEdit(answer.id, newValue),
                  onCancelEdit: () => setEditingAnswer(null)
                },
                answer.id
              )) }),
              isExpanded && categoryAnswers.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 py-4 text-center text-xs text-gray-400", children: "No items in this category" })
            ]
          },
          category.name
        );
      })
    ] })
  ] });
}
function AnswerItem({ answer, isSensitive, isEditing, onToggleAutofill, onEdit, onDelete, onSaveEdit, onCancelEdit }) {
  const [editValue, setEditValue] = reactExports.useState(answer.value);
  reactExports.useEffect(() => {
    setEditValue(answer.value);
  }, [answer.value, isEditing]);
  if (isEditing) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-2 bg-blue-50", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            value: editValue,
            onChange: (e) => setEditValue(e.target.value),
            className: "flex-1 px-2 py-1 text-sm border border-blue-300 rounded focus:ring-2 focus:ring-blue-500 focus:border-transparent",
            autoFocus: true,
            onKeyDown: (e) => {
              if (e.key === "Enter") onSaveEdit(editValue);
              if (e.key === "Escape") onCancelEdit();
            }
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => onSaveEdit(editValue),
            className: "p-1 text-green-600 hover:bg-green-100 rounded",
            title: "Save",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-4 h-4" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: onCancelEdit,
            className: "p-1 text-gray-500 hover:bg-gray-100 rounded",
            title: "Cancel",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-gray-400 mt-1 block", children: getTypeLabel(answer.type) })
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-2 hover:bg-gray-50 flex items-center justify-between group", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-gray-400", children: getTypeLabel(answer.type) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-800 truncate", children: answer.value })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 flex-shrink-0", children: [
      isSensitive && /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-1 cursor-pointer mr-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-gray-400", children: "Auto" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "checkbox",
              className: "sr-only peer",
              checked: answer.autofillAllowed !== false,
              onChange: (e) => onToggleAutofill(e.target.checked)
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-5 bg-gray-200 rounded-full peer peer-checked:bg-blue-600 transition-colors" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute left-0.5 top-0.5 w-4 h-4 bg-white rounded-full shadow peer-checked:translate-x-3 transition-transform" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: onEdit,
          className: "opacity-0 group-hover:opacity-100 p-1 text-gray-400 hover:text-blue-600 transition-all",
          title: "Edit",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "w-4 h-4" })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: onDelete,
          className: "opacity-0 group-hover:opacity-100 p-1 text-gray-400 hover:text-red-600 transition-all",
          title: "Delete",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4" })
        }
      )
    ] })
  ] });
}
function ExperienceItem$1({ experience, index, onDelete }) {
  const isWork = experience.groupType === "WORK";
  const title = isWork ? experience.fields.JOB_TITLE || "Untitled Position" : experience.fields.SCHOOL || "Untitled Education";
  const subtitle = isWork ? experience.fields.COMPANY_NAME || "" : [experience.fields.DEGREE, experience.fields.MAJOR].filter(Boolean).join(" in ");
  const dateRange = [
    experience.startDate,
    experience.endDate === "present" ? "Present" : experience.endDate
  ].filter(Boolean).join(" - ");
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 py-2 hover:bg-gray-50 group", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded", children: [
          "#",
          index + 1
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-gray-800 truncate", children: title })
      ] }),
      subtitle && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-600 mt-0.5 truncate", children: subtitle }),
      dateRange && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-400 mt-0.5", children: dateRange })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: onDelete,
        className: "opacity-0 group-hover:opacity-100 p-1 text-gray-400 hover:text-red-600 transition-all flex-shrink-0",
        title: "Delete",
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4" })
      }
    )
  ] }) });
}

var Taxonomy = /* @__PURE__ */ ((Taxonomy2) => {
  Taxonomy2["FULL_NAME"] = "FULL_NAME";
  Taxonomy2["FIRST_NAME"] = "FIRST_NAME";
  Taxonomy2["LAST_NAME"] = "LAST_NAME";
  Taxonomy2["EMAIL"] = "EMAIL";
  Taxonomy2["PHONE"] = "PHONE";
  Taxonomy2["COUNTRY_CODE"] = "COUNTRY_CODE";
  Taxonomy2["LOCATION"] = "LOCATION";
  Taxonomy2["CITY"] = "CITY";
  Taxonomy2["LINKEDIN"] = "LINKEDIN";
  Taxonomy2["GITHUB"] = "GITHUB";
  Taxonomy2["PORTFOLIO"] = "PORTFOLIO";
  Taxonomy2["SUMMARY"] = "SUMMARY";
  Taxonomy2["SCHOOL"] = "SCHOOL";
  Taxonomy2["DEGREE"] = "DEGREE";
  Taxonomy2["MAJOR"] = "MAJOR";
  Taxonomy2["GPA"] = "GPA";
  Taxonomy2["GRAD_DATE"] = "GRAD_DATE";
  Taxonomy2["GRAD_YEAR"] = "GRAD_YEAR";
  Taxonomy2["GRAD_MONTH"] = "GRAD_MONTH";
  Taxonomy2["COMPANY_NAME"] = "COMPANY_NAME";
  Taxonomy2["JOB_TITLE"] = "JOB_TITLE";
  Taxonomy2["JOB_DESCRIPTION"] = "JOB_DESCRIPTION";
  Taxonomy2["SKILLS"] = "SKILLS";
  Taxonomy2["START_DATE"] = "START_DATE";
  Taxonomy2["END_DATE"] = "END_DATE";
  Taxonomy2["WORK_AUTH"] = "WORK_AUTH";
  Taxonomy2["NEED_SPONSORSHIP"] = "NEED_SPONSORSHIP";
  Taxonomy2["RESUME_TEXT"] = "RESUME_TEXT";
  Taxonomy2["SALARY"] = "SALARY";
  Taxonomy2["EEO_GENDER"] = "EEO_GENDER";
  Taxonomy2["EEO_ETHNICITY"] = "EEO_ETHNICITY";
  Taxonomy2["EEO_VETERAN"] = "EEO_VETERAN";
  Taxonomy2["EEO_DISABILITY"] = "EEO_DISABILITY";
  Taxonomy2["GOV_ID"] = "GOV_ID";
  Taxonomy2["UNKNOWN"] = "UNKNOWN";
  return Taxonomy2;
})(Taxonomy || {});
const SENSITIVE_TYPES = /* @__PURE__ */ new Set([
  "EEO_GENDER" /* EEO_GENDER */,
  "EEO_ETHNICITY" /* EEO_ETHNICITY */,
  "EEO_VETERAN" /* EEO_VETERAN */,
  "EEO_DISABILITY" /* EEO_DISABILITY */,
  "GOV_ID" /* GOV_ID */,
  "SALARY" /* SALARY */,
  "RESUME_TEXT" /* RESUME_TEXT */
]);
const DEFAULT_FILL_ANIMATION_CONFIG = {
  enabled: true,
  maxDuration: 10,
  minCharDelay: 15,
  maxCharDelay: 60,
  stageDelays: {
    scanning: 800,
    thinking: 1200
  },
  fieldDelay: 100
};

let JsonContext$1 = class JsonContext {
    constructor() {
        this.contextStack = [];
    }

    get current() {
        return this.contextStack[this.contextStack.length - 1];
    }

    get context() {
        return [...this.contextStack];
    }

    get empty() {
        return this.contextStack.length === 0;
    }

    set(value) {
        this.contextStack.push(value);
    }

    reset() {
        this.contextStack = [];
    }

    remove(value) {
        const index = this.contextStack.lastIndexOf(value);
        if (index !== -1) {
            this.contextStack.splice(index, 1);
        }
    }
};

// Context değerleri için enum benzeri sabitler
const ContextValues$1 = {
    OBJECT_KEY: 'OBJECT_KEY',
    OBJECT_VALUE: 'OBJECT_VALUE',
    ARRAY: 'ARRAY'
};

var JsonContext_1 = { JsonContext: JsonContext$1, ContextValues: ContextValues$1 };

const { JsonContext, ContextValues } = JsonContext_1;

const STRING_DELIMITERS = ['"', "'"];
const WHITESPACE = new Set([0x20, 0x09, 0x0A, 0x0D]); // space, tab, newline, return

let JsonParser$1 = class JsonParser {
    constructor(jsonStr = "", logging = false) {
        this.jsonStr = jsonStr;
        this.index = 0;
        this.context = new JsonContext();
        this.logging = logging;
        this.logger = [];
    }

    log(text) {
        if (!this.logging) return;
        const window = 10;
        const start = Math.max(this.index - window, 0);
        const end = Math.min(this.index + window, this.jsonStr.length);
        const context = this.jsonStr.slice(start, end);
        this.logger.push({ text, context });
    }

    parse() {
        let foundJson = false;

        while (this.index < this.jsonStr.length) {
            const char = this.peek();
            
            // Handle code blocks in markdown/text
            if (char === '`') {
                if (this.jsonStr.slice(this.index, this.index + 3) === '```') {
                    this.index += 3;
                    continue;
                }
            }

            // Look for JSON start
            if (char === '{' || char === '[') {
                foundJson = true;
                break;
            }

            this.index++;
        }

        if (!foundJson) {
            return "";
        }

        const result = this.parseValue();
        return this.logging ? [result, this.logger] : result;
    }

    parseValue() {
        this.skipWhitespace();
        const char = this.peek();

        if (!char) return "";
        
        if (char === "{") return this.parseObject();
        if (char === "[") return this.parseArray();
        if (STRING_DELIMITERS.includes(char)) return this.parseString();
        if (/[-0-9]/.test(char)) return this.parseNumber();
        if (/[a-zA-Z]/.test(char)) return this.parseUnquotedString();

        this.index++;
        return "";
    }

    parseObject() {
        const obj = {};
        this.index++; // skip {

        while (this.index < this.jsonStr.length) {
            this.skipWhitespace();
            
            if (this.peek() === "}") {
                this.index++;
                break;
            }

            // Parse key
            this.context.set(ContextValues.OBJECT_KEY);
            const key = this.parseString() || this.parseUnquotedString();
            if (!key) break;

            this.skipWhitespace();

            // Handle missing colon
            if (this.peek() !== ":") {
                this.log("Missing colon after key, adding it");
            } else {
                this.index++; // skip :
            }

            this.skipWhitespace();
            
            // Parse value
            this.context.reset();
            this.context.set(ContextValues.OBJECT_VALUE);
            const value = this.parseValue();
            this.context.reset();

            if (key) {
                obj[key] = value;
            }

            this.skipWhitespace();

            // Handle comma
            if (this.peek() === ",") {
                this.index++;
            }
        }

        return obj;
    }

    parseArray() {
        const arr = [];
        this.index++; // skip [
        this.context.set(ContextValues.ARRAY);

        while (this.index < this.jsonStr.length) {
            this.skipWhitespace();
            
            if (this.peek() === "]") {
                this.index++;
                break;
            }

            const value = this.parseValue();
            if (value !== undefined) {
                arr.push(value);
            }

            this.skipWhitespace();

            // Handle comma
            if (this.peek() === ",") {
                this.index++;
            }
        }

        this.context.reset();
        return arr;
    }

    parseString() {
        let char = this.peek();
        let isQuoted = STRING_DELIMITERS.includes(char);
        let stringAcc = "";

        // Skip leading whitespace
        while (char && /\s/.test(char)) {
            this.index++;
            char = this.peek();
        }

        if (isQuoted) {
            const quote = char;
            this.index++; // skip opening quote

            while (this.index < this.jsonStr.length) {
                char = this.peek();
                
                if (char === quote && this.jsonStr[this.index - 1] !== "\\") {
                    this.index++; // skip closing quote
                    break;
                }

                stringAcc += char;
                this.index++;
            }
        } else {
            // For unquoted strings, collect until delimiter
            while (this.index < this.jsonStr.length) {
                char = this.peek();

                if ([",", "}", "]", ":"].includes(char)) {
                    break;
                } else if (/\s/.test(char)) {
                    // Skip whitespace between words
                    if (stringAcc && this.index < this.jsonStr.length - 1) {
                        const nextChar = this.jsonStr[this.index + 1];
                        if (!/[,}\]:]/.test(nextChar)) {
                            stringAcc += " ";
                        }
                    }
                } else {
                    stringAcc += char;
                }

                this.index++;
            }
        }

        // Convert value types for object values
        if (!isQuoted && this.context.current === ContextValues.OBJECT_VALUE) {
            const trimmed = stringAcc.trim();
            
            // Try number
            const num = Number(trimmed);
            if (!isNaN(num)) return num;
            
            // Try boolean/null
            if (trimmed.toLowerCase() === "true") return true;
            if (trimmed.toLowerCase() === "false") return false;
            if (trimmed.toLowerCase() === "null") return null;
        }

        return stringAcc.trim();
    }

    parseNumber() {
        let numStr = "";
        
        while (this.index < this.jsonStr.length) {
            const char = this.peek();
            if (!/[-0-9.eE]/.test(char)) break;
            numStr += char;
            this.index++;
        }

        const num = Number(numStr);
        return isNaN(num) ? numStr : num;
    }

    parseUnquotedString() {
        let str = "";
        
        while (this.index < this.jsonStr.length) {
            const char = this.peek();
            if ([",", "}", "]", ":"].includes(char) || /\s/.test(char)) break;
            str += char;
            this.index++;
        }

        return str;
    }

    skipWhitespace() {
        while (this.index < this.jsonStr.length) {
            const code = this.jsonStr.charCodeAt(this.index);
            if (!WHITESPACE.has(code)) break;
            this.index++;
        }
    }

    peek() {
        return this.jsonStr[this.index];
    }
};

var JsonParser_1 = JsonParser$1;

const __viteBrowserExternal = {};

const __viteBrowserExternal$1 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	default: __viteBrowserExternal
}, Symbol.toStringTag, { value: 'Module' }));

const require$$0 = /*@__PURE__*/getAugmentedNamespace(__viteBrowserExternal$1);

const JsonParser = JsonParser_1;

/**
 * Bozuk JSON string'ini onarır
 * @param {string} jsonStr - Onarılacak JSON string'i
 * @param {Object} options - Onarım seçenekleri
 * @param {boolean} options.returnObjects - true ise JavaScript objesi döner, false ise JSON string döner
 * @param {boolean} options.skipJsonParse - true ise JSON.parse kontrolünü atlar
 * @param {boolean} options.logging - true ise onarım loglarını da döner
 * @param {boolean} options.ensureAscii - false ise Unicode karakterleri korur
 * @returns {string|Object} Onarılmış JSON string'i veya objesi
 */
function repairJson(jsonStr = "", options = {}) {
    const {
        returnObjects = false,
        skipJsonParse = false,
        logging = false,
        ensureAscii = true
    } = options;

    // Önce normal JSON.parse ile dene
    if (!skipJsonParse) {
        try {
            const parsed = JSON.parse(jsonStr);
            return returnObjects ? parsed : JSON.stringify(parsed, null, 2);
        } catch (e) {
            // JSON.parse başarısız olursa devam et
        }
    }

    // JSON.parse başarısız olduysa veya atlanması istendiyse, onararak parse et
    const parser = new JsonParser(jsonStr, logging);
    const result = parser.parse();

    if (logging) {
        return result; // [parsedJson, logs] şeklinde döner
    }

    // String'e çevir veya obje olarak döndür
    if (returnObjects) {
        return result;
    }

    // JSON string'e çevir
    const indent = 2;
    const replacer = ensureAscii ? (key, value) => {
        if (typeof value === 'string') {
            return value.replace(/[^\x00-\x7F]/g, char => {
                return '\\u' + ('0000' + char.charCodeAt(0).toString(16)).slice(-4);
            });
        }
        return value;
    } : null;

    return JSON.stringify(result, replacer, indent);
}

/**
 * JSON.parse benzeri fonksiyon, ancak bozuk JSON'ları da onarır
 * @param {string} jsonStr - Parse edilecek JSON string'i
 * @param {Object} options - Parse seçenekleri
 * @param {boolean} options.skipJsonParse - true ise JSON.parse kontrolünü atlar
 * @param {boolean} options.logging - true ise onarım loglarını da döner
 * @returns {Object} Parse edilmiş JavaScript objesi
 */
function loads(jsonStr, options = {}) {
    return repairJson(jsonStr, { ...options, returnObjects: true });
}

/**
 * Dosyadan JSON okur ve onarır
 * @param {string} filename - JSON dosyasının yolu
 * @param {Object} options - Parse seçenekleri
 * @returns {Object} Parse edilmiş JavaScript objesi
 */
function fromFile(filename, options = {}) {
    const fs = require$$0;
    const content = fs.readFileSync(filename, 'utf8');
    return loads(content, options);
}

var src = {
    repairJson,
    loads,
    fromFile
};

function parseJSONSafe(text, fallback = {}) {
  if (!text || typeof text !== "string") {
    return fallback;
  }
  try {
    return JSON.parse(text);
  } catch {
  }
  const codeBlockMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (codeBlockMatch) {
    try {
      return JSON.parse(codeBlockMatch[1].trim());
    } catch {
    }
  }
  const jsonMatch = text.match(/(\{[\s\S]*\}|\[[\s\S]*\])/);
  if (jsonMatch) {
    try {
      return JSON.parse(jsonMatch[1]);
    } catch {
    }
  }
  try {
    const result = src.loads(text);
    if (result !== void 0 && result !== null) {
      return result;
    }
  } catch {
  }
  try {
    const repaired = src.repairJson(text, {
      returnObjects: true,
      ensureAscii: false
    });
    if (repaired !== void 0 && repaired !== null) {
      return repaired;
    }
  } catch {
  }
  console.warn("[JSONRepair] Failed to parse/repair JSON:", text.substring(0, 200));
  return fallback;
}

const PROVIDER_ENDPOINTS$1 = {
  openai: "https://api.openai.com/v1/chat/completions",
  anthropic: "https://api.anthropic.com/v1/messages",
  dashscope: "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
  deepseek: "https://api.deepseek.com/v1/chat/completions",
  zhipu: "https://open.bigmodel.cn/api/paas/v4/chat/completions"
};
const DEFAULT_MODELS$1 = {
  openai: "gpt-4o-mini",
  anthropic: "claude-3-haiku-20240307",
  dashscope: "qwen-plus",
  deepseek: "deepseek-chat",
  zhipu: "glm-4-flash"
};
const MONTH_MAP = {
  jan: "01",
  january: "01",
  feb: "02",
  february: "02",
  mar: "03",
  march: "03",
  apr: "04",
  april: "04",
  may: "05",
  jun: "06",
  june: "06",
  jul: "07",
  july: "07",
  aug: "08",
  august: "08",
  sep: "09",
  september: "09",
  oct: "10",
  october: "10",
  nov: "11",
  november: "11",
  dec: "12",
  december: "12"
};
async function callOpenAICompatible(config, prompt, systemPrompt = "You are a helpful assistant. Respond with valid JSON only.", options = {}) {
  const endpoint = config.endpoint || PROVIDER_ENDPOINTS$1[config.provider] || PROVIDER_ENDPOINTS$1.openai;
  const model = config.model || DEFAULT_MODELS$1[config.provider] || "gpt-4o-mini";
  const needsStream = config.provider === "zhipu" || model.startsWith("glm-4");
  const requestBody = {
    model,
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: prompt }
    ],
    temperature: options.temperature ?? 0,
    max_tokens: options.maxTokens ?? 500
  };
  if (needsStream || options.stream) {
    requestBody.stream = true;
  }
  if (config.disableThinking) {
    requestBody.enable_thinking = false;
    requestBody.thinking = { type: "disabled" };
  }
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${config.apiKey}`
    },
    body: JSON.stringify(requestBody)
  });
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`API error ${response.status}: ${errorText}`);
  }
  if (requestBody.stream) {
    return parseStreamResponse$1(response);
  }
  const data = await response.json();
  return data.choices?.[0]?.message?.content || "";
}
async function callAnthropic(config, prompt, options = {}) {
  const endpoint = config.endpoint || PROVIDER_ENDPOINTS$1.anthropic;
  const model = config.model || DEFAULT_MODELS$1.anthropic;
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": config.apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true"
    },
    body: JSON.stringify({
      model,
      max_tokens: options.maxTokens ?? 500,
      messages: [{ role: "user", content: prompt }]
    })
  });
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Anthropic API error ${response.status}: ${errorText}`);
  }
  const data = await response.json();
  return data.content?.[0]?.text || "";
}
async function callLLM(config, prompt, systemPrompt, options = {}) {
  if (config.provider === "anthropic") {
    const fullPrompt = `${systemPrompt}

${prompt}` ;
    return callAnthropic(config, fullPrompt, options);
  }
  return callOpenAICompatible(config, prompt, systemPrompt, options);
}
async function parseStreamResponse$1(response) {
  const reader = response.body?.getReader();
  if (!reader) {
    throw new Error("No response body");
  }
  const decoder = new TextDecoder();
  let content = "";
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const chunk = decoder.decode(value, { stream: true });
      const lines = chunk.split("\n");
      for (const line of lines) {
        if (line.startsWith("data: ")) {
          const data = line.slice(6).trim();
          if (data === "[DONE]") continue;
          try {
            const json = JSON.parse(data);
            const delta = json.choices?.[0]?.delta?.content;
            if (delta) {
              content += delta;
            }
          } catch {
          }
        }
      }
    }
  } finally {
    reader.releaseLock();
  }
  return content;
}
let cachedConfig = null;
let configLoaded = false;
async function loadLLMConfig() {
  if (configLoaded) {
    return cachedConfig;
  }
  try {
    const result = await chrome.storage.local.get("llmConfig");
    cachedConfig = result.llmConfig || null;
    configLoaded = true;
  } catch {
    configLoaded = true;
  }
  return cachedConfig;
}
function resetLLMConfigCache() {
  cachedConfig = null;
  configLoaded = false;
}

const scriptRel = 'modulepreload';const assetsURL = function(dep) { return "/"+dep };const seen = {};const __vitePreload = function preload(baseModule, deps, importerUrl) {
  let promise = Promise.resolve();
  if (true && deps && deps.length > 0) {
    document.getElementsByTagName("link");
    const cspNonceMeta = document.querySelector(
      "meta[property=csp-nonce]"
    );
    const cspNonce = cspNonceMeta?.nonce || cspNonceMeta?.getAttribute("nonce");
    promise = Promise.allSettled(
      deps.map((dep) => {
        dep = assetsURL(dep);
        if (dep in seen) return;
        seen[dep] = true;
        const isCss = dep.endsWith(".css");
        const cssSelector = isCss ? '[rel="stylesheet"]' : "";
        if (document.querySelector(`link[href="${dep}"]${cssSelector}`)) {
          return;
        }
        const link = document.createElement("link");
        link.rel = isCss ? "stylesheet" : scriptRel;
        if (!isCss) {
          link.as = "script";
        }
        link.crossOrigin = "";
        link.href = dep;
        if (cspNonce) {
          link.setAttribute("nonce", cspNonce);
        }
        document.head.appendChild(link);
        if (isCss) {
          return new Promise((res, rej) => {
            link.addEventListener("load", res);
            link.addEventListener(
              "error",
              () => rej(new Error(`Unable to preload CSS for ${dep}`))
            );
          });
        }
      })
    );
  }
  function handlePreloadError(err) {
    const e = new Event("vite:preloadError", {
      cancelable: true
    });
    e.payload = err;
    window.dispatchEvent(e);
    if (!e.defaultPrevented) {
      throw err;
    }
  }
  return promise.then((res) => {
    for (const item of res || []) {
      if (item.status !== "rejected") continue;
      handlePreloadError(item.reason);
    }
    return baseModule().catch(handlePreloadError);
  });
};

const DEFAULT_LLM_CONFIG = {
  enabled: false,
  provider: "openai",
  apiKey: "",
  model: "gpt-4o-mini",
  disableThinking: false
};
const PROVIDER_ENDPOINTS = {
  openai: "https://api.openai.com/v1/chat/completions",
  anthropic: "https://api.anthropic.com/v1/messages",
  dashscope: "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
  deepseek: "https://api.deepseek.com/v1/chat/completions",
  zhipu: "https://open.bigmodel.cn/api/paas/v4/chat/completions"
};
const DEFAULT_MODELS = {
  openai: "gpt-4o-mini",
  anthropic: "claude-3-haiku-20240307",
  dashscope: "qwen-plus",
  deepseek: "deepseek-chat",
  zhipu: "glm-4-flash"
};
async function getLLMConfig() {
  try {
    const result = await chrome.storage.local.get("llmConfig");
    return { ...DEFAULT_LLM_CONFIG, ...result.llmConfig };
  } catch {
    return DEFAULT_LLM_CONFIG;
  }
}
async function isLLMEnabled() {
  const config = await getLLMConfig();
  return config.enabled && !!config.apiKey;
}
async function callLLMWithText(prompt, options = {}) {
  const config = await getLLMConfig();
  if (!config.enabled || !config.apiKey) {
    throw new Error("LLM is not configured or enabled");
  }
  const { systemPrompt, maxTokens = 2e3, temperature = 0 } = options;
  if (config.provider === "anthropic") {
    return callAnthropicText(config, prompt, systemPrompt, maxTokens, temperature);
  }
  return callOpenAICompatibleText(config, prompt, systemPrompt, maxTokens, temperature);
}
async function callLLMWithImage(imageBase64, prompt, mimeType = "image/png", options = {}) {
  const config = await getLLMConfig();
  if (!config.enabled || !config.apiKey) {
    throw new Error("LLM is not configured or enabled");
  }
  const { systemPrompt, maxTokens = 4e3, temperature = 0 } = options;
  if (config.provider === "anthropic") {
    return callAnthropicVision(config, imageBase64, prompt, mimeType, systemPrompt, maxTokens, temperature);
  }
  return callOpenAIVision(config, imageBase64, prompt, mimeType, systemPrompt, maxTokens, temperature);
}
async function callOpenAICompatibleText(config, prompt, systemPrompt, maxTokens = 2e3, temperature = 0) {
  const endpoint = config.endpoint || PROVIDER_ENDPOINTS[config.provider] || PROVIDER_ENDPOINTS.openai;
  const model = config.model || DEFAULT_MODELS[config.provider] || "gpt-4o-mini";
  const messages = [];
  if (systemPrompt) {
    messages.push({ role: "system", content: systemPrompt });
  }
  messages.push({ role: "user", content: prompt });
  const needsStream = config.provider === "zhipu" || model.startsWith("glm-4");
  const requestBody = {
    model,
    messages,
    temperature,
    max_tokens: maxTokens
  };
  if (needsStream) {
    requestBody.stream = true;
  }
  if (config.disableThinking) {
    requestBody.enable_thinking = false;
    requestBody.thinking = { type: "disabled" };
  }
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${config.apiKey}`
    },
    body: JSON.stringify(requestBody)
  });
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`API error ${response.status}: ${errorText}`);
  }
  if (needsStream) {
    return parseStreamResponse(response);
  }
  const data = await response.json();
  return data.choices?.[0]?.message?.content || "";
}
async function callAnthropicText(config, prompt, systemPrompt, maxTokens = 2e3, temperature = 0) {
  const endpoint = config.endpoint || PROVIDER_ENDPOINTS.anthropic;
  const model = config.model || DEFAULT_MODELS.anthropic;
  const body = {
    model,
    max_tokens: maxTokens,
    messages: [{ role: "user", content: prompt }]
  };
  if (systemPrompt) {
    body.system = systemPrompt;
  }
  if (temperature > 0) {
    body.temperature = temperature;
  }
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": config.apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true"
    },
    body: JSON.stringify(body)
  });
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Anthropic API error ${response.status}: ${errorText}`);
  }
  const data = await response.json();
  return data.content?.[0]?.text || "";
}
async function callOpenAIVision(config, imageBase64, prompt, mimeType, systemPrompt, maxTokens = 4e3, temperature = 0) {
  const endpoint = config.endpoint || PROVIDER_ENDPOINTS[config.provider] || PROVIDER_ENDPOINTS.openai;
  let model = config.model || DEFAULT_MODELS[config.provider] || "gpt-4o-mini";
  if (config.provider === "openai" && !model.includes("vision") && !model.includes("4o")) {
    model = "gpt-4o-mini";
  }
  const messages = [];
  if (systemPrompt) {
    messages.push({ role: "system", content: systemPrompt });
  }
  messages.push({
    role: "user",
    content: [
      {
        type: "image_url",
        image_url: {
          url: `data:${mimeType};base64,${imageBase64}`
        }
      },
      {
        type: "text",
        text: prompt
      }
    ]
  });
  const needsStream = config.provider === "zhipu" || model && model.startsWith("glm-4");
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${config.apiKey}`
    },
    body: JSON.stringify({
      model,
      messages,
      temperature,
      max_tokens: maxTokens,
      ...needsStream && { stream: true }
    })
  });
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Vision API error ${response.status}: ${errorText}`);
  }
  if (needsStream) {
    return parseStreamResponse(response);
  }
  const data = await response.json();
  return data.choices?.[0]?.message?.content || "";
}
async function callAnthropicVision(config, imageBase64, prompt, mimeType, systemPrompt, maxTokens = 4e3, temperature = 0) {
  const endpoint = config.endpoint || PROVIDER_ENDPOINTS.anthropic;
  let model = config.model || DEFAULT_MODELS.anthropic;
  if (!model.includes("claude-3")) {
    model = "claude-3-haiku-20240307";
  }
  const body = {
    model,
    max_tokens: maxTokens,
    messages: [
      {
        role: "user",
        content: [
          {
            type: "image",
            source: {
              type: "base64",
              media_type: mimeType,
              data: imageBase64
            }
          },
          {
            type: "text",
            text: prompt
          }
        ]
      }
    ]
  };
  if (systemPrompt) {
    body.system = systemPrompt;
  }
  if (temperature > 0) {
    body.temperature = temperature;
  }
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": config.apiKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true"
    },
    body: JSON.stringify(body)
  });
  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Anthropic Vision API error ${response.status}: ${errorText}`);
  }
  const data = await response.json();
  return data.content?.[0]?.text || "";
}
function parseJSONFromLLMResponse(content) {
  try {
    const codeBlockMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (codeBlockMatch) {
      return JSON.parse(codeBlockMatch[1].trim());
    }
    const objectMatch = content.match(/\{[\s\S]*\}/);
    if (objectMatch) {
      return JSON.parse(objectMatch[0]);
    }
    const arrayMatch = content.match(/\[[\s\S]*\]/);
    if (arrayMatch) {
      return JSON.parse(arrayMatch[0]);
    }
    return null;
  } catch (error) {
    console.error("[llmHelpers] Failed to parse JSON from LLM response:", error);
    return null;
  }
}
async function parseStreamResponse(response) {
  const reader = response.body?.getReader();
  if (!reader) {
    throw new Error("No response body");
  }
  const decoder = new TextDecoder();
  let content = "";
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const chunk = decoder.decode(value, { stream: true });
      const lines = chunk.split("\n");
      for (const line of lines) {
        if (line.startsWith("data: ")) {
          const data = line.slice(6).trim();
          if (data === "[DONE]") continue;
          try {
            const json = JSON.parse(data);
            const delta = json.choices?.[0]?.delta?.content;
            if (delta) {
              content += delta;
            }
          } catch {
          }
        }
      }
    }
  } finally {
    reader.releaseLock();
  }
  return content;
}

const RESUME_PARSE_PROMPT = `You are a resume parser. Extract structured information from the resume text below.

Return a JSON object with the following structure:
{
  "fullName": "Full name of the candidate",
  "firstName": "First name only",
  "lastName": "Last name only",
  "email": "Email address",
  "phone": "Phone number (with country code if present)",
  "location": "Full location/address",
  "city": "City name only",
  "linkedinUrl": "LinkedIn profile URL",
  "githubUrl": "GitHub profile URL",
  "portfolioUrl": "Portfolio/personal website URL",
  "summary": "Professional summary or objective",
  "education": [
    {
      "school": "University/School name",
      "degree": "Degree type (e.g., Bachelor of Science, Master of Arts)",
      "major": "Field of study/Major",
      "gpa": "GPA if mentioned",
      "startDate": "YYYY-MM format",
      "endDate": "YYYY-MM format",
      "gradDate": "YYYY-MM format if graduation date is explicitly mentioned"
    }
  ],
  "experience": [
    {
      "company": "Company name",
      "title": "Job title",
      "location": "Work location",
      "startDate": "YYYY-MM format",
      "endDate": "YYYY-MM format or 'present' if current",
      "description": "Job description/responsibilities",
      "highlights": ["Key achievement 1", "Key achievement 2"]
    }
  ],
  "skills": ["Skill 1", "Skill 2", "..."]
}

Important:
- Extract ALL education entries, ordered from most recent to oldest
- Extract ALL work experiences, ordered from most recent to oldest
- Use YYYY-MM format for dates (e.g., "2023-06")
- If only year is available, use YYYY-01 (e.g., "2023-01")
- Use "present" for current positions
- Leave fields as null if not found
- For skills, extract individual technical skills, tools, and technologies

Resume text:
`;
const RESUME_VISION_PROMPT = `You are a resume parser analyzing a resume image. Extract all information visible in the resume.

Return a JSON object with the following structure:
{
  "fullName": "Full name of the candidate",
  "firstName": "First name only",
  "lastName": "Last name only",
  "email": "Email address",
  "phone": "Phone number (with country code if present)",
  "location": "Full location/address",
  "city": "City name only",
  "linkedinUrl": "LinkedIn profile URL",
  "githubUrl": "GitHub profile URL",
  "portfolioUrl": "Portfolio/personal website URL",
  "summary": "Professional summary or objective",
  "education": [
    {
      "school": "University/School name",
      "degree": "Degree type",
      "major": "Field of study",
      "gpa": "GPA if visible",
      "startDate": "YYYY-MM format",
      "endDate": "YYYY-MM format",
      "gradDate": "YYYY-MM format"
    }
  ],
  "experience": [
    {
      "company": "Company name",
      "title": "Job title",
      "location": "Work location",
      "startDate": "YYYY-MM format",
      "endDate": "YYYY-MM format or 'present'",
      "description": "Job description",
      "highlights": ["Achievement 1", "Achievement 2"]
    }
  ],
  "skills": ["Skill 1", "Skill 2"]
}

Important:
- Carefully read all text in the image
- Order education and experience from most recent to oldest
- Use YYYY-MM format for dates
- Use "present" for current positions
- Leave fields as null if not visible
`;

class ResumeParser {
  static SUPPORTED_TYPES = ["pdf", "docx", "doc", "png", "jpg", "jpeg", "webp"];
  /**
   * Check if a file type is supported
   */
  static isSupported(file) {
    const ext = file.name.split(".").pop()?.toLowerCase();
    return ext ? this.SUPPORTED_TYPES.includes(ext) : false;
  }
  /**
   * Parse a resume file and return structured profile data
   */
  async parse(file) {
    const ext = file.name.split(".").pop()?.toLowerCase();
    if (!ext || !ResumeParser.SUPPORTED_TYPES.includes(ext)) {
      throw new Error(`Unsupported file type: ${ext}`);
    }
    const enabled = await isLLMEnabled();
    if (!enabled) {
      throw new Error("LLM is not configured. Please configure LLM settings to parse resumes.");
    }
    let rawText = "";
    let parseResult;
    if (ext === "pdf") {
      rawText = await this.extractPdfText(file);
      parseResult = await this.parseWithLLM(rawText);
    } else if (["docx", "doc"].includes(ext)) {
      rawText = await this.extractWordText(file);
      parseResult = await this.parseWithLLM(rawText);
    } else if (["png", "jpg", "jpeg", "webp"].includes(ext)) {
      parseResult = await this.parseImageWithLLM(file);
    } else {
      throw new Error(`Unsupported file type: ${ext}`);
    }
    return this.buildParsedProfile(parseResult, rawText);
  }
  /**
   * Extract text from PDF file using pdf.js
   */
  async extractPdfText(file) {
    const pdfjsLib = await __vitePreload(() => import('./chunks/pdf-DM9BqXBE.js'),true?__vite__mapDeps([0,1]):void 0);
    pdfjsLib.GlobalWorkerOptions.workerSrc = new URL("/assets/pdf.worker.min.mjs", import.meta.url).toString();
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    const textParts = [];
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map((item) => "str" in item ? item.str : "").join(" ");
      textParts.push(pageText);
    }
    return textParts.join("\n\n");
  }
  /**
   * Extract text from Word document using mammoth.js
   */
  async extractWordText(file) {
    const mammoth = await __vitePreload(() => import('./chunks/index-BarD-bws.js').then(n => n.i),true?[]:void 0);
    const arrayBuffer = await file.arrayBuffer();
    const result = await mammoth.extractRawText({ arrayBuffer });
    return result.value;
  }
  /**
   * Parse text using LLM
   */
  async parseWithLLM(text) {
    const prompt = RESUME_PARSE_PROMPT + text;
    const response = await callLLMWithText(prompt, {
      systemPrompt: "You are a resume parser. Extract structured information and return valid JSON only.",
      maxTokens: 3e3
    });
    const parsed = parseJSONFromLLMResponse(response);
    if (!parsed) {
      throw new Error("Failed to parse LLM response");
    }
    return this.normalizeParseResult(parsed);
  }
  /**
   * Parse image using LLM vision
   */
  async parseImageWithLLM(file) {
    const base64 = await this.fileToBase64(file);
    const mimeType = file.type || "image/png";
    const response = await callLLMWithImage(base64, RESUME_VISION_PROMPT, mimeType, {
      systemPrompt: "You are a resume parser. Extract all visible information from the image and return valid JSON only.",
      maxTokens: 4e3
    });
    const parsed = parseJSONFromLLMResponse(response);
    if (!parsed) {
      throw new Error("Failed to parse LLM vision response");
    }
    return this.normalizeParseResult(parsed);
  }
  /**
   * Convert file to base64
   */
  fileToBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result;
        const base64 = result.split(",")[1];
        resolve(base64);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }
  /**
   * Normalize parse result to ensure consistent format
   */
  normalizeParseResult(result) {
    return {
      fullName: result.fullName?.trim(),
      firstName: result.firstName?.trim(),
      lastName: result.lastName?.trim(),
      email: result.email?.trim()?.toLowerCase(),
      phone: result.phone?.trim(),
      location: result.location?.trim(),
      city: result.city?.trim(),
      linkedinUrl: result.linkedinUrl?.trim(),
      githubUrl: result.githubUrl?.trim(),
      portfolioUrl: result.portfolioUrl?.trim(),
      summary: result.summary?.trim(),
      education: (result.education || []).map((edu) => ({
        school: edu.school?.trim() || "",
        degree: edu.degree?.trim(),
        major: edu.major?.trim(),
        gpa: edu.gpa != null ? String(edu.gpa).trim() : void 0,
        startDate: this.normalizeDate(edu.startDate),
        endDate: this.normalizeDate(edu.endDate),
        gradDate: this.normalizeDate(edu.gradDate)
      })),
      experience: (result.experience || []).map((exp) => ({
        company: exp.company?.trim() || "",
        title: exp.title?.trim() || "",
        location: exp.location?.trim(),
        startDate: this.normalizeDate(exp.startDate),
        endDate: this.normalizeDate(exp.endDate),
        description: exp.description?.trim(),
        highlights: exp.highlights?.map((h) => h.trim())
      })),
      skills: (result.skills || []).map((s) => s.trim()).filter(Boolean)
    };
  }
  /**
   * Normalize date to YYYY-MM format
   */
  normalizeDate(date) {
    if (!date) return void 0;
    date = date.trim().toLowerCase();
    if (date === "present" || date === "至今") {
      return "present";
    }
    if (/^\d{4}-\d{2}$/.test(date)) {
      return date;
    }
    if (/^\d{4}$/.test(date)) {
      return `${date}-01`;
    }
    const monthMap = {
      "jan": "01",
      "january": "01",
      "feb": "02",
      "february": "02",
      "mar": "03",
      "march": "03",
      "apr": "04",
      "april": "04",
      "may": "05",
      "jun": "06",
      "june": "06",
      "jul": "07",
      "july": "07",
      "aug": "08",
      "august": "08",
      "sep": "09",
      "september": "09",
      "oct": "10",
      "october": "10",
      "nov": "11",
      "november": "11",
      "dec": "12",
      "december": "12"
    };
    const monthYearMatch = date.match(/([a-z]+)\s*(\d{4})/i);
    if (monthYearMatch) {
      const month = monthMap[monthYearMatch[1].toLowerCase().slice(0, 3)];
      if (month) {
        return `${monthYearMatch[2]}-${month}`;
      }
    }
    const chineseMatch = date.match(/(\d{4})年(\d{1,2})月?/);
    if (chineseMatch) {
      return `${chineseMatch[1]}-${chineseMatch[2].padStart(2, "0")}`;
    }
    return void 0;
  }
  /**
   * Build ParsedProfile from ResumeParseResult
   */
  buildParsedProfile(result, rawText) {
    const singleAnswers = [];
    const experiences = [];
    const now = Date.now();
    const fieldMappings = [
      [Taxonomy.FULL_NAME, result.fullName, 0.9],
      [Taxonomy.FIRST_NAME, result.firstName, 0.85],
      [Taxonomy.LAST_NAME, result.lastName, 0.85],
      [Taxonomy.EMAIL, result.email, 0.95],
      [Taxonomy.PHONE, result.phone, 0.9],
      [Taxonomy.LOCATION, result.location, 0.85],
      [Taxonomy.CITY, result.city, 0.8],
      [Taxonomy.LINKEDIN, result.linkedinUrl, 0.95],
      [Taxonomy.GITHUB, result.githubUrl, 0.95],
      [Taxonomy.PORTFOLIO, result.portfolioUrl, 0.9],
      [Taxonomy.SUMMARY, result.summary, 0.85],
      [Taxonomy.SKILLS, result.skills?.join(", "), 0.85]
    ];
    for (const [type, value, confidence] of fieldMappings) {
      if (value) {
        singleAnswers.push({ type, value, confidence });
      }
    }
    for (let index = 0; index < result.experience.length; index++) {
      const exp = result.experience[index];
      const fields = this.buildFields([
        [Taxonomy.COMPANY_NAME, exp.company],
        [Taxonomy.JOB_TITLE, exp.title],
        [Taxonomy.LOCATION, exp.location],
        [Taxonomy.START_DATE, exp.startDate],
        [Taxonomy.END_DATE, exp.endDate],
        [Taxonomy.JOB_DESCRIPTION, exp.description]
      ]);
      experiences.push({
        id: `resume-work-${now}-${index}`,
        groupType: "WORK",
        priority: index,
        startDate: exp.startDate,
        endDate: exp.endDate,
        fields,
        createdAt: now,
        updatedAt: now
      });
    }
    for (let index = 0; index < result.education.length; index++) {
      const edu = result.education[index];
      const fields = this.buildFields([
        [Taxonomy.SCHOOL, edu.school],
        [Taxonomy.DEGREE, edu.degree],
        [Taxonomy.MAJOR, edu.major],
        [Taxonomy.GPA, edu.gpa],
        [Taxonomy.START_DATE, edu.startDate],
        [Taxonomy.END_DATE, edu.endDate],
        [Taxonomy.GRAD_DATE, edu.gradDate]
      ]);
      experiences.push({
        id: `resume-edu-${now}-${index}`,
        groupType: "EDUCATION",
        priority: index,
        startDate: edu.startDate,
        endDate: edu.endDate || edu.gradDate,
        fields,
        createdAt: now,
        updatedAt: now
      });
    }
    return {
      source: "resume",
      extractedAt: now,
      singleAnswers,
      experiences,
      rawText
    };
  }
  /**
   * Build fields object from array of [Taxonomy, value] pairs, filtering out undefined values
   */
  buildFields(pairs) {
    const fields = {};
    for (const [type, value] of pairs) {
      if (value) {
        fields[type] = value;
      }
    }
    return fields;
  }
}
const resumeParser = new ResumeParser();

const index$1 = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	ResumeParser,
	callLLMWithImage,
	callLLMWithText,
	getLLMConfig,
	isLLMEnabled,
	parseJSONFromLLMResponse,
	resumeParser
}, Symbol.toStringTag, { value: 'Module' }));

const STORAGE_KEY$1 = "experiences";
async function getStorage$1(key) {
  const result = await chrome.storage.local.get(key);
  return result[key] || null;
}
async function setStorage$1(key, value) {
  await chrome.storage.local.set({ [key]: value });
}
class ExperienceStorage {
  async save(entry) {
    const entries = await this.getAllMap();
    entries[entry.id] = entry;
    await setStorage$1(STORAGE_KEY$1, entries);
  }
  async saveBatch(newEntries) {
    const entries = await this.getAllMap();
    for (const entry of newEntries) {
      entries[entry.id] = entry;
    }
    await setStorage$1(STORAGE_KEY$1, entries);
  }
  async getById(id) {
    const entries = await this.getAllMap();
    return entries[id] || null;
  }
  async getByGroupType(type) {
    const all = await this.getAll();
    return all.filter((e) => e.groupType === type).sort((a, b) => a.priority - b.priority);
  }
  async getByPriority(type, priority) {
    const entries = await this.getByGroupType(type);
    return entries[priority] || null;
  }
  async getAll() {
    const entries = await this.getAllMap();
    return Object.values(entries).sort((a, b) => {
      if (a.groupType !== b.groupType) {
        const order = { WORK: 0, EDUCATION: 1, PROJECT: 2 };
        return order[a.groupType] - order[b.groupType];
      }
      return a.priority - b.priority;
    });
  }
  async delete(id) {
    const entries = await this.getAllMap();
    delete entries[id];
    await setStorage$1(STORAGE_KEY$1, entries);
    await this.normalizePriorities();
  }
  async deleteByGroupType(type) {
    const entries = await this.getAllMap();
    const filtered = Object.fromEntries(
      Object.entries(entries).filter(([, entry]) => entry.groupType !== type)
    );
    await setStorage$1(STORAGE_KEY$1, filtered);
  }
  async update(id, updates) {
    const entry = await this.getById(id);
    if (entry) {
      const updated = {
        ...entry,
        ...updates,
        updatedAt: Date.now()
      };
      await this.save(updated);
    }
  }
  async reorder(ids) {
    const entries = await this.getAllMap();
    for (let i = 0; i < ids.length; i++) {
      const entry = entries[ids[i]];
      if (entry) {
        entry.priority = i;
        entry.updatedAt = Date.now();
      }
    }
    await setStorage$1(STORAGE_KEY$1, entries);
  }
  async clearAll() {
    await setStorage$1(STORAGE_KEY$1, {});
  }
  async getCount() {
    const entries = await this.getAllMap();
    return Object.keys(entries).length;
  }
  async getCountByGroupType(type) {
    const entries = await this.getByGroupType(type);
    return entries.length;
  }
  async getAllMap() {
    return await getStorage$1(STORAGE_KEY$1) || {};
  }
  async normalizePriorities() {
    const entries = await this.getAllMap();
    const groups = ["WORK", "EDUCATION", "PROJECT"];
    for (const type of groups) {
      const typeEntries = Object.values(entries).filter((e) => e.groupType === type).sort((a, b) => a.priority - b.priority);
      typeEntries.forEach((entry, index) => {
        entry.priority = index;
      });
    }
    await setStorage$1(STORAGE_KEY$1, entries);
  }
}
const experienceStorage = new ExperienceStorage();

const DEGREE_FALLBACK = {
  "bachelor's": { level: "bachelor", standardName: "Bachelor's Degree", abbreviation: "BS" },
  "bs": { level: "bachelor", standardName: "Bachelor's Degree", abbreviation: "BS" },
  "ba": { level: "bachelor", standardName: "Bachelor's Degree", abbreviation: "BA" },
  "本科": { level: "bachelor", standardName: "Bachelor's Degree", abbreviation: "BS" },
  "master's": { level: "master", standardName: "Master's Degree", abbreviation: "MS" },
  "ms": { level: "master", standardName: "Master's Degree", abbreviation: "MS" },
  "mba": { level: "master", standardName: "MBA", abbreviation: "MBA" },
  "硕士": { level: "master", standardName: "Master's Degree", abbreviation: "MS" },
  "phd": { level: "doctoral", standardName: "PhD", abbreviation: "PhD" },
  "博士": { level: "doctoral", standardName: "PhD", abbreviation: "PhD" }
};
const SKILL_FALLBACK = {
  "javascript": { name: "JavaScript", category: "language", aliases: ["JS"] },
  "js": { name: "JavaScript", category: "language", aliases: ["JS"] },
  "typescript": { name: "TypeScript", category: "language", aliases: ["TS"] },
  "python": { name: "Python", category: "language", aliases: [] },
  "react": { name: "React", category: "framework", aliases: ["ReactJS"] },
  "vue": { name: "Vue.js", category: "framework", aliases: ["Vue"] },
  "node": { name: "Node.js", category: "framework", aliases: ["NodeJS"] }
};
const COUNTRY_FALLBACK = {
  "us": { name: "United States", code: "US" },
  "usa": { name: "United States", code: "US" },
  "美国": { name: "United States", code: "US" },
  "china": { name: "China", code: "CN" },
  "中国": { name: "China", code: "CN" },
  "uk": { name: "United Kingdom", code: "GB" }
};
class KnowledgeNormalizer {
  config = null;
  configLoaded = false;
  /**
   * Whether to use LLM for normalization (sends user data to LLM)
   * Default: false - only use local rules to protect user privacy
   */
  useLLMForNormalization = false;
  constructor() {
    this.initConfig();
  }
  async initConfig() {
    this.config = await loadLLMConfig();
    this.configLoaded = true;
    try {
      const result = await chrome.storage.local.get("useLLMNormalization");
      this.useLLMForNormalization = result.useLLMNormalization === true;
    } catch {
      this.useLLMForNormalization = false;
    }
  }
  async ensureConfigLoaded() {
    if (!this.configLoaded) {
      this.config = await loadLLMConfig();
      this.configLoaded = true;
    }
    return this.config;
  }
  /**
   * Check if LLM normalization is available AND user has opted in
   * By default, we don't send user data to LLM for privacy
   */
  isLLMNormalizationEnabled() {
    return this.useLLMForNormalization && !!(this.config?.enabled && this.config?.apiKey);
  }
  // --------------------------------------------------------------------------
  // Main Normalization API (LLM-first)
  // --------------------------------------------------------------------------
  /**
   * Normalize a degree value
   * LLM-first with local fallback
   */
  async normalizeDegree(degree) {
    await this.ensureConfigLoaded();
    if (this.isLLMNormalizationEnabled()) {
      try {
        const result = await this.llmNormalizeDegree(degree);
        if (result.confidence >= 0.7) return result;
      } catch (e) {
        console.warn("[KnowledgeNormalizer] LLM degree normalization failed, using fallback:", e);
      }
    }
    return this.fallbackNormalizeDegree(degree);
  }
  /**
   * Normalize a major/field of study
   */
  async normalizeMajor(major) {
    await this.ensureConfigLoaded();
    if (this.isLLMNormalizationEnabled()) {
      try {
        const result = await this.llmNormalize("major", major, `
Standardize this field of study/major to a common format.
- Use standard English names (e.g., "Computer Science", "Business Administration")
- Include common abbreviations as aliases
- For Chinese majors, translate to English equivalent`);
        if (result.confidence >= 0.7) return result;
      } catch (e) {
        console.warn("[KnowledgeNormalizer] LLM major normalization failed:", e);
      }
    }
    return this.fallbackNormalizeMajor(major);
  }
  /**
   * Normalize a skill name
   */
  async normalizeSkill(skill) {
    await this.ensureConfigLoaded();
    if (this.isLLMNormalizationEnabled()) {
      try {
        const result = await this.llmNormalizeSkill(skill);
        if (result.confidence >= 0.7) return result;
      } catch (e) {
        console.warn("[KnowledgeNormalizer] LLM skill normalization failed:", e);
      }
    }
    return this.fallbackNormalizeSkill(skill);
  }
  /**
   * Normalize a list of skills (with deduplication)
   */
  async normalizeSkills(skills) {
    const seen = /* @__PURE__ */ new Set();
    const result = [];
    await this.ensureConfigLoaded();
    if (this.isLLMNormalizationEnabled() && skills.length > 0) {
      try {
        const batchResult = await this.llmNormalizeSkillsBatch(skills);
        for (const info of batchResult) {
          const key = info.name.toLowerCase();
          if (!seen.has(key)) {
            seen.add(key);
            result.push(info);
          }
        }
        return result;
      } catch (e) {
        console.warn("[KnowledgeNormalizer] LLM batch skill normalization failed:", e);
      }
    }
    for (const skill of skills) {
      const normalized = await this.normalizeSkill(skill);
      const key = normalized.normalized.name.toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        result.push(normalized.normalized);
      }
    }
    return result;
  }
  /**
   * Normalize a company name
   */
  async normalizeCompany(company) {
    await this.ensureConfigLoaded();
    if (this.isLLMNormalizationEnabled()) {
      try {
        const result = await this.llmNormalize("company", company, `
Clean and standardize this company name:
- Remove suffixes like Inc., Ltd., LLC, Corp., GmbH, 有限公司, etc.
- Keep the core brand name
- Fix capitalization
- Do NOT translate company names`);
        if (result.confidence >= 0.7) return result;
      } catch (e) {
        console.warn("[KnowledgeNormalizer] LLM company normalization failed:", e);
      }
    }
    return this.fallbackNormalizeCompany(company);
  }
  /**
   * Normalize a location/address
   */
  async normalizeLocation(location) {
    await this.ensureConfigLoaded();
    if (this.isLLMNormalizationEnabled()) {
      try {
        const result = await this.llmNormalizeLocation(location);
        if (result.confidence >= 0.6) return result;
      } catch (e) {
        console.warn("[KnowledgeNormalizer] LLM location normalization failed:", e);
      }
    }
    return this.fallbackNormalizeLocation(location);
  }
  /**
   * Normalize work authorization status
   */
  async normalizeWorkAuth(auth) {
    await this.ensureConfigLoaded();
    if (this.isLLMNormalizationEnabled()) {
      try {
        const result = await this.llmNormalizeWorkAuth(auth);
        if (result.confidence >= 0.7) return result;
      } catch (e) {
        console.warn("[KnowledgeNormalizer] LLM work auth normalization failed:", e);
      }
    }
    return this.fallbackNormalizeWorkAuth(auth);
  }
  /**
   * Normalize phone number to E.164 format
   */
  normalizePhone(phone, defaultCountryCode = "+1") {
    let digits = phone.replace(/[^\d+]/g, "");
    if (digits.startsWith("+")) {
      return { original: phone, normalized: digits, confidence: 0.95, method: "rule" };
    }
    if (digits.length === 10) {
      return { original: phone, normalized: `+1${digits}`, confidence: 0.9, method: "rule" };
    }
    if (digits.length === 11 && digits.startsWith("1")) {
      if (/^1[3-9]\d{9}$/.test(digits)) {
        return { original: phone, normalized: `+86${digits}`, confidence: 0.85, method: "rule" };
      }
      return { original: phone, normalized: `+${digits}`, confidence: 0.8, method: "rule" };
    }
    return { original: phone, normalized: `${defaultCountryCode}${digits}`, confidence: 0.6, method: "rule" };
  }
  /**
   * Normalize a date string to YYYY-MM format
   */
  normalizeDate(date) {
    if (!date || date.toLowerCase() === "present") {
      return { original: date, normalized: date?.toLowerCase() === "present" ? "present" : "", confidence: 1, method: "passthrough" };
    }
    if (/^\d{4}-\d{2}$/.test(date)) {
      return { original: date, normalized: date, confidence: 1, method: "passthrough" };
    }
    const chineseMatch = date.match(/(\d{4})年(\d{1,2})月?/);
    if (chineseMatch) {
      return { original: date, normalized: `${chineseMatch[1]}-${chineseMatch[2].padStart(2, "0")}`, confidence: 0.95, method: "rule" };
    }
    const englishMatch = date.match(/([A-Za-z]+)\s+(\d{4})/);
    if (englishMatch) {
      const month = MONTH_MAP[englishMatch[1].toLowerCase().slice(0, 3)];
      if (month) {
        return { original: date, normalized: `${englishMatch[2]}-${month}`, confidence: 0.95, method: "rule" };
      }
    }
    const yearMatch = date.match(/^(\d{4})$/);
    if (yearMatch) {
      return { original: date, normalized: `${yearMatch[1]}-01`, confidence: 0.7, method: "rule" };
    }
    return { original: date, normalized: date, confidence: 0.3, method: "passthrough" };
  }
  // --------------------------------------------------------------------------
  // Batch Processing
  // --------------------------------------------------------------------------
  /**
   * Normalize an entire AnswerValue
   */
  async normalizeAnswer(answer) {
    const normalized = { ...answer };
    switch (answer.type) {
      case Taxonomy.DEGREE: {
        const result = await this.normalizeDegree(answer.value);
        normalized.value = result.normalized.standardName;
        normalized.aliases = result.aliases || [];
        break;
      }
      case Taxonomy.MAJOR: {
        const result = await this.normalizeMajor(answer.value);
        normalized.value = result.normalized;
        normalized.aliases = result.aliases || [];
        break;
      }
      case Taxonomy.PHONE: {
        const result = this.normalizePhone(answer.value);
        normalized.value = result.normalized;
        break;
      }
      case Taxonomy.COMPANY_NAME: {
        const result = await this.normalizeCompany(answer.value);
        normalized.value = result.normalized;
        break;
      }
      case Taxonomy.LOCATION:
      case Taxonomy.CITY: {
        const result = await this.normalizeLocation(answer.value);
        if (answer.type === Taxonomy.CITY && result.normalized.city) {
          normalized.value = result.normalized.city;
        }
        break;
      }
      case Taxonomy.WORK_AUTH:
      case Taxonomy.NEED_SPONSORSHIP: {
        const result = await this.normalizeWorkAuth(answer.value);
        normalized.value = result.normalized.standard;
        break;
      }
      case Taxonomy.SKILLS: {
        const skills = answer.value.split(/[,;，；]/).map((s) => s.trim()).filter(Boolean);
        const normalizedSkills = await this.normalizeSkills(skills);
        normalized.value = normalizedSkills.map((s) => s.name).join(", ");
        break;
      }
    }
    return normalized;
  }
  /**
   * Normalize an ExperienceEntry
   */
  async normalizeExperience(entry) {
    const normalized = { ...entry, fields: { ...entry.fields } };
    if (entry.startDate) normalized.startDate = this.normalizeDate(entry.startDate).normalized;
    if (entry.endDate) normalized.endDate = this.normalizeDate(entry.endDate).normalized;
    if (entry.groupType === "WORK") {
      if (normalized.fields[Taxonomy.COMPANY_NAME]) {
        normalized.fields[Taxonomy.COMPANY_NAME] = (await this.normalizeCompany(normalized.fields[Taxonomy.COMPANY_NAME])).normalized;
      }
    }
    if (entry.groupType === "EDUCATION") {
      if (normalized.fields[Taxonomy.DEGREE]) {
        const result = await this.normalizeDegree(normalized.fields[Taxonomy.DEGREE]);
        normalized.fields[Taxonomy.DEGREE] = result.normalized.standardName;
      }
      if (normalized.fields[Taxonomy.MAJOR]) {
        normalized.fields[Taxonomy.MAJOR] = (await this.normalizeMajor(normalized.fields[Taxonomy.MAJOR])).normalized;
      }
      if (normalized.fields[Taxonomy.SCHOOL]) {
        normalized.fields[Taxonomy.SCHOOL] = (await this.normalizeCompany(normalized.fields[Taxonomy.SCHOOL])).normalized;
      }
    }
    for (const field of [Taxonomy.START_DATE, Taxonomy.END_DATE, Taxonomy.GRAD_DATE]) {
      if (normalized.fields[field]) {
        normalized.fields[field] = this.normalizeDate(normalized.fields[field]).normalized;
      }
    }
    return normalized;
  }
  // --------------------------------------------------------------------------
  // LLM Normalization Methods
  // --------------------------------------------------------------------------
  async llmNormalizeDegree(degree) {
    const prompt = `Standardize this academic degree to a common format.

Input: "${degree}"

Rules:
- Map to standard English degree names
- Identify the level: high_school, associate, bachelor, master, doctoral, professional, other
- Provide standard name and common abbreviation
- Handle Chinese degrees (本科=Bachelor's, 硕士=Master's, 博士=PhD)

Return JSON only:
{
  "level": "bachelor|master|doctoral|...",
  "standardName": "Bachelor's Degree",
  "abbreviation": "BS",
  "confidence": 0.0-1.0,
  "aliases": ["other forms"]
}`;
    const response = await this.callLLMInternal(prompt);
    const parsed = this.parseJSON(response);
    return {
      original: degree,
      normalized: {
        level: parsed.level || "other",
        standardName: parsed.standardName || degree,
        abbreviation: parsed.abbreviation || degree
      },
      confidence: parsed.confidence || 0.8,
      method: "llm",
      aliases: parsed.aliases
    };
  }
  async llmNormalizeSkill(skill) {
    const prompt = `Standardize this technical skill name.

Input: "${skill}"

Rules:
- Use official/common industry naming (e.g., "JavaScript" not "javascript")
- Categorize: language, framework, tool, database, cloud, soft_skill, other
- Include common aliases/abbreviations

Return JSON only:
{
  "name": "JavaScript",
  "category": "language",
  "aliases": ["JS", "js"],
  "confidence": 0.0-1.0
}`;
    const response = await this.callLLMInternal(prompt);
    const parsed = this.parseJSON(response);
    return {
      original: skill,
      normalized: {
        name: parsed.name || skill,
        category: parsed.category || "other",
        aliases: parsed.aliases || []
      },
      confidence: parsed.confidence || 0.8,
      method: "llm",
      aliases: parsed.aliases
    };
  }
  async llmNormalizeSkillsBatch(skills) {
    const prompt = `Standardize these technical skills.

Input: ${JSON.stringify(skills)}

Rules:
- Use official/common industry naming
- Categorize each: language, framework, tool, database, cloud, soft_skill, other
- Deduplicate (e.g., "JS" and "JavaScript" are the same)
- Include aliases for each

Return JSON array only:
[{"name": "JavaScript", "category": "language", "aliases": ["JS"]}]`;
    const response = await this.callLLMInternal(prompt);
    const parsed = this.parseJSON(response);
    if (Array.isArray(parsed)) {
      return parsed.map((item) => ({
        name: item.name || "",
        category: item.category || "other",
        aliases: item.aliases || []
      }));
    }
    throw new Error("Invalid batch response");
  }
  async llmNormalizeLocation(location) {
    const prompt = `Parse and standardize this location/address.

Input: "${location}"

Rules:
- Extract: city, state/province, country, countryCode (ISO 3166-1 alpha-2)
- Standardize country names to English
- For Chinese addresses, extract city name without 市/区/县 suffix
- For Western addresses, preserve original city names

Return JSON only:
{
  "city": "San Francisco",
  "state": "California",
  "country": "United States",
  "countryCode": "US",
  "confidence": 0.0-1.0
}`;
    const response = await this.callLLMInternal(prompt);
    const parsed = this.parseJSON(response);
    return {
      original: location,
      normalized: {
        city: parsed.city,
        state: parsed.state,
        country: parsed.country,
        countryCode: parsed.countryCode
      },
      confidence: parsed.confidence || 0.8,
      method: "llm"
    };
  }
  async llmNormalizeWorkAuth(auth) {
    const prompt = `Standardize this work authorization status.

Input: "${auth}"

Rules:
- Determine if person needs visa sponsorship
- Map to standard terms:
  - "US Citizen", "Permanent Resident", "Green Card" → needsSponsorship: false
  - "H1B", "OPT", "F1", "Requires Sponsorship" → needsSponsorship: true
  - "Authorized to work" (without context) → assume needsSponsorship: false

Return JSON only:
{
  "standard": "Permanent Resident",
  "needsSponsorship": false,
  "confidence": 0.0-1.0
}`;
    const response = await this.callLLMInternal(prompt);
    const parsed = this.parseJSON(response);
    return {
      original: auth,
      normalized: {
        standard: parsed.standard || auth,
        needsSponsorship: !!parsed.needsSponsorship
      },
      confidence: parsed.confidence || 0.8,
      method: "llm"
    };
  }
  async llmNormalize(_type, value, instructions) {
    const prompt = `${instructions}

Input: "${value}"

Return JSON only:
{
  "normalized": "standardized value",
  "confidence": 0.0-1.0,
  "aliases": ["other forms"]
}`;
    const response = await this.callLLMInternal(prompt);
    const parsed = this.parseJSON(response);
    return {
      original: value,
      normalized: parsed.normalized || value,
      confidence: parsed.confidence || 0.8,
      method: "llm",
      aliases: parsed.aliases
    };
  }
  // --------------------------------------------------------------------------
  // Fallback Methods (when LLM unavailable)
  // --------------------------------------------------------------------------
  fallbackNormalizeDegree(degree) {
    const lower = degree.toLowerCase().trim();
    for (const [key, info] of Object.entries(DEGREE_FALLBACK)) {
      if (lower === key || lower.includes(key)) {
        return { original: degree, normalized: info, confidence: 0.8, method: "rule" };
      }
    }
    return {
      original: degree,
      normalized: { level: "other", standardName: degree, abbreviation: degree },
      confidence: 0.3,
      method: "passthrough"
    };
  }
  fallbackNormalizeMajor(major) {
    return { original: major, normalized: this.titleCase(major), confidence: 0.5, method: "passthrough" };
  }
  fallbackNormalizeSkill(skill) {
    const lower = skill.toLowerCase().trim();
    const mapped = SKILL_FALLBACK[lower];
    if (mapped) {
      return { original: skill, normalized: mapped, confidence: 0.8, method: "rule", aliases: mapped.aliases };
    }
    return {
      original: skill,
      normalized: { name: skill, category: "other", aliases: [] },
      confidence: 0.3,
      method: "passthrough"
    };
  }
  fallbackNormalizeCompany(company) {
    const suffixes = [
      /,?\s*(inc\.?|incorporated|corp\.?|corporation|llc|ltd\.?|limited|co\.?|company|plc|gmbh|ag|sa|pte\.?\s*ltd\.?)$/i,
      /,?\s*(株式会社|有限公司|有限责任公司|集团|控股)$/
    ];
    let normalized = company.trim();
    for (const pattern of suffixes) {
      normalized = normalized.replace(pattern, "").trim();
    }
    return {
      original: company,
      normalized,
      confidence: normalized !== company ? 0.85 : 0.5,
      method: "rule"
    };
  }
  fallbackNormalizeLocation(location) {
    const parts = location.split(/[,，·]/).map((p) => p.trim()).filter(Boolean);
    const components = {};
    for (let i = parts.length - 1; i >= 0; i--) {
      const lower = parts[i].toLowerCase();
      const country = COUNTRY_FALLBACK[lower];
      if (country) {
        components.country = country.name;
        components.countryCode = country.code;
        parts.splice(i, 1);
        break;
      }
    }
    if (/[\u4e00-\u9fa5]/.test(location)) {
      for (let i = parts.length - 1; i >= 0; i--) {
        if (!parts[i].includes("省") && !parts[i].includes("国")) {
          components.city = parts[i].replace(/[市区县]$/, "");
          break;
        }
      }
    } else if (parts.length > 0) {
      components.city = parts[0];
      if (parts.length > 1) components.state = parts[1];
    }
    return {
      original: location,
      normalized: components,
      confidence: components.city ? 0.7 : 0.4,
      method: "rule"
    };
  }
  fallbackNormalizeWorkAuth(auth) {
    const lower = auth.toLowerCase();
    if (/citizen|permanent|green\s*card|authorized/i.test(lower)) {
      return {
        original: auth,
        normalized: { standard: "Authorized to work", needsSponsorship: false },
        confidence: 0.7,
        method: "rule"
      };
    }
    if (/h1b|opt|f1|sponsor|visa/i.test(lower)) {
      return {
        original: auth,
        normalized: { standard: "Requires Sponsorship", needsSponsorship: true },
        confidence: 0.7,
        method: "rule"
      };
    }
    return {
      original: auth,
      normalized: { standard: auth, needsSponsorship: false },
      confidence: 0.3,
      method: "passthrough"
    };
  }
  // --------------------------------------------------------------------------
  // LLM Call Infrastructure (using shared @/utils/llmProvider)
  // --------------------------------------------------------------------------
  async callLLMInternal(prompt) {
    if (!this.config) throw new Error("LLM config not loaded");
    return callLLM(
      this.config,
      prompt,
      "You are a data normalization assistant. Respond with valid JSON only.",
      { maxTokens: 300 }
    );
  }
  parseJSON(text) {
    return parseJSONSafe(text, {});
  }
  titleCase(str) {
    return str.toLowerCase().split(" ").map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(" ");
  }
  /** Reset config (for testing or after settings change) */
  resetConfig() {
    this.configLoaded = false;
    this.config = null;
    this.useLLMForNormalization = false;
    resetLLMConfigCache();
  }
  /**
   * Enable or disable LLM normalization
   * When enabled, user data (degree, company, etc.) will be sent to LLM for better normalization
   * When disabled (default), only local rules are used - no user data sent to LLM
   */
  async setLLMNormalization(enabled) {
    this.useLLMForNormalization = enabled;
    try {
      await chrome.storage.local.set({ useLLMNormalization: enabled });
    } catch {
    }
  }
  /**
   * Check if LLM normalization is currently enabled
   */
  isLLMNormalizationActive() {
    return this.useLLMForNormalization;
  }
}
const knowledgeNormalizer = new KnowledgeNormalizer();

const STORAGE_KEYS = {
  ANSWERS: "answers",
  OBSERVATIONS: "observations",
  SITE_SETTINGS: "siteSettings",
  QUESTION_KEYS: "questionKeys",
  AUTH_STATE: "authState",
  CREDITS_CACHE: "creditsCache"
};
function isExtensionContextValid() {
  try {
    if (typeof chrome === "undefined") return false;
    if (chrome.runtime) {
      return !!chrome.runtime.id;
    }
    if (chrome.storage?.local) {
      return true;
    }
    return false;
  } catch {
    return false;
  }
}
class ExtensionContextInvalidatedError extends Error {
  constructor() {
    super("Extension has been updated. Please refresh the page.");
    this.name = "ExtensionContextInvalidatedError";
  }
}
async function getStorage(key) {
  if (!isExtensionContextValid()) {
    throw new ExtensionContextInvalidatedError();
  }
  const result = await chrome.storage.local.get(key);
  return result[key] || null;
}
async function setStorage(key, value) {
  if (!isExtensionContextValid()) {
    throw new ExtensionContextInvalidatedError();
  }
  await chrome.storage.local.set({ [key]: value });
}
class AnswerStorage {
  /**
   * Save an answer with optional normalization
   * @param answer The answer to save
   * @param normalize Whether to normalize the value before saving (default: true)
   */
  async save(answer, normalize = true) {
    const toSave = normalize ? await knowledgeNormalizer.normalizeAnswer(answer) : answer;
    const answers = await this.getAllMap();
    answers[toSave.id] = toSave;
    await setStorage(STORAGE_KEYS.ANSWERS, answers);
  }
  async getById(id) {
    const answers = await this.getAllMap();
    return answers[id] || null;
  }
  async getByType(type) {
    const answers = await this.getAllMap();
    return Object.values(answers).filter((a) => a.type === type);
  }
  async findByValue(type, value) {
    const answers = await this.getByType(type);
    const normalizedValue = value.toLowerCase().trim();
    for (const answer of answers) {
      if (answer.value.toLowerCase() === normalizedValue) {
        return answer;
      }
      if (answer.aliases.some((a) => a.toLowerCase() === normalizedValue)) {
        return answer;
      }
    }
    return null;
  }
  async getAll() {
    const answers = await this.getAllMap();
    return Object.values(answers);
  }
  async delete(id) {
    const answers = await this.getAllMap();
    delete answers[id];
    await setStorage(STORAGE_KEYS.ANSWERS, answers);
  }
  async update(id, updates) {
    const answer = await this.getById(id);
    if (answer) {
      const updated = { ...answer, ...updates, updatedAt: Date.now() };
      await this.save(updated);
    }
  }
  async getAllMap() {
    return await getStorage(STORAGE_KEYS.ANSWERS) || {};
  }
}
class ObservationStorage {
  async save(observation) {
    const observations = await this.getAllMap();
    observations[observation.id] = observation;
    await setStorage(STORAGE_KEYS.OBSERVATIONS, observations);
  }
  async getById(id) {
    const observations = await this.getAllMap();
    return observations[id] || null;
  }
  async getBySite(siteKey) {
    const observations = await this.getAllMap();
    return Object.values(observations).filter((o) => o.siteKey === siteKey).sort((a, b) => b.timestamp - a.timestamp);
  }
  async getRecent(limit = 50) {
    const observations = await this.getAllMap();
    return Object.values(observations).sort((a, b) => b.timestamp - a.timestamp).slice(0, limit);
  }
  async getByQuestionKey(questionKeyId) {
    const observations = await this.getAllMap();
    return Object.values(observations).filter((o) => o.questionKeyId === questionKeyId).sort((a, b) => b.timestamp - a.timestamp);
  }
  /**
   * Get relevant historical examples for few-shot learning
   * Returns high-confidence observations grouped by taxonomy type
   */
  async getRelevantExamples(limit = 5) {
    const observations = await this.getAllMap();
    return Object.values(observations).filter((o) => o.confidence >= 0.8).sort((a, b) => b.confidence - a.confidence).slice(0, limit).map((o) => ({
      questionKeyId: o.questionKeyId,
      answerId: o.answerId,
      confidence: o.confidence,
      siteKey: o.siteKey
    }));
  }
  async delete(id) {
    const observations = await this.getAllMap();
    delete observations[id];
    await setStorage(STORAGE_KEYS.OBSERVATIONS, observations);
  }
  async clearBySite(siteKey) {
    const observations = await this.getAllMap();
    const filtered = {};
    for (const [id, obs] of Object.entries(observations)) {
      if (obs.siteKey !== siteKey) {
        filtered[id] = obs;
      }
    }
    await setStorage(STORAGE_KEYS.OBSERVATIONS, filtered);
  }
  async getAllMap() {
    return await getStorage(STORAGE_KEYS.OBSERVATIONS) || {};
  }
}
class SiteSettingsStorage {
  async save(settings) {
    const allSettings = await this.getAllMap();
    allSettings[settings.siteKey] = settings;
    await setStorage(STORAGE_KEYS.SITE_SETTINGS, allSettings);
  }
  async get(siteKey) {
    const allSettings = await this.getAllMap();
    return allSettings[siteKey] || null;
  }
  async getOrCreate(siteKey) {
    const existing = await this.get(siteKey);
    if (existing) return existing;
    const newSettings = {
      siteKey,
      recordEnabled: true,
      autofillEnabled: false,
      // Default OFF for security - prevents data leakage on malicious forms
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    await this.save(newSettings);
    return newSettings;
  }
  async update(siteKey, updates) {
    const settings = await this.get(siteKey);
    if (settings) {
      const updated = { ...settings, ...updates, updatedAt: Date.now() };
      await this.save(updated);
    }
  }
  async delete(siteKey) {
    const allSettings = await this.getAllMap();
    delete allSettings[siteKey];
    await setStorage(STORAGE_KEYS.SITE_SETTINGS, allSettings);
  }
  async getAll() {
    const allSettings = await this.getAllMap();
    return Object.values(allSettings);
  }
  async getAllMap() {
    return await getStorage(STORAGE_KEYS.SITE_SETTINGS) || {};
  }
}
class PendingObservationStorage {
  pendingByForm = /* @__PURE__ */ new Map();
  add(formId, pending) {
    const existing = this.pendingByForm.get(formId) || [];
    const idx = existing.findIndex((p) => p.fieldLocator === pending.fieldLocator);
    if (idx >= 0) existing[idx] = pending;
    else existing.push(pending);
    this.pendingByForm.set(formId, existing);
  }
  getByForm(formId) {
    return this.pendingByForm.get(formId) || [];
  }
  getAllPending() {
    return Array.from(this.pendingByForm.values()).flat();
  }
  getFormIds() {
    return Array.from(this.pendingByForm.keys());
  }
  updateStatus(formId, status) {
    this.pendingByForm.get(formId)?.forEach((p) => p.status = status);
  }
  commit(formId) {
    const pending = this.pendingByForm.get(formId) || [];
    this.pendingByForm.delete(formId);
    return pending.map((p) => ({ ...p, status: "committed" }));
  }
  discard(formId) {
    this.pendingByForm.delete(formId);
  }
  discardAll() {
    this.pendingByForm.clear();
  }
  hasPending(formId) {
    return (this.pendingByForm.get(formId)?.length ?? 0) > 0;
  }
  getPendingCount() {
    return Array.from(this.pendingByForm.values()).reduce((sum, arr) => sum + arr.length, 0);
  }
}
const API_BASE_URL$1 = "https://www.onefil.help/api";
const TOKEN_BUFFER_MS = 5 * 60 * 1e3;
class AuthStorage {
  async getAuthState() {
    return getStorage(STORAGE_KEYS.AUTH_STATE);
  }
  async setAuthState(state) {
    await setStorage(STORAGE_KEYS.AUTH_STATE, state);
  }
  async clearAuthState() {
    if (!isExtensionContextValid()) throw new ExtensionContextInvalidatedError();
    await chrome.storage.local.remove(STORAGE_KEYS.AUTH_STATE);
  }
  async getAccessToken() {
    const state = await this.getAuthState();
    if (!state || state.expiresAt <= Date.now() + TOKEN_BUFFER_MS) return null;
    return state.accessToken;
  }
  async fetchCredits() {
    const token = await this.getAccessToken();
    if (!token) return null;
    try {
      const response = await fetch(`${API_BASE_URL$1}/credits`, {
        headers: { "Authorization": `Bearer ${token}` }
      });
      if (!response.ok) {
        if (response.status === 401) await this.clearAuthState();
        return null;
      }
      const credits = await response.json();
      await setStorage(STORAGE_KEYS.CREDITS_CACHE, credits);
      return credits;
    } catch {
      return getStorage(STORAGE_KEYS.CREDITS_CACHE);
    }
  }
  async consumeCredits(amount, type) {
    const token = await this.getAccessToken();
    if (!token) return { success: false, newBalance: 0, error: "Not logged in" };
    try {
      const response = await fetch(`${API_BASE_URL$1}/credits`, {
        method: "POST",
        headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
        body: JSON.stringify({ amount, type })
      });
      const result = await response.json();
      if (!response.ok) {
        return { success: false, newBalance: result.balance || 0, error: result.error || "Failed to consume credits" };
      }
      const cached = await getStorage(STORAGE_KEYS.CREDITS_CACHE);
      if (cached) {
        cached.balance = result.newBalance;
        await setStorage(STORAGE_KEYS.CREDITS_CACHE, cached);
      }
      return { success: true, newBalance: result.newBalance };
    } catch (e) {
      return { success: false, newBalance: 0, error: `Network error: ${e}` };
    }
  }
}
class Storage {
  answers = new AnswerStorage();
  observations = new ObservationStorage();
  siteSettings = new SiteSettingsStorage();
  pendingObservations = new PendingObservationStorage();
  experiences = experienceStorage;
  auth = new AuthStorage();
  async clearAll() {
    await chrome.storage.local.remove([
      STORAGE_KEYS.ANSWERS,
      STORAGE_KEYS.OBSERVATIONS,
      STORAGE_KEYS.SITE_SETTINGS,
      STORAGE_KEYS.QUESTION_KEYS,
      "experiences"
    ]);
    this.pendingObservations.discardAll();
  }
  async exportData() {
    const [answers, observations, siteSettings, experiences] = await Promise.all([
      this.answers.getAll(),
      this.observations.getRecent(1e3),
      this.siteSettings.getAll(),
      this.experiences.getAll()
    ]);
    return { answers, observations, siteSettings, experiences };
  }
  async importData(data) {
    if (data.answers) {
      for (const answer of data.answers) {
        await this.answers.save(answer);
      }
    }
    if (data.siteSettings) {
      for (const settings of data.siteSettings) {
        await this.siteSettings.save(settings);
      }
    }
    if (data.experiences) {
      await this.experiences.saveBatch(data.experiences);
    }
  }
}
const storage = new Storage();

const index = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
	__proto__: null,
	AnswerStorage,
	AuthStorage,
	ExperienceStorage,
	ExtensionContextInvalidatedError,
	ObservationStorage,
	PendingObservationStorage,
	SiteSettingsStorage,
	Storage,
	experienceStorage,
	isExtensionContextValid,
	storage
}, Symbol.toStringTag, { value: 'Module' }));

function isLinkedInProfileUrl(url) {
  return /linkedin\.com\/in\//.test(url);
}
function getErrorMessage(err, fallback) {
  return err instanceof Error ? err.message : fallback;
}
function ImportProfile() {
  const [status, setStatus] = reactExports.useState("idle");
  const [mode, setMode] = reactExports.useState("resume");
  const [error, setError] = reactExports.useState(null);
  const [parsedProfile, setParsedProfile] = reactExports.useState(null);
  const [importResult, setImportResult] = reactExports.useState(null);
  const [linkedinUrl, setLinkedinUrl] = reactExports.useState("");
  const [linkedinOpened, setLinkedinOpened] = reactExports.useState(false);
  const [linkedinPageReady, setLinkedinPageReady] = reactExports.useState(false);
  const [activeTabLinkedIn, setActiveTabLinkedIn] = reactExports.useState(null);
  const fileInputRef = reactExports.useRef(null);
  const checkActiveTab = reactExports.useCallback(async () => {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.url && isLinkedInProfileUrl(tab.url)) {
        setActiveTabLinkedIn(tab.url);
        if (!linkedinUrl) {
          setLinkedinUrl(tab.url);
        }
      } else {
        setActiveTabLinkedIn(null);
        setLinkedinPageReady(false);
      }
    } catch {
      setActiveTabLinkedIn(null);
    }
  }, [linkedinUrl]);
  const checkLinkedInPageReady = reactExports.useCallback(async () => {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id || !tab.url || !isLinkedInProfileUrl(tab.url)) {
        return false;
      }
      const response = await chrome.tabs.sendMessage(tab.id, { action: "checkLinkedInReady" });
      return response?.ready === true;
    } catch {
      return false;
    }
  }, []);
  reactExports.useEffect(() => {
    if (mode === "linkedin" && status === "idle") {
      checkActiveTab();
    }
  }, [mode, status, checkActiveTab]);
  reactExports.useEffect(() => {
    if (!linkedinOpened) return;
    if (status !== "idle") return;
    if (linkedinPageReady) return;
    setStatus("checking");
    let cancelled = false;
    let attempts = 0;
    const maxAttempts = 30;
    const pollPageReady = async () => {
      if (cancelled) return;
      const ready = await checkLinkedInPageReady();
      if (cancelled) return;
      if (ready) {
        setLinkedinPageReady(true);
        setStatus("idle");
        return;
      }
      attempts++;
      if (attempts < maxAttempts) {
        setTimeout(pollPageReady, 1e3);
      } else {
        setStatus("idle");
      }
    };
    const timer = setTimeout(pollPageReady, 1500);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [linkedinOpened, checkLinkedInPageReady]);
  function showError(message) {
    setError(message);
    setStatus("error");
  }
  async function handleFileSelect(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!ResumeParser.isSupported(file)) {
      showError(`Unsupported file type. Supported: ${ResumeParser.SUPPORTED_TYPES.join(", ")}`);
      return;
    }
    setStatus("parsing");
    setError(null);
    try {
      const profile = await resumeParser.parse(file);
      setParsedProfile(profile);
      setStatus("previewing");
    } catch (err) {
      showError(getErrorMessage(err, "Failed to parse resume"));
    }
  }
  function openLinkedInProfile() {
    const trimmed = linkedinUrl.trim();
    if (!trimmed) {
      setError("Please enter your LinkedIn profile URL");
      return;
    }
    const url = trimmed.startsWith("http") ? trimmed : "https://" + trimmed;
    if (!url.includes("linkedin.com/in/")) {
      setError("Please enter a valid LinkedIn profile URL (e.g., linkedin.com/in/yourname)");
      return;
    }
    chrome.tabs.create({ url, active: true });
    setLinkedinOpened(true);
    setError(null);
  }
  function handleParseClick() {
    setStatus("consent");
    setError(null);
  }
  async function parseLinkedInPage(useAI) {
    setStatus("parsing");
    setError(null);
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) throw new Error("No active tab found");
      const response = await chrome.tabs.sendMessage(tab.id, {
        action: "parseLinkedInProfile",
        useLLMCleaning: useAI
      });
      if (!response?.success) throw new Error(response?.error || "Failed to parse LinkedIn profile");
      setParsedProfile(response.profile);
      setStatus("previewing");
    } catch (err) {
      showError(getErrorMessage(err, "Failed to parse LinkedIn profile"));
    }
  }
  async function handleImport() {
    if (!parsedProfile) return;
    setStatus("importing");
    try {
      let answersAdded = 0;
      let answersSkipped = 0;
      for (const extracted of parsedProfile.singleAnswers) {
        const existing = await storage.answers.getByType(extracted.type);
        const isDuplicate = existing.some((e) => e.value.toLowerCase() === extracted.value.toLowerCase());
        if (isDuplicate) {
          answersSkipped++;
          continue;
        }
        const now = Date.now();
        const answer = {
          id: `import-${now}-${extracted.type}`,
          type: extracted.type,
          value: extracted.value,
          display: extracted.display || extracted.value,
          aliases: [],
          sensitivity: "normal",
          autofillAllowed: true,
          createdAt: now,
          updatedAt: now
        };
        await storage.answers.save(answer);
        answersAdded++;
      }
      await storage.experiences.saveBatch(parsedProfile.experiences);
      setImportResult({
        answersAdded,
        answersSkipped,
        experiencesAdded: parsedProfile.experiences.length
      });
      setStatus("success");
    } catch (err) {
      showError(getErrorMessage(err, "Failed to import profile"));
    }
  }
  function reset() {
    setStatus("idle");
    setError(null);
    setParsedProfile(null);
    setImportResult(null);
    setLinkedinOpened(false);
    setLinkedinPageReady(false);
    setActiveTabLinkedIn(null);
    if (fileInputRef.current) fileInputRef.current.value = "";
  }
  const workExperiences = parsedProfile?.experiences.filter((e) => e.groupType === "WORK") ?? [];
  const educationExperiences = parsedProfile?.experiences.filter((e) => e.groupType === "EDUCATION") ?? [];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center pb-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-semibold text-gray-800", children: "Import Profile" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-500", children: "Import from resume or LinkedIn" })
    ] }),
    (status === "idle" || status === "checking") && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex rounded-lg bg-gray-100 p-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ModeTab, { label: "Resume", active: mode === "resume", onClick: () => setMode("resume") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ModeTab, { label: "LinkedIn", active: mode === "linkedin", onClick: () => setMode("linkedin") })
      ] }),
      mode === "resume" && /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "div",
        {
          className: "border-2 border-dashed border-gray-200 rounded-xl p-6 text-center hover:border-blue-400 hover:bg-blue-50/50 transition-colors cursor-pointer",
          onClick: () => fileInputRef.current?.click(),
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                ref: fileInputRef,
                type: "file",
                accept: ".pdf,.docx,.doc,.png,.jpg,.jpeg,.webp",
                onChange: handleFileSelect,
                className: "hidden"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-10 h-10 text-gray-400 mx-auto mb-3" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-gray-700", children: "Upload Resume" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500 mt-1", children: "PDF, Word, or Image" })
          ]
        }
      ),
      mode === "linkedin" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 p-3 bg-blue-50 rounded-xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Linkedin, { className: "w-6 h-6 text-blue-600 flex-shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-blue-700", children: activeTabLinkedIn ? "LinkedIn profile detected! Click Parse to import." : 'Enter your LinkedIn profile URL, open it, then click "Parse" to import.' })
        ] }),
        activeTabLinkedIn && !linkedinOpened ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 p-2 bg-green-50 border border-green-200 rounded-lg", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 text-green-600 flex-shrink-0" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-green-700 truncate", children: activeTabLinkedIn })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ActionButton, { color: "green", icon: RefreshCw, onClick: handleParseClick, children: "Parse LinkedIn Profile" })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "text",
              value: linkedinUrl,
              onChange: (e) => setLinkedinUrl(e.target.value),
              placeholder: "linkedin.com/in/yourname",
              className: "w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            }
          ),
          error && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-red-600", children: error }),
          !linkedinOpened ? /* @__PURE__ */ jsxRuntimeExports.jsx(ActionButton, { color: "blue", icon: ExternalLink, onClick: openLinkedInProfile, children: "Open LinkedIn Profile" }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
            status === "checking" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 p-2 bg-blue-50 border border-blue-200 rounded-lg", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 text-blue-600 animate-spin flex-shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-blue-700", children: "Waiting for LinkedIn page to load..." })
            ] }) : linkedinPageReady ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 p-2 bg-green-50 border border-green-200 rounded-lg", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-4 h-4 text-green-600 flex-shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-green-700", children: "LinkedIn page loaded. Ready to parse!" })
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-amber-600 text-center", children: "Make sure you're on a LinkedIn profile page." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ActionButton, { color: "green", icon: RefreshCw, onClick: handleParseClick, children: "Parse LinkedIn Profile" })
          ] })
        ] })
      ] })
    ] }),
    status === "consent" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "w-10 h-10 text-blue-500 mx-auto mb-2" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base font-semibold text-gray-800", children: "Choose Processing Method" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500 mt-1", children: "How would you like to process your LinkedIn profile?" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => parseLinkedInPage(true),
            className: "w-full p-3 border-2 border-blue-200 rounded-xl hover:border-blue-400 hover:bg-blue-50/50 transition-colors text-left",
            children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2 bg-blue-100 rounded-lg", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-5 h-5 text-blue-600" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-gray-800", children: "AI-Enhanced Processing" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500 mt-0.5", children: "Better accuracy for names, dates, and formatting" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 p-2 bg-amber-50 border border-amber-200 rounded-lg", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-amber-700", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Note:" }),
                  " Your profile data will be sent to our AI service for processing. Data is NOT stored or used for training."
                ] }) })
              ] })
            ] })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => parseLinkedInPage(false),
            className: "w-full p-3 border-2 border-gray-200 rounded-xl hover:border-gray-400 hover:bg-gray-50/50 transition-colors text-left",
            children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2 bg-gray-100 rounded-lg", children: /* @__PURE__ */ jsxRuntimeExports.jsx(HardDrive, { className: "w-5 h-5 text-gray-600" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-gray-800", children: "Local Processing Only" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500 mt-0.5", children: "All processing happens on your device" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 p-2 bg-green-50 border border-green-200 rounded-lg", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-green-700", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Privacy:" }),
                  " No data leaves your browser. Results may be less accurate for complex profiles."
                ] }) })
              ] })
            ] })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => setStatus("idle"),
          className: "w-full px-4 py-2 text-sm font-medium text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200",
          children: "Cancel"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-gray-400 text-center", children: [
        "By continuing, you agree to our",
        " ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "https://www.onefil.help/privacy", target: "_blank", rel: "noopener noreferrer", className: "text-blue-600 hover:underline", children: "Privacy Policy" })
      ] })
    ] }),
    status === "parsing" && /* @__PURE__ */ jsxRuntimeExports.jsx(LoadingState, { message: mode === "linkedin" ? "Parsing LinkedIn profile..." : "Parsing resume..." }),
    status === "previewing" && parsedProfile && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(PreviewSection, { title: "Basic Info", count: parsedProfile.singleAnswers.length, children: [
        parsedProfile.singleAnswers.slice(0, 5).map((a, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-xs py-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-gray-500", children: a.type }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-gray-800 truncate ml-2 max-w-[150px]", children: a.value })
        ] }, i)),
        parsedProfile.singleAnswers.length > 5 && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-gray-400 text-center", children: [
          "+",
          parsedProfile.singleAnswers.length - 5,
          " more"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(PreviewSection, { title: "Work Experience", count: workExperiences.length, children: workExperiences.slice(0, 3).map((exp, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        ExperienceItem,
        {
          title: exp.fields.JOB_TITLE || "Unknown Title",
          subtitle: formatWorkSubtitle(exp)
        },
        i
      )) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(PreviewSection, { title: "Education", count: educationExperiences.length, children: educationExperiences.slice(0, 3).map((exp, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        ExperienceItem,
        {
          title: exp.fields.SCHOOL || "Unknown School",
          subtitle: formatEducationSubtitle(exp)
        },
        i
      )) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: reset,
            className: "flex-1 px-4 py-2 text-sm font-medium text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200",
            children: "Cancel"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: handleImport,
            className: "flex-1 px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700",
            children: "Import All"
          }
        )
      ] })
    ] }),
    status === "importing" && /* @__PURE__ */ jsxRuntimeExports.jsx(LoadingState, { message: "Importing profile..." }),
    status === "success" && importResult && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheck, { className: "w-12 h-12 text-green-500 mx-auto mb-3" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-semibold text-gray-800", children: "Import Complete!" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 space-y-1 text-sm text-gray-600", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { children: [
          importResult.answersAdded,
          " answers added"
        ] }),
        importResult.answersSkipped > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-gray-400", children: [
          importResult.answersSkipped,
          " duplicates skipped"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { children: [
          importResult.experiencesAdded,
          " experiences added"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: reset,
          className: "mt-4 px-6 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700",
          children: "Done"
        }
      )
    ] }),
    status === "error" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-12 h-12 text-red-500 mx-auto mb-3" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-semibold text-gray-800", children: "Import Failed" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-red-600", children: error }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: reset,
          className: "mt-4 px-6 py-2 text-sm font-medium text-gray-600 bg-gray-100 rounded-lg hover:bg-gray-200",
          children: "Try Again"
        }
      )
    ] })
  ] });
}
function formatWorkSubtitle(exp) {
  const company = exp.fields.COMPANY_NAME || "Unknown Company";
  const dateRange = [exp.startDate, exp.endDate].filter(Boolean).join(" - ");
  return dateRange ? `${company} · ${dateRange}` : company;
}
function formatEducationSubtitle(exp) {
  const parts = [exp.fields.DEGREE, exp.fields.MAJOR ? `in ${exp.fields.MAJOR}` : ""].filter(Boolean);
  return parts.join(" ");
}
function ModeTab({ label, active, onClick }) {
  const className = active ? "bg-white shadow text-gray-900" : "text-gray-500 hover:text-gray-700";
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "button",
    {
      onClick,
      className: `flex-1 py-2 text-sm font-medium rounded-md transition-colors ${className}`,
      children: label
    }
  );
}
function ActionButton({ color, icon: Icon, onClick, children }) {
  const colorClass = color === "blue" ? "bg-blue-600 hover:bg-blue-700" : "bg-green-600 hover:bg-green-700";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "button",
    {
      onClick,
      className: `w-full flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-white rounded-lg ${colorClass}`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "w-4 h-4" }),
        children
      ]
    }
  );
}
function LoadingState({ message }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-8", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-10 h-10 text-blue-500 animate-spin mx-auto mb-3" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-600", children: message }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-400 mt-1", children: "This may take a moment" })
  ] });
}
function PreviewSection({ title, count, children }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border border-gray-200 rounded-xl overflow-hidden", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-3 py-2 bg-gray-50 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-medium text-gray-700", children: title }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs text-gray-400", children: [
        count,
        " items"
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "px-3 py-2", children })
  ] });
}
function ExperienceItem({ title, subtitle }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "py-1 border-b border-gray-100 last:border-0", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-gray-800", children: title }),
    subtitle && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500", children: subtitle })
  ] });
}

function ThisSite() {
  const [siteKey, setSiteKey] = reactExports.useState("");
  const [settings, setSettings] = reactExports.useState(null);
  const [stats, setStats] = reactExports.useState({ recorded: 0, filled: 0 });
  const [loading, setLoading] = reactExports.useState(true);
  reactExports.useEffect(() => {
    loadCurrentSite();
  }, []);
  async function loadCurrentSite() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.url) {
        const url = new URL(tab.url);
        const key = url.hostname;
        setSiteKey(key);
        const result = await chrome.storage.local.get(["siteSettings", "observations", "activityLog"]);
        const allSettings = result.siteSettings || {};
        setSettings(allSettings[key] || null);
        const observations = result.observations || {};
        const activityLog = result.activityLog || [];
        const siteObservations = Object.values(observations).filter(
          (obs) => obs.siteKey === key
        );
        const siteFills = activityLog.filter(
          (log) => log.siteKey === key && log.action === "fill"
        );
        setStats({
          recorded: siteObservations.length,
          filled: siteFills.length
        });
      }
    } catch {
      setSiteKey("");
    } finally {
      setLoading(false);
    }
  }
  async function toggleSetting(settingKey) {
    if (!siteKey) return;
    const result = await chrome.storage.local.get("siteSettings");
    const allSettings = result.siteSettings || {};
    const current = allSettings[siteKey] || {
      siteKey,
      recordEnabled: true,
      autofillEnabled: false,
      createdAt: Date.now(),
      updatedAt: Date.now()
    };
    current[settingKey] = !current[settingKey];
    current.updatedAt = Date.now();
    allSettings[siteKey] = current;
    await chrome.storage.local.set({ siteSettings: allSettings });
    setSettings(current);
  }
  async function clearSiteData() {
    if (!siteKey) return;
    if (!confirm(`Clear all data for ${siteKey}?`)) return;
    const result = await chrome.storage.local.get(["observations", "siteSettings"]);
    const observations = result.observations || {};
    const siteSettings = result.siteSettings || {};
    const filteredObservations = {};
    for (const [id, obs] of Object.entries(observations)) {
      if (obs.siteKey !== siteKey) {
        filteredObservations[id] = obs;
      }
    }
    delete siteSettings[siteKey];
    await chrome.storage.local.set({
      observations: filteredObservations,
      siteSettings
    });
    setSettings(null);
    setStats({ recorded: 0, filled: 0 });
  }
  if (loading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center py-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-gray-500 text-sm", children: "Loading..." }) });
  }
  const recordEnabled = settings?.recordEnabled ?? true;
  const autofillEnabled = settings?.autofillEnabled ?? false;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-gradient-to-br from-blue-50 to-sky-50 rounded-xl p-3 border border-blue-100", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-8 h-8 bg-white rounded-lg flex items-center justify-center shadow-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { className: "w-5 h-5 text-blue-600" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-medium text-gray-800 text-sm", children: siteKey || "Unknown" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500", children: "Current site" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between p-2 bg-white rounded-lg", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-gray-700", children: "Record Mode" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500", children: "Learn inputs" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ToggleSwitch, { enabled: recordEnabled, onToggle: () => toggleSetting("recordEnabled") })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between p-2 bg-white rounded-lg", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-gray-700", children: "Auto-Fill" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500", children: "Fill automatically" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ToggleSwitch, { enabled: autofillEnabled, onToggle: () => toggleSetting("autofillEnabled") })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border border-gray-200 rounded-xl p-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-medium text-gray-500 mb-2", children: "Statistics" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-gray-50 rounded-lg p-2 text-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xl font-bold text-blue-600", children: stats.recorded }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500", children: "Recorded" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-gray-50 rounded-lg p-2 text-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xl font-bold text-green-600", children: stats.filled }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500", children: "Filled" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        onClick: clearSiteData,
        className: "w-full px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors flex items-center justify-center gap-2",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4" }),
          "Clear Site Data"
        ]
      }
    )
  ] });
}
function ToggleSwitch({ enabled, onToggle }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "relative inline-flex items-center cursor-pointer", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "input",
      {
        type: "checkbox",
        className: "sr-only peer",
        checked: enabled,
        onChange: onToggle
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-9 h-5 bg-gray-200 rounded-full peer peer-checked:bg-blue-600 transition-colors" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute left-0.5 top-0.5 w-4 h-4 bg-white rounded-full shadow peer-checked:translate-x-4 transition-transform" })
  ] });
}

function ActivityLog() {
  const [activities, setActivities] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  reactExports.useEffect(() => {
    loadActivities();
  }, []);
  async function loadActivities() {
    try {
      const result = await chrome.storage.local.get(["observations", "activityLog"]);
      const observations = result.observations || {};
      const activityLog = result.activityLog || [];
      const observationItems = Object.values(observations).map((obs) => ({
        id: obs.id,
        action: "learn",
        timestamp: obs.timestamp,
        fieldType: obs.questionKeyId.split("_")[0] || "UNKNOWN",
        value: "***",
        siteKey: obs.siteKey,
        confidence: Math.round(obs.confidence * 100)
      }));
      const allActivities = [...activityLog, ...observationItems].sort((a, b) => b.timestamp - a.timestamp).slice(0, 50);
      setActivities(allActivities);
    } catch {
      setActivities([]);
    } finally {
      setLoading(false);
    }
  }
  function formatTime(timestamp) {
    const date = new Date(timestamp);
    const now = /* @__PURE__ */ new Date();
    const diff = now.getTime() - date.getTime();
    if (diff < 6e4) return "now";
    if (diff < 36e5) return `${Math.floor(diff / 6e4)}m`;
    if (diff < 864e5) return `${Math.floor(diff / 36e5)}h`;
    return `${Math.floor(diff / 864e5)}d`;
  }
  function getDateGroup(timestamp) {
    const date = new Date(timestamp);
    const now = /* @__PURE__ */ new Date();
    const diff = now.getTime() - date.getTime();
    if (diff < 864e5) return "Today";
    if (diff < 1728e5) return "Yesterday";
    return date.toLocaleDateString();
  }
  function groupActivitiesByDate(items) {
    const groups = {};
    for (const item of items) {
      const group = getDateGroup(item.timestamp);
      if (!groups[group]) groups[group] = [];
      groups[group].push(item);
    }
    return groups;
  }
  if (loading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center py-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-gray-500 text-sm", children: "Loading..." }) });
  }
  if (activities.length === 0) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 mx-auto bg-gray-100 rounded-full flex items-center justify-center mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-6 h-6 text-gray-400" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-medium text-gray-900", children: "No activity yet" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-gray-500", children: "Your form activity will appear here." })
    ] });
  }
  const groupedActivities = groupActivitiesByDate(activities);
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: Object.entries(groupedActivities).map(([dateGroup, items]) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-400 uppercase mb-2", children: dateGroup }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: items.map((activity) => /* @__PURE__ */ jsxRuntimeExports.jsx(ActivityCard, { activity, formatTime }, activity.id)) })
  ] }, dateGroup)) });
}
function ActivityCard({
  activity,
  formatTime
}) {
  const isSkip = activity.action === "skip";
  const isFill = activity.action === "fill";
  const isLearn = activity.action === "learn";
  const iconBgClass = isFill ? "bg-green-100" : isLearn ? "bg-blue-100" : "bg-amber-100";
  const iconColorClass = isFill ? "text-green-600" : isLearn ? "text-blue-600" : "text-amber-600";
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `border rounded-lg p-2 hover:border-blue-200 transition-colors ${isSkip ? "border-amber-200 bg-amber-50/30" : "border-gray-200"}`, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-6 h-6 ${iconBgClass} rounded-full flex items-center justify-center flex-shrink-0 mt-0.5`, children: isFill ? /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: `w-3 h-3 ${iconColorClass}` }) : isLearn ? /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: `w-3 h-3 ${iconColorClass}` }) : /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: `w-3 h-3 ${iconColorClass}` }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-gray-800", children: isFill ? `Filled ${activity.count || 1} fields` : isLearn ? `Learned: ${activity.fieldType}` : `Skipped: ${activity.fieldType}` }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-gray-400", children: formatTime(activity.timestamp) })
      ] }),
      isLearn && activity.value && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500", children: activity.value }),
      isLearn && activity.confidence && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-blue-600", children: [
        activity.confidence,
        "% confidence"
      ] }),
      isSkip && activity.reason && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-amber-600", children: activity.reason }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500", children: activity.siteKey })
    ] })
  ] }) });
}

const STORAGE_KEY = "userLocale";
function detectBrowserLocale() {
  const lang = navigator.language || navigator.userLanguage || "en";
  return lang.toLowerCase().startsWith("zh") ? "zh" : "en";
}
let currentLocale = detectBrowserLocale();
let userPreference = "auto";
async function initLocale() {
  try {
    const result = await chrome.storage.local.get(STORAGE_KEY);
    if (result[STORAGE_KEY]) {
      userPreference = result[STORAGE_KEY];
      currentLocale = userPreference === "auto" ? detectBrowserLocale() : userPreference;
    }
  } catch {
  }
}
try {
  if (typeof chrome !== "undefined" && chrome.storage?.local) {
    chrome.storage.local.get(STORAGE_KEY).then((result) => {
      if (result[STORAGE_KEY]) {
        userPreference = result[STORAGE_KEY];
        currentLocale = userPreference === "auto" ? detectBrowserLocale() : userPreference;
      }
    }).catch(() => {
    });
  }
} catch {
}
function getUserPreference() {
  return userPreference;
}
async function setLocale(locale) {
  userPreference = locale;
  currentLocale = locale === "auto" ? detectBrowserLocale() : locale;
  try {
    await chrome.storage.local.set({ [STORAGE_KEY]: locale });
  } catch {
  }
}
const messages = {
  // App
  "app.title": {
    en: "OneFillr",
    zh: "OneFillr"
  },
  // Language Settings
  "settings.language": {
    en: "Language",
    zh: "语言"
  },
  "settings.language.auto": {
    en: "Auto (Browser)",
    zh: "自动 (跟随浏览器)"
  },
  "settings.language.en": {
    en: "English",
    zh: "English"
  },
  "settings.language.zh": {
    en: "中文",
    zh: "中文"
  },
  // Tabs
  "tabs.localKnowledge": {
    en: "Local Database",
    zh: "本地知识库"
  },
  "tabs.import": {
    en: "Import",
    zh: "导入"
  },
  "tabs.thisSite": {
    en: "This Site",
    zh: "此网站"
  },
  "tabs.activity": {
    en: "Activity",
    zh: "活动"
  },
  "tabs.settings": {
    en: "Settings",
    zh: "设置"
  },
  "tabs.developer": {
    en: "Developer",
    zh: "开发者"
  },
  // Consent Modal
  "consent.title": {
    en: "Privacy Notice",
    zh: "隐私声明"
  },
  "consent.subtitle": {
    en: "Please understand how we handle your data before using",
    zh: "在使用前，请了解我们如何处理您的数据"
  },
  "consent.localStorage.title": {
    en: "Local Data Storage",
    zh: "本地数据存储"
  },
  "consent.localStorage.desc": {
    en: "Your form data is stored locally on your device. We do not automatically upload your personal information to any server.",
    zh: "您的表单数据存储在本地设备，不会自动上传到任何服务器。您完全掌控自己的数据。"
  },
  "consent.ai.title": {
    en: "AI Recognition (Optional)",
    zh: "AI 智能识别 (可选)"
  },
  "consent.ai.desc": {
    en: "When enabled, form field labels (not your data) may be sent to AI services to improve recognition accuracy.",
    zh: "启用后，表单字段标签（非您的数据）可能发送至 AI 服务以提高识别准确度。"
  },
  "consent.policyAck": {
    en: "I have read and agree to the",
    zh: "我已阅读并同意"
  },
  "consent.privacyPolicy": {
    en: "Privacy Policy",
    zh: "隐私政策"
  },
  "consent.decline": {
    en: "Decline",
    zh: "拒绝"
  },
  "consent.accept": {
    en: "Accept & Continue",
    zh: "同意并继续"
  },
  "consent.saving": {
    en: "Saving...",
    zh: "保存中..."
  },
  // Privacy Section
  "privacy.title": {
    en: "Privacy & Data",
    zh: "隐私与数据"
  },
  "privacy.policy": {
    en: "Privacy Policy",
    zh: "隐私政策"
  },
  "privacy.dataSummary": {
    en: "Local Data Summary",
    zh: "本地数据摘要"
  },
  "privacy.savedAnswers": {
    en: "Saved Answers",
    zh: "已保存答案"
  },
  "privacy.workEducation": {
    en: "Work/Education",
    zh: "工作/教育"
  },
  "privacy.fillRecords": {
    en: "Fill Records",
    zh: "填充记录"
  },
  "privacy.aiEnabled": {
    en: "AI Features Enabled",
    zh: "AI 功能已启用"
  },
  "privacy.aiDataSentTo": {
    en: "Field metadata may be sent to:",
    zh: "字段元数据可能发送至:"
  },
  "privacy.aiDataNote": {
    en: "Your actual data values are not sent, only field labels and type information.",
    zh: "您的实际数据值不会被发送，仅发送字段标签和类型信息。"
  },
  "privacy.allowAiSharing": {
    en: "Allow AI data sharing",
    zh: "允许 AI 数据共享"
  },
  "privacy.deleteAll": {
    en: "Delete All Data",
    zh: "删除所有数据"
  },
  "privacy.deleteConfirm": {
    en: "Are you sure you want to delete all data?",
    zh: "确定要删除所有数据吗？"
  },
  "privacy.deleteWarning": {
    en: "This will remove all saved answers, experiences, and settings. This action cannot be undone.",
    zh: "此操作将移除所有保存的答案、经历和设置，且无法恢复。"
  },
  "privacy.cancel": {
    en: "Cancel",
    zh: "取消"
  },
  "privacy.confirmDelete": {
    en: "Confirm Delete",
    zh: "确认删除"
  },
  "privacy.deleting": {
    en: "Deleting...",
    zh: "删除中..."
  },
  // Settings
  "settings.account": {
    en: "Account",
    zh: "账户"
  },
  "settings.loading": {
    en: "Loading...",
    zh: "加载中..."
  },
  "settings.signOut": {
    en: "Sign out",
    zh: "退出登录"
  },
  "settings.credits": {
    en: "Credits",
    zh: "积分"
  },
  "settings.unlimited": {
    en: "Unlimited",
    zh: "无限"
  },
  "settings.renews": {
    en: "renews",
    zh: "续期"
  },
  "settings.buyCredits": {
    en: "Buy Credits",
    zh: "购买积分"
  },
  "settings.loginDesc": {
    en: "Sign in to manage your credits and use premium features.",
    zh: "登录以管理您的积分和使用高级功能。"
  },
  "settings.login": {
    en: "Sign In",
    zh: "登录账户"
  },
  "settings.loggingIn": {
    en: "Signing in...",
    zh: "登录中..."
  },
  "settings.noAccountNeeded": {
    en: "Local fill features available without account",
    zh: "不登录也可使用本地填充功能"
  },
  "settings.llm.title": {
    en: "LLM Classification",
    zh: "LLM 分类"
  },
  "settings.llm.desc": {
    en: "Use AI to classify ambiguous form fields. Requires API key.",
    zh: "使用 AI 对模糊的表单字段进行分类。需要 API 密钥。"
  },
  "settings.llm.provider": {
    en: "Provider",
    zh: "提供商"
  },
  "settings.llm.apiKey": {
    en: "API Key",
    zh: "API 密钥"
  },
  "settings.llm.model": {
    en: "Model",
    zh: "模型"
  },
  "settings.llm.modelPlaceholder": {
    en: "Select or type model name",
    zh: "选择或输入模型名称"
  },
  "settings.llm.modelHint": {
    en: "Select from list or type custom model name",
    zh: "从列表中选择或输入自定义模型名称"
  },
  "settings.llm.modelName": {
    en: "Model Name",
    zh: "模型名称"
  },
  "settings.llm.endpoint": {
    en: "Endpoint URL",
    zh: "接口地址"
  },
  "settings.llm.disableThinking": {
    en: "Disable Thinking Mode",
    zh: "禁用思考模式"
  },
  "settings.llm.disableThinkingDesc": {
    en: "Turn off deep reasoning for faster responses (required for some models)",
    zh: "关闭深度推理以加快响应速度（某些模型需要）"
  },
  "settings.save": {
    en: "Save Settings",
    zh: "保存设置"
  },
  "settings.saving": {
    en: "Saving...",
    zh: "保存中..."
  },
  "settings.saved": {
    en: "Saved",
    zh: "已保存"
  },
  "settings.about": {
    en: "About",
    zh: "关于"
  },
  "settings.aboutDesc": {
    en: "Smart form auto-filler for job applications.",
    zh: "智能求职表单自动填充工具。"
  },
  "settings.typingAnimation": {
    en: "Typing Animation",
    zh: "打字动画"
  },
  "settings.typingAnimationDesc": {
    en: "Show typewriter effect when filling forms",
    zh: "填充表单时显示打字机效果"
  },
  "settings.devMode": {
    en: "Developer Mode",
    zh: "开发者模式"
  },
  "settings.devModeDesc": {
    en: "Enable developer tools tab",
    zh: "启用开发者工具选项卡"
  },
  "settings.aiEnhancement": {
    en: "AI Enhancement",
    zh: "AI 增强"
  },
  "settings.aiEnhancementDesc": {
    en: "Use AI to better recognize complex form fields",
    zh: "使用 AI 更好地识别复杂表单字段"
  },
  "settings.aiEnhancementLoginRequired": {
    en: "Login required to use AI features",
    zh: "需要登录才能使用 AI 功能"
  },
  "settings.usingBackendApi": {
    en: "Using cloud API (included in your plan)",
    zh: "使用云端 API（已包含在您的套餐中）"
  },
  "settings.useCustomApi": {
    en: "Use Custom LLM API",
    zh: "使用自定义 LLM API"
  },
  "settings.useCustomApiDesc": {
    en: "Use your own API key instead of backend service",
    zh: "使用自己的 API 密钥而非后端服务"
  },
  // Saved Answers
  "answers.search": {
    en: "Search...",
    zh: "搜索..."
  },
  "answers.noSaved": {
    en: "No saved answers",
    zh: "没有保存的答案"
  },
  "answers.noSavedDesc": {
    en: "Fill out forms to save your answers automatically.",
    zh: "填写表单以自动保存您的答案。"
  },
  "answers.workExperience": {
    en: "Work Experience",
    zh: "工作经历"
  },
  "answers.educationExperience": {
    en: "Education",
    zh: "教育经历"
  },
  "answers.personal": {
    en: "Personal",
    zh: "个人信息"
  },
  "answers.education": {
    en: "Education",
    zh: "教育"
  },
  "answers.sensitive": {
    en: "Sensitive",
    zh: "敏感信息"
  },
  "answers.noAutoFill": {
    en: "no auto-fill",
    zh: "不自动填充"
  },
  "answers.noItems": {
    en: "No items in this category",
    zh: "此分类下没有项目"
  },
  "answers.noWorkExp": {
    en: "No work experiences",
    zh: "没有工作经历"
  },
  "answers.noEduExp": {
    en: "No education experiences",
    zh: "没有教育经历"
  },
  "answers.auto": {
    en: "Auto",
    zh: "自动"
  },
  "answers.edit": {
    en: "Edit",
    zh: "编辑"
  },
  "answers.delete": {
    en: "Delete",
    zh: "删除"
  },
  "answers.save": {
    en: "Save",
    zh: "保存"
  },
  "answers.deleteConfirm": {
    en: "Delete this answer?",
    zh: "删除此答案？"
  },
  "answers.deleteExpConfirm": {
    en: "Delete this experience?",
    zh: "删除此经历？"
  },
  "answers.untitledPosition": {
    en: "Untitled Position",
    zh: "未命名职位"
  },
  "answers.untitledEducation": {
    en: "Untitled Education",
    zh: "未命名教育"
  },
  "answers.present": {
    en: "Present",
    zh: "至今"
  },
  // Floating Widget
  "widget.save": {
    en: "Save",
    zh: "保存"
  },
  "widget.fill": {
    en: "Fill",
    zh: "填充"
  },
  "widget.manageDb": {
    en: "Manage Database",
    zh: "管理数据库"
  },
  "widget.closePanel": {
    en: "Close Panel",
    zh: "关闭面板"
  },
  "widget.learned": {
    en: "I just learned these:",
    zh: "我刚学到了这些："
  },
  "widget.editHint": {
    en: "(Edit values and types, then confirm)",
    zh: "(编辑值和类型，然后确认)"
  },
  "widget.willReplace": {
    en: "Will replace:",
    zh: "将替换："
  },
  "widget.sensitive": {
    en: "(sensitive)",
    zh: "(敏感)"
  },
  "widget.cancel": {
    en: "Cancel",
    zh: "取消"
  },
  "widget.confirm": {
    en: "Confirm",
    zh: "确认"
  },
  "widget.savedToDb": {
    en: "Saved to Database!",
    zh: "已保存到数据库！"
  },
  "widget.savedDesc": {
    en: "Your answers have been saved and will be used for auto-filling.",
    zh: "您的答案已保存，将用于自动填充。"
  },
  "widget.viewEditDb": {
    en: "View/Edit Database",
    zh: "查看/编辑数据库"
  },
  "widget.done": {
    en: "Done",
    zh: "完成"
  },
  "widget.database": {
    en: "Database",
    zh: "数据库"
  },
  "widget.openSidePanel": {
    en: "Open the side panel for full database management.",
    zh: "打开侧边栏以进行完整的数据库管理。"
  },
  "widget.clickExtIcon": {
    en: "Click the extension icon → Open Side Panel",
    zh: "点击扩展图标 → 打开侧边栏"
  },
  "widget.filling": {
    en: "Filling...",
    zh: "填充中..."
  },
  "widget.preparing": {
    en: "Preparing...",
    zh: "准备中..."
  },
  "widget.scanning": {
    en: "Scanning",
    zh: "扫描中"
  },
  "widget.thinking": {
    en: "Thinking",
    zh: "思考中"
  },
  "widget.complete": {
    en: "Complete!",
    zh: "完成！"
  },
  "widget.processing": {
    en: "Processing...",
    zh: "处理中..."
  },
  "widget.allFieldsFilled": {
    en: "All fields filled!",
    zh: "所有字段已填充！"
  },
  "widget.fieldOf": {
    en: "Field {current} of {total}",
    zh: "字段 {current}/{total}"
  },
  // AI Promotion Bubble
  "aiPromo.title": {
    en: "Enable AI to fill more fields",
    zh: "启用 AI 可填充更多字段"
  },
  "aiPromo.thisFill": {
    en: "This fill:",
    zh: "本次填充:"
  },
  "aiPromo.fields": {
    en: "{filled}/{total} fields ({rate}%)",
    zh: "{filled}/{total} 个字段 ({rate}%)"
  },
  "aiPromo.withAi": {
    en: "With AI:",
    zh: "启用 AI 后:"
  },
  "aiPromo.canRecognize": {
    en: "Can recognize ~95% fields",
    zh: "可识别 ~95% 字段"
  },
  "aiPromo.benefit1": {
    en: "Smarter field recognition",
    zh: "更智能的字段识别"
  },
  "aiPromo.benefit2": {
    en: "Support complex dropdowns",
    zh: "支持复杂下拉框"
  },
  "aiPromo.benefit3": {
    en: "Auto-learn new forms",
    zh: "自动学习新表单"
  },
  "aiPromo.dismiss": {
    en: "Don't remind for 3 days",
    zh: "3天内不再提醒"
  },
  "aiPromo.tryAi": {
    en: "Enable AI Features",
    zh: "启用 AI 功能"
  },
  "aiPromo.privacy": {
    en: "Only field labels are sent, not your data",
    zh: "仅发送字段标签，不发送您的数据"
  },
  // Toast messages
  "toast.filled": {
    en: "Filled {count} fields successfully!",
    zh: "成功填充 {count} 个字段！"
  },
  "toast.noFieldsDetected": {
    en: "No filled fields detected",
    zh: "未检测到已填充的字段"
  },
  "toast.errorDetecting": {
    en: "Error detecting fields",
    zh: "检测字段时出错"
  },
  "toast.errorFilling": {
    en: "Error filling fields",
    zh: "填充字段时出错"
  },
  "toast.errorSaving": {
    en: "Error saving fields",
    zh: "保存字段时出错"
  },
  "toast.extensionUpdated": {
    en: "Extension updated. Please refresh the page.",
    zh: "扩展已更新。请刷新页面。"
  },
  "toast.saved": {
    en: "Saved: {details}",
    zh: "已保存: {details}"
  },
  "toast.new": {
    en: "{count} new",
    zh: "{count} 个新增"
  },
  "toast.replaced": {
    en: "{count} replaced",
    zh: "{count} 个替换"
  },
  "toast.noNewFields": {
    en: "No new fields to save ({count} skipped as UNKNOWN)",
    zh: "没有新字段需要保存（{count} 个因为未知类型被跳过）"
  },
  "toast.allInDb": {
    en: "All fields already in database",
    zh: "所有字段已在数据库中"
  },
  "toast.autoFilled": {
    en: "Auto-filled {count} new field(s)",
    zh: "自动填充了 {count} 个新字段"
  },
  "toast.filledInSection": {
    en: "Filled {count} fields in new {section} entry",
    zh: "在新的{section}条目中填充了 {count} 个字段"
  },
  "toast.sidePanelHint": {
    en: "Click extension icon to open side panel",
    zh: "点击扩展图标以打开侧边栏"
  },
  "toast.sidePanelNotAvailable": {
    en: "Side panel not available",
    zh: "侧边栏不可用"
  },
  // Fill debug reasons
  "debug.autofillDisabled": {
    en: "Autofill is disabled for this site. Enable it in settings.",
    zh: "此网站的自动填充已禁用。请在设置中启用。"
  },
  "debug.noFields": {
    en: "No form fields found on this page.",
    zh: "此页面上未找到表单字段。"
  },
  "debug.unknownTypes": {
    en: "Found {count} fields but couldn't identify their types.",
    zh: "找到 {count} 个字段，但无法识别其类型。"
  },
  "debug.noAnswers": {
    en: "Found {count} fields but no matching answers in database. Save some answers first.",
    zh: "找到 {count} 个字段，但数据库中没有匹配的答案。请先保存一些答案。"
  },
  "debug.manualSelection": {
    en: "Found {count} fields requiring manual selection (see badges).",
    zh: "找到 {count} 个需要手动选择的字段（请查看标记）。"
  },
  "debug.noMatch": {
    en: "No matching fields found. Check console for debug details.",
    zh: "未找到匹配的字段。请查看控制台了解详情。"
  },
  // Login prompts
  "toast.loginForAi": {
    en: "Sign in to try AI-enhanced filling for better accuracy!",
    zh: "登录即可试用 AI 增强填充，获得更高准确率！"
  },
  "toast.loginAction": {
    en: "Sign In",
    zh: "登录"
  },
  "toast.enableAutofillPrompt": {
    en: "Enable auto-fill for this site? Next time fields will fill automatically.",
    zh: "是否为此网站启用自动填充？下次将自动填写表单。"
  },
  "toast.enableAutofillAction": {
    en: "Enable",
    zh: "启用"
  },
  "toast.autofillEnabled": {
    en: "Auto-fill enabled for this site!",
    zh: "已为此网站启用自动填充！"
  }
};
function t(key, params) {
  const msg = messages[key];
  if (!msg) {
    console.warn(`Missing translation key: ${key}`);
    return key;
  }
  let text = msg[currentLocale] || msg.en;
  return text;
}

const PRIVACY_POLICY_URL$1 = "https://www.onefil.help/privacy";
function PrivacySection({ llmEnabled, llmProvider }) {
  const [consent, setConsent] = reactExports.useState(null);
  const [dataSummary, setDataSummary] = reactExports.useState({ answersCount: 0, experiencesCount: 0, observationsCount: 0 });
  const [loading, setLoading] = reactExports.useState(true);
  const [deleting, setDeleting] = reactExports.useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = reactExports.useState(false);
  const [expanded, setExpanded] = reactExports.useState(false);
  reactExports.useEffect(() => {
    loadData();
  }, []);
  async function loadData() {
    setLoading(true);
    try {
      const [consentState, answers, experiences, observations] = await Promise.all([
        getConsentState(),
        storage.answers.getAll(),
        storage.experiences.getAll(),
        storage.observations.getRecent(1e3)
      ]);
      setConsent(consentState);
      setDataSummary({
        answersCount: answers.length,
        experiencesCount: experiences.length,
        observationsCount: observations.length
      });
    } catch (error) {
      console.error("Failed to load privacy data:", error);
    } finally {
      setLoading(false);
    }
  }
  async function handleToggleLLMConsent() {
    if (!consent) return;
    const newConsent = createConsentPreferences({
      dataCollection: consent.dataCollection,
      llmDataSharing: !consent.llmDataSharing,
      acknowledgedPrivacyPolicy: consent.acknowledgedPrivacyPolicy
    });
    await setConsentState(newConsent);
    setConsent(newConsent);
  }
  async function handleDeleteAllData() {
    setDeleting(true);
    try {
      await storage.clearAll();
      setDataSummary({ answersCount: 0, experiencesCount: 0, observationsCount: 0 });
      setShowDeleteConfirm(false);
    } catch (error) {
      console.error("Failed to delete data:", error);
    } finally {
      setDeleting(false);
    }
  }
  if (loading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-white rounded-lg border border-gray-200 p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "animate-pulse space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-5 bg-gray-200 rounded w-1/3" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-4 bg-gray-200 rounded w-2/3" })
    ] }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-lg border border-gray-200 overflow-hidden", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        onClick: () => setExpanded(!expanded),
        className: "w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50 transition-colors",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "w-5 h-5 text-green-500" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-gray-900", children: t("privacy.title") })
          ] }),
          expanded ? /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronUp, { className: "w-4 h-4 text-gray-400" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "w-4 h-4 text-gray-400" })
        ]
      }
    ),
    expanded && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 pb-4 space-y-4 border-t border-gray-100 pt-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "a",
        {
          href: PRIVACY_POLICY_URL$1,
          target: "_blank",
          rel: "noopener noreferrer",
          className: "flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "w-4 h-4 text-blue-500" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-medium text-gray-700", children: t("privacy.policy") })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-4 h-4 text-gray-400" })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-blue-50 rounded-lg", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Database, { className: "w-4 h-4 text-blue-500" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-medium text-gray-700", children: t("privacy.dataSummary") })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 gap-2 text-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-lg p-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-bold text-gray-900", children: dataSummary.answersCount }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-gray-500", children: t("privacy.savedAnswers") })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-lg p-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-bold text-gray-900", children: dataSummary.experiencesCount }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-gray-500", children: t("privacy.workEducation") })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-lg p-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-lg font-bold text-gray-900", children: dataSummary.observationsCount }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-gray-500", children: t("privacy.fillRecords") })
          ] })
        ] })
      ] }),
      llmEnabled && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-amber-50 border border-amber-200 rounded-lg", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-amber-800", children: /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: t("privacy.aiEnabled") }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-amber-700 mt-1", children: [
              t("privacy.aiDataSentTo"),
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: llmProvider })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-amber-600 mt-1", children: t("privacy.aiDataNote") })
          ] })
        ] }),
        consent && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-amber-700", children: t("privacy.allowAiSharing") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: handleToggleLLMConsent,
              className: `relative inline-flex h-5 w-9 items-center rounded-full transition-colors ${consent.llmDataSharing ? "bg-amber-500" : "bg-gray-300"}`,
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: `inline-block h-3 w-3 transform rounded-full bg-white transition-transform ${consent.llmDataSharing ? "translate-x-5" : "translate-x-1"}`
                }
              )
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-t border-gray-100 pt-4", children: showDeleteConfirm ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-red-50 border border-red-200 rounded-lg", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-red-800 font-medium mb-2", children: t("privacy.deleteConfirm") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-red-600 mb-3", children: t("privacy.deleteWarning") }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: () => setShowDeleteConfirm(false),
              className: "flex-1 px-3 py-1.5 text-sm text-gray-600 bg-white border border-gray-300 rounded-lg hover:bg-gray-50",
              children: t("privacy.cancel")
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              onClick: handleDeleteAllData,
              disabled: deleting,
              className: "flex-1 px-3 py-1.5 text-sm text-white bg-red-600 rounded-lg hover:bg-red-700 disabled:opacity-50 flex items-center justify-center gap-1",
              children: [
                deleting ? /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-3 h-3 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3 h-3" }),
                deleting ? t("privacy.deleting") : t("privacy.confirmDelete")
              ]
            }
          )
        ] })
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          onClick: () => setShowDeleteConfirm(true),
          className: "w-full flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-red-600 bg-red-50 rounded-lg hover:bg-red-100 transition-colors",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4" }),
            t("privacy.deleteAll")
          ]
        }
      ) })
    ] })
  ] });
}

const WEBSITE_URL = "https://www.onefil.help";
const DEFAULT_CONFIG = {
  enabled: true,
  // LLM is enabled by default (uses backend API)
  useCustomApi: false,
  // Default to backend API
  provider: "openai",
  apiKey: "",
  model: "gpt-4o-mini",
  disableThinking: false
};
const PROVIDERS = [
  { id: "openai", name: "OpenAI", models: ["gpt-4o-mini", "gpt-4o", "gpt-3.5-turbo"], endpoint: "https://api.openai.com/v1/chat/completions" },
  { id: "anthropic", name: "Anthropic", models: ["claude-3-haiku-20240307", "claude-3-sonnet-20240229"], endpoint: "https://api.anthropic.com/v1/messages" },
  { id: "dashscope", name: "Aliyun DashScope (通义千问)", models: ["qwen-plus", "qwen-turbo", "qwen-max", "qwen-long"], endpoint: "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions" },
  { id: "deepseek", name: "DeepSeek", models: ["deepseek-chat", "deepseek-coder"], endpoint: "https://api.deepseek.com/v1/chat/completions" },
  { id: "zhipu", name: "Zhipu AI (智谱)", models: ["glm-4-flash", "glm-4", "glm-4-plus"], endpoint: "https://open.bigmodel.cn/api/paas/v4/chat/completions" },
  { id: "custom", name: "Custom Endpoint", models: [], endpoint: "" }
];
function Settings() {
  const [config, setConfig] = reactExports.useState(DEFAULT_CONFIG);
  const [devModeEnabled, setDevModeEnabled] = reactExports.useState(false);
  const [fillAnimationEnabled, setFillAnimationEnabled] = reactExports.useState(true);
  const [saving, setSaving] = reactExports.useState(false);
  const [saved, setSaved] = reactExports.useState(false);
  const [language, setLanguage] = reactExports.useState(getUserPreference());
  const [user, setUser] = reactExports.useState(null);
  const [credits, setCredits] = reactExports.useState(null);
  const [loadingAuth, setLoadingAuth] = reactExports.useState(true);
  const [loggingIn, setLoggingIn] = reactExports.useState(false);
  const [loginError, setLoginError] = reactExports.useState("");
  const [refreshingCredits, setRefreshingCredits] = reactExports.useState(false);
  reactExports.useEffect(() => {
    (async () => {
      const result = await chrome.storage.local.get(["llmConfig", "devSettings", "fillAnimationConfig"]);
      if (result.llmConfig) setConfig({ ...DEFAULT_CONFIG, ...result.llmConfig });
      if (result.devSettings) setDevModeEnabled(result.devSettings.devModeEnabled ?? false);
      if (result.fillAnimationConfig) setFillAnimationEnabled(result.fillAnimationConfig.enabled ?? true);
      const authState = await storage.auth.getAuthState();
      if (authState && authState.expiresAt > Date.now()) {
        setUser(authState.user);
        setCredits(await storage.auth.fetchCredits());
      }
      setLoadingAuth(false);
    })();
  }, []);
  async function handleLogin() {
    setLoggingIn(true);
    setLoginError("");
    try {
      const redirectUrl = chrome.identity.getRedirectURL("callback");
      const authUrl = `${WEBSITE_URL}/extension/auth?redirect_uri=${encodeURIComponent(redirectUrl)}`;
      const responseUrl = await new Promise((resolve, reject) => {
        chrome.identity.launchWebAuthFlow({ url: authUrl, interactive: true }, (callbackUrl) => {
          if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
          else if (callbackUrl) resolve(callbackUrl);
          else reject(new Error("No callback URL received"));
        });
      });
      const encodedToken = new URL(responseUrl).searchParams.get("token");
      if (!encodedToken) throw new Error("No token in callback");
      const tokenData = JSON.parse(decodeURIComponent(encodedToken));
      if (!tokenData.accessToken || !tokenData.user) throw new Error("Invalid token data");
      await storage.auth.setAuthState(tokenData);
      setUser(tokenData.user);
      setCredits(await storage.auth.fetchCredits());
    } catch (err) {
      setLoginError(err instanceof Error ? err.message : "Login failed");
    } finally {
      setLoggingIn(false);
    }
  }
  async function handleRefreshCredits() {
    setRefreshingCredits(true);
    setCredits(await storage.auth.fetchCredits());
    setRefreshingCredits(false);
  }
  async function handleLogout() {
    await storage.auth.clearAuthState();
    setUser(null);
    setCredits(null);
  }
  async function toggleDevMode() {
    const newValue = !devModeEnabled;
    setDevModeEnabled(newValue);
    await chrome.storage.local.set({ devSettings: { devModeEnabled: newValue } });
  }
  async function toggleFillAnimation() {
    const newValue = !fillAnimationEnabled;
    setFillAnimationEnabled(newValue);
    await chrome.storage.local.set({ fillAnimationConfig: { enabled: newValue } });
  }
  async function handleLanguageChange(newLocale) {
    setLanguage(newLocale);
    await setLocale(newLocale);
    window.location.reload();
  }
  async function saveConfig() {
    setSaving(true);
    await chrome.storage.local.set({ llmConfig: config });
    setSaved(true);
    setTimeout(() => setSaved(false), 2e3);
    setSaving(false);
  }
  function handleProviderChange(provider) {
    setConfig((prev) => ({
      ...prev,
      provider,
      model: "",
      endpoint: provider === "custom" ? prev.endpoint || "" : void 0
    }));
  }
  const currentProvider = PROVIDERS.find((p) => p.id === config.provider);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-lg border border-gray-200 p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(User, { className: "w-5 h-5 text-blue-500" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-gray-900", children: t("settings.account") })
      ] }),
      loadingAuth ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-gray-500", children: t("settings.loading") }) : user ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-gray-900", children: user.displayName }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500", children: user.email })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              onClick: handleLogout,
              className: "flex items-center gap-1 text-sm text-gray-500 hover:text-gray-700",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "w-4 h-4" }),
                t("settings.signOut")
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-gray-50 rounded-lg p-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(CreditCard, { className: "w-4 h-4 text-blue-500" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-medium text-gray-700", children: t("settings.credits") })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  onClick: handleRefreshCredits,
                  disabled: refreshingCredits,
                  className: "p-1 text-gray-400 hover:text-gray-600",
                  title: "Refresh credits",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: `w-3 h-3 ${refreshingCredits ? "animate-spin" : ""}` })
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-right", children: credits?.subscription ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 text-green-600", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Infinity$1, { className: "w-4 h-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-semibold", children: t("settings.unlimited") })
              ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-lg font-bold text-gray-900", children: credits?.balance ?? "..." }) })
            ] })
          ] }),
          credits?.subscription && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-gray-500 mt-1", children: [
            credits.subscription.planId,
            " - ",
            t("settings.renews"),
            " ",
            new Date(credits.subscription.expiresAt).toLocaleDateString()
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "a",
          {
            href: `${WEBSITE_URL}/pricing`,
            target: "_blank",
            rel: "noopener noreferrer",
            className: "flex items-center justify-center gap-2 w-full px-4 py-2 text-sm font-medium text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(CreditCard, { className: "w-4 h-4" }),
              t("settings.buyCredits"),
              /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
            ]
          }
        )
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-600", children: t("settings.loginDesc") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: handleLogin,
            disabled: loggingIn,
            className: "flex items-center justify-center gap-2 w-full px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors",
            children: loggingIn ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin" }),
              t("settings.loggingIn")
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(LogIn, { className: "w-4 h-4" }),
              t("settings.login")
            ] })
          }
        ),
        loginError && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-red-500", children: loginError }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500 text-center", children: t("settings.noAccountNeeded") })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-lg border border-gray-200 p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-5 h-5 text-purple-500" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-gray-900", children: t("settings.aiEnhancement") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500", children: user ? t("settings.aiEnhancementDesc") : t("settings.aiEnhancementLoginRequired") })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => {
              const newConfig = { ...config, enabled: !config.enabled };
              setConfig(newConfig);
              chrome.storage.local.set({ llmConfig: newConfig });
            },
            disabled: !user && !config.useCustomApi,
            className: `relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${config.enabled ? "bg-purple-600" : "bg-gray-200"} ${!user && !config.useCustomApi ? "opacity-50 cursor-not-allowed" : ""}`,
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                className: `inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${config.enabled ? "translate-x-6" : "translate-x-1"}`
              }
            )
          }
        )
      ] }),
      config.enabled && user && !config.useCustomApi && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-green-600 mt-2 flex items-center gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheckBig, { className: "w-3 h-3" }),
        t("settings.usingBackendApi")
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-lg border border-gray-200 p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-gray-900 mb-2", children: t("settings.about") }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500", children: "OneFillr v1.0.0" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500 mt-1", children: t("settings.aboutDesc") })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-white rounded-lg border border-gray-200 p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Globe, { className: "w-5 h-5 text-blue-500" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-gray-900", children: t("settings.language") })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "select",
        {
          value: language,
          onChange: (e) => handleLanguageChange(e.target.value),
          className: "px-3 py-1.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "auto", children: t("settings.language.auto") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "en", children: t("settings.language.en") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "zh", children: t("settings.language.zh") })
          ]
        }
      )
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-white rounded-lg border border-gray-200 p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Type, { className: "w-5 h-5 text-green-500" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-gray-900", children: t("settings.typingAnimation") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500", children: t("settings.typingAnimationDesc") })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: toggleFillAnimation,
          className: `relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${fillAnimationEnabled ? "bg-green-600" : "bg-gray-200"}`,
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "span",
            {
              className: `inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${fillAnimationEnabled ? "translate-x-6" : "translate-x-1"}`
            }
          )
        }
      )
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      PrivacySection,
      {
        llmEnabled: config.enabled,
        llmProvider: config.useCustomApi ? PROVIDERS.find((p) => p.id === config.provider)?.name || config.provider : "Backend API"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-lg border border-gray-200 p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CodeXml, { className: "w-5 h-5 text-purple-500" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-gray-900", children: t("settings.devMode") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500", children: t("settings.devModeDesc") })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: toggleDevMode,
            className: `relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${devModeEnabled ? "bg-purple-600" : "bg-gray-200"}`,
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                className: `inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${devModeEnabled ? "translate-x-6" : "translate-x-1"}`
              }
            )
          }
        )
      ] }),
      devModeEnabled && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 pt-4 border-t border-gray-200 space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-medium text-gray-700", children: t("settings.useCustomApi") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500", children: t("settings.useCustomApiDesc") })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: () => setConfig((prev) => ({ ...prev, useCustomApi: !prev.useCustomApi })),
              className: `relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${config.useCustomApi ? "bg-blue-600" : "bg-gray-200"}`,
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "span",
                {
                  className: `inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${config.useCustomApi ? "translate-x-6" : "translate-x-1"}`
                }
              )
            }
          )
        ] }),
        config.useCustomApi && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 pl-2 border-l-2 border-blue-200", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: t("settings.llm.provider") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "select",
              {
                value: config.provider,
                onChange: (e) => handleProviderChange(e.target.value),
                className: "w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500",
                children: PROVIDERS.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: p.id, children: p.name }, p.id))
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Key, { className: "w-3.5 h-3.5" }),
              t("settings.llm.apiKey")
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "password",
                value: config.apiKey,
                onChange: (e) => setConfig((prev) => ({ ...prev, apiKey: e.target.value })),
                placeholder: "sk-...",
                className: "w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500"
              }
            )
          ] }),
          currentProvider && currentProvider.models.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: t("settings.llm.model") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "text",
                list: `models-${config.provider}`,
                value: config.model || "",
                onChange: (e) => setConfig((prev) => ({ ...prev, model: e.target.value })),
                placeholder: t("settings.llm.modelPlaceholder"),
                className: "w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("datalist", { id: `models-${config.provider}`, children: currentProvider.models.map((m) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: m }, m)) })
          ] }),
          config.provider === "custom" && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: t("settings.llm.modelName") }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: config.model || "",
                  onChange: (e) => setConfig((prev) => ({ ...prev, model: e.target.value })),
                  placeholder: "e.g., gpt-4o-mini",
                  className: "w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-medium text-gray-700 mb-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Server, { className: "w-3.5 h-3.5" }),
                t("settings.llm.endpoint")
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "url",
                  value: config.endpoint || "",
                  onChange: (e) => setConfig((prev) => ({ ...prev, endpoint: e.target.value })),
                  placeholder: "https://api.example.com/v1/chat/completions",
                  className: "w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500"
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: saveConfig,
              disabled: saving,
              className: "w-full flex items-center justify-center gap-2 px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 disabled:opacity-50",
              children: saved ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheckBig, { className: "w-4 h-4" }),
                t("settings.saved")
              ] }) : t("settings.save")
            }
          )
        ] })
      ] })
    ] })
  ] });
}

const LOG_PREFIX = "[AutoFiller]";
const LLM_LOG_KEY = "autofiller_llm_logs";
const MAX_LLM_LOGS = 100;
async function saveLLMLog(entry) {
  if (typeof chrome === "undefined" || !chrome.storage?.local) {
    console.log(`[AutoFiller LLM] ${entry.type}:`, entry);
    return;
  }
  try {
    const result = await chrome.storage.local.get(LLM_LOG_KEY);
    const logs = result[LLM_LOG_KEY] || [];
    logs.unshift({
      timestamp: Date.now(),
      ...entry
    });
    if (logs.length > MAX_LLM_LOGS) {
      logs.length = MAX_LLM_LOGS;
    }
    await chrome.storage.local.set({ [LLM_LOG_KEY]: logs });
  } catch (e) {
    console.error("[AutoFiller] Failed to save LLM log:", e);
  }
}
async function getLLMLogs() {
  if (typeof chrome === "undefined" || !chrome.storage?.local) {
    return [];
  }
  try {
    const result = await chrome.storage.local.get(LLM_LOG_KEY);
    return result[LLM_LOG_KEY] || [];
  } catch {
    return [];
  }
}
async function clearLLMLogs() {
  if (typeof chrome === "undefined" || !chrome.storage?.local) {
    return;
  }
  try {
    await chrome.storage.local.remove(LLM_LOG_KEY);
  } catch (e) {
    console.error("[AutoFiller] Failed to clear LLM logs:", e);
  }
}
function logLLMRequest(provider, model, prompt) {
  console.group(`${LOG_PREFIX} 🤖 LLM Request`);
  console.log(`Provider: ${provider}, Model: ${model}`);
  console.log(`Prompt: ${prompt.substring(0, 200)}${prompt.length > 200 ? "..." : ""}`);
  console.groupEnd();
}
function logLLMResponse(provider, model, response, latencyMs) {
  console.group(`${LOG_PREFIX} 🤖 LLM Response (${latencyMs.toFixed(0)}ms)`);
  console.log(`Provider: ${provider}, Model: ${model}`);
  console.log(`Response: ${response.substring(0, 200)}${response.length > 200 ? "..." : ""}`);
  console.groupEnd();
}
function logLLMError(provider, model, error) {
  console.group(`${LOG_PREFIX} ❌ LLM Error`);
  console.log(`Provider: ${provider}, Model: ${model}`);
  console.log(`Error: ${error}`);
  console.groupEnd();
}

const API_BASE_URL = "https://www.onefil.help/api";
const TEST_PROFILES = {
  us: {
    name: "US Developer",
    description: "Standard US-based developer profile",
    answers: [
      { type: Taxonomy.FULL_NAME, value: "John Smith", display: "John Smith" },
      { type: Taxonomy.FIRST_NAME, value: "John", display: "John" },
      { type: Taxonomy.LAST_NAME, value: "Smith", display: "Smith" },
      { type: Taxonomy.EMAIL, value: "john.smith@example.com", display: "john.smith@example.com" },
      { type: Taxonomy.PHONE, value: "+14155551234", display: "+1 (415) 555-1234" },
      { type: Taxonomy.CITY, value: "San Francisco", display: "San Francisco" },
      { type: Taxonomy.LOCATION, value: "San Francisco, CA", display: "San Francisco, CA" },
      { type: Taxonomy.LINKEDIN, value: "https://linkedin.com/in/johnsmith", display: "linkedin.com/in/johnsmith" },
      { type: Taxonomy.GITHUB, value: "https://github.com/johnsmith", display: "github.com/johnsmith" },
      { type: Taxonomy.PORTFOLIO, value: "https://johnsmith.dev", display: "johnsmith.dev" },
      { type: Taxonomy.SCHOOL, value: "Stanford University", display: "Stanford University" },
      { type: Taxonomy.DEGREE, value: "Bachelor's", display: "Bachelor's Degree" },
      { type: Taxonomy.MAJOR, value: "Computer Science", display: "Computer Science" },
      { type: Taxonomy.GRAD_DATE, value: "2020-06-01", display: "June 2020" },
      { type: Taxonomy.GRAD_YEAR, value: "2020", display: "2020" },
      { type: Taxonomy.GRAD_MONTH, value: "06", display: "June" },
      { type: Taxonomy.WORK_AUTH, value: "US Citizen", display: "US Citizen" },
      { type: Taxonomy.NEED_SPONSORSHIP, value: "No", display: "No" }
    ]
  },
  cn: {
    name: "CN Developer",
    description: "Chinese developer profile with international experience",
    answers: [
      { type: Taxonomy.FULL_NAME, value: "Wei Zhang", display: "Wei Zhang" },
      { type: Taxonomy.FIRST_NAME, value: "Wei", display: "Wei" },
      { type: Taxonomy.LAST_NAME, value: "Zhang", display: "Zhang" },
      { type: Taxonomy.EMAIL, value: "wei.zhang@example.com", display: "wei.zhang@example.com" },
      { type: Taxonomy.PHONE, value: "+8613812345678", display: "+86 138 1234 5678" },
      { type: Taxonomy.CITY, value: "Beijing", display: "Beijing" },
      { type: Taxonomy.LOCATION, value: "Beijing, China", display: "Beijing, China" },
      { type: Taxonomy.LINKEDIN, value: "https://linkedin.com/in/weizhang", display: "linkedin.com/in/weizhang" },
      { type: Taxonomy.GITHUB, value: "https://github.com/weizhang", display: "github.com/weizhang" },
      { type: Taxonomy.SCHOOL, value: "Tsinghua University", display: "Tsinghua University" },
      { type: Taxonomy.DEGREE, value: "Master's", display: "Master's Degree" },
      { type: Taxonomy.MAJOR, value: "Software Engineering", display: "Software Engineering" },
      { type: Taxonomy.GRAD_DATE, value: "2022-07-01", display: "July 2022" },
      { type: Taxonomy.GRAD_YEAR, value: "2022", display: "2022" },
      { type: Taxonomy.GRAD_MONTH, value: "07", display: "July" },
      { type: Taxonomy.WORK_AUTH, value: "Requires Visa", display: "Requires Visa" },
      { type: Taxonomy.NEED_SPONSORSHIP, value: "Yes", display: "Yes" }
    ]
  },
  intl: {
    name: "International",
    description: "International profile with diverse background",
    answers: [
      { type: Taxonomy.FULL_NAME, value: "Maria Garcia", display: "Maria Garcia" },
      { type: Taxonomy.FIRST_NAME, value: "Maria", display: "Maria" },
      { type: Taxonomy.LAST_NAME, value: "Garcia", display: "Garcia" },
      { type: Taxonomy.EMAIL, value: "maria.garcia@example.com", display: "maria.garcia@example.com" },
      { type: Taxonomy.PHONE, value: "+442071234567", display: "+44 20 7123 4567" },
      { type: Taxonomy.CITY, value: "London", display: "London" },
      { type: Taxonomy.LOCATION, value: "London, UK", display: "London, UK" },
      { type: Taxonomy.LINKEDIN, value: "https://linkedin.com/in/mariagarcia", display: "linkedin.com/in/mariagarcia" },
      { type: Taxonomy.GITHUB, value: "https://github.com/mariagarcia", display: "github.com/mariagarcia" },
      { type: Taxonomy.PORTFOLIO, value: "https://mariagarcia.io", display: "mariagarcia.io" },
      { type: Taxonomy.SCHOOL, value: "University of Cambridge", display: "University of Cambridge" },
      { type: Taxonomy.DEGREE, value: "PhD", display: "PhD" },
      { type: Taxonomy.MAJOR, value: "Machine Learning", display: "Machine Learning" },
      { type: Taxonomy.GRAD_DATE, value: "2023-09-01", display: "September 2023" },
      { type: Taxonomy.GRAD_YEAR, value: "2023", display: "2023" },
      { type: Taxonomy.GRAD_MONTH, value: "09", display: "September" },
      { type: Taxonomy.WORK_AUTH, value: "Work Permit", display: "Work Permit" },
      { type: Taxonomy.NEED_SPONSORSHIP, value: "No", display: "No" }
    ]
  }
};
function Developer() {
  const [loading, setLoading] = reactExports.useState(false);
  const [message, setMessage] = reactExports.useState(null);
  const [llmConfig, setLLMConfig] = reactExports.useState(null);
  const [chatInput, setChatInput] = reactExports.useState("");
  const [chatMessages, setChatMessages] = reactExports.useState([]);
  const [chatLoading, setChatLoading] = reactExports.useState(false);
  const [llmLogs, setLLMLogs] = reactExports.useState([]);
  const [showLogs, setShowLogs] = reactExports.useState(false);
  const [animationConfig, setAnimationConfig] = reactExports.useState(DEFAULT_FILL_ANIMATION_CONFIG);
  const [animationTesting, setAnimationTesting] = reactExports.useState(false);
  const [isLoggedIn, setIsLoggedIn] = reactExports.useState(false);
  const [animationStage, setAnimationStage] = reactExports.useState("idle");
  const [demoInputs, setDemoInputs] = reactExports.useState([
    { label: "Full Name", targetValue: "John Smith", currentValue: "" },
    { label: "Email", targetValue: "john.smith@example.com", currentValue: "" }
  ]);
  const [currentFieldIndex, setCurrentFieldIndex] = reactExports.useState(0);
  const [animationProgress, setAnimationProgress] = reactExports.useState(0);
  reactExports.useEffect(() => {
    loadLLMConfig();
    loadLLMLogs();
    loadAnimationConfig();
    checkLoginStatus();
  }, []);
  async function checkLoginStatus() {
    try {
      const token = await storage.auth.getAccessToken();
      setIsLoggedIn(!!token);
    } catch {
      setIsLoggedIn(false);
    }
  }
  async function loadLLMConfig() {
    try {
      const result = await chrome.storage.local.get("llmConfig");
      const defaultConfig = {
        enabled: true,
        useCustomApi: false,
        provider: "openai",
        apiKey: ""
      };
      setLLMConfig(result.llmConfig ? { ...defaultConfig, ...result.llmConfig } : defaultConfig);
    } catch {
      setLLMConfig({
        enabled: true,
        useCustomApi: false,
        provider: "openai",
        apiKey: ""
      });
    }
  }
  async function loadLLMLogs() {
    const logs = await getLLMLogs();
    setLLMLogs(logs);
  }
  async function loadAnimationConfig() {
    try {
      const result = await chrome.storage.local.get("fillAnimationConfig");
      if (result.fillAnimationConfig) {
        setAnimationConfig({ ...DEFAULT_FILL_ANIMATION_CONFIG, ...result.fillAnimationConfig });
      }
    } catch {
    }
  }
  async function saveAnimationConfig(config) {
    setAnimationConfig(config);
    await chrome.storage.local.set({ fillAnimationConfig: config });
    showMessage("success", "Animation config saved");
  }
  function updateAnimationConfig(updates) {
    const newConfig = { ...animationConfig, ...updates };
    saveAnimationConfig(newConfig);
  }
  function calculateCharDelay() {
    const totalChars = demoInputs.reduce((sum, input) => sum + input.targetValue.length, 0);
    const totalFields = demoInputs.length;
    const stageTime = animationConfig.stageDelays.scanning + animationConfig.stageDelays.thinking;
    const fieldDelayTime = totalFields * animationConfig.fieldDelay;
    const availableTime = animationConfig.maxDuration * 1e3 - stageTime - fieldDelayTime;
    if (totalChars === 0) return animationConfig.minCharDelay;
    const calculatedDelay = availableTime / totalChars;
    return Math.max(animationConfig.minCharDelay, Math.min(animationConfig.maxCharDelay, calculatedDelay));
  }
  async function playDemoAnimation() {
    if (animationTesting) return;
    setAnimationTesting(true);
    setDemoInputs((prev) => prev.map((input) => ({ ...input, currentValue: "" })));
    setCurrentFieldIndex(0);
    setAnimationProgress(0);
    const charDelay = calculateCharDelay();
    try {
      setAnimationStage("scanning");
      setAnimationProgress(5);
      await new Promise((r) => setTimeout(r, animationConfig.stageDelays.scanning));
      setAnimationStage("thinking");
      setAnimationProgress(15);
      await new Promise((r) => setTimeout(r, animationConfig.stageDelays.thinking));
      setAnimationStage("filling");
      const totalChars = demoInputs.reduce((sum, input) => sum + input.targetValue.length, 0);
      let charsFilled = 0;
      for (let fieldIdx = 0; fieldIdx < demoInputs.length; fieldIdx++) {
        setCurrentFieldIndex(fieldIdx);
        const targetValue = demoInputs[fieldIdx].targetValue;
        for (let charIdx = 0; charIdx <= targetValue.length; charIdx++) {
          const partialValue = targetValue.substring(0, charIdx);
          setDemoInputs((prev) => prev.map(
            (input, idx) => idx === fieldIdx ? { ...input, currentValue: partialValue } : input
          ));
          charsFilled++;
          const progress = 20 + charsFilled / totalChars * 75;
          setAnimationProgress(Math.min(95, progress));
          if (charIdx < targetValue.length) {
            await new Promise((r) => setTimeout(r, charDelay));
          }
        }
        if (fieldIdx < demoInputs.length - 1) {
          await new Promise((r) => setTimeout(r, animationConfig.fieldDelay));
        }
      }
      setAnimationStage("done");
      setAnimationProgress(100);
      await new Promise((r) => setTimeout(r, 1500));
      setAnimationStage("idle");
    } catch (err) {
      showMessage("error", "Animation error");
    } finally {
      setAnimationTesting(false);
    }
  }
  function resetDemo() {
    setAnimationStage("idle");
    setDemoInputs((prev) => prev.map((input) => ({ ...input, currentValue: "" })));
    setCurrentFieldIndex(0);
    setAnimationProgress(0);
    setAnimationTesting(false);
  }
  async function handleClearLLMLogs() {
    await clearLLMLogs();
    setLLMLogs([]);
    showMessage("success", "LLM logs cleared");
  }
  async function sendChatMessage() {
    if (!chatInput.trim() || chatLoading) return;
    const useBackendApi = !llmConfig?.useCustomApi;
    if (useBackendApi) {
      if (!isLoggedIn) {
        showMessage("error", "Please login to test backend API");
        return;
      }
    } else {
      if (!llmConfig?.apiKey) {
        showMessage("error", "Please configure API key first");
        return;
      }
    }
    const userMessage = chatInput.trim();
    setChatInput("");
    setChatMessages((prev) => [...prev, { role: "user", content: userMessage }]);
    setChatLoading(true);
    const provider = useBackendApi ? "backend" : llmConfig.provider;
    const model = useBackendApi ? "AI Gateway" : llmConfig.model || "gpt-4o-mini";
    const startTime = Date.now();
    logLLMRequest(provider, model, userMessage);
    await saveLLMLog({
      type: "request",
      provider,
      model,
      prompt: userMessage,
      endpoint: useBackendApi ? API_BASE_URL : llmConfig.provider === "custom" ? llmConfig.endpoint : void 0
    });
    try {
      let assistantMessage;
      let latencyMs;
      let tokenUsage;
      if (useBackendApi) {
        const token = await storage.auth.getAccessToken();
        if (!token) throw new Error("Not logged in");
        const response = await fetch(`${API_BASE_URL}/llm/classify`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`
          },
          body: JSON.stringify({
            fields: [{
              index: 0,
              labelText: "Test field",
              name: "test",
              id: "test",
              type: "text",
              placeholder: userMessage,
              // Use user message as context for testing
              surroundingText: userMessage
            }]
          })
        });
        latencyMs = Date.now() - startTime;
        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          if (response.status === 402) {
            throw new Error(`Insufficient credits: ${errorData.balance || 0} remaining`);
          }
          throw new Error(`Backend API error ${response.status}: ${errorData.error || "Unknown"}`);
        }
        const data = await response.json();
        if (!data.success) {
          throw new Error(data.error || "Request failed");
        }
        assistantMessage = `✅ Backend API test successful!

Credits used: ${data.creditsUsed}
Results: ${JSON.stringify(data.results, null, 2)}`;
      } else {
        let endpoint;
        let headers = {
          "Content-Type": "application/json"
        };
        let body;
        const PROVIDER_ENDPOINTS = {
          openai: "https://api.openai.com/v1/chat/completions",
          dashscope: "https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions",
          deepseek: "https://api.deepseek.com/v1/chat/completions",
          zhipu: "https://open.bigmodel.cn/api/paas/v4/chat/completions",
          anthropic: "https://api.anthropic.com/v1/messages"
        };
        if (provider === "anthropic") {
          endpoint = PROVIDER_ENDPOINTS.anthropic;
          headers["x-api-key"] = llmConfig.apiKey;
          headers["anthropic-version"] = "2023-06-01";
          body = {
            model,
            max_tokens: 500,
            messages: [{ role: "user", content: userMessage }]
          };
        } else if (provider === "custom") {
          endpoint = llmConfig.endpoint || "";
          if (!endpoint) throw new Error("Custom endpoint URL not configured");
          headers["Authorization"] = `Bearer ${llmConfig.apiKey}`;
          body = {
            model,
            messages: [{ role: "user", content: userMessage }],
            max_tokens: 500
          };
          console.log("[LLM Test] Custom endpoint request:", {
            endpoint,
            hasAuthHeader: !!headers["Authorization"],
            model
          });
        } else {
          endpoint = PROVIDER_ENDPOINTS[provider] || PROVIDER_ENDPOINTS.openai;
          headers["Authorization"] = `Bearer ${llmConfig.apiKey}`;
          body = {
            model,
            messages: [{ role: "user", content: userMessage }],
            max_tokens: 500
          };
        }
        const response = await fetch(endpoint, {
          method: "POST",
          headers,
          body: JSON.stringify(body)
        });
        latencyMs = Date.now() - startTime;
        if (!response.ok) {
          const errorText = await response.text();
          throw new Error(`API Error ${response.status}: ${errorText}`);
        }
        const data = await response.json();
        if (provider === "anthropic") {
          assistantMessage = data.content?.[0]?.text || "No response";
        } else {
          assistantMessage = data.choices?.[0]?.message?.content || "No response";
        }
        tokenUsage = data.usage ? {
          promptTokens: data.usage.prompt_tokens,
          completionTokens: data.usage.completion_tokens,
          totalTokens: data.usage.total_tokens
        } : void 0;
      }
      logLLMResponse(provider, model, assistantMessage, latencyMs);
      await saveLLMLog({
        type: "response",
        provider,
        model,
        response: assistantMessage,
        latencyMs,
        tokenUsage
      });
      setChatMessages((prev) => [...prev, { role: "assistant", content: assistantMessage }]);
      showMessage("success", `LLM response received (${latencyMs}ms)`);
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Unknown error";
      logLLMError(provider, model, errorMessage);
      await saveLLMLog({
        type: "error",
        provider,
        model,
        error: errorMessage
      });
      setChatMessages((prev) => [...prev, { role: "assistant", content: `❌ Error: ${errorMessage}` }]);
      showMessage("error", `LLM error: ${errorMessage}`);
    } finally {
      setChatLoading(false);
      await loadLLMLogs();
    }
  }
  function generateId() {
    return crypto.randomUUID();
  }
  function showMessage(type, text) {
    setMessage({ type, text });
    setTimeout(() => setMessage(null), 3e3);
  }
  async function loadTestProfile(profileKey) {
    setLoading(true);
    try {
      const profile = TEST_PROFILES[profileKey];
      const now = Date.now();
      const answers = profile.answers.map((a) => ({
        id: generateId(),
        type: a.type,
        value: a.value,
        display: a.display,
        aliases: [],
        sensitivity: SENSITIVE_TYPES.has(a.type) ? "sensitive" : "normal",
        autofillAllowed: !SENSITIVE_TYPES.has(a.type),
        createdAt: now,
        updatedAt: now
      }));
      const answersMap = {};
      for (const answer of answers) {
        answersMap[answer.id] = answer;
      }
      await chrome.storage.local.set({ answers: answersMap });
      showMessage("success", `Loaded "${profile.name}" profile with ${answers.length} fields`);
    } catch (err) {
      showMessage("error", "Failed to load profile");
    } finally {
      setLoading(false);
    }
  }
  async function clearAllData() {
    if (!confirm("This will delete ALL stored data including answers, observations, and settings. Continue?")) {
      return;
    }
    setLoading(true);
    try {
      await chrome.storage.local.clear();
      showMessage("success", "All data cleared");
    } catch (err) {
      showMessage("error", "Failed to clear data");
    } finally {
      setLoading(false);
    }
  }
  async function clearAnswersOnly() {
    if (!confirm("This will delete all saved answers and experiences. Continue?")) {
      return;
    }
    setLoading(true);
    try {
      await chrome.storage.local.remove(["answers", "experiences"]);
      showMessage("success", "All answers and experiences deleted");
    } catch (err) {
      showMessage("error", "Failed to delete answers");
    } finally {
      setLoading(false);
    }
  }
  async function exportData() {
    setLoading(true);
    try {
      const data = await chrome.storage.local.get(null);
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `autofiller-backup-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      showMessage("success", "Data exported successfully");
    } catch (err) {
      showMessage("error", "Failed to export data");
    } finally {
      setLoading(false);
    }
  }
  async function importData() {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json";
    input.onchange = async (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      setLoading(true);
      try {
        const text = await file.text();
        const data = JSON.parse(text);
        const ALLOWED_KEYS = ["answers", "observations", "siteSettings", "experiences", "fillAnimationConfig"];
        const sanitized = {};
        for (const key of ALLOWED_KEYS) {
          if (key in data) sanitized[key] = data[key];
        }
        if (Object.keys(sanitized).length === 0) {
          showMessage("error", "No valid data keys found in file");
          setLoading(false);
          return;
        }
        await chrome.storage.local.set(sanitized);
        showMessage("success", `Imported ${Object.keys(sanitized).length} data keys successfully`);
      } catch (err) {
        showMessage("error", "Failed to import data - invalid format");
      } finally {
        setLoading(false);
      }
    };
    input.click();
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
    message && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex items-center gap-2 p-3 rounded-lg text-sm ${message.type === "success" ? "bg-green-50 text-green-700 border border-green-200" : "bg-red-50 text-red-700 border border-red-200"}`, children: [
      message.type === "success" ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheckBig, { className: "w-4 h-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-4 h-4" }),
      message.text
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-purple-50 rounded-lg border border-purple-200 p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Database, { className: "w-5 h-5 text-purple-600" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-purple-900", children: "Test Profiles" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-purple-700 mb-4", children: "Load pre-configured test data for development and testing" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: Object.keys(TEST_PROFILES).map((key) => {
        const profile = TEST_PROFILES[key];
        const IconComponent = key === "us" ? User : key === "cn" ? Building2 : GraduationCap;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: () => loadTestProfile(key),
            disabled: loading,
            className: "w-full flex items-center gap-3 p-3 bg-white rounded-lg border border-purple-200 hover:border-purple-400 hover:bg-purple-50 transition-colors text-left disabled:opacity-50",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(IconComponent, { className: "w-5 h-5 text-purple-500" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-0", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-medium text-gray-900 text-sm", children: profile.name }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-gray-500 truncate", children: profile.description })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs text-purple-600 font-medium", children: [
                profile.answers.length,
                " fields"
              ] })
            ]
          },
          key
        );
      }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-blue-50 rounded-lg border border-blue-200 p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Bot, { className: "w-5 h-5 text-blue-600" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-blue-900", children: "LLM Connection Test" })
      ] }),
      !llmConfig?.useCustomApi ? (
        // Backend API Mode
        /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-blue-700 mb-3 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Cloud, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "Using: ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium", children: "Backend API (AI Gateway)" })
            ] }),
            isLoggedIn ? /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-green-600 ml-2", children: "✓ Logged in" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-amber-600 ml-2", children: "⚠️ Login required" })
          ] }),
          !isLoggedIn ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-amber-700 bg-amber-100 p-3 rounded-lg", children: "Please login in the Settings tab to test backend API" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
            ChatUI,
            {
              chatMessages,
              chatLoading,
              chatInput,
              setChatInput,
              sendChatMessage,
              clearChat: () => setChatMessages([]),
              placeholder: "Enter field context to test classification..."
            }
          )
        ] })
      ) : (
        // Custom API Mode
        /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: !llmConfig?.apiKey ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-blue-700 bg-blue-100 p-3 rounded-lg", children: "Please configure Custom LLM API key in Settings tab first" }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-blue-700 mb-3 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Key, { className: "w-4 h-4" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "Using: ",
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-medium", children: [
                "Custom API (",
                llmConfig.provider,
                ")"
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-blue-700 mb-3", children: [
            "Model: ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium", children: llmConfig.model || "default" }),
            llmConfig.provider === "custom" && llmConfig.endpoint && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
              "Endpoint: ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-blue-600", children: llmConfig.endpoint })
            ] }),
            llmConfig.provider === "custom" && !llmConfig.endpoint && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-red-500 ml-2", children: "Endpoint not configured" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            ChatUI,
            {
              chatMessages,
              chatLoading,
              chatInput,
              setChatInput,
              sendChatMessage,
              clearChat: () => setChatMessages([]),
              placeholder: "Type a test message..."
            }
          )
        ] }) })
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-gray-50 rounded-lg border border-gray-200 p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(MessageSquare, { className: "w-5 h-5 text-gray-600" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-gray-900", children: "LLM Logs" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs text-gray-500", children: [
            "(",
            llmLogs.length,
            ")"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: () => setShowLogs(!showLogs),
              className: "text-xs text-gray-600 hover:text-gray-800",
              children: showLogs ? "Hide" : "Show"
            }
          ),
          llmLogs.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: handleClearLLMLogs,
              className: "text-xs text-red-600 hover:text-red-800",
              children: "Clear"
            }
          )
        ] })
      ] }),
      showLogs && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2 max-h-64 overflow-y-auto", children: llmLogs.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-gray-500 text-center py-4", children: "No logs yet" }) : llmLogs.map((log, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-xs p-2 rounded border ${log.type === "error" ? "bg-red-50 border-red-200" : log.type === "request" ? "bg-yellow-50 border-yellow-200" : "bg-green-50 border-green-200"}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-1", children: [
          log.type === "error" ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleX, { className: "w-3 h-3 text-red-500" }) : log.type === "request" ? /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-3 h-3 text-yellow-600" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheckBig, { className: "w-3 h-3 text-green-500" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium", children: log.type.toUpperCase() }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-gray-500", children: [
            log.provider,
            "/",
            log.model
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-gray-400 ml-auto flex items-center gap-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "w-3 h-3" }),
            new Date(log.timestamp).toLocaleTimeString()
          ] })
        ] }),
        log.endpoint && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-blue-600 truncate", children: [
          "Endpoint: ",
          log.endpoint
        ] }),
        log.prompt && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-gray-700 truncate", children: [
          "Prompt: ",
          log.prompt
        ] }),
        log.response && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-gray-700 truncate", children: [
          "Response: ",
          log.response
        ] }),
        log.error && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-red-600", children: [
          "Error: ",
          log.error
        ] }),
        log.latencyMs && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-gray-500", children: [
          "Latency: ",
          log.latencyMs,
          "ms"
        ] })
      ] }, idx)) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-indigo-50 rounded-lg border border-indigo-200 p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-5 h-5 text-indigo-600" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-indigo-900", children: "Fill Animation" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-2 cursor-pointer", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-indigo-700", children: "Enabled" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "checkbox",
              checked: animationConfig.enabled,
              onChange: (e) => updateAnimationConfig({ enabled: e.target.checked }),
              className: "w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-indigo-700 mb-4", children: "Typewriter effect with Scanning → Thinking → Filling stages" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-xs mb-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-indigo-800", children: "Max Duration" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-medium text-indigo-900", children: [
              animationConfig.maxDuration,
              "s"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "range",
              min: "3",
              max: "20",
              step: "1",
              value: animationConfig.maxDuration,
              onChange: (e) => updateAnimationConfig({ maxDuration: Number(e.target.value) }),
              className: "w-full h-2 bg-indigo-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-xs mb-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-indigo-800", children: "Min Char Delay" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-medium text-indigo-900", children: [
                animationConfig.minCharDelay,
                "ms"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "range",
                min: "5",
                max: "50",
                step: "5",
                value: animationConfig.minCharDelay,
                onChange: (e) => updateAnimationConfig({ minCharDelay: Number(e.target.value) }),
                className: "w-full h-2 bg-indigo-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-xs mb-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-indigo-800", children: "Max Char Delay" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-medium text-indigo-900", children: [
                animationConfig.maxCharDelay,
                "ms"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "range",
                min: "30",
                max: "150",
                step: "10",
                value: animationConfig.maxCharDelay,
                onChange: (e) => updateAnimationConfig({ maxCharDelay: Number(e.target.value) }),
                className: "w-full h-2 bg-indigo-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-xs mb-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-indigo-800", children: "Scanning Stage" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-medium text-indigo-900", children: [
                animationConfig.stageDelays.scanning,
                "ms"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "range",
                min: "200",
                max: "2000",
                step: "100",
                value: animationConfig.stageDelays.scanning,
                onChange: (e) => updateAnimationConfig({
                  stageDelays: { ...animationConfig.stageDelays, scanning: Number(e.target.value) }
                }),
                className: "w-full h-2 bg-indigo-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-xs mb-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-indigo-800", children: "Thinking Stage" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-medium text-indigo-900", children: [
                animationConfig.stageDelays.thinking,
                "ms"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "input",
              {
                type: "range",
                min: "200",
                max: "2000",
                step: "100",
                value: animationConfig.stageDelays.thinking,
                onChange: (e) => updateAnimationConfig({
                  stageDelays: { ...animationConfig.stageDelays, thinking: Number(e.target.value) }
                }),
                className: "w-full h-2 bg-indigo-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-xs mb-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-indigo-800", children: "Field Delay" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-medium text-indigo-900", children: [
              animationConfig.fieldDelay,
              "ms"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "range",
              min: "0",
              max: "500",
              step: "50",
              value: animationConfig.fieldDelay,
              onChange: (e) => updateAnimationConfig({ fieldDelay: Number(e.target.value) }),
              className: "w-full h-2 bg-indigo-200 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-gradient-to-br from-indigo-900 to-purple-900 rounded-lg p-4 mt-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center gap-2 mb-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-lg", children: [
              animationStage === "idle" && "⏸️",
              animationStage === "scanning" && "🔍",
              animationStage === "thinking" && "🧠",
              animationStage === "filling" && "✍️",
              animationStage === "done" && "✨"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-white font-medium", children: [
              animationStage === "idle" && "Ready",
              animationStage === "scanning" && "Scanning...",
              animationStage === "thinking" && "Thinking...",
              animationStage === "filling" && `Filling: ${demoInputs[currentFieldIndex]?.label || ""}`,
              animationStage === "done" && "Complete!"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-1.5 bg-white/20 rounded-full overflow-hidden mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: "h-full bg-gradient-to-r from-indigo-400 to-purple-400 transition-all duration-100",
              style: { width: `${animationProgress}%` }
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: demoInputs.map((input, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs text-indigo-200 mb-1 block", children: input.label }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `relative bg-white rounded-lg overflow-hidden ${animationStage === "filling" && currentFieldIndex === idx ? "ring-2 ring-indigo-400" : ""}`, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  value: input.currentValue,
                  readOnly: true,
                  placeholder: input.targetValue,
                  className: "w-full px-3 py-2 text-sm text-gray-800 bg-transparent outline-none"
                }
              ),
              animationStage === "filling" && currentFieldIndex === idx && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute right-2 top-1/2 -translate-y-1/2 w-0.5 h-4 bg-indigo-600 animate-pulse" })
            ] })
          ] }, idx)) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2 pt-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              onClick: playDemoAnimation,
              disabled: animationTesting || !animationConfig.enabled,
              className: "flex-1 flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 disabled:opacity-50 transition-colors",
              children: [
                animationTesting ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: "w-4 h-4" }),
                animationTesting ? "Playing..." : "Play Demo"
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              onClick: resetDemo,
              disabled: animationTesting,
              className: "flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium text-indigo-700 bg-white border border-indigo-300 rounded-lg hover:bg-indigo-50 disabled:opacity-50 transition-colors",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-4 h-4" }),
                "Reset"
              ]
            }
          )
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-lg border border-gray-200 p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-gray-900 mb-3", children: "Data Management" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: exportData,
            disabled: loading,
            className: "w-full flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 disabled:opacity-50 transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-4 h-4" }),
              "Export All Data"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: importData,
            disabled: loading,
            className: "w-full flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 disabled:opacity-50 transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "w-4 h-4" }),
              "Import Data"
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-amber-50 rounded-lg border border-amber-200 p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-5 h-5 text-amber-600" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-amber-900", children: "Debug Tools" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: async () => {
              await chrome.storage.local.remove("onboardingComplete");
              showMessage("success", "Onboarding reset. Reload the extension to see it.");
              window.location.reload();
            },
            disabled: loading,
            className: "w-full flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-amber-700 bg-white border border-amber-300 rounded-lg hover:bg-amber-100 disabled:opacity-50 transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-4 h-4" }),
              "Restart Onboarding Flow"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: async () => {
              await chrome.storage.local.remove("userConsent");
              showMessage("success", "Consent reset. Reload the extension.");
              window.location.reload();
            },
            disabled: loading,
            className: "w-full flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-amber-700 bg-white border border-amber-300 rounded-lg hover:bg-amber-100 disabled:opacity-50 transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-4 h-4" }),
              "Reset Consent Dialog"
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-amber-600 mt-2", children: "Use these to test the first-run experience without clearing all data." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-lg border border-red-200 p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-medium text-red-900 mb-3", children: "Danger Zone" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: clearAnswersOnly,
            disabled: loading,
            className: "w-full flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-red-700 bg-red-50 border border-red-200 rounded-lg hover:bg-red-100 disabled:opacity-50 transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4" }),
              "Delete All Saved Answers"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: clearAllData,
            disabled: loading,
            className: "w-full flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium text-white bg-red-600 rounded-lg hover:bg-red-700 disabled:opacity-50 transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-4 h-4" }),
              "Clear All Data"
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-red-600 mt-2", children: "This will permanently delete saved data and cannot be undone." })
    ] })
  ] });
}
function ChatUI({ chatMessages, chatLoading, chatInput, setChatInput, sendChatMessage, clearChat, placeholder }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    chatMessages.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-lg border border-blue-200 p-2 mb-3 max-h-48 overflow-y-auto", children: [
      chatMessages.map((msg, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `text-xs p-2 rounded mb-1 ${msg.role === "user" ? "bg-blue-100 text-blue-800 ml-4" : "bg-gray-100 text-gray-800 mr-4"}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-medium", children: [
          msg.role === "user" ? "You" : "AI",
          ":"
        ] }),
        " ",
        msg.content
      ] }, idx)),
      chatLoading && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs text-blue-600 p-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-3 h-3 animate-spin" }),
        "Waiting for response..."
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "text",
          value: chatInput,
          onChange: (e) => setChatInput(e.target.value),
          onKeyDown: (e) => e.key === "Enter" && sendChatMessage(),
          placeholder,
          disabled: chatLoading,
          className: "flex-1 px-3 py-2 text-sm border border-blue-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:opacity-50"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: sendChatMessage,
          disabled: chatLoading || !chatInput.trim(),
          className: "px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "w-4 h-4" })
        }
      )
    ] }),
    chatMessages.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: clearChat,
        className: "mt-2 text-xs text-blue-600 hover:text-blue-800",
        children: "Clear chat"
      }
    )
  ] });
}

const PRIVACY_POLICY_URL = "https://www.onefil.help/privacy";
function ConsentModal({ onConsent, onDecline }) {
  const [llmDataSharing, setLlmDataSharing] = reactExports.useState(false);
  const [acknowledgedPolicy, setAcknowledgedPolicy] = reactExports.useState(false);
  const [saving, setSaving] = reactExports.useState(false);
  async function handleAccept() {
    if (!acknowledgedPolicy) return;
    setSaving(true);
    try {
      const preferences = createConsentPreferences({
        dataCollection: true,
        llmDataSharing,
        acknowledgedPrivacyPolicy: acknowledgedPolicy
      });
      await setConsentState(preferences);
      onConsent();
    } catch (error) {
      console.error("Failed to save consent:", error);
    } finally {
      setSaving(false);
    }
  }
  function handleDecline() {
    onDecline();
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-2xl shadow-2xl max-w-md w-full overflow-hidden", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-5 text-white", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "w-6 h-6" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-bold", children: t("consent.title") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-blue-100 text-sm", children: t("consent.subtitle") })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-6 py-5 space-y-5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Database, { className: "w-5 h-5 text-green-600" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold text-gray-900", children: t("consent.localStorage.title") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-600 mt-1", children: t("consent.localStorage.desc") })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-3 p-3 bg-gray-50 rounded-lg", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Brain, { className: "w-5 h-5 text-purple-600" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold text-gray-900", children: t("consent.ai.title") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              "button",
              {
                onClick: () => setLlmDataSharing(!llmDataSharing),
                className: `relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${llmDataSharing ? "bg-purple-600" : "bg-gray-300"}`,
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "span",
                  {
                    className: `inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${llmDataSharing ? "translate-x-6" : "translate-x-1"}`
                  }
                )
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-600 mt-1", children: t("consent.ai.desc") })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-start gap-3 cursor-pointer", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-0.5", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "checkbox",
            checked: acknowledgedPolicy,
            onChange: (e) => setAcknowledgedPolicy(e.target.checked),
            className: "w-5 h-5 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-sm text-gray-700", children: [
          t("consent.policyAck"),
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "a",
            {
              href: PRIVACY_POLICY_URL,
              target: "_blank",
              rel: "noopener noreferrer",
              className: "text-blue-600 hover:underline inline-flex items-center gap-1",
              children: [
                t("consent.privacyPolicy"),
                /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
              ]
            }
          )
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-6 py-4 bg-gray-50 border-t border-gray-100 flex gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          onClick: handleDecline,
          className: "flex-1 px-4 py-2.5 text-gray-700 font-medium rounded-lg hover:bg-gray-200 transition-colors flex items-center justify-center gap-2",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" }),
            t("consent.decline")
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          onClick: handleAccept,
          disabled: !acknowledgedPolicy || saving,
          className: `flex-1 px-4 py-2.5 font-medium rounded-lg transition-colors flex items-center justify-center gap-2 ${acknowledgedPolicy && !saving ? "bg-blue-600 text-white hover:bg-blue-700" : "bg-gray-300 text-gray-500 cursor-not-allowed"}`,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-4 h-4" }),
            saving ? t("consent.saving") : t("consent.accept")
          ]
        }
      )
    ] })
  ] }) });
}

const DEFAULT_INPUTS = [
  { label: "Full Name", value: "John Smith" },
  { label: "Email", value: "john.smith@example.com" }
];
function FillDemo({
  autoPlay = false,
  showControls = true,
  compact = false,
  inputs = DEFAULT_INPUTS,
  onComplete
}) {
  const [animationConfig, setAnimationConfig] = reactExports.useState(DEFAULT_FILL_ANIMATION_CONFIG);
  const [animationStage, setAnimationStage] = reactExports.useState("idle");
  const [demoInputs, setDemoInputs] = reactExports.useState(
    inputs.map((i) => ({ label: i.label, targetValue: i.value, currentValue: "" }))
  );
  const [currentFieldIndex, setCurrentFieldIndex] = reactExports.useState(0);
  const [animationProgress, setAnimationProgress] = reactExports.useState(0);
  const [isPlaying, setIsPlaying] = reactExports.useState(false);
  reactExports.useEffect(() => {
    loadAnimationConfig();
  }, []);
  reactExports.useEffect(() => {
    if (autoPlay && !isPlaying && animationStage === "idle") {
      const timer = setTimeout(() => playAnimation(), 500);
      return () => clearTimeout(timer);
    }
  }, [autoPlay, animationStage]);
  async function loadAnimationConfig() {
    try {
      const result = await chrome.storage.local.get("fillAnimationConfig");
      if (result.fillAnimationConfig) {
        setAnimationConfig({ ...DEFAULT_FILL_ANIMATION_CONFIG, ...result.fillAnimationConfig });
      }
    } catch {
    }
  }
  function calculateCharDelay() {
    const totalChars = demoInputs.reduce((sum, input) => sum + input.targetValue.length, 0);
    const totalFields = demoInputs.length;
    const stageTime = animationConfig.stageDelays.scanning + animationConfig.stageDelays.thinking;
    const fieldDelayTime = totalFields * animationConfig.fieldDelay;
    const availableTime = animationConfig.maxDuration * 1e3 - stageTime - fieldDelayTime;
    if (totalChars === 0) return animationConfig.minCharDelay;
    const calculatedDelay = availableTime / totalChars;
    return Math.max(animationConfig.minCharDelay, Math.min(animationConfig.maxCharDelay, calculatedDelay));
  }
  async function playAnimation() {
    if (isPlaying) return;
    setIsPlaying(true);
    setDemoInputs((prev) => prev.map((input) => ({ ...input, currentValue: "" })));
    setCurrentFieldIndex(0);
    setAnimationProgress(0);
    const charDelay = calculateCharDelay();
    try {
      setAnimationStage("scanning");
      setAnimationProgress(5);
      await new Promise((r) => setTimeout(r, animationConfig.stageDelays.scanning));
      setAnimationStage("thinking");
      setAnimationProgress(15);
      await new Promise((r) => setTimeout(r, animationConfig.stageDelays.thinking));
      setAnimationStage("filling");
      const totalChars = demoInputs.reduce((sum, input) => sum + input.targetValue.length, 0);
      let charsFilled = 0;
      for (let fieldIdx = 0; fieldIdx < demoInputs.length; fieldIdx++) {
        setCurrentFieldIndex(fieldIdx);
        const targetValue = demoInputs[fieldIdx].targetValue;
        for (let charIdx = 0; charIdx <= targetValue.length; charIdx++) {
          const partialValue = targetValue.substring(0, charIdx);
          setDemoInputs((prev) => prev.map(
            (input, idx) => idx === fieldIdx ? { ...input, currentValue: partialValue } : input
          ));
          charsFilled++;
          const progress = 20 + charsFilled / totalChars * 75;
          setAnimationProgress(Math.min(95, progress));
          if (charIdx < targetValue.length) {
            await new Promise((r) => setTimeout(r, charDelay));
          }
        }
        if (fieldIdx < demoInputs.length - 1) {
          await new Promise((r) => setTimeout(r, animationConfig.fieldDelay));
        }
      }
      setAnimationStage("done");
      setAnimationProgress(100);
      await new Promise((r) => setTimeout(r, 1500));
      onComplete?.();
      setAnimationStage("idle");
    } finally {
      setIsPlaying(false);
    }
  }
  function resetDemo() {
    setAnimationStage("idle");
    setDemoInputs((prev) => prev.map((input) => ({ ...input, currentValue: "" })));
    setCurrentFieldIndex(0);
    setAnimationProgress(0);
    setIsPlaying(false);
  }
  const stageEmoji = {
    idle: "⏸️",
    scanning: "🔍",
    thinking: "🧠",
    filling: "✍️",
    done: "✨"
  }[animationStage];
  const stageText = {
    idle: "Ready",
    scanning: "Scanning...",
    thinking: "Thinking...",
    filling: `Filling: ${demoInputs[currentFieldIndex]?.label || ""}`,
    done: "Complete!"
  }[animationStage];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `bg-gradient-to-br from-indigo-900 to-purple-900 rounded-xl ${compact ? "p-3" : "p-4"}`, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex items-center justify-center gap-2 ${compact ? "mb-2" : "mb-3"}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: compact ? "text-base" : "text-lg", children: stageEmoji }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-white font-medium ${compact ? "text-sm" : ""}`, children: stageText })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `h-1.5 bg-white/20 rounded-full overflow-hidden ${compact ? "mb-3" : "mb-4"}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "h-full bg-gradient-to-r from-indigo-400 to-purple-400 transition-all duration-100",
        style: { width: `${animationProgress}%` }
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: compact ? "space-y-2" : "space-y-3", children: demoInputs.map((input, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: `text-indigo-200 mb-1 block ${compact ? "text-[10px]" : "text-xs"}`, children: input.label }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `relative bg-white rounded-lg overflow-hidden ${animationStage === "filling" && currentFieldIndex === idx ? "ring-2 ring-indigo-400" : ""}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            value: input.currentValue,
            readOnly: true,
            placeholder: input.targetValue,
            className: `w-full text-gray-800 bg-transparent outline-none ${compact ? "px-2 py-1.5 text-xs" : "px-3 py-2 text-sm"}`
          }
        ),
        animationStage === "filling" && currentFieldIndex === idx && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute right-2 top-1/2 -translate-y-1/2 w-0.5 h-4 bg-indigo-600 animate-pulse" })
      ] })
    ] }, idx)) }),
    showControls && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex gap-2 ${compact ? "pt-2" : "pt-3"}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          onClick: playAnimation,
          disabled: isPlaying,
          className: `flex-1 flex items-center justify-center gap-2 font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 disabled:opacity-50 transition-colors ${compact ? "px-2 py-1.5 text-xs" : "px-3 py-2 text-sm"}`,
          children: [
            isPlaying ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: `animate-spin ${compact ? "w-3 h-3" : "w-4 h-4"}` }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Play, { className: compact ? "w-3 h-3" : "w-4 h-4" }),
            isPlaying ? "Playing..." : "Play"
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: resetDemo,
          disabled: isPlaying,
          className: `flex items-center justify-center gap-2 font-medium text-indigo-200 bg-white/10 rounded-lg hover:bg-white/20 disabled:opacity-50 transition-colors ${compact ? "px-2 py-1.5 text-xs" : "px-3 py-2 text-sm"}`,
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: compact ? "w-3 h-3" : "w-4 h-4" })
        }
      )
    ] })
  ] });
}

function PrivacyBadge({ variant = "local" }) {
  if (variant === "ai-optional") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 p-2 bg-amber-50 border border-amber-200 rounded-lg mt-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Shield, { className: "w-4 h-4 text-amber-600 flex-shrink-0" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-amber-700", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Privacy:" }),
        " AI processing is optional. You can choose local-only processing."
      ] })
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 p-2 bg-green-50 border border-green-200 rounded-lg mt-3", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-4 h-4 text-green-600 flex-shrink-0" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-green-700", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Privacy:" }),
      " All data is stored locally on your device. Nothing is sent to any server."
    ] })
  ] });
}
function Onboarding({ onComplete, onSkip }) {
  const [step, setStep] = reactExports.useState("welcome");
  const [linkedinDone, setLinkedinDone] = reactExports.useState(false);
  const [resumeDone, setResumeDone] = reactExports.useState(false);
  const [practiceDone, setPracticeDone] = reactExports.useState(false);
  const steps = ["welcome", "linkedin", "resume", "practice", "features"];
  const currentIndex = steps.indexOf(step);
  const progress = currentIndex / (steps.length - 1) * 100;
  function nextStep() {
    const next = steps[currentIndex + 1];
    if (next) setStep(next);
    else onComplete();
  }
  function prevStep() {
    const prev = steps[currentIndex - 1];
    if (prev) setStep(prev);
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen bg-gradient-to-b from-blue-50 to-white p-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-center mb-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-gray-500", children: "Setup Progress" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: onSkip, className: "text-xs text-gray-400 hover:text-gray-600", children: "Skip for now" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-1.5 bg-gray-200 rounded-full overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: "h-full bg-blue-500 transition-all duration-300",
          style: { width: `${progress}%` }
        }
      ) })
    ] }),
    step === "welcome" && /* @__PURE__ */ jsxRuntimeExports.jsx(WelcomeStep, { onNext: nextStep }),
    step === "linkedin" && /* @__PURE__ */ jsxRuntimeExports.jsx(
      LinkedInStep,
      {
        done: linkedinDone,
        onDone: () => setLinkedinDone(true),
        onNext: nextStep,
        onBack: prevStep
      }
    ),
    step === "resume" && /* @__PURE__ */ jsxRuntimeExports.jsx(
      ResumeStep,
      {
        done: resumeDone,
        onDone: () => setResumeDone(true),
        onNext: nextStep,
        onBack: prevStep
      }
    ),
    step === "practice" && /* @__PURE__ */ jsxRuntimeExports.jsx(
      PracticeStep,
      {
        done: practiceDone,
        onDone: () => setPracticeDone(true),
        onNext: nextStep,
        onBack: prevStep
      }
    ),
    step === "features" && /* @__PURE__ */ jsxRuntimeExports.jsx(FeaturesStep, { onComplete, onBack: prevStep })
  ] });
}
function WelcomeStep({ onNext }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-14 h-14 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Zap, { className: "w-7 h-7 text-blue-600" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-bold text-gray-900", children: "Welcome to OneFillr!" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-600 mt-1", children: "Auto-fill job applications in seconds" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-left", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500 mb-2 text-center", children: "See how it works:" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(FillDemo, { autoPlay: true, compact: true, showControls: false })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-green-50 border border-green-200 rounded-xl p-3 text-left", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-medium text-green-800", children: "Your Privacy is Protected" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-green-700 mt-0.5", children: "All data stored locally. AI features are optional." })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        onClick: onNext,
        className: "w-full py-3 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700 transition-colors flex items-center justify-center gap-2",
        children: [
          "Get Started ",
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4" })
        ]
      }
    )
  ] });
}
function LinkedInStep({ done, onDone, onNext, onBack }) {
  const [status, setStatus] = reactExports.useState("idle");
  async function openLinkedIn() {
    chrome.tabs.create({ url: "https://www.linkedin.com/in/me/", active: true });
  }
  function handleParseClick() {
    setStatus("choosing");
  }
  async function parseProfile(withAI) {
    setStatus("parsing");
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) throw new Error("No active tab");
      const response = await chrome.tabs.sendMessage(tab.id, {
        action: "parseLinkedInProfile",
        useLLMCleaning: withAI
      });
      if (!response?.success) throw new Error(response?.error || "Failed");
      const { storage } = await __vitePreload(async () => { const { storage } = await Promise.resolve().then(() => index);return { storage }},true?void 0:void 0);
      const profile = response.profile;
      for (const answer of profile.singleAnswers) {
        const existing = await storage.answers.getByType(answer.type);
        if (!existing.some((e) => e.value.toLowerCase() === answer.value.toLowerCase())) {
          await storage.answers.save({
            id: `onboarding-${Date.now()}-${answer.type}`,
            type: answer.type,
            value: answer.value,
            display: answer.display || answer.value,
            aliases: [],
            sensitivity: "normal",
            autofillAllowed: true,
            createdAt: Date.now(),
            updatedAt: Date.now()
          });
        }
      }
      await storage.experiences.saveBatch(profile.experiences);
      setStatus("done");
      onDone();
    } catch (err) {
      console.error("LinkedIn parse error:", err);
      setStatus("error");
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Linkedin, { className: "w-6 h-6 text-blue-600" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-bold text-gray-900", children: "Import from LinkedIn" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-600 mt-1", children: "The fastest way to set up your profile" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-white rounded-xl p-4 space-y-3", children: status === "choosing" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-700 text-center font-medium", children: "Choose processing method:" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => parseProfile(false),
          className: "w-full p-3 border-2 border-green-200 rounded-xl hover:border-green-400 hover:bg-green-50/50 transition-colors text-left",
          children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2 bg-green-100 rounded-lg", children: /* @__PURE__ */ jsxRuntimeExports.jsx(HardDrive, { className: "w-5 h-5 text-green-600" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-gray-800", children: "Local Processing (Recommended)" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-green-700 mt-0.5", children: "All processing happens on your device. No data leaves your browser." })
            ] })
          ] })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => parseProfile(true),
          className: "w-full p-3 border-2 border-gray-200 rounded-xl hover:border-blue-400 hover:bg-blue-50/50 transition-colors text-left",
          children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2 bg-blue-100 rounded-lg", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-5 h-5 text-blue-600" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-gray-800", children: "AI-Enhanced Processing" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500 mt-0.5", children: "Better accuracy for names and dates." }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-amber-600 mt-1", children: "⚠️ Data will be sent to AI service (not stored or used for training)" })
            ] })
          ] })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => setStatus("idle"),
          className: "w-full py-2 text-sm text-gray-500 hover:text-gray-700",
          children: "Cancel"
        }
      )
    ] }) : !done && status !== "done" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 p-3 bg-gray-50 rounded-lg", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-bold", children: "1" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-700 flex-1", children: "Open your LinkedIn profile" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: openLinkedIn, className: "text-xs text-blue-600 hover:underline flex items-center gap-1", children: [
          "Open ",
          /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "w-3 h-3" })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 p-3 bg-gray-50 rounded-lg", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-6 h-6 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-xs font-bold", children: "2" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-700 flex-1", children: "Click Parse when page loaded" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: handleParseClick,
            disabled: status === "parsing",
            className: "px-3 py-1 text-xs bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50",
            children: status === "parsing" ? "Parsing..." : "Parse"
          }
        )
      ] }),
      status === "error" && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-red-600 text-center", children: "Failed to parse. Make sure you're on a LinkedIn profile page." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(PrivacyBadge, { variant: "ai-optional" })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 p-4 bg-green-50 rounded-lg", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-5 h-5 text-green-600" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-green-700 font-medium", children: "LinkedIn profile imported!" })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: onBack, className: "flex-1 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-600 hover:bg-gray-50 flex items-center justify-center gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-4 h-4" }),
        " Back"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: onNext, className: "flex-1 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-medium hover:bg-blue-700 flex items-center justify-center gap-1", children: [
        done ? "Continue" : "Skip",
        " ",
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4" })
      ] })
    ] })
  ] });
}
function ResumeStep({ done, onDone, onNext, onBack }) {
  const [status, setStatus] = reactExports.useState("idle");
  const [errorMsg, setErrorMsg] = reactExports.useState("");
  async function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setStatus("parsing");
    setErrorMsg("");
    try {
      const { resumeParser } = await __vitePreload(async () => { const { resumeParser } = await Promise.resolve().then(() => index$1);return { resumeParser }},true?void 0:void 0);
      const profile = await resumeParser.parse(file);
      const { storage } = await __vitePreload(async () => { const { storage } = await Promise.resolve().then(() => index);return { storage }},true?void 0:void 0);
      for (const answer of profile.singleAnswers) {
        const existing = await storage.answers.getByType(answer.type);
        if (!existing.some((e2) => e2.value.toLowerCase() === answer.value.toLowerCase())) {
          await storage.answers.save({
            id: `onboarding-resume-${Date.now()}-${answer.type}`,
            type: answer.type,
            value: answer.value,
            display: answer.display || answer.value,
            aliases: [],
            sensitivity: "normal",
            autofillAllowed: true,
            createdAt: Date.now(),
            updatedAt: Date.now()
          });
        }
      }
      await storage.experiences.saveBatch(profile.experiences);
      setStatus("done");
      onDone();
    } catch (err) {
      console.error("Resume parse error:", err);
      setStatus("error");
      setErrorMsg(err instanceof Error ? err.message : "Failed to parse resume");
    }
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "w-6 h-6 text-green-600" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-bold text-gray-900", children: "Upload Your Resume" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-600 mt-1", children: "We'll extract your information automatically" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-xl p-4", children: [
      !done && status !== "done" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block cursor-pointer", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border-2 border-dashed border-gray-200 rounded-xl p-6 text-center hover:border-green-400 hover:bg-green-50/50 transition-colors", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "w-10 h-10 text-gray-400 mx-auto mb-2" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-gray-700", children: status === "parsing" ? "Processing..." : "Click to upload" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500 mt-1", children: "PDF, Word, or Image" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "file",
              accept: ".pdf,.docx,.doc,.png,.jpg,.jpeg,.webp",
              onChange: handleFile,
              className: "hidden",
              disabled: status === "parsing"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(PrivacyBadge, {})
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 p-4 bg-green-50 rounded-lg", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-5 h-5 text-green-600" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-green-700 font-medium", children: "Resume imported!" })
      ] }),
      status === "error" && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-red-600 text-center mt-2", children: errorMsg })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: onBack, className: "flex-1 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-600 hover:bg-gray-50 flex items-center justify-center gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-4 h-4" }),
        " Back"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: onNext, className: "flex-1 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-medium hover:bg-blue-700 flex items-center justify-center gap-1", children: [
        done ? "Continue" : "Skip",
        " ",
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4" })
      ] })
    ] })
  ] });
}
function PracticeStep({ done, onDone, onNext, onBack }) {
  const [fields, setFields] = reactExports.useState({
    fullName: "",
    email: "",
    phone: "",
    city: ""
  });
  const [saved, setSaved] = reactExports.useState(false);
  async function handleSave() {
    const { storage } = await __vitePreload(async () => { const { storage } = await Promise.resolve().then(() => index);return { storage }},true?void 0:void 0);
    const mappings = [
      ["fullName", Taxonomy.FULL_NAME],
      ["email", Taxonomy.EMAIL],
      ["phone", Taxonomy.PHONE],
      ["city", Taxonomy.CITY]
    ];
    for (const [field, type] of mappings) {
      const value = fields[field].trim();
      if (!value) continue;
      const existing = await storage.answers.getByType(type);
      if (!existing.some((e) => e.value.toLowerCase() === value.toLowerCase())) {
        await storage.answers.save({
          id: `onboarding-practice-${Date.now()}-${type}`,
          type,
          value,
          display: value,
          aliases: [],
          sensitivity: "normal",
          autofillAllowed: true,
          createdAt: Date.now(),
          updatedAt: Date.now()
        });
      }
    }
    setSaved(true);
    onDone();
  }
  const hasInput = Object.values(fields).some((v) => v.trim());
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(RectangleEllipsis, { className: "w-6 h-6 text-purple-600" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-bold text-gray-900", children: "Quick Practice" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-600 mt-1", children: "Fill this form using your browser's autofill, then save" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-white rounded-xl p-4 space-y-3", children: !done && !saved ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs text-gray-500 mb-1 block", children: "Full Name" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            name: "name",
            autoComplete: "name",
            value: fields.fullName,
            onChange: (e) => setFields((f) => ({ ...f, fullName: e.target.value })),
            className: "w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent",
            placeholder: "Click and let browser autofill..."
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs text-gray-500 mb-1 block", children: "Email" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "email",
            name: "email",
            autoComplete: "email",
            value: fields.email,
            onChange: (e) => setFields((f) => ({ ...f, email: e.target.value })),
            className: "w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs text-gray-500 mb-1 block", children: "Phone" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "tel",
            name: "tel",
            autoComplete: "tel",
            value: fields.phone,
            onChange: (e) => setFields((f) => ({ ...f, phone: e.target.value })),
            className: "w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs text-gray-500 mb-1 block", children: "City" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            name: "address-level2",
            autoComplete: "address-level2",
            value: fields.city,
            onChange: (e) => setFields((f) => ({ ...f, city: e.target.value })),
            className: "w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          }
        )
      ] }),
      hasInput && /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: handleSave,
          className: "w-full py-2 bg-purple-600 text-white rounded-lg text-sm font-medium hover:bg-purple-700",
          children: "Save to OneFillr"
        }
      )
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 p-4 bg-green-50 rounded-lg", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-5 h-5 text-green-600" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-green-700 font-medium", children: "Data saved!" })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-400 text-center", children: "💡 Tip: Click a field and select from browser suggestions" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(PrivacyBadge, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: onBack, className: "flex-1 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-600 hover:bg-gray-50 flex items-center justify-center gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-4 h-4" }),
        " Back"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: onNext, className: "flex-1 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-medium hover:bg-blue-700 flex items-center justify-center gap-1", children: [
        done ? "Continue" : "Skip",
        " ",
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4" })
      ] })
    ] })
  ] });
}
function FeaturesStep({ onComplete, onBack }) {
  const features = [
    {
      icon: Database,
      color: "blue",
      title: "Local Knowledge",
      desc: "View and edit your saved answers"
    },
    {
      icon: Sparkles,
      color: "purple",
      title: "Smart Fill",
      desc: "Click Fill button on any job application"
    },
    {
      icon: Brain,
      color: "green",
      title: "Auto Learn",
      desc: "We learn from forms you fill manually"
    },
    {
      icon: Shield,
      color: "amber",
      title: "Privacy First",
      desc: "Your data stays on your device by default"
    }
  ];
  const colorMap = {
    blue: "bg-blue-50 text-blue-600",
    purple: "bg-purple-50 text-purple-600",
    green: "bg-green-50 text-green-600",
    amber: "bg-amber-50 text-amber-600"
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 rounded-xl flex items-center justify-center mx-auto mb-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-6 h-6 text-white" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-bold text-gray-900", children: "You're All Set!" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-600 mt-1", children: "Here's what you can do with OneFillr" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: features.map((f, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 p-3 bg-white rounded-xl", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-10 h-10 rounded-lg flex items-center justify-center ${colorMap[f.color]}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(f.icon, { className: "w-5 h-5" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-gray-800", children: f.title }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500", children: f.desc })
      ] })
    ] }, i)) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: onBack, className: "flex-1 py-2.5 border border-gray-200 rounded-xl text-sm text-gray-600 hover:bg-gray-50 flex items-center justify-center gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-4 h-4" }),
        " Back"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: onComplete, className: "flex-1 py-2.5 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-xl text-sm font-medium hover:opacity-90 flex items-center justify-center gap-1", children: [
        "Start Using ",
        /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-4 h-4" })
      ] })
    ] })
  ] });
}

function classNames(...classes) {
  return classes.filter(Boolean).join(" ");
}
function App() {
  const [devModeEnabled, setDevModeEnabled] = reactExports.useState(false);
  const [consentValid, setConsentValid] = reactExports.useState(null);
  const [onboardingComplete, setOnboardingComplete] = reactExports.useState(null);
  const [localeReady, setLocaleReady] = reactExports.useState(false);
  reactExports.useEffect(() => {
    async function init() {
      await initLocale();
      setLocaleReady(true);
      await loadDevSettings();
      await checkConsent();
      await checkOnboarding();
    }
    init();
    const handleStorageChange = (changes) => {
      if (changes.devSettings) {
        setDevModeEnabled(changes.devSettings.newValue?.devModeEnabled ?? false);
      }
      if (changes.userConsent) {
        checkConsent();
      }
      if (changes.onboardingComplete) {
        setOnboardingComplete(changes.onboardingComplete.newValue ?? false);
      }
    };
    chrome.storage.onChanged.addListener(handleStorageChange);
    return () => chrome.storage.onChanged.removeListener(handleStorageChange);
  }, []);
  async function loadDevSettings() {
    try {
      const result = await chrome.storage.local.get("devSettings");
      setDevModeEnabled(result.devSettings?.devModeEnabled ?? false);
    } catch {
      setDevModeEnabled(false);
    }
  }
  async function checkConsent() {
    const valid = await hasValidConsent();
    setConsentValid(valid);
  }
  async function checkOnboarding() {
    try {
      const result = await chrome.storage.local.get("onboardingComplete");
      setOnboardingComplete(result.onboardingComplete ?? false);
    } catch {
      setOnboardingComplete(false);
    }
  }
  function handleConsentAccepted() {
    setConsentValid(true);
  }
  function handleConsentDeclined() {
    window.close();
  }
  async function handleOnboardingComplete() {
    await chrome.storage.local.set({ onboardingComplete: true });
    setOnboardingComplete(true);
  }
  async function handleOnboardingSkip() {
    await chrome.storage.local.set({ onboardingComplete: true });
    setOnboardingComplete(true);
  }
  const baseTabs = [
    { name: t("tabs.localKnowledge"), icon: Database, component: SavedAnswers },
    { name: t("tabs.import"), icon: Upload, component: ImportProfile },
    { name: t("tabs.thisSite"), icon: Globe, component: ThisSite },
    { name: t("tabs.activity"), icon: Activity, component: ActivityLog },
    { name: t("tabs.settings"), icon: Settings$1, component: Settings }
  ];
  const devTab = { name: t("tabs.developer"), icon: CodeXml, component: Developer };
  const tabs = devModeEnabled ? [...baseTabs, devTab] : baseTabs;
  if (consentValid === null || onboardingComplete === null || !localeReady) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-white w-[360px] max-w-[360px] flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-gray-400 text-sm", children: "Loading..." }) });
  }
  if (!consentValid) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-white w-[360px] max-w-[360px]", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      ConsentModal,
      {
        onConsent: handleConsentAccepted,
        onDecline: handleConsentDeclined
      }
    ) });
  }
  if (!onboardingComplete) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-white w-[360px] max-w-[360px]", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      Onboarding,
      {
        onComplete: handleOnboardingComplete,
        onSkip: handleOnboardingSkip
      }
    ) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-h-screen bg-white w-[360px] max-w-[360px] overflow-x-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(dt.Group, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(dt.List, { className: "flex border-b border-gray-100 overflow-x-auto scrollbar-hide", children: tabs.map((tab) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      dt,
      {
        className: ({ selected }) => classNames(
          "flex-shrink-0 px-3 py-2.5 text-xs font-medium border-b-2 transition-colors whitespace-nowrap",
          "focus:outline-none",
          selected ? "text-blue-600 border-blue-600 bg-blue-50/50" : "text-gray-500 hover:text-gray-700 hover:bg-gray-50 border-transparent"
        ),
        children: tab.name
      },
      tab.name
    )) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(dt.Panels, { className: "max-h-[calc(100vh-45px)] overflow-y-auto custom-scrollbar", children: tabs.map((tab) => /* @__PURE__ */ jsxRuntimeExports.jsx(dt.Panel, { className: "p-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(tab.component, {}) }, tab.name)) })
  ] }) });
}

async function notifySidePanelState(isOpen) {
  const action = isOpen ? "sidePanelOpened" : "sidePanelClosed";
  try {
    chrome.runtime.sendMessage({ action });
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) {
      chrome.tabs.sendMessage(tab.id, { action });
    }
  } catch {
  }
}
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "closeSidePanel") {
    window.close();
  }
});
notifySidePanelState(true);
window.addEventListener("pagehide", () => notifySidePanelState(false));
client.createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(React.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(App, {}) })
);

export { __vitePreload as _, __viteBrowserExternal$1 as a, commonjsGlobal as c, getAugmentedNamespace as g, require$$0 as r };
//# sourceMappingURL=sidepanel.js.map
